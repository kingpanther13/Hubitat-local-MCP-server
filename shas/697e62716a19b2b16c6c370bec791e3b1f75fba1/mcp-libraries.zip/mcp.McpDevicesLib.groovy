library(name: "McpDevicesLib", namespace: "mcp", author: "kingpanther13", description: "Device tool implementations (list/get/attribute/events/command/update/delete) for the MCP Rule Server; #include'd by the main app. Gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")

def toolListDevices(detailed, offset, limit, filter = null, labelFilter = null, capabilityFilter = null, format = null, fields = null, cursor = null, scope = null, roomFilter = null, onlyOn = null, changedSince = null, attributeNames = null) {
    // Opt-in cursor pagination decodes onto the existing offset/limit mechanics. The
    // real range check against the filtered total happens further down (the
    // offset-exceeds early return) because we don't have the filtered count yet; pass
    // Integer.MAX_VALUE so the helper only does the parse + negative check.
    // cursor='' / null returns offset 0 exactly like every other paginated tool.
    if (cursor != null) {
        // Reject ambiguous combinations -- a caller passing both cursor and a non-default
        // offset is asking for two different starting points; pick one.
        if (offset != null && (offset as Integer) > 0) {
            throw new IllegalArgumentException("cursor and offset are mutually exclusive (got cursor=${cursor}, offset=${offset}); pick one")
        }
        offset = _parseListCursor(cursor, Integer.MAX_VALUE, "hub_list_devices")
        // Default page size in cursor mode so nextCursor arithmetic is deterministic.
        // Callers who want a different page size set limit explicitly (cursor still wins
        // on offset; limit just sizes the page).
        if (!limit || limit <= 0) limit = 50
    }
    // context format defaults to a 50-device page (same size cursor mode uses) so an
    // unpaginated call on a large hub stays token-cheap; limit is read at pagination time,
    // so defaulting here (before resolvedFormat exists) is safe.
    if (format == "context" && (!limit || limit <= 0)) limit = 50
    // Type/format validity for the state-filter args, BEFORE the scope='all' route below
    // (and called by the filter='virtual' route in the dispatch case): a malformed value
    // must be a -32602 on every path, never silently carried into a specialized listing.
    _validateListDeviceStateArgTypes(roomFilter, onlyOn, changedSince, attributeNames, format)
    // scope='all' lists EVERY hub device (not just MCP-authorized), tagging each mcpAuthorized
    // true/false so a caller who can't control a device sees it must be added to the MCP list.
    // Distinct lightweight path (plain endpoint maps, not Groovy device objects).
    if (scope != null && !(scope in ["authorized", "all"])) {
        throw new IllegalArgumentException("scope must be 'authorized' (default) or 'all' (got: '${scope}')")
    }
    if (scope == "all") {
        if (detailed) {
            throw new IllegalArgumentException("scope='all' does not support detailed=true (attributes/commands/currentStates require MCP-authorized devices); use scope='authorized' for detail.")
        }
        // The scope='all' records are lightweight endpoint maps with no room/attribute/
        // activity data, so none of the state-based filters (or the state-bearing context
        // format) can be evaluated for them.
        // onlyOn compares == true and roomFilter by truthiness: false / empty string are
        // the documented no-op values everywhere else (the filter='virtual' guard in the
        // dispatch case matches), so they must not become errors only under scope='all'.
        if (format == "context" || roomFilter || onlyOn == true || changedSince != null || attributeNames != null) {
            throw new IllegalArgumentException("scope='all' does not support format='context', roomFilter, onlyOn, changedSince, or attributeNames (those need MCP-authorized device state); use scope='authorized' (default).")
        }
        return _listAllHubDevices(offset, limit, labelFilter, capabilityFilter, format, cursor)
    }
    // Combine selected devices and MCP-managed child devices (virtual devices); childDevs
    // is kept separately for the mcpManaged flag below and passed through so the helper
    // does not re-read the child list from the hub.
    def childDevs = getChildDevices() ?: []
    def allDevices = _mcpVisibleDevices(childDevs)

    // Remaining validation for the classic args, BEFORE the empty-inventory early return
    // so a bad argument is a -32602 even on a hub with no authorized devices. Groovy
    // coercion would otherwise surface as MissingMethodException deep in the filter
    // logic rather than a clear -32602 error. (The state-filter arg types were already
    // validated above, before the scope='all' route.)
    if (labelFilter != null && !(labelFilter instanceof String)) {
        throw new IllegalArgumentException("labelFilter must be a string")
    }
    if (capabilityFilter != null && !(capabilityFilter instanceof String)) {
        throw new IllegalArgumentException("capabilityFilter must be a string")
    }
    if (fields != null && !(fields instanceof List)) {
        throw new IllegalArgumentException("fields must be an array")
    }
    def resolvedFormat = format ?: "summary"
    // attributeNames only shapes the context lines; on any other format it would be
    // silently ignored, and the caller would believe the projection applied. (Semantic
    // check, deliberately AFTER the scope='all' route so that route's own rejection
    // message wins for scope='all' callers.)
    if (attributeNames != null && resolvedFormat != "context") {
        throw new IllegalArgumentException("attributeNames applies only to format='context' (got format '${resolvedFormat}'); it would be silently ignored otherwise.")
    }
    // Re-parse changedSince to the Date the filter needs (validity was proven above).
    def changedSinceDate = changedSince != null ? _parseSinceArg(changedSince) : null

    if (!allDevices) {
        def emptyMsg = "No devices selected for MCP access and no MCP-managed virtual devices"
        // format='context' keeps its shape contract even on an empty install: a caller
        // reading `summary` must never get a bare devices-array shape instead.
        if (resolvedFormat == "context") {
            def header = _contextHeaderLines()
            header << "Devices: 0 of 0"
            def r = [mode: location.mode?.toString(), summary: (header + [emptyMsg]).join("\n"), count: 0, total: 0, message: emptyMsg]
            def hsm = _safeHsmStatus()
            if (hsm) r.hsmStatus = hsm
            return r
        }
        return [devices: [], message: emptyMsg, total: 0]
    }

    // Capture the full set BEFORE any filter narrows it. Consumed by the zero-match
    // typo-vs-absence diagnostics (capabilityFilterMatchedKnownCapability and
    // roomFilterMatchedKnownRoom) so a mistyped value can be distinguished from a
    // real-but-excluded one even when an earlier filter already emptied the set.
    def unfilteredDevices = allDevices

    def unfilteredTotal = allDevices.size()

    // Parse and apply server-side filter BEFORE pagination so limit/offset respect the filtered set.
    // Supported filters: null/"all" (default), "enabled", "disabled", "stale:<hours>" (e.g. "stale:24").
    // Filtering happens in-memory against device properties already loaded, no extra hub API calls.
    def filterType = null
    def staleMs = 0L
    if (filter && filter != "all") {
        if (filter == "enabled" || filter == "disabled") {
            filterType = filter
        } else if (filter.startsWith("stale:")) {
            def hoursStr = filter.substring(6).trim()
            def hours
            try {
                hours = hoursStr as Double
            } catch (Exception e) {
                throw new IllegalArgumentException("Invalid stale filter '${filter}'. Expected format: stale:<hours> (e.g. stale:24)")
            }
            if (hours <= 0) {
                throw new IllegalArgumentException("stale filter hours must be positive, got: ${hours}")
            }
            filterType = "stale"
            staleMs = (long)(hours * 3600000L)
        } else {
            throw new IllegalArgumentException("Invalid filter '${filter}'. Must be one of: all, enabled, disabled, stale:<hours>")
        }
    }

    if (filterType) {
        def nowMs = now()
        allDevices = allDevices.findAll { d ->
            switch (filterType) {
                case "enabled": return !isDeviceDisabled(d)
                case "disabled": return isDeviceDisabled(d)
                case "stale":
                    def la = safeLastActivity(d)
                    if (la == null) return true  // never-reported device counts as stale
                    return (nowMs - la.time) >= staleMs
                default: return true
            }
        }
    }

    // Apply labelFilter (case-insensitive substring match on device label)
    if (labelFilter) {
        def lf = labelFilter.toLowerCase()
        allDevices = allDevices.findAll { d ->
            def lbl = (d.label ?: d.name)?.toString()?.toLowerCase()
            lbl != null && lbl.contains(lf)
        }
    }

    // Apply capabilityFilter (case-insensitive exact match on capability name).
    if (capabilityFilter) {
        def cf = capabilityFilter.toLowerCase()
        allDevices = allDevices.findAll { d ->
            d.capabilities?.any { cap -> cap.name?.toLowerCase() == cf }
        }
    }

    // Apply roomFilter (case-insensitive exact match on the device's assigned room).
    if (roomFilter) {
        allDevices = allDevices.findAll { d -> d.roomName?.toString()?.equalsIgnoreCase(roomFilter) }
    }

    // onlyOn keeps devices whose switch attribute currently reads "on" -- "what's on right
    // now" in one call. onlyOn=false is a no-op (not "only off"): absence of the filter.
    if (onlyOn == true) {
        allDevices = allDevices.findAll { d -> d.currentValue("switch")?.toString() == "on" }
    }

    // changedSince keeps devices ACTIVE since the timestamp -- the inverse of filter=stale:N.
    // A device with no readable lastActivity is excluded here (it cannot prove it changed),
    // where stale:N KEEPS the same device (counts it stale) -- both treat unproven as
    // not-recently-active, which lands on opposite sides of inclusion.
    if (changedSinceDate != null) {
        allDevices = allDevices.findAll { d ->
            def la = safeLastActivity(d)
            la != null && la.time >= changedSinceDate.time
        }
    }

    def totalCount = allDevices.size()

    // Apply pagination (post-filter)
    def startIndex = offset ?: 0
    if (startIndex < 0) startIndex = 0
    def endIndex = totalCount
    if (limit && limit > 0) {
        endIndex = Math.min(startIndex + limit, totalCount)
    }

    // Shared filter-echo block for every result shape (summary/detailed/ids/context and the
    // early returns): echo each active filter, report unfilteredTotal when anything narrowed
    // the set, and attach the zero-match typo-vs-absence diagnostics.
    def anyFilterActive = (filter && filter != "all") || labelFilter || capabilityFilter ||
        roomFilter || (onlyOn == true) || changedSinceDate != null
    def applyFilterEchoes = { Map r ->
        if (filter && filter != "all") r.filter = filter
        if (anyFilterActive) r.unfilteredTotal = unfilteredTotal
        if (labelFilter) r.labelFilter = labelFilter
        if (capabilityFilter) r.capabilityFilter = capabilityFilter
        if (roomFilter) r.roomFilter = roomFilter
        if (onlyOn == true) r.onlyOn = true
        if (changedSinceDate != null) {
            // Epoch-ms input echoes as canonical ISO (same policy as _resolveSinceWindow) so
            // the echo always satisfies the string-typed outputSchema field.
            r.changedSince = (changedSince instanceof Number || changedSince.toString().trim().isLong()) ?
                changedSinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ") : changedSince.toString().trim()
        }
        if (capabilityFilter && totalCount == 0) {
            def allCaps = unfilteredDevices.collectMany { d -> d.capabilities?.collect { cap -> cap.name?.toLowerCase() } ?: [] } as Set
            r.capabilityFilterMatchedKnownCapability = allCaps.contains(capabilityFilter.toLowerCase())
        }
        if (roomFilter && totalCount == 0) {
            def allRooms = unfilteredDevices.collect { d -> d.roomName?.toString()?.toLowerCase() }.findAll { it != null } as Set
            r.roomFilterMatchedKnownRoom = allRooms.contains(roomFilter.toLowerCase())
        }
        return r
    }

    // Validate offset (after the argument validation above, so callers always get the
    // format/type errors first). Every branch keeps its format's shape contract and the
    // shared filter echoes.
    if (totalCount > 0 && startIndex >= totalCount) {
        def offsetMsg = "Offset ${startIndex} exceeds filtered device count ${totalCount}".toString()
        if (resolvedFormat == "ids") {
            return applyFilterEchoes([deviceIds: [], count: 0, total: totalCount, hasMore: false, nextOffset: null])
        }
        if (resolvedFormat == "context") {
            def header = _contextHeaderLines()
            header << "Devices: 0 of ${totalCount}".toString()
            def r = applyFilterEchoes([mode: location.mode?.toString(), summary: (header + [offsetMsg]).join("\n"), count: 0, total: totalCount, message: offsetMsg])
            def hsm = _safeHsmStatus()
            if (hsm) r.hsmStatus = hsm
            r.offset = startIndex
            r.limit = limit ?: 0
            return r
        }
        def r = applyFilterEchoes([devices: [], total: totalCount, offset: startIndex, limit: limit ?: 0, message: offsetMsg])
        // Preserve this branch's historical unconditional echoes alongside the shared block.
        if (!r.containsKey("filter")) r.filter = filter ?: "all"
        if (!r.containsKey("unfilteredTotal")) r.unfilteredTotal = unfilteredTotal
        return r
    }

    // format="ids" returns a flat array of integer IDs; ignores detailed/fields
    if (resolvedFormat == "ids") {
        def pagedDevices = totalCount > 0 ? allDevices.subList(startIndex, endIndex) : []
        def ids = pagedDevices.collect { it.id as Integer }
        def result = applyFilterEchoes([deviceIds: ids, count: ids.size(), total: totalCount])
        if (limit && limit > 0) {
            result.offset = startIndex
            result.limit = limit
            result.hasMore = endIndex < totalCount
            if (endIndex < totalCount) result.nextOffset = endIndex
            // Cursor mode also emits nextCursor (opaque string) alongside nextOffset so a
            // client iterating cursor sees the same shape used by other paginated tools.
            if (cursor != null && endIndex < totalCount) result.nextCursor = endIndex.toString()
        }
        return result
    }

    // format="context" (issue #366): a token-cheap plain-text house snapshot -- mode + one
    // line per device ("Label (id, room) - capabilities; attr=value, ...") with the
    // standard filters and pagination applied. Unit-suffixed values (72.5°F) keep each
    // line compact and unambiguous for a model reader. The summary string is
    // self-contained (header + lines) so a client can drop it straight into model
    // context; structured fields ride alongside for chaining. Ignores detailed/fields
    // like format='ids'.
    if (resolvedFormat == "context") {
        def pagedDevices = totalCount > 0 ? allDevices.subList(startIndex, endIndex) : []
        def attrNames = (attributeNames && !attributeNames.isEmpty()) ? attributeNames.collect { it.toString() } : _contextAttributeNames()
        def lines = pagedDevices.collect { d -> _contextDeviceLine(d, attrNames) }
        def header = _contextHeaderLines()
        def hsm = _safeHsmStatus()
        def deviceLine = "Devices: ${lines.size()} of ${totalCount}"
        if (endIndex < totalCount) deviceLine += " (nextCursor=${endIndex} -- pass cursor:'${endIndex}' for the next page)"
        header << deviceLine.toString()
        def result = applyFilterEchoes([
            mode: location.mode?.toString(),
            summary: (header + lines).join("\n"),
            count: lines.size(),
            total: totalCount
        ])
        if (hsm) result.hsmStatus = hsm
        // Typo-vs-absence for the projection, mirroring roomFilter/capabilityFilter: an
        // explicit attributeNames that matched nothing on any line would otherwise be
        // indistinguishable from genuinely attribute-less devices.
        if (attributeNames && !attributeNames.isEmpty() && lines.size() > 0 && lines.every { !it.contains("; ") }) {
            result.attributeNamesMatchedNoAttributes = true
        }
        if (limit && limit > 0) {
            result.offset = startIndex
            result.limit = limit
            result.hasMore = endIndex < totalCount
            if (endIndex < totalCount) {
                result.nextOffset = endIndex
                result.nextCursor = endIndex.toString()
            }
        }
        return result
    }

    def pagedDevices = totalCount > 0 ? allDevices.subList(startIndex, endIndex) : []
    def childDeviceIds = childDevs.collect { it.id.toString() } as Set

    // Build the requested field set. null/empty means "all fields for this format mode".
    def fieldSet = (fields && !fields.isEmpty()) ? (fields as Set) : null

    // Validate field names against the documented whitelist. Unknown names would silently
    // produce empty device objects (a typo gives {id: '1'} instead of {id: '1', label: 'X'})
    // -- catching it here gives the caller a recoverable -32602 instead of bad data.
    if (fieldSet) {
        def validFieldNames = ["id", "name", "label", "room", "disabled", "deviceNetworkId",
            "lastActivity", "parentDeviceId", "mcpManaged", "currentStates",
            "capabilities", "attributes", "commands"] as Set
        def unknownFields = fieldSet - validFieldNames
        if (unknownFields) {
            throw new IllegalArgumentException("Unknown fields: ${unknownFields.sort()}. Valid: ${validFieldNames.sort()}")
        }
    }

    // Resolve whether to use detailed mode: explicit format="detailed", detailed=true, or any
    // detail-only field requested via the fields projection (capabilities, attributes, commands).
    // Auto-promote so fields=['id','capabilities'] works without requiring detailed=true.
    def detailFields = ['capabilities', 'attributes', 'commands'] as Set
    def useDetailed = (resolvedFormat == "detailed") || detailed ||
        (fieldSet != null && fieldSet.any { detailFields.contains(it) })

    def devices = pagedDevices.collect { device ->
        def deviceIdStr = device.id.toString()

        // Per-field gating avoids calling expensive hub APIs (currentValue, supportedAttributes,
        // supportedCommands) for omitted fields. id is always emitted -- without it callers
        // get a list of objects with no correlation key; use format='ids' for id-only results.
        def info = [:]

        info.id = deviceIdStr
        if (fieldSet == null || fieldSet.contains("name")) info.name = device.name
        if (fieldSet == null || fieldSet.contains("label")) info.label = device.label ?: device.name
        if (fieldSet == null || fieldSet.contains("room")) info.room = device.roomName
        if (fieldSet == null || fieldSet.contains("disabled")) info.disabled = isDeviceDisabled(device)
        if (fieldSet == null || fieldSet.contains("deviceNetworkId")) info.deviceNetworkId = safeDni(device)
        if (fieldSet == null || fieldSet.contains("lastActivity")) info.lastActivity = formatLastActivity(safeLastActivity(device))
        if (fieldSet == null || fieldSet.contains("parentDeviceId")) info.parentDeviceId = safeParentDeviceId(device)

        if (childDeviceIds.contains(deviceIdStr)) {
            if (fieldSet == null || fieldSet.contains("mcpManaged")) info.mcpManaged = true
        }

        if (useDetailed) {
            if (fieldSet == null || fieldSet.contains("capabilities")) {
                info.capabilities = device.capabilities?.collect { it.name }
            }
            if (fieldSet == null || fieldSet.contains("attributes")) {
                info.attributes = device.supportedAttributes?.collect { attr ->
                    [name: attr.name, value: device.currentValue(attr.name)]
                }
            }
            if (fieldSet == null || fieldSet.contains("commands")) {
                info.commands = device.supportedCommands?.collect { it.name }
            }
        } else {
            // Summary mode: populate currentStates only when requested (or when no projection active)
            if (fieldSet == null || fieldSet.contains("currentStates")) {
                info.currentStates = [:]
                ["switch", "level", "motion", "contact", "temperature", "humidity", "battery"].each { attr ->
                    def val = device.currentValue(attr)
                    if (val != null) info.currentStates[attr] = val
                }
            }
        }

        return info
    }

    def result = applyFilterEchoes([
        devices: devices,
        count: devices.size(),
        total: totalCount
    ])

    // Include pagination info if pagination was used
    if (limit && limit > 0) {
        result.offset = startIndex
        result.limit = limit
        result.hasMore = endIndex < totalCount
        if (endIndex < totalCount) {
            result.nextOffset = endIndex
        }
        if (cursor != null && endIndex < totalCount) result.nextCursor = endIndex.toString()
    }

    return result
}

private Boolean isDeviceDisabled(device) {
    try {
        if (device.hasProperty("disabled") && device.disabled != null) return device.disabled == true
    } catch (Exception ignore) {}
    try {
        return device.isDisabled() == true
    } catch (Exception ignore) {}
    try {
        if (device.hasProperty("status") && device.status?.toString()?.toLowerCase() == "disabled") return true
    } catch (Exception ignore) {}
    return false
}

private String safeDni(device) {
    try {
        return device.deviceNetworkId?.toString()
    } catch (Exception ignore) {
        return null
    }
}

private String safeParentDeviceId(device) {
    try {
        return device.parentDeviceId?.toString()
    } catch (Exception ignore) {
        return null
    }
}

private Date safeLastActivity(device) {
    try {
        return device.getLastActivity()
    } catch (Exception ignore) {
        return null
    }
}

private String formatLastActivity(Date d) {
    if (d == null) return null
    try {
        return d.format("yyyy-MM-dd'T'HH:mm:ssXXX")
    } catch (Exception ignore) {
        return d.toString()
    }
}

// Type/format validity for the issue-#366 state-filter args, shared by toolListDevices
// (before its scope='all' route) and the filter='virtual' route in the dispatch case --
// every path must reject a malformed value with -32602 instead of silently ignoring it.
def _validateListDeviceStateArgTypes(roomFilter, onlyOn, changedSince, attributeNames, format) {
    if (roomFilter != null && !(roomFilter instanceof String)) {
        throw new IllegalArgumentException("roomFilter must be a string")
    }
    if (onlyOn != null && !(onlyOn instanceof Boolean)) {
        throw new IllegalArgumentException("onlyOn must be a boolean")
    }
    if (attributeNames != null && (!(attributeNames instanceof List) || attributeNames.any { !(it instanceof String) })) {
        throw new IllegalArgumentException("attributeNames must be an array of attribute-name strings")
    }
    if (format && !["summary", "detailed", "ids", "context"].contains(format)) {
        throw new IllegalArgumentException("Invalid format '${format}'. Must be one of: summary, detailed, ids, context")
    }
    if (changedSince != null && _parseSinceArg(changedSince) == null) {
        throw new IllegalArgumentException("Unparseable changedSince '${changedSince}'. Pass epoch milliseconds or ISO-8601 with a numeric offset (e.g. 2026-06-23T10:00:00-0600 or -06:00; trailing Z accepted).")
    }
}

// Default attribute set for format='context' lines when the caller passes no attributeNames.
// The common state-bearing attributes an LLM needs to answer "what's going on in the house";
// a device reports only the ones it has, so unused entries cost nothing per device.
private List _contextAttributeNames() {
    ["switch", "level", "motion", "contact", "presence", "lock", "temperature", "humidity",
     "illuminance", "battery", "power", "energy", "thermostatMode", "thermostatOperatingState",
     "heatingSetpoint", "coolingSetpoint", "speed", "position", "valve", "water", "smoke"]
}

// The "Mode:" (+ optional "HSM:") header lines every context-format result leads with;
// each call site appends its own "Devices: N of M" line. A null mode renders as
// "unknown" -- the literal "Mode: null" would read as a mode named null.
private List _contextHeaderLines() {
    def header = ["Mode: ${location.mode ?: 'unknown'}".toString()]
    def hsm = _safeHsmStatus()
    if (hsm) header << "HSM: ${hsm}".toString()
    return header
}

// One context-summary line: "- Label (id, room) - Cap1, Cap2; attr=value<unit>, ...".
// Reads the device's currentStates ONCE (the same per-device hub read summary mode pays;
// the saving vs per-attribute currentValue() calls is ~21 reads -> 1), then projects the
// requested attribute names in caller order. Values carry the reported unit directly
// appended (temperature=72.5°F) -- compact and unambiguous for a model reader.
private String _contextDeviceLine(device, List attrNames) {
    def states = [:]
    boolean stateReadFailed = false
    try {
        device.currentStates?.each { st ->
            if (st?.name != null && st.value != null) states[st.name.toString()] = st
        }
    } catch (Exception e) {
        // Serve the line rather than failing the whole snapshot, but a failed read must
        // be VISIBLE in the payload itself -- byte-identical to "reports nothing" would
        // invite the model to act on absent state. Logged too, for the operator.
        stateReadFailed = true
        mcpLog("warn", "device", "context snapshot: currentStates read failed for device ${device?.id}: ${e.message}")
    }
    def attrParts = []
    attrNames.each { an ->
        def st = states[an]
        if (st != null) {
            def unit = null
            // Per-attribute micro-read; a failure only drops the unit suffix, so no log.
            try { unit = st.unit } catch (Exception ignore) {}
            attrParts << "${an}=${st.value}${unit ?: ''}"
        }
    }
    def caps = device.capabilities?.collect { it.name }?.findAll { it != null } ?: []
    def line = "- ${device.label ?: device.name} (${device.id}, ${device.roomName ?: 'No room'})"
    if (caps) line += " - ${caps.join(', ')}"
    if (attrParts) line += "; ${attrParts.join(', ')}"
    if (stateReadFailed) line += " (state unavailable)"
    return line.toString()
}

// location.hsmStatus is a dynamic property (not on every firmware's Location model) --
// absent/unreadable degrades to "no HSM line" rather than throwing.
private String _safeHsmStatus() {
    try {
        return location.hsmStatus?.toString()
    } catch (Exception ignore) {
        return null
    }
}

// The MCP-visible device population: authorized devices plus this app's own child
// (virtual) devices, deduplicated by id. Shared by toolListDevices and the context
// resource builders so the populations cannot drift. Callers that already hold the
// child-device list pass it in to avoid a second getChildDevices() hub read.
private List _mcpVisibleDevices(List childDevs = null) {
    def all = (selectedDevices ?: []).toList()
    def ids = all.collect { it.id.toString() } as Set
    ((childDevs != null ? childDevs : getChildDevices()) ?: []).each { cd ->
        if (!ids.contains(cd.id.toString())) all.add(cd)
    }
    return all
}

// Budget for the unpaginated context RESOURCES (resources/read takes only a uri, so an
// oversized body would be permanently dead behind the outer -32603 guard with no
// narrower request to retry). Measured in ESCAPED-envelope characters via _escapedLen:
// the body rides inside the JSON-RPC envelope as a JSON string, where JsonOutput
// escapes quotes AND expands every non-ASCII character to a 6-char \\uXXXX sequence
// (escaped output is pure ASCII, so envelope chars == wire bytes). Budgeting the
// escaped form is what keeps a CJK/emoji-labelled inventory under the 124,000-byte
// wire guard, not just an ASCII one; 80,000 leaves ample envelope headroom.
def _contextResourceByteBudget() { 80000 }

// The cost of `s` once embedded in the serialized envelope: its JSON-escaped length
// minus the surrounding quotes JsonOutput adds.
private int _escapedLen(String s) { s == null ? 0 : groovy.json.JsonOutput.toJson(s).length() - 2 }

// The hubitat://context-summary resource body: the format='context' snapshot without
// cursor pagination, truncated at the resource byte budget with an explicit pointer at
// the paginated tool form. Shared with the tool path so resource and tool can never
// drift. The device limit is derived from the budget (shortest plausible line ~25
// bytes) so a pathological inventory bounds the per-device hub reads, not just the
// response size.
def _buildContextSummaryText() {
    int maxUseful = (int) (_contextResourceByteBudget() / 25)
    def res = toolListDevices(false, 0, maxUseful, null, null, null, "context", null, null, null, null, null, null, null)
    def total = (res.total ?: 0) as Integer
    return _truncateContextText(res.summary ?: res.message, total)
}

private String _truncateContextText(String text, int totalDevices) {
    int budget = _contextResourceByteBudget()
    if (text == null || _escapedLen(text) <= budget) return text
    def kept = []
    int size = 0
    int deviceLinesKept = 0
    // split("\n"), not readLines(): the established hub-safe idiom in this codebase.
    // Per-line cost is the ESCAPED length plus the escaped newline ("\\n" = 2 chars).
    for (ln in text.split("\n")) {
        int lnCost = _escapedLen(ln) + 2
        if (size + lnCost > budget) break
        kept << ln
        size += lnCost
        if (ln.startsWith("- ")) deviceLinesKept++
    }
    kept << "... truncated at ${deviceLinesKept} of ${totalDevices} devices (hub response-size cap). Use the hub_list_devices tool (format='context', cursor pagination) for the full inventory.".toString()
    return kept.join("\n")
}

// The hubitat://context resource body: the structured counterpart of the context summary
// -- current mode (+ HSM when available), the mode list, a rooms[] index with deviceIds,
// and one compact record per MCP-visible device (id, label, room, capabilities,
// attribute values). Attributes are projected through the same default set as the text
// form but carry RAW values with no unit suffix (the text form appends units): an
// unfiltered currentStates dump drags in driver-internal rows (e.g. tile-text
// attributes like "_1") that only add noise to a context snapshot -- verified live on a
// real inventory. The rooms index is capped at half the budget and device records stop
// at whatever remains (clamped non-negative); a truncated result says so on each axis
// and points at the paginated tool form / hub_list_rooms.
def _buildContextJson() {
    def allDevices = _mcpVisibleDevices()
    def contextAttrs = _contextAttributeNames() as Set
    def roomIndex = [:]
    allDevices.each { d ->
        def r = d.roomName?.toString() ?: "No room"
        if (!roomIndex.containsKey(r)) roomIndex[r] = []
        roomIndex[r] << d.id.toString()
    }
    // The rooms index scales with the inventory too, so it gets its own cap (half the
    // budget) -- on an extreme fleet it could exceed the whole budget by itself, and no
    // amount of device-record clamping would save the response.
    int roomsCap = (int) (_contextResourceByteBudget() / 2)
    int roomsUsed = 0
    boolean roomsTruncated = false
    def rooms = []
    for (entry in roomIndex.collect { name, ids -> [name: name, deviceIds: ids] }) {
        roomsUsed += _escapedLen(groovy.json.JsonOutput.toJson(entry))
        if (roomsUsed > roomsCap) {
            roomsTruncated = true
            break
        }
        rooms << entry
    }
    // Device records get whatever the budget leaves after the rooms index; all costs are
    // escaped-envelope characters (see _contextResourceByteBudget).
    int budget = Math.max(0, _contextResourceByteBudget() - roomsUsed - 1000)
    int used = 0
    boolean truncated = false
    def devices = []
    for (d in allDevices) {
        def attrs = [:]
        boolean stateReadFailed = false
        try {
            d.currentStates?.each { st ->
                if (st?.name != null && st.value != null && contextAttrs.contains(st.name.toString())) {
                    attrs[st.name.toString()] = st.value.toString()
                }
            }
        } catch (Exception e) {
            // Mirror the text form: mark the record in-band, not just in the log.
            stateReadFailed = true
            mcpLog("warn", "device", "context snapshot: currentStates read failed for device ${d?.id}: ${e.message}")
        }
        def rec = [id: d.id.toString(), label: d.label ?: d.name, room: d.roomName,
                   capabilities: d.capabilities?.collect { it.name }?.findAll { it != null } ?: [],
                   attributes: attrs]
        if (stateReadFailed) rec.stateUnavailable = true
        used += _escapedLen(groovy.json.JsonOutput.toJson(rec))
        if (used > budget) {
            truncated = true
            break
        }
        devices << rec
    }
    def result = [
        currentMode: location.mode?.toString(),
        modes: location.modes?.collect { it?.name?.toString() }?.findAll { it != null } ?: [],
        deviceCount: devices.size(),
        totalDevices: allDevices.size(),
        rooms: rooms,
        devices: devices
    ]
    if (truncated) {
        result.truncated = true
        result.note = "Device records truncated at ${devices.size()} of ${allDevices.size()} (hub response-size cap). Use the hub_list_devices tool (format='context', cursor pagination) for the full inventory.".toString()
    }
    if (roomsTruncated) {
        result.roomsTruncated = true
        result.note = "${result.note ?: ''} Rooms index truncated at ${rooms.size()} of ${roomIndex.size()} rooms (hub response-size cap); use hub_list_rooms for the full room list.".toString().trim()
    }
    def hsm = _safeHsmStatus()
    if (hsm) result.hsmStatus = hsm
    return result
}

// scope='all' implementation: every hub device + an mcpAuthorized flag. Sourced from the admin
// endpoint /device/listWithCapabilities/json (id/label/capabilities) -- the ONLY way the app sees
// devices it isn't granted; the Groovy device model is authorization-scoped. Lightweight uniform
// records (no attributes/commands/currentStates -- those need an MCP-authorized Groovy device).
// /hub2/devicesList nests child devices under their parent's `children`, and wraps each record
// as {key, data:{id,name,...}, children:[...]}. Flatten to the {id, label} shape the caller
// expects; `name` there is the user-facing label (the driver name is `secondaryName`).
private List _flattenHub2DeviceTree(nodes, List acc = null) {
    // A non-List at the TOP level means the contract moved -- return null so the caller
    // raises it, rather than an empty list that would read as "this hub has no devices".
    // Nested `children` legitimately arrive absent, so those recurse into the accumulator.
    if (!(nodes instanceof List)) return acc
    if (acc == null) acc = []
    nodes.each { node ->
        if (!(node instanceof Map)) return
        def data = node.data
        if (data instanceof Map && data.id != null) {
            acc << [id: data.id, label: data.name]
        }
        _flattenHub2DeviceTree(node.children, acc)
    }
    return acc
}

private Map _listAllHubDevices(offset, limit, labelFilter, capabilityFilter, format, cursor) {
    if (labelFilter != null && !(labelFilter instanceof String)) {
        throw new IllegalArgumentException("labelFilter must be a string")
    }
    if (capabilityFilter != null && !(capabilityFilter instanceof String)) {
        throw new IllegalArgumentException("capabilityFilter must be a string")
    }
    def resolvedFormat = format ?: "summary"
    if (format && !["summary", "ids"].contains(resolvedFormat)) {
        throw new IllegalArgumentException("scope='all' supports format 'summary' or 'ids' only (detailed/currentStates require MCP-authorized devices; got '${format}')")
    }
    // Two inventory sources, tried in order. /device/listWithCapabilities/json carried
    // capabilities for every device but is gone as of platform 2.5.1 (404). /hub2/devicesList
    // survives and is still a superset of the authorized set -- the point of scope='all' -- but
    // exposes no capabilities, so those are filled in from the Groovy model where the app has
    // access and left empty where it does not (an unauthorized device's capabilities are simply
    // not knowable from inside the sandbox).
    def raw = null
    def sourceEndpoint = "/device/listWithCapabilities/json"
    def capabilitiesComplete = true
    try {
        def txt = hubInternalGet("/device/listWithCapabilities/json")
        def parsed = new groovy.json.JsonSlurper().parseText(txt ?: "[]")
        if (parsed instanceof List) raw = parsed
    } catch (Exception e) {
        mcpLog("debug", "device", "hub_list_devices scope='all': /device/listWithCapabilities/json unavailable (${e.message}) -- falling back to /hub2/devicesList")
    }
    if (raw == null) {
        sourceEndpoint = "/hub2/devicesList"
        capabilitiesComplete = false
        try {
            def txt = hubInternalGet("/hub2/devicesList")
            def parsed = new groovy.json.JsonSlurper().parseText(txt ?: "{}")
            raw = _flattenHub2DeviceTree(parsed instanceof Map ? parsed.devices : null)
        } catch (Exception e) {
            mcpLog("warn", "device", "hub_list_devices scope='all': /hub2/devicesList fetch/parse failed: ${e.message}")
            return [success: false, error: "Failed to fetch the all-hub device list (${sourceEndpoint}): ${e.message}", note: "Endpoint may be unavailable on this firmware; use scope='authorized' (default)."]
        }
        if (!(raw instanceof List)) {
            mcpLog("warn", "device", "hub_list_devices scope='all': /hub2/devicesList returned an unexpected shape")
            return [success: false, error: "Unexpected /hub2/devicesList response (expected {devices:[...]}).", note: "Hub firmware may have changed the endpoint contract."]
        }
    }
    def authorizedIds = ((selectedDevices ?: []).collect { it.id?.toString() }.findAll { it != null } as Set)
    (getChildDevices() ?: []).each { def cid = it.id?.toString(); if (cid != null) authorizedIds.add(cid) }
    // Capability lookup for the fallback source, built once from the authorization-scoped model.
    def capsById = [:]
    if (!capabilitiesComplete) {
        (selectedDevices ?: []).each { dev ->
            def did = dev?.id?.toString()
            if (did != null) capsById[did] = (dev.capabilities ?: []).collect { it?.toString() }
        }
    }

    // Only process actual Map elements; a null/non-object element from a firmware contract drift
    // would otherwise NPE/ClassCast past the structured-error envelope. id is emitted as a String
    // to match the outputSchema and the scope='authorized' path.
    def devices = raw.findAll { it instanceof Map }.collect { d ->
        def idStr = d.id?.toString()
        def caps = (d.capabilities instanceof List) ? d.capabilities.collect { it?.toString() }
                                                   : (idStr != null ? (capsById[idStr] ?: []) : [])
        [id: idStr, label: d.label, capabilities: caps, mcpAuthorized: idStr != null && authorizedIds.contains(idStr)]
    }
    def unfilteredTotal = devices.size()
    if (labelFilter) {
        def lf = labelFilter.toLowerCase()
        devices = devices.findAll { (it.label ?: "").toString().toLowerCase().contains(lf) }
    }
    if (capabilityFilter) {
        def cf = capabilityFilter.toLowerCase()
        devices = devices.findAll { dev -> dev.capabilities.any { c -> c?.toLowerCase() == cf } }
    }
    def totalCount = devices.size()
    def startIndex = (offset && offset > 0) ? (offset as Integer) : 0
    if (startIndex > totalCount) startIndex = totalCount
    def endIndex = (limit && limit > 0) ? Math.min(startIndex + (limit as Integer), totalCount) : totalCount
    def paged = (totalCount > 0 && startIndex < endIndex) ? devices.subList(startIndex, endIndex) : []

    if (resolvedFormat == "ids") {
        def ids = paged.findAll { it.id?.isInteger() }.collect { it.id as Integer }
        def r = [deviceIds: ids, count: ids.size(), total: totalCount, scope: "all", unfilteredTotal: unfilteredTotal]
        if (labelFilter) r.labelFilter = labelFilter
        if (capabilityFilter) r.capabilityFilter = capabilityFilter
        if (limit && limit > 0) {
            r.offset = startIndex; r.limit = limit; r.hasMore = endIndex < totalCount
            if (endIndex < totalCount) r.nextOffset = endIndex
            if (cursor != null && endIndex < totalCount) r.nextCursor = endIndex.toString()
        }
        return r
    }
    def authorizedCount = devices.findAll { it.mcpAuthorized }.size()
    def result = [
        devices: paged,
        count: paged.size(),
        total: totalCount,
        scope: "all",
        unfilteredTotal: unfilteredTotal,
        mcpAuthorizedCount: authorizedCount,
        unauthorizedCount: totalCount - authorizedCount,
        note: "scope='all' lists EVERY hub device with mcpAuthorized true/false. mcpAuthorized=false means the device is NOT in this MCP app's device list, so it cannot be read or controlled until added in the hub UI (MCP Rule Server app > device selection). Records are lightweight (id/label/capabilities/mcpAuthorized); use scope='authorized' (default) for full detail/currentStates. mcpAuthorizedCount/unauthorizedCount are over the full filtered set (they sum to total), not the returned page."
    ]
    result.source = sourceEndpoint
    if (!capabilitiesComplete) {
        // Say it plainly rather than let an empty list read as "this device has no capabilities":
        // capabilityFilter can only match authorized devices on this path.
        result.capabilitiesPartial = true
        result.capabilitiesNote = "This firmware no longer serves /device/listWithCapabilities/json, so the inventory came from /hub2/devicesList, which carries no capabilities. Capabilities are filled in for mcpAuthorized devices only; an unauthorized device shows an empty list because its capabilities are not visible to the app. capabilityFilter therefore matches authorized devices only."
    }
    if (labelFilter) result.labelFilter = labelFilter
    if (capabilityFilter) result.capabilityFilter = capabilityFilter
    if (limit && limit > 0) {
        result.offset = startIndex; result.limit = limit; result.hasMore = endIndex < totalCount
        if (endIndex < totalCount) result.nextOffset = endIndex
        if (cursor != null && endIndex < totalCount) result.nextCursor = endIndex.toString()
    }
    return result
}

// ==================== DEVICE-ALLOWLIST BYPASS ====================
// When the operator turns ON bypassDeviceAllowlist, device tools that would otherwise throw
// "Device not found" for a device outside settings.selectedDevices fall back to the hub's
// id-keyed admin endpoints, reaching ANY device on the hub. The toggle is independent of
// Developer Mode -- once on it works in normal operation. LISTED / MCP-managed devices ALWAYS
// keep the rich Groovy-device path; only the unlisted fallback is new.

// True when the operator enabled the device-allowlist bypass. Default OFF (null/unset == off).
private boolean _bypassEnabled() {
    return settings.bypassDeviceAllowlist == true
}

// Fetch + parse /device/fullJson/<id>. Returns the parsed Map ({device, commands, ...}) or null
// on a fetch/parse failure or a non-object body. The bypass fallbacks read device state, the
// attribute list, and the command set from this -- the Groovy device object is unavailable for
// an unlisted device (the device model is authorization-scoped).
private Map _fetchDeviceFullJson(deviceId) {
    try {
        def txt = hubInternalGet("/device/fullJson/${deviceId}")
        def parsed = txt ? new groovy.json.JsonSlurper().parseText(txt) : null
        return (parsed instanceof Map) ? parsed : null
    } catch (Exception e) {
        mcpLog("warn", "device", "bypass: /device/fullJson/${deviceId} fetch/parse failed: ${e.message ?: e.toString()}")
        return null
    }
}

// Confirm a device's disabled flag via a FRESH /device/fullJson re-read. NOT via the request-scoped
// Groovy device handle, whose disabled/isDisabled() is execution-cached and does NOT reflect a
// same-request /device/disable POST. Robust to the flag arriving as a Boolean or the string "true".
//   [ok:true]                          -> matches wantDisabled
//   [ok:false, fetchFailed:true]       -> read-back fetch failed (could not confirm)
//   [ok:false, actualDisabled:<bool>]  -> confirmed mismatch (flip did not land)
private Map _confirmDisabledFlip(deviceId, boolean wantDisabled) {
    def fj = _fetchDeviceFullJson(deviceId)
    if (fj?.device == null) return [ok: false, fetchFailed: true]
    def raw = fj.device.disabled
    def nowDisabled = (raw == true || raw?.toString() == "true")
    return (nowDisabled == wantDisabled) ? [ok: true] : [ok: false, actualDisabled: nowDisabled]
}

// Fetch + parse /device/eventsJson/<id> (the event-history analogue of /device/fullJson for the
// allowlist bypass). Returns the parsed List of event Maps (newest-first, no query params) or
// null on a fetch/parse failure or a non-array body. Empty history is [] (a real list), distinct
// from null (the failure sentinel).
private List _fetchBypassDeviceEvents(deviceId) {
    try {
        def txt = hubInternalGet("/device/eventsJson/${deviceId}")
        def parsed = txt ? new groovy.json.JsonSlurper().parseText(txt) : null
        return (parsed instanceof List) ? parsed.findAll { it instanceof Map } : null
    } catch (Exception e) {
        mcpLog("warn", "device", "bypass: /device/eventsJson/${deviceId} fetch/parse failed: ${e.message ?: e.toString()}")
        return null
    }
}

// The display label for a fullJson device (label, else name, else "Device <id>"). Single source
// for the bypass paths so the fallback label is consistent everywhere.
private String _bypassDeviceLabel(Map fj, deviceId) {
    return fj?.device?.label ?: fj?.device?.name ?: "Device ${deviceId}".toString()
}

// Map one /device/eventsJson row to the SAME shape the Groovy-device event paths return
// (description <- descriptionText; the ISO date string passes through). Single source for both the
// recent-N (toolGetDeviceEvents) and the windowed (_deviceHistoryBypass) bypass branches.
private Map _mapBypassEventRow(evt) {
    return [
        name: evt.name,
        value: evt.value,
        unit: evt.unit,
        description: evt.descriptionText,
        date: evt.date,
        isStateChange: evt.isStateChange
    ]
}

// The attribute names a fullJson device exposes. currentStates is an OBJECT keyed by attribute
// name (each value carries value/dataType/unit/date), so its key set IS the device's attribute
// list -- what the bypass paths validate a requested attribute against. NOTE: fullJson lists only
// attributes that have REPORTED a value, so a declared-but-not-yet-reported attribute is absent
// here -- bypass attribute discovery is limited to reported attributes.
private List _fullJsonAttributeNames(Map fullJson) {
    def cs = fullJson?.device?.currentStates
    return (cs instanceof Map) ? new ArrayList(cs.keySet()) : []
}

// The command names a fullJson device exposes. Top-level `commands` is an array of
// {capability, name, arguments, parameters, relatedAttribute}; its names are the supported-command
// set the bypass send-command path validates against.
private List _fullJsonCommandNames(Map fullJson) {
    def cmds = fullJson?.commands
    return (cmds instanceof List) ? cmds.collect { it?.name }.findAll { it != null } : []
}

// Read a device PREFERENCE/setting value from a fullJson device model. fullJson `settings` is an
// ARRAY of {name, type, value}; returns the named setting's value (or null when absent). Used by
// the bypass preference read-back to confirm a /device/preference/save actually landed.
private _fullJsonSettingValue(deviceMap, name) {
    def settings = deviceMap?.settings
    if (!(settings instanceof List)) return null
    def m = settings.find { it instanceof Map && it.name?.toString() == name }
    return (m instanceof Map) ? m.value : null
}

// Infer the /device/preference/save `type` token when the caller did not supply one: a Boolean
// is "bool", a Number is "number", everything else "string". A typed pref should pass its type
// explicitly ({type, value}); this is the fallback for a bare value.
private String _inferPrefType(value) {
    if (value instanceof Boolean) return "bool"
    if (value instanceof Number) return "number"
    return "string"
}

// Read one attribute's current value from a fullJson device model (currentStates keyed by name).
// Returns the String value or null when the attribute has not reported.
private _readBypassAttrValueFrom(Map fullJson, attribute) {
    def st = fullJson?.device?.currentStates
    if (!(st instanceof Map)) return null
    def entry = st[attribute]
    return (entry instanceof Map) ? entry.value : entry
}

// Re-fetch fullJson and read one attribute's value. The bypass poll value-reader: re-fetching
// fullJson each interval is the unlisted-device analogue of the listed device's live
// currentStates list (both re-read fresh from the hub each poll).
private _readBypassAttrValue(deviceId, attribute) {
    return _readBypassAttrValueFrom(_fetchDeviceFullJson(deviceId), attribute)
}

// Build the toolGetDevice summary shape from a fullJson device model (allowlist-bypass path).
// Mirrors the Groovy-device path: id/name/label/room/capabilities + attributes (from
// currentStates) + commands (from the top-level commands array).
private Map _getDeviceFromFullJson(deviceId, Map fj) {
    def d = fj.device
    def attributes = []
    def cs = d?.currentStates
    if (cs instanceof Map) {
        cs.each { name, st ->
            if (name != null) {
                def dataType = (st instanceof Map) ? st.dataType?.toString() : null
                def value = (st instanceof Map) ? st.value : st
                attributes << [name: name, dataType: dataType, value: value]
            }
        }
    }
    def commands = []
    if (fj.commands instanceof List) {
        fj.commands.each { c ->
            if (c?.name != null) commands << [name: c.name, arguments: _fullJsonCommandArgs(c)]
        }
    }
    def caps = (d.capabilities instanceof List) ? d.capabilities.collect { (it instanceof Map) ? it.name : it } : []
    return [
        id: deviceId.toString(),
        name: d.name,
        label: d.label ?: d.name,
        room: d.roomName,
        capabilities: caps,
        attributes: attributes,
        commands: commands
    ]
}

// Map a fullJson command's declared arguments to the listed-device {name, type} shape, or null
// when it declares none. fullJson exposes arg metadata as `parameters` (typed maps) and/or
// `arguments` (type tokens) -- prefer the richer `parameters` when present.
private _fullJsonCommandArgs(c) {
    if (c?.parameters instanceof List && !c.parameters.isEmpty()) {
        return c.parameters.collect { p ->
            (p instanceof Map) ? [name: (p.name ?: "arg"), type: (p.type ?: "unknown")?.toString()]
                               : [name: p?.toString(), type: "unknown"]
        }
    }
    if (c?.arguments instanceof List && !c.arguments.isEmpty()) {
        return c.arguments.collect { a -> [name: "arg", type: a?.toString()] }
    }
    return null
}

def toolGetDevice(deviceId) {
    def device = findDevice(deviceId)
    if (!device) {
        if (_bypassEnabled()) {
            def fj = _fetchDeviceFullJson(deviceId)
            if (fj?.device != null) return _getDeviceFromFullJson(deviceId, fj)
        }
        throw new IllegalArgumentException("Device not found: ${deviceId}")
    }

    def attributes = []
    try {
        attributes = device.supportedAttributes?.collect { attr ->
            [name: attr.name, dataType: attr.dataType?.toString(), value: device.currentValue(attr.name)]
        } ?: []
    } catch (Exception e) {
        logDebug("Error getting attributes for device ${deviceId}: ${e.message}")
    }

    def commands = []
    try {
        commands = device.supportedCommands?.collect { cmd ->
            def args = null
            try {
                args = cmd.arguments?.collect { arg ->
                    if (arg instanceof Map) {
                        [name: arg.name ?: "arg", type: arg.type ?: "unknown"]
                    } else if (arg.respondsTo("getName")) {
                        [name: arg.getName() ?: "arg", type: arg.getType()?.toString() ?: "unknown"]
                    } else {
                        [name: arg.toString(), type: "unknown"]
                    }
                }
            } catch (Exception e) {
                args = null
            }
            [name: cmd.name, arguments: args]
        } ?: []
    } catch (Exception e) {
        logDebug("Error getting commands for device ${deviceId}: ${e.message}")
    }

    return [
        id: device.id.toString(),
        name: device.name,
        label: device.label ?: device.name,
        room: device.roomName,
        capabilities: device.capabilities?.collect { it.name } ?: [],
        attributes: attributes,
        commands: commands
    ]
}

def toolSendCommand(deviceId, command, parameters, waitFor = null, commands = null, reqT0 = null, includeState = true) {
    // Batch form: one call carrying several {deviceId, command, parameters?} entries. A parameter
    // rather than a second tool, and mutually exclusive with the single-device arguments, which is
    // the same shape hub_get_device_attribute already uses for deviceId vs deviceIds.
    if (commands != null) {
        def conflicting = []
        if (deviceId != null) conflicting << "deviceId"
        if (command != null) conflicting << "command"
        // A top-level parameters with commands would otherwise be SILENTLY dropped -- the batch
        // executes without the caller's arguments, which is worse than refusing the mixed shape.
        if (parameters != null) conflicting << "parameters"
        if (conflicting) {
            throw new IllegalArgumentException("commands is mutually exclusive with ${conflicting.join(' and ')} -- pass EITHER a single deviceId+command OR a commands array, not both (per-entry parameters go inside each commands entry)")
        }
        if (waitFor != null) {
            throw new IllegalArgumentException("waitFor is not supported with commands: it blocks a hub thread per device. Send the batch, then confirm the whole set in one call with hub_get_device_attribute using deviceIds + mode")
        }
        return _sendCommandBatch(commands, reqT0)
    }

    if (deviceId == null) throw new IllegalArgumentException("deviceId is required (or pass a commands array to send several at once)")
    if (command == null) throw new IllegalArgumentException("command is required (or pass a commands array to send several at once)")

    // Canonicalize BEFORE resolution: a fractional or non-scalar id must fail validation here,
    // not spend a bypass fullJson fetch on a value that can never name a device.
    def canonicalId = _canonicalDeviceIdArg(deviceId)
    if (canonicalId == null) {
        throw new IllegalArgumentException("deviceId must be a non-empty string or integral number (got: ${_describeValueForError(deviceId)})")
    }
    deviceId = canonicalId

    def device = findDevice(deviceId)
    // Allowlist bypass: an unlisted device (bypass on) resolves through /device/fullJson and is
    // commanded via the id-keyed runmethod endpoint. A LISTED device keeps the Groovy-device path
    // unchanged (bypass stays false). fullJson==null leaves bypass off so the not-found throw fires.
    def bypass = false
    def fullJson = null
    if (!device) {
        if (_bypassEnabled()) fullJson = _fetchDeviceFullJson(deviceId)
        if (fullJson?.device == null) {
            throw new IllegalArgumentException("Device not found: ${deviceId}")
        }
        bypass = true
    }

    // Capture label before command execution to avoid serialization issues
    def deviceLabel = bypass ? _bypassDeviceLabel(fullJson, deviceId)
                             : (device.label ?: device.name ?: "Device ${deviceId}")

    def supportedCommands = bypass ? _fullJsonCommandNames(fullJson)
                                   : device.supportedCommands?.collect { it.name }
    if (!supportedCommands?.contains(command)) {
        throw new IllegalArgumentException("Device ${deviceLabel} does not support command: ${command}. Available: ${supportedCommands}")
    }

    // Validate waitFor BEFORE firing the command so a bad spec fails the call without
    // a side effect (the command would otherwise have already actuated the device). The
    // attribute set comes from the Groovy device for a listed device; under bypass it is null
    // (NOT the fullJson reported-attribute set) so the pre-fire attribute-existence check is
    // SKIPPED -- fullJson cannot list a declared-but-not-yet-reported attribute, and hard-failing
    // on it would block a legitimate command. The poll then reports neverReported if it never shows.
    def supportedAttrs = bypass ? null
                                : (device.supportedAttributes?.collect { it.name } ?: [])
    def pollArgs = (waitFor != null) ? _buildWaitForPollArgs(deviceId, supportedAttrs, deviceLabel, waitFor) : null

    // Normalize parameters once (when present) so both paths see the typed values. A blank
    // String means "no parameters" -- null it so the reported parameters stay inside the
    // outputSchema's array-or-null contract (a non-blank String always normalizes to a List).
    if (parameters instanceof String && !parameters.trim()) parameters = null
    if (parameters && parameters.size() > 0) {
        parameters = normalizeCommandParams(parameters)
    }
    if (bypass) {
        // Single bypass branch: fire via runmethod (empty arg list for a no-parameter command).
        def fireErr = _fireBypassCommand(deviceId, command, (parameters && parameters.size() > 0) ? parameters : [], fullJson)
        if (fireErr != null) return fireErr
    } else if (parameters && parameters.size() > 0) {
        device."${command}"(*parameters)
    } else {
        device."${command}"()
    }

    def result = [
        success: true,
        device: deviceLabel,
        command: command,
        parameters: parameters
    ]

    if (pollArgs != null) {
        // Block-poll until the attribute converges (or times out), then snapshot, so the
        // state reflects the RESULTING (converged) value -- the immediate snapshot alone
        // is pre-effect because the hub commits the change after this request returns.
        def waitForBlock = [
            attribute: pollArgs.attribute,
            expected : (pollArgs.containsKey("expectedValues") ? pollArgs.expectedValues : pollArgs.expectedValue)
        ]
        try {
            def poll = toolPollUntilAttribute(pollArgs)
            waitForBlock.converged  = poll.success == true
            waitForBlock.finalValue = poll.finalValue
            // poll.polledCount is intentionally NOT surfaced into the waitFor block: elapsedMs
            // is the caller-relevant diagnostic (how long the command-confirm blocked); the
            // raw poll count is an engine-internal detail.
            waitForBlock.elapsedMs  = poll.elapsedMs
            // Surface the engine's diagnostic flags when present so the caller can tell a
            // plain timeout apart from a hub-reload interrupt or a never-reported attribute.
            if (poll.timedOut == true)      waitForBlock.timedOut = true
            if (poll.interrupted == true)   waitForBlock.interrupted = true
            if (poll.readError == true)     waitForBlock.readError = true
            if (poll.neverReported == true) waitForBlock.neverReported = true
            if (poll.nonNumericAttribute == true) waitForBlock.nonNumericAttribute = true
            // nonNumericAttribute carries an actionable note (names the comparator/attribute,
            // suggests eq/ne) -- propagate it so a waitFor caller gets the same guidance.
            if (poll.note != null) waitForBlock.note = poll.note
            // transitioning is present on the timeout path as true OR false (both meaningful),
            // so copy it whenever the engine emitted the key -- not only when true.
            if (poll.containsKey("transitioning")) waitForBlock.transitioning = poll.transitioning
        } catch (Throwable e) {
            // The command already fired; a poll-loop failure (e.g. a malformed numeric
            // attribute) must not lose the response. Catch Throwable -- not just Exception --
            // for the same reason the snapshot does: a non-Exception Throwable after the
            // device actuated must report non-convergence, not escape as a hard error that
            // drops the state/waitFor blocks. Include the class so an NPE doesn't render as
            // "(no message)" with no other clue. Snapshot is still taken below.
            def cls = e.class.simpleName
            // Log at error: a warn is below Hubitat's default log level and returns before
            // writing, so this degraded-path failure would land in neither buffer nor hub log.
            mcpLog("error", "send-command", "waitFor poll failed for ${deviceLabel}: ${cls}: ${e.message ?: '(no message)'}")
            waitForBlock.converged  = false
            waitForBlock.finalValue = null
            waitForBlock.error      = "waitFor poll failed: ${cls}: ${e.message ?: '(no message)'}".toString()
            // The command fired but the confirmation poll degraded -- flag the partial result.
            result.partial = true
        }
        result.waitFor = waitForBlock
    }

    // Batch entries skip the read-back entirely: their response drops state anyway, and under
    // bypass the snapshot is a SECOND /device/fullJson fetch per entry -- up to 20 wasted reads
    // against the same relay budget the batch is trying to stay inside.
    if (!includeState) return result

    // Snapshot AFTER any waitFor poll. Without waitFor this is the immediate (pre-effect)
    // read; with waitFor it reflects the converged state. A null return is the read-back
    // FAILURE sentinel (distinct from a legitimately empty [:]); surface why so the agent
    // can tell a failed confirmation read apart from a device with no readable attributes.
    def stateErr = []
    def snap = bypass ? _snapshotBypassDeviceState(deviceId, deviceLabel, stateErr)
                      : _snapshotDeviceState(device, deviceLabel, stateErr)
    if (snap == null) {
        // Genuine read-back failure: state is empty AND stateError says why, so the agent
        // distinguishes this from a device that legitimately has no readable attributes
        // (which returns an empty map and NO stateError).
        result.state = [:]
        result.stateError = "device-state read-back failed: ${stateErr ? stateErr[0] : '(no detail)'}".toString()
        // The command fired but the confirmation snapshot failed -- flag the partial result.
        result.partial = true
    } else {
        result.state = snap
    }
    return result
}

// Canonical string form of a device-id argument. A String passes through; an INTEGRAL Number is
// stringified (ids arrive numeric from hub_list_devices format='ids'); anything else -- a
// fractional number included -- returns null for the caller to reject before any side effect.
private _canonicalDeviceIdArg(value) {
    // CharSequence, not String: an internal caller may hand a GString and must not be rejected.
    if (value instanceof CharSequence) return value.toString().trim() ?: null
    if (value instanceof Number) return (value == value.longValue()) ? value.longValue().toString() : null
    return null
}

// The commands-array form of hub_call_device_command. Not a tool of its own: it is reached only
// through that tool's `commands` parameter. Batching exists because the per-call round trip, not
// the hub actuating the device, dominates wall clock. The measured figures, the bridged-device
// exception and the group/scene trade-off live in hub_get_tool_guide(section='performance').
private _sendCommandBatch(commands, reqT0 = null) {
    if (!(commands instanceof List) || commands.isEmpty()) {
        throw new IllegalArgumentException("commands must be a non-empty array of {deviceId, command, parameters?} objects")
    }
    // Same ceiling as hub_get_device_attribute's multi-device poll (MAX_POLL_DEVICES); this bound
    // keeps one request's serial dispatch inside the relay window.
    def MAX_BATCH_COMMANDS = 20
    if (commands.size() > MAX_BATCH_COMMANDS) {
        throw new IllegalArgumentException("commands may contain at most ${MAX_BATCH_COMMANDS} entries (got ${commands.size()})")
    }

    // Validate the whole batch BEFORE firing any of it. A malformed entry half way down would
    // otherwise leave the earlier devices actuated and the caller holding an error with no way to
    // know how far it got -- the same no-side-effect-on-a-bad-spec guarantee waitFor already
    // gives on the single-device path.
    def validEntryKeys = ["deviceId", "command", "parameters"] as Set
    def entryDeviceIds = []
    commands.eachWithIndex { entry, i ->
        if (!(entry instanceof Map)) {
            throw new IllegalArgumentException("commands[${i}] must be an object with deviceId and command")
        }
        // A hub device id is numeric, so a caller that sends it as a JSON number is not wrong --
        // coerce to the string form every downstream comparison uses instead of rejecting it.
        def id = _canonicalDeviceIdArg(entry.deviceId)
        if (!(id instanceof String) || !id.trim()) {
            throw new IllegalArgumentException("commands[${i}].deviceId is required and must be a non-empty string (got: ${_describeValueForError(entry.deviceId)})")
        }
        if (!(entry.command instanceof String) || !entry.command.trim()) {
            throw new IllegalArgumentException("commands[${i}].command is required and must be a non-empty string (got: ${_describeValueForError(entry.command)})")
        }
        // A String parameters value is passed straight through: normalizeCommandParams repairs the
        // shape the hub's JSON parser produces when a nested object defeats it.
        if (entry.parameters != null && !(entry.parameters instanceof List) && !(entry.parameters instanceof String)) {
            throw new IllegalArgumentException("commands[${i}].parameters must be an array when present (got: ${_describeValueForError(entry.parameters)})")
        }
        def unknown = (entry.keySet() - validEntryKeys).sort()
        if (unknown) {
            throw new IllegalArgumentException("commands[${i}] has unknown keys: ${unknown.join(', ')}. Valid keys: ${validEntryKeys.sort().join(', ')}")
        }
        entryDeviceIds << id
    }

    // One entry failing must not abandon the rest. A batch is a list of independent intents, and
    // a caller turning off six lights would rather five went off with one reported failure than
    // have the whole thing refused because a sixth device had been removed. Per-entry outcomes
    // are reported individually so the caller can tell exactly which. "Failing" means an
    // Exception: a JVM-level Error (OOM, StackOverflow) deliberately escapes the loop and aborts
    // the batch -- a broken VM should stop actuating hardware, not soldier on.
    def results = []
    def remaining = []
    long t0 = (reqT0 instanceof Number) ? ((Number) reqT0).longValue() : now()
    for (int i = 0; i < commands.size(); i++) {
        // Hand the untried tail back rather than let a long batch of slow devices run the request
        // past the relay's response window, where a dropped response leaves the caller unable to
        // tell what actuated. Never on the first entry: a batch always attempts at least one.
        if (i > 0 && _timeBudgetExceeded(t0)) {
            remaining = commands.subList(i, commands.size()).collect { it }
            break
        }
        def e = commands[i]
        def deviceId = entryDeviceIds[i]
        try {
            // Delegates to the single-device tool, so allowlist handling, the bypass path,
            // command-support validation and parameter normalisation stay in one place and cannot
            // drift between the two entry points.
            def one = toolSendCommand(deviceId, e.command, e.parameters, null, null, null, false)

            // A bypass-path failure arrives as a returned [success:false, error, note], not a
            // throw, so the aggregate below derives from results[] rather than counting throws.
            // That returned map carries no command, hence the backfill (a real command from the
            // delegate wins). The per-device state snapshot is dropped: a batch confirms through
            // hub_get_device_attribute's deviceIds form, not through N inline snapshots.
            def entry = [deviceId: deviceId, command: e.command] + one
            entry.remove("state")
            entry.remove("stateError")
            entry.remove("partial")
            if (entry.success == false) {
                mcpLog("error", "send-command", "batch entry failed for ${deviceId} (${e.command}): ${entry.error ?: '(no error text)'}")
            }
            results << entry
        } catch (Exception ex) {
            def cls = ex.class.simpleName
            mcpLog("error", "send-command", "batch entry threw for ${deviceId} (${e.command}): ${cls}: ${ex.message ?: '(no message)'}")
            results << [
                success : false,
                deviceId: deviceId,
                command : e.command,
                error   : "${cls}: ${ex.message ?: '(no message)'}".toString(),
                note    : "This entry was not confirmed to actuate; the other attempted entries were still sent (entries the relay budget stopped are in remainingCommands, unsent). Verify the deviceId with hub_list_devices and the command with hub_get_device -- and if the failure happened mid-command, confirm the device state before re-sending this entry."
            ]
        }
    }

    def failed = results.count { it.success == false }
    def sent = results.size() - failed
    def result = [
        success    : failed == 0,
        count      : results.size(),
        sentCount  : sent,
        failedCount: failed,
        results    : results
    ]
    if (failed > 0) {
        result.failedDeviceIds = results.findAll { it.success == false }.collect { it.deviceId }
        if (failed < results.size()) result.partial = true
        result.error = "${failed} of ${results.size()} device command(s) failed; ${sent} were sent. See results[] for the per-device cause.".toString()
        result.note = "The entries that succeeded ALREADY actuated -- do NOT re-send the whole batch. Before re-sending a failed entry, read its error/note: an outcome the hub did not CONFIRM may still have actuated, so verify with hub_get_device_attribute first. See hub_get_tool_guide(section='device_authorization') for what makes an entry fail."
        // Only a batch where nothing landed is a tool-execution error. Flagging a partial one
        // would tell the caller the call did nothing while devices had in fact moved.
        if (failed == results.size() && !remaining) result.isError = true
    }
    if (remaining) {
        result.success = false
        result.stoppedEarly = true
        result.remainingCommands = remaining
        result.error = ("Stopped after attempting ${results.size()} of ${commands.size()} entries, nearing the relay time budget; the remaining ${remaining.size()} were NOT sent." +
                        (failed > 0 ? " ${failed} of the attempted entries also failed -- see results[]." : "")).toString()
        result.note = "The ${results.size()} attempted entries were already dispatched (see results[]); re-send ONLY remainingCommands in a new call.".toString()
    }
    return result
}

// Validate a waitFor spec and translate it into a toolPollUntilAttribute args map, reusing
// that tool's block-poll engine for the runtime poll behavior. This validator fully covers
// shape, type, numeric-range, and attribute-existence so a bad spec is rejected BEFORE the
// command fires (the poll engine repeats these checks as defense-in-depth, but its run is
// post-fire, so completing them here is what buys the no-side-effect-on-bad-spec guarantee).
private Map _buildWaitForPollArgs(deviceId, supportedAttrs, deviceLabel, waitFor) {
    if (!(waitFor instanceof Map)) {
        throw new IllegalArgumentException("waitFor must be an object with at least attribute and expectedValue/expectedValues")
    }
    def validKeys = ["attribute", "expectedValue", "expectedValues", "timeoutMs", "pollIntervalMs", "comparator", "stableForMs"] as Set
    def unknownKeys = (waitFor.keySet() - validKeys).sort()
    if (unknownKeys) {
        def label = unknownKeys.size() == 1 ? 'an unknown key' : 'unknown keys'
        throw new IllegalArgumentException("waitFor has ${label}: ${unknownKeys.join(', ')}. Valid keys: ${validKeys.sort().join(', ')}")
    }
    if (!(waitFor.attribute instanceof String) || !waitFor.attribute.trim()) {
        throw new IllegalArgumentException("waitFor.attribute is required and must be a non-empty string")
    }
    // supportedAttrs == null means "skip the existence check" (the allowlist-bypass path: fullJson
    // cannot enumerate a declared-but-unreported attribute, so the command must not be hard-failed
    // pre-fire). A non-null list (the listed-device path) still rejects an unknown attribute.
    if (supportedAttrs != null && !supportedAttrs.contains(waitFor.attribute)) {
        throw new IllegalArgumentException("waitFor.attribute '${waitFor.attribute}' not found on device '${deviceLabel}'. Available: ${supportedAttrs.join(', ')}")
    }
    def hasExpectedValue  = waitFor.containsKey("expectedValue")
    def hasExpectedValues = waitFor.containsKey("expectedValues")
    if (hasExpectedValue && hasExpectedValues) {
        throw new IllegalArgumentException("waitFor: provide exactly one of expectedValue or expectedValues, not both")
    }
    if (!hasExpectedValue && !hasExpectedValues) {
        throw new IllegalArgumentException("waitFor: exactly one of expectedValue or expectedValues is required")
    }
    // Validate every pre-checkable field HERE so a bad spec never fires the command.
    // The pollIntervalMs bound MIRRORS toolPollUntilAttribute's [50,5000]. timeoutMs is
    // STRICTER on this command-flow path: a waitFor poll pins a hub thread for the full
    // timeout, so the pre-fire cap is 30000ms (vs the engine's standalone [100,60000]).
    if (hasExpectedValue) {
        // .trim() for parity with attribute -- reject a whitespace-only value, not just "".
        if (!(waitFor.expectedValue instanceof String) || !waitFor.expectedValue.trim()) {
            throw new IllegalArgumentException("waitFor.expectedValue must be a non-empty string (got: ${_describeValueForError(waitFor.expectedValue)})")
        }
    }
    if (hasExpectedValues) {
        if (!(waitFor.expectedValues instanceof List) || waitFor.expectedValues.isEmpty()) {
            throw new IllegalArgumentException("waitFor.expectedValues must be a non-empty list of strings")
        }
        waitFor.expectedValues.eachWithIndex { v, i ->
            if (!(v instanceof String)) {
                throw new IllegalArgumentException("waitFor.expectedValues[${i}] must be a string, got: ${_describeValueForError(v)}")
            }
        }
    }
    // Accept any Number (not just Integer) so a Long/BigDecimal that the engine would
    // accept is not wrongly rejected pre-fire -- toolPollUntilAttribute validates these
    // same fields with `instanceof Number`. The comparison is direct (no `as Integer`
    // cast), so an in-range fractional passes the bounds check exactly as the engine does.
    if (waitFor.containsKey("timeoutMs")) {
        if (!(waitFor.timeoutMs instanceof Number) || waitFor.timeoutMs < 100 || waitFor.timeoutMs > 30000) {
            throw new IllegalArgumentException("waitFor.timeoutMs must be a number between 100 and 30000 (got: ${waitFor.timeoutMs})")
        }
    }
    if (waitFor.containsKey("pollIntervalMs")) {
        if (!(waitFor.pollIntervalMs instanceof Number) || waitFor.pollIntervalMs < 50 || waitFor.pollIntervalMs > 5000) {
            throw new IllegalArgumentException("waitFor.pollIntervalMs must be a number between 50 and 5000 (got: ${waitFor.pollIntervalMs})")
        }
    }
    // Comparator + stableForMs pre-fire validation: mirror the engine's comparator constraints
    // HERE so a bad spec never fires the command (the engine repeats these post-fire as
    // defense-in-depth). The effective timeout for the stableForMs upper bound is the same
    // default applied below.
    def effectiveTimeoutMs = waitFor.containsKey("timeoutMs") ? (waitFor.timeoutMs as Integer) : 5000
    def validComparators = ["eq", "ne", "gt", "gte", "lt", "lte", "between"]
    if (waitFor.containsKey("comparator") && waitFor.comparator == null) {
        throw new IllegalArgumentException("waitFor.comparator must not be null (omit the arg to use the default \"eq\")")
    }
    def comparator = waitFor.containsKey("comparator") ? waitFor.comparator : "eq"
    if (!(comparator instanceof String) || !validComparators.contains(comparator)) {
        throw new IllegalArgumentException("waitFor.comparator must be one of ${validComparators} (got: ${_describeValueForError(waitFor.comparator)})")
    }
    if (["gt", "gte", "lt", "lte"].contains(comparator)) {
        if (hasExpectedValues) {
            throw new IllegalArgumentException("waitFor.comparator '${comparator}' takes a single numeric threshold via expectedValue, not expectedValues")
        }
        if (_parseBigDecimalOrNull(waitFor.expectedValue) == null) {
            throw new IllegalArgumentException("waitFor.comparator '${comparator}' requires expectedValue to be a numeric-parseable string (got: ${_describeValueForError(waitFor.expectedValue)})")
        }
    } else if (comparator == "between") {
        if (hasExpectedValue) {
            throw new IllegalArgumentException("waitFor.comparator 'between' takes two numeric bounds via expectedValues, not expectedValue")
        }
        if (waitFor.expectedValues.size() != 2) {
            throw new IllegalArgumentException("waitFor.comparator 'between' requires expectedValues to have exactly 2 numeric bounds [low, high] (got ${waitFor.expectedValues.size()})")
        }
        def lo = _parseBigDecimalOrNull(waitFor.expectedValues[0])
        def hi = _parseBigDecimalOrNull(waitFor.expectedValues[1])
        if (lo == null || hi == null) {
            throw new IllegalArgumentException("waitFor.comparator 'between' requires both expectedValues bounds to be numeric-parseable strings (got: ${waitFor.expectedValues})")
        }
        if (lo > hi) {
            throw new IllegalArgumentException("waitFor.comparator 'between' requires low <= high (got low=${waitFor.expectedValues[0]}, high=${waitFor.expectedValues[1]})")
        }
    }
    if (waitFor.containsKey("stableForMs") && waitFor.stableForMs == null) {
        throw new IllegalArgumentException("waitFor.stableForMs must not be null (omit the arg to use default 0)")
    }
    if (waitFor.containsKey("stableForMs")) {
        if (!(waitFor.stableForMs instanceof Number)) {
            throw new IllegalArgumentException("waitFor.stableForMs must be an integer (got: ${_describeValueForError(waitFor.stableForMs)})")
        }
        if (waitFor.stableForMs < 0) {
            throw new IllegalArgumentException("waitFor.stableForMs must be >= 0 (got: ${waitFor.stableForMs})")
        }
        if ((waitFor.stableForMs as Integer) >= effectiveTimeoutMs) {
            throw new IllegalArgumentException("waitFor.stableForMs (${waitFor.stableForMs}) must be less than timeoutMs (${effectiveTimeoutMs}) -- the condition could never hold long enough to converge")
        }
    }
    def pollArgs = [deviceId: deviceId.toString(), attribute: waitFor.attribute]
    if (hasExpectedValue)  pollArgs.expectedValue  = waitFor.expectedValue
    if (hasExpectedValues) pollArgs.expectedValues = waitFor.expectedValues
    if (waitFor.containsKey("comparator"))  pollArgs.comparator  = waitFor.comparator
    if (waitFor.containsKey("stableForMs")) pollArgs.stableForMs = waitFor.stableForMs
    // Default the timeout/interval here so an omitted value uses the command-flow default
    // (5000ms) and pollIntervalMs 250ms -- the 250ms default is the post-command-flow
    // default by intent (the engine's standalone default is 200ms); explicit values pass through.
    pollArgs.timeoutMs      = waitFor.containsKey("timeoutMs")      ? waitFor.timeoutMs      : 5000
    pollArgs.pollIntervalMs = waitFor.containsKey("pollIntervalMs") ? waitFor.pollIntervalMs : 250
    return pollArgs
}

// Render a value plus a coarse runtime-type label for a validation error message. Uses
// instanceof rather than getClass() (reflection is blocked in the Hubitat sandbox), so the
// label is a small fixed vocabulary -- enough to tell a caller "you passed a number/boolean
// where a string was required" without naming the exact JVM class.
private String _describeValueForError(v) {
    def typeLabel = (v == null) ? "null"
        : (v instanceof String)  ? "string"
        : (v instanceof Boolean) ? "boolean"
        : (v instanceof Number)  ? "number"
        : (v instanceof List)    ? "list"
        : (v instanceof Map)     ? "object"
        : "value"
    if (v == null) return "null"
    // Quote strings so an empty or whitespace-only value renders as "" / "   " rather than a
    // bare gap in the message; non-string values render unquoted (e.g. 42 (number)).
    def rendered = (v instanceof String) ? "\"${v}\"" : "${v}"
    return "${rendered} (${typeLabel})"
}

// Parse a value as BigDecimal for numeric comparator math, or null if it is not numeric.
// Accepts a Number directly and a numeric-parseable CharSequence (a String or a GString --
// the form device states report); anything else (null, non-numeric string, list, map) yields
// null so the caller treats it as "no match" rather than throwing. A GString is not a String
// subtype in Groovy, so match CharSequence and normalize via toString() before parsing.
// NumberFormatException is the only expected failure.
private BigDecimal _parseBigDecimalOrNull(v) {
    if (v instanceof Number) return v as BigDecimal
    if (v instanceof CharSequence && v.isNumber()) {
        try { return new BigDecimal(v.toString()) } catch (NumberFormatException ignored) { return null }
    }
    return null
}

// Compact current-state snapshot for a command response: per attribute, its current
// value plus the event timestamp (freshness signal). Reads device.currentStates (each
// State has name/value/date). Includes only attributes that have a current state; if the
// device reports no states at all, falls back to supportedAttributes + currentValue (each
// with a null timestamp). Never returns the full device object -- values and timestamps only.
// NOTE: this is an IMMEDIATE read taken in the same request that fired the command -- the
// hub commits a command's effect AFTER that request returns, so without waitFor the value
// here is the PRE-effect state even for virtual/local devices. The timestamp is the freshness
// signal; waitFor (block-poll) is what makes this snapshot reflect the converged state.
private Map _snapshotDeviceState(device, deviceLabel, errOut = null) {
    def snapshot = [:]
    try {
        def states = device.currentStates
        if (states) {
            states.each { st ->
                if (st?.name != null) {
                    // st.date is a java.util.Date on a live hub -- format it directly
                    // (formatTimestamp has no Date branch and would mangle it via toString).
                    // Guard ONLY the date format locally: a single date that fails to format
                    // yields timestamp:null for THAT attribute (keeping its value) instead of
                    // discarding the whole snapshot. A structural read throw (currentStates /
                    // name / value) still falls to the outer catch and clears to [:].
                    def ts = null
                    if (st.date) {
                        try {
                            ts = st.date.format("yyyy-MM-dd HH:mm:ss")
                        } catch (Throwable dt) {
                            // Log at error so an operator can tell a date-format failure (value
                            // kept, timestamp null) apart from an attribute that never reported.
                            // Error -- not warn -- because warn is below Hubitat's default level
                            // and returns before writing, so this degradation would be invisible.
                            ts = null
                            mcpLog("error", "send-command", "date format failed for attribute '${st.name}' on ${deviceLabel}: ${dt.class.simpleName}")
                        }
                    }
                    snapshot[st.name] = [value: st.value, timestamp: ts]
                }
            }
        } else {
            // Fallback to currentValue only because currentStates is empty -- the device has
            // emitted no state event at all, so there is no prior event for currentValue to be
            // stale against; staleness (the reason the poll engine avoids currentValue) is moot
            // here. Each entry carries a null timestamp since there is no event to date it.
            device.supportedAttributes?.each { attr ->
                def name = attr?.name
                if (name != null) {
                    // Per-attribute guard for parity with the currentStates branch's date guard:
                    // one attribute whose currentValue read throws degrades to value:null for
                    // THAT attribute, keeping the rest, instead of the outer catch discarding the
                    // whole snapshot. name is non-null here, so the entry is always present.
                    def val = null
                    try {
                        val = device.currentValue(name)
                    } catch (Throwable cv) {
                        // Error -- not warn -- because this guard degrades to value:null with no
                        // stateError/partial, so a warn (below the default level, returns before
                        // writing) would leave a systemic read failure fully invisible.
                        mcpLog("error", "send-command", "currentValue read failed for attribute '${name}' on ${deviceLabel}: ${cv.class.simpleName}")
                    }
                    snapshot[name] = [value: val, timestamp: null]
                }
            }
        }
    } catch (Throwable t) {
        // Read-back must never break the command (which already fired). Discard any
        // partial snapshot built before a mid-iteration throw and return the null FAILURE
        // sentinel so the caller can distinguish a failed read from a legitimately empty
        // device. Log at error so it writes under the hub's default log level (a warn here
        // is below default and would be invisible -- a silently-failed confirmation read).
        // t.message can be null.
        def detail = "${t.class.simpleName}: ${t.message ?: '(no message)'}".toString()
        mcpLog("error", "send-command", "Failed to snapshot device state for ${deviceLabel}: ${detail}")
        if (errOut != null) errOut << detail
        return null
    }
    return snapshot
}

// Fire a device command on an unlisted device via the hub's id-keyed runmethod endpoint (the
// allowlist-bypass analogue of device."cmd"(*params)). POST /device/runmethod with
// {id, method, args:[{type, value}, ...]}; empty args for a no-parameter command. Each arg's
// type comes from the command's declared parameters in fullJson when available, else inferred
// from the value. Returns null on success, or a structured [success:false, error, note] runtime-
// error map (the AGENTS.md runtime-error contract) on a non-success/non-JSON body or a hub-call
// failure -- the caller surfaces it directly rather than a thrown exception.
private Map _fireBypassCommand(deviceId, command, List params, Map fullJson) {
    def args = _buildRunMethodArgs(command, params, fullJson)
    def body = groovy.json.JsonOutput.toJson([id: _runMethodDeviceId(deviceId), method: command, args: args])
    def resp
    try {
        resp = hubInternalPostJson("/device/runmethod", body)
    } catch (Exception e) {
        // Log at error: a warn is below Hubitat's default log level, so this failed-fire would
        // land in neither the hub log nor the buffer.
        mcpLog("error", "send-command", "bypass: /device/runmethod for '${command}' on ${deviceId} threw: ${e.message ?: e.toString()}")
        return [success: false, error: "runmethod call failed for '${command}': ${e.message ?: e.toString()}",
                note: "The hub call to /device/runmethod failed; the command may not have actuated. Retry, or verify the device id."]
    }
    // FAIL-CLOSED on anything that is not a positive confirmation. A null/empty body (dropped
    // response on a write -> unknown commit), a non-JSON body, a non-Map, or a Map that does not
    // carry success==true (e.g. {}) all mean "not confirmed" -- never silently treat them as success.
    if (resp == null) {
        mcpLog("error", "send-command", "bypass: /device/runmethod for '${command}' on ${deviceId} returned an empty/dropped response")
        return [success: false, error: "runmethod returned an empty/dropped response for '${command}'",
                note: "The hub call to /device/runmethod returned no body; the command may have actuated but was not confirmed. Retry, or verify with hub_get_device."]
    }
    if (resp instanceof Map && resp._unparseable) {
        mcpLog("error", "send-command", "bypass: /device/runmethod for '${command}' on ${deviceId} returned a non-JSON body: ${resp.message}")
        return [success: false, error: "runmethod returned a non-JSON body for '${command}': ${resp.message}",
                note: "The hub did not return a JSON result; the command may not have actuated. Retry."]
    }
    if (!(resp instanceof Map) || resp.success != true) {
        mcpLog("error", "send-command", "bypass: /device/runmethod for '${command}' on ${deviceId} did not confirm success: ${resp}")
        return [success: false, error: "runmethod did not confirm success for '${command}': ${resp}",
                note: "The hub rejected or did not confirm the command. Verify the command and arguments against hub_get_device."]
    }
    return null
}

// Coerce a device id to the integer the runmethod endpoint expects, passing a non-numeric id
// through unchanged (fullJson already proved the device exists, so the id is well-formed).
private _runMethodDeviceId(deviceId) {
    def s = deviceId?.toString()
    return (s != null && s.isInteger()) ? s.toInteger() : deviceId
}

// Build the runmethod args list ([{type, value}, ...]) from the normalized parameter values,
// typing each positionally from the command's declared parameters in fullJson, else inferring.
private List _buildRunMethodArgs(command, List params, Map fullJson) {
    if (!params) return []
    def cmdDef = (fullJson?.commands instanceof List) ? fullJson.commands.find { it?.name == command } : null
    def declaredTypes = _commandParamTypes(cmdDef)
    def out = []
    params.eachWithIndex { v, i ->
        def t = (i < declaredTypes.size() && declaredTypes[i]) ? declaredTypes[i] : _inferRunMethodArgType(v)
        out << [type: t, value: v]
    }
    return out
}

// Positional arg-type tokens declared by a fullJson command, from `parameters` (typed maps) or
// `arguments` (type tokens). Empty when the command declares no typed parameters.
private List _commandParamTypes(cmdDef) {
    if (cmdDef?.parameters instanceof List && !cmdDef.parameters.isEmpty()) {
        return cmdDef.parameters.collect { p -> (p instanceof Map) ? p.type?.toString() : p?.toString() }
    }
    if (cmdDef?.arguments instanceof List && !cmdDef.arguments.isEmpty()) {
        return cmdDef.arguments.collect { a -> (a instanceof Map) ? a.type?.toString() : a?.toString() }
    }
    return []
}

// Fallback runmethod arg type when the command declares none: a Map/List value is a
// JSON_OBJECT (e.g. setColor), a Number is a NUMBER, everything else a STRING.
private String _inferRunMethodArgType(v) {
    if (v instanceof Map || v instanceof List) return "JSON_OBJECT"
    if (v instanceof Number) return "NUMBER"
    return "STRING"
}

// Compact current-state snapshot for an unlisted device's command response, mirroring
// _snapshotDeviceState's {attr: {value, timestamp}} shape but sourced from /device/fullJson
// currentStates. Returns null (the read-back FAILURE sentinel) when fullJson is unavailable.
private Map _snapshotBypassDeviceState(deviceId, deviceLabel, errOut = null) {
    try {
        def fj = _fetchDeviceFullJson(deviceId)
        def cs = fj?.device?.currentStates
        if (!(cs instanceof Map)) {
            if (errOut != null) errOut << "fullJson currentStates unavailable for ${deviceId}"
            return null
        }
        def snapshot = [:]
        cs.each { name, st ->
            if (name != null) {
                def val = (st instanceof Map) ? st.value : st
                def rawDate = (st instanceof Map) ? st.date : null
                snapshot[name] = [value: val, timestamp: _formatBypassStateDate(rawDate)]
            }
        }
        return snapshot
    } catch (Throwable t) {
        def detail = "${t.class.simpleName}: ${t.message ?: '(no message)'}".toString()
        mcpLog("error", "send-command", "Failed to snapshot bypass device state for ${deviceLabel}: ${detail}")
        if (errOut != null) errOut << detail
        return null
    }
}

// Normalize a fullJson currentState date (an ISO-8601 String) to the snapshot's
// "yyyy-MM-dd HH:mm:ss" form for parity with the listed-device snapshot, falling back to the
// raw string when it does not parse. null in -> null out (no event timestamp).
private String _formatBypassStateDate(rawDate) {
    if (rawDate == null) return null
    def s = rawDate.toString()
    def parsed = _parseSinceArg(s)
    if (parsed == null) return s
    try {
        return parsed.format("yyyy-MM-dd HH:mm:ss")
    } catch (Throwable t) {
        return s
    }
}

def normalizeCommandParams(params) {
    // Case 1: Already a List (Hubitat parsed it successfully) — go straight to element conversion
    if (params instanceof List) {
        return convertParamElements(params)
    }

    // Case 2: String (Hubitat parser failed on nested JSON)
    // Example: '["{"hue":0,"saturation":100,"level":50}"]'
    def s = params.toString().trim()

    // Try to extract an embedded JSON object between first { and last }
    def firstBrace = s.indexOf("{")
    def lastBrace = s.lastIndexOf("}")
    if (firstBrace >= 0 && lastBrace > firstBrace) {
        def jsonContent = s.substring(firstBrace, lastBrace + 1)
        try {
            def parsed = new groovy.json.JsonSlurper().parseText(jsonContent)
            return [parsed]
        } catch (Exception e) {
            // Not valid JSON object, fall through
        }
    }

    // No JSON object found — strip outer ["..."] wrapper and split into string params
    if (s.startsWith("[\"") && s.endsWith("\"]")) {
        def inner = s.substring(2, s.length() - 2)
        return convertParamElements(inner.split('","').toList())
    }

    // Last resort: treat the whole string as a single parameter
    return convertParamElements([s])
}

def convertParamElements(List params) {
    return params.collect { param ->
        if (param == null) return param
        if (param instanceof Map || param instanceof List) return param
        def s = param.toString()
        // Numeric conversion
        try {
            if (s.isNumber()) {
                return s.contains(".") ? s.toDouble() : s.toInteger()
            }
        } catch (Exception e) {}
        // JSON object/array string → parse to Map/List
        if ((s.startsWith("{") || s.startsWith("[")) && s.length() > 1) {
            try {
                return new groovy.json.JsonSlurper().parseText(s)
            } catch (Exception e) {}
        }
        return param
    }
}

def toolGetDeviceEvents(deviceId, limit) {
    if (limit == null || limit < 1) limit = 10
    def device = findDevice(deviceId)
    if (!device) {
        if (_bypassEnabled()) {
            def fj = _fetchDeviceFullJson(deviceId)
            if (fj?.device != null) {
                def label = _bypassDeviceLabel(fj, deviceId)
                // /device/eventsJson returns newest-first with no query params, so apply the
                // limit client-side. Rows carry descriptionText + an ISO date string; map to the
                // SAME shape the Groovy-device path returns. A null return is the FETCH-FAILURE
                // sentinel (distinct from [] = real empty history) -- surface it as a structured
                // error, never an empty-success that silently lies about the device having no events.
                def rows = _fetchBypassDeviceEvents(deviceId)
                if (rows == null) {
                    return [success: false, error: "Device event history fetch failed (/device/eventsJson/${deviceId})", device: label,
                            note: "The device is reachable via the allowlist bypass but its event store could not be read -- likely a transient hub blip; retry."]
                }
                def events = rows.take(limit as Integer).collect { evt -> _mapBypassEventRow(evt) }
                return [device: label, events: events, count: events.size()]
            }
        }
        throw new IllegalArgumentException("Device not found: ${deviceId}")
    }

    def events = device.events(max: limit)?.collect { evt ->
        [
            name: evt.name,
            value: evt.value,
            unit: evt.unit,
            description: evt.descriptionText,
            date: evt.date?.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ"),
            isStateChange: evt.isStateChange
        ]
    }

    return [
        device: device.label,
        events: events ?: [],
        count: events?.size() ?: 0
    ]
}

def toolGetAttribute(deviceId, attribute) {
    // Same canonical form as every other device-id entry point: reject a fractional or
    // non-scalar id before it can spend a bypass fullJson fetch below.
    def canonicalId = _canonicalDeviceIdArg(deviceId)
    if (canonicalId == null) {
        throw new IllegalArgumentException("deviceId must be a non-empty string or integral number (got: ${_describeValueForError(deviceId)})")
    }
    deviceId = canonicalId

    def device = findDevice(deviceId)
    if (!device) {
        if (_bypassEnabled()) {
            def fj = _fetchDeviceFullJson(deviceId)
            if (fj?.device != null) {
                def label = _bypassDeviceLabel(fj, deviceId)
                // fullJson lists only REPORTED attributes, so a declared-but-unreported attribute
                // reads as "not found" here -- bypass attribute discovery is limited to reported
                // attributes (the message says so), unlike the listed path's supportedAttributes.
                def attrs = _fullJsonAttributeNames(fj)
                if (!attrs.contains(attribute)) {
                    throw new IllegalArgumentException("Attribute '${attribute}' not found among the reported attributes of device '${label}' (allowlist bypass sees only reported attributes). Reported: ${attrs}")
                }
                return [device: label, attribute: attribute, value: _readBypassAttrValueFrom(fj, attribute)]
            }
        }
        throw new IllegalArgumentException("Device not found: ${deviceId}")
    }

    // Capture label before operations to avoid serialization issues
    def deviceLabel = device.label ?: device.name ?: "Device ${deviceId}"

    // Check if attribute exists on this device before reading its value
    def supportedAttrs = device.supportedAttributes?.collect { it.name } ?: []
    if (!supportedAttrs.contains(attribute)) {
        throw new IllegalArgumentException("Attribute '${attribute}' not found on device '${deviceLabel}'. Available: ${supportedAttrs}")
    }

    def value = device.currentValue(attribute)
    return [
        device: deviceLabel,
        attribute: attribute,
        value: value
    ]
}

// Single source of truth for the per-value match logic, shared by the single- and multi-device
// poll paths so they can never diverge. Returns [matched, numeric]: matched is the boolean
// condition result (eq = value in matchSet; ne = a non-null value NOT in matchSet; gt/gte/lt/lte/
// between = numeric, a null/non-numeric value never matches); numeric is true only when THIS value
// parsed as a number under a numeric comparator (false for eq/ne), letting the caller latch the
// per-device sawNumeric signal.
def _evalAttrCondition(value, comparator, matchSet, numericThreshold, betweenLow, betweenHigh) {
    if (comparator == "eq" || comparator == "ne") {
        def inSet = matchSet.contains(value?.toString()) ||
            (value instanceof Number && matchSet.any { it instanceof String && it.isNumber() && (it as BigDecimal) == (value as BigDecimal) }) ||
            (value instanceof String && value.isNumber() && matchSet.any { it instanceof String && it.isNumber() && (it as BigDecimal) == (value as BigDecimal) })
        def matched = (comparator == "eq") ? inSet : (value != null && !inSet)
        return [matched, false]
    }
    def num = _parseBigDecimalOrNull(value)
    if (num == null) {
        return [false, false]   // null/non-numeric never satisfies a numeric comparator
    }
    def matched
    if (comparator == "gt")            matched = num >  numericThreshold
    else if (comparator == "gte")      matched = num >= numericThreshold
    else if (comparator == "lt")       matched = num <  numericThreshold
    else if (comparator == "lte")      matched = num <= numericThreshold
    else if (comparator == "between")  matched = (num >= betweenLow && num <= betweenHigh)
    else throw new IllegalArgumentException("Unsupported comparator: ${comparator}")
    return [matched, true]
}

def toolPollUntilAttribute(args) {
    // 0. Reject unknown args early to surface caller mistakes (e.g., timeoutSeconds vs timeoutMs).
    def validArgKeys = ["deviceId", "deviceIds", "mode", "attribute", "expectedValue", "expectedValues", "timeoutMs", "pollIntervalMs", "comparator", "stableForMs"] as Set
    if (args instanceof Map) {
        def unknownKeys = (args.keySet() - validArgKeys).sort()
        if (unknownKeys) {
            throw new IllegalArgumentException("Unknown arg(s): ${unknownKeys}. Valid args: ${validArgKeys.sort()}. Common gotcha: timeout is 'timeoutMs' in milliseconds, not 'timeoutSeconds'.")
        }
    }

    // 1. Resolve the target device(s). Exactly one of deviceId (single) or deviceIds (multi)
    //    must be present. A present-but-null key is a distinct caller mistake from an omitted
    //    one, so it is rejected with the same null-guard style the rest of this engine uses.
    def hasDeviceId  = args.containsKey("deviceId")  && args.deviceId  != null
    def hasDeviceIds = args.containsKey("deviceIds") && args.deviceIds != null
    if (args.containsKey("deviceId") && args.deviceId == null) {
        throw new IllegalArgumentException("deviceId must not be null (omit the arg or pass a non-empty string)")
    }
    if (args.containsKey("deviceIds") && args.deviceIds == null) {
        throw new IllegalArgumentException("deviceIds must not be null (omit the arg or pass a non-empty list of device IDs)")
    }
    if (hasDeviceId && hasDeviceIds) {
        throw new IllegalArgumentException("provide exactly one of deviceId or deviceIds, not both")
    }
    if (!hasDeviceId && !hasDeviceIds) {
        throw new IllegalArgumentException("deviceId (single device) or deviceIds (a list of device IDs) is required -- provide exactly one")
    }
    def multiDevice = hasDeviceIds

    // Per-device count cap: the poll re-reads every device's state each interval, so the
    // per-interval work scales with the device count -- bound it to keep a blocking poll cheap.
    def MAX_POLL_DEVICES = 20
    def deviceIdList
    if (multiDevice) {
        if (!(args.deviceIds instanceof List) || args.deviceIds.isEmpty()) {
            throw new IllegalArgumentException("deviceIds must be a non-empty list of device-ID strings")
        }
        // A hub device id is numeric, so a caller that sends it as a JSON number is not wrong --
        // coerce to the string form the rest of the engine compares on. Coercing here also makes
        // the duplicate check see 5 and "5" as the same device.
        def coercedIds = []
        args.deviceIds.eachWithIndex { v, i ->
            def id = _canonicalDeviceIdArg(v)
            if (!(id instanceof String) || !id) {
                throw new IllegalArgumentException("deviceIds[${i}] must be a non-empty string, got: ${_describeValueForError(v)}")
            }
            coercedIds << id
        }
        if (coercedIds.size() > MAX_POLL_DEVICES) {
            throw new IllegalArgumentException("deviceIds has ${coercedIds.size()} device IDs -- the cap is ${MAX_POLL_DEVICES} per poll")
        }
        // Reject duplicates: a repeated id would double-count convergedCount and emit duplicate
        // devices[] rows. Each device may appear at most once.
        def dupes = coercedIds.countBy { it }.findAll { k, c -> c > 1 }.keySet().sort()
        if (dupes) {
            throw new IllegalArgumentException("deviceIds contains duplicate entries: ${dupes} -- each device may appear once")
        }
        deviceIdList = coercedIds
    } else {
        // Same Number coercion as the deviceIds branch: a numeric id is not wrong, just unstrung.
        def singleId = _canonicalDeviceIdArg(args.deviceId)
        if (!(singleId instanceof String) || !singleId) {
            throw new IllegalArgumentException("deviceId is required and must be a non-empty string (got: ${_describeValueForError(args.deviceId)})")
        }
        deviceIdList = [singleId]
    }

    // 2. Validate attribute (the same condition applies to every device).
    if (args.containsKey("attribute") && args.attribute == null) {
        throw new IllegalArgumentException("attribute must not be null (omit the arg or pass a non-empty string)")
    }
    if (!(args.attribute instanceof String) || !args.attribute) {
        throw new IllegalArgumentException("attribute is required and must be a non-empty string")
    }

    // Resolve every device up front (a missing ID names WHICH one) and confirm each supports
    // the attribute (fail fast, naming the device that lacks it) -- the same per-device check
    // the single path runs, looped over the resolved set. devices[i] aligns with deviceIdList[i].
    def devices = []
    def deviceLabels = []
    // devices[i] aligns with deviceIdList[i]: the Groovy device for a listed/MCP device, or null
    // for an unlisted device reached via the allowlist bypass. The per-poll read (_readPollValue)
    // is source-agnostic over that pair -- a listed device reads its live currentStates list; a
    // bypass device re-fetches /device/fullJson each poll -- so the converge/timeout/honesty logic
    // below is shared unchanged.
    deviceIdList.each { did ->
        def dev = findDevice(did)
        if (dev) {
            def label = dev.label ?: dev.name ?: "Device ${did}"
            def supportedAttrs = dev.supportedAttributes?.collect { it.name } ?: []
            if (!supportedAttrs.contains(args.attribute)) {
                throw new IllegalArgumentException("Attribute '${args.attribute}' not found on device '${label}'. Available: ${supportedAttrs}")
            }
            devices << dev
            deviceLabels << label
        } else if (_bypassEnabled()) {
            def fj = _fetchDeviceFullJson(did)
            if (fj?.device == null) {
                throw new IllegalArgumentException("Device not found: ${did}")
            }
            def label = _bypassDeviceLabel(fj, did)
            // No attribute-existence check on the bypass path: fullJson lists only reported
            // attributes, so a declared-but-unreported attribute would be wrongly rejected. The
            // per-poll read returns null until the attribute reports, so an unknown/unreported
            // attribute simply times out with neverReported instead of hard-failing.
            devices << null
            deviceLabels << label
        } else {
            throw new IllegalArgumentException("Device not found: ${did}")
        }
    }
    // Single-path label kept for the existing single-device return shape and the read-fault log.
    def deviceLabel = deviceLabels[0]

    // 2b. Validate mode (any/all over deviceIds). Only meaningful with deviceIds; default "all"
    //     (converge when EVERY device matches). "any" converges on the first device to match.
    //     Validate the VALUE before the single-deviceId reject so an invalid value surfaces as
    //     "must be one of [any, all]" rather than being masked by the deviceIds-only message.
    def validModes = ["any", "all"]
    if (args.containsKey("mode") && args.mode == null) {
        throw new IllegalArgumentException("mode must not be null (omit the arg to use the default \"all\")")
    }
    if (args.mode != null && !(args.mode instanceof String && validModes.contains(args.mode))) {
        throw new IllegalArgumentException("mode must be one of ${validModes} (got: ${_describeValueForError(args.mode)})")
    }
    if (args.mode != null && !multiDevice) {
        throw new IllegalArgumentException("mode applies only to deviceIds (multi-device polling); omit it for a single deviceId")
    }
    def mode = (args.mode != null) ? args.mode : "all"

    // 3. Validate expectedValue / expectedValues (at least one required)
    if (args.containsKey("expectedValue") && args.expectedValue == null) {
        throw new IllegalArgumentException("expectedValue must not be null (omit the arg or pass a non-empty string)")
    }
    if (args.containsKey("expectedValues") && args.expectedValues == null) {
        throw new IllegalArgumentException("expectedValues must not be null (omit the arg or pass a non-empty list)")
    }
    def hasExpectedValue  = (args.expectedValue  != null)
    def hasExpectedValues = (args.expectedValues != null)
    // Exactly-one, the same rule _buildWaitForPollArgs enforces on the waitFor pre-fire path: a
    // numeric comparator takes only expectedValue, between takes only expectedValues, eq/ne take
    // one or the other -- never both. The two checks share intent, not identical messages: the
    // waitFor path prefixes "waitFor." and keys on containsKey (presence of the key), while this
    // engine path keys on != null (a key present-but-null is rejected earlier above as "must not
    // be null"), so {expectedValue:'x', expectedValues:null} reaches the both-set check on the
    // waitFor path but the null-reject here. Aligned for valid specs; the edge messages differ.
    if (hasExpectedValue && hasExpectedValues) {
        throw new IllegalArgumentException("provide exactly one of expectedValue or expectedValues, not both")
    }
    if (!hasExpectedValue && !hasExpectedValues) {
        throw new IllegalArgumentException("At least one of expectedValue or expectedValues must be provided")
    }
    if (hasExpectedValue && !(args.expectedValue instanceof String)) {
        throw new IllegalArgumentException("expectedValue must be a string")
    }
    if (hasExpectedValue && args.expectedValue == "") {
        throw new IllegalArgumentException("expectedValue must not be empty (omit the arg or pass a non-empty value)")
    }
    if (hasExpectedValues) {
        if (!(args.expectedValues instanceof List)) {
            throw new IllegalArgumentException("expectedValues must be a list of strings")
        }
        if (args.expectedValues.isEmpty()) {
            throw new IllegalArgumentException("expectedValues must not be empty (omit the arg or pass at least one value)")
        }
        args.expectedValues.eachWithIndex { v, i ->
            if (!(v instanceof String)) {
                throw new IllegalArgumentException("expectedValues[${i}] must be a string, got: ${_describeValueForError(v)}")
            }
        }
    }

    // 4. Validate timeoutMs.
    // Range [100,60000] for this standalone engine path. _buildWaitForPollArgs uses a STRICTER
    // [100,30000] on the command-flow waitFor path -- this divergence is INTENTIONAL, not a
    // drift: a waitFor poll pins a hub thread for the full timeout, so its pre-fire cap is lower.
    if (args.containsKey("timeoutMs") && args.timeoutMs == null) {
        throw new IllegalArgumentException("timeoutMs must not be null (omit the arg to use default 5000ms)")
    }
    def timeoutMs = (args.timeoutMs != null) ? args.timeoutMs : 5000
    if (!(timeoutMs instanceof Number)) {
        throw new IllegalArgumentException("timeoutMs must be an integer (got: ${timeoutMs})")
    }
    timeoutMs = timeoutMs as Integer
    if (timeoutMs < 100 || timeoutMs > 60000) {
        throw new IllegalArgumentException("timeoutMs must be between 100 and 60000 (got: ${timeoutMs})")
    }

    // 5. Validate pollIntervalMs, clamp to timeoutMs if larger.
    // Range [50,5000]: _buildWaitForPollArgs uses the SAME bounds on its pre-fire path
    // (unlike timeoutMs, the pollIntervalMs range is intentionally identical) -- keep aligned.
    if (args.containsKey("pollIntervalMs") && args.pollIntervalMs == null) {
        throw new IllegalArgumentException("pollIntervalMs must not be null (omit the arg to use default 200ms)")
    }
    def pollIntervalMs = (args.pollIntervalMs != null) ? args.pollIntervalMs : 200
    if (!(pollIntervalMs instanceof Number)) {
        throw new IllegalArgumentException("pollIntervalMs must be an integer (got: ${pollIntervalMs})")
    }
    pollIntervalMs = pollIntervalMs as Integer
    if (pollIntervalMs < 50 || pollIntervalMs > 5000) {
        throw new IllegalArgumentException("pollIntervalMs must be between 50 and 5000 (got: ${pollIntervalMs})")
    }
    // Clamp poll interval so at least one poll is possible within the timeout
    if (pollIntervalMs > timeoutMs) {
        pollIntervalMs = timeoutMs
    }

    // 5b. Validate comparator (default "eq") and its expectedValue/expectedValues shape.
    //   - eq/ne: string-set semantics (existing expectedValue/expectedValues validation above).
    //   - gt/gte/lt/lte: numeric, single threshold from expectedValue; expectedValues is rejected.
    //   - between: numeric inclusive, two bounds from expectedValues (exactly 2); expectedValue rejected.
    if (args.containsKey("comparator") && args.comparator == null) {
        throw new IllegalArgumentException("comparator must not be null (omit the arg to use the default \"eq\")")
    }
    def validComparators = ["eq", "ne", "gt", "gte", "lt", "lte", "between"]
    def comparator = (args.comparator != null) ? args.comparator : "eq"
    if (!(comparator instanceof String) || !validComparators.contains(comparator)) {
        throw new IllegalArgumentException("comparator must be one of ${validComparators} (got: ${_describeValueForError(args.comparator)})")
    }
    def numericComparators = ["gt", "gte", "lt", "lte"] as Set
    def numericThreshold = null
    def betweenLow = null
    def betweenHigh = null
    if (numericComparators.contains(comparator)) {
        if (hasExpectedValues) {
            throw new IllegalArgumentException("comparator '${comparator}' takes a single numeric threshold via expectedValue, not expectedValues")
        }
        numericThreshold = _parseBigDecimalOrNull(args.expectedValue)
        if (numericThreshold == null) {
            throw new IllegalArgumentException("comparator '${comparator}' requires expectedValue to be a numeric-parseable string (got: ${_describeValueForError(args.expectedValue)})")
        }
    } else if (comparator == "between") {
        if (hasExpectedValue) {
            throw new IllegalArgumentException("comparator 'between' takes two numeric bounds via expectedValues, not expectedValue")
        }
        if (args.expectedValues.size() != 2) {
            throw new IllegalArgumentException("comparator 'between' requires expectedValues to have exactly 2 numeric bounds [low, high] (got ${args.expectedValues.size()})")
        }
        betweenLow  = _parseBigDecimalOrNull(args.expectedValues[0])
        betweenHigh = _parseBigDecimalOrNull(args.expectedValues[1])
        if (betweenLow == null || betweenHigh == null) {
            throw new IllegalArgumentException("comparator 'between' requires both expectedValues bounds to be numeric-parseable strings (got: ${args.expectedValues})")
        }
        if (betweenLow > betweenHigh) {
            throw new IllegalArgumentException("comparator 'between' requires low <= high (got low=${args.expectedValues[0]}, high=${args.expectedValues[1]})")
        }
    }

    // 5c. Validate stableForMs (debounce, default 0): the matched condition must hold
    //   continuously for this many ms before converging. Bounded [0, timeoutMs): a value
    //   >= timeoutMs could never converge, so it is rejected pre-poll rather than silently
    //   guaranteeing a timeout.
    if (args.containsKey("stableForMs") && args.stableForMs == null) {
        throw new IllegalArgumentException("stableForMs must not be null (omit the arg to use default 0)")
    }
    def stableForMs = (args.stableForMs != null) ? args.stableForMs : 0
    if (!(stableForMs instanceof Number)) {
        throw new IllegalArgumentException("stableForMs must be an integer (got: ${_describeValueForError(args.stableForMs)})")
    }
    stableForMs = stableForMs as Integer
    if (stableForMs < 0) {
        throw new IllegalArgumentException("stableForMs must be >= 0 (got: ${stableForMs})")
    }
    if (stableForMs >= timeoutMs) {
        throw new IllegalArgumentException("stableForMs (${stableForMs}) must be less than timeoutMs (${timeoutMs}) -- the condition could never hold long enough to converge")
    }

    // 6. Build the expected-value set for match checking (eq/ne comparators only). Exactly one
    //    of the two is present (enforced above), so this populates from whichever was supplied;
    //    a multi-element expectedValues set is OR (match any member).
    def matchSet = [] as Set
    if (hasExpectedValue)  matchSet << args.expectedValue
    if (hasExpectedValues) matchSet.addAll(args.expectedValues)

    // 6b. Multi-device poll: await the mode predicate (any/all) across every device, the SAME
    //     condition applied to each. The aggregate predicate drives the debounce window and the
    //     converge/timeout return -- the same control flow as the single path, just predicate-
    //     over-devices instead of one value. Returns early; the single-device loop below is the
    //     unchanged deviceId path.
    if (multiDevice) {
        return _pollMultiDevice(args, devices, deviceLabels, deviceIdList, mode, comparator,
                                matchSet, numericThreshold, betweenLow, betweenHigh,
                                timeoutMs, pollIntervalMs, stableForMs)
    }

    // 7. Poll loop.
    //    Two termination guards:
    //      (a) wall-clock: elapsedMs >= timeoutMs  (primary, production path)
    //      (b) poll count: polledCount >= maxPolls  (safety net; also the test path
    //          since now() is fixed in the test harness making elapsedMs always 0)
    //    Both guards produce the same timedOut=true result. maxPolls is the number
    //    of polls that would fit in timeoutMs at the configured pollIntervalMs, plus
    //    one to account for the initial read before the first sleep.
    def maxPolls    = ((timeoutMs / pollIntervalMs) as Integer) + 1
    def startMs     = now()
    def polledCount = 0
    def finalValue  = null
    // Track whether the attribute ever reported a non-null value during the poll window.
    // Null throughout the window means the driver has never reported the attribute,
    // which is a different condition from "reported a wrong value the whole time."
    def everNonNull = false
    // Track whether the attribute's non-null value CHANGED across polls. On a timeout, this
    // distinguishes "value was still moving between reads (likely still settling)" from "value
    // was stable at a non-target (a real mismatch)". Best-effort: only reliable when the timeout
    // spans at least one of the device's reporting jumps -- at a short timeout a stable-but-wrong
    // intermediate reads transitioning:false even though the device is physically still settling.
    def sawChange      = false
    def lastNonNull    = null
    // Track whether any poll under a NUMERIC comparator parsed the attribute to a number.
    // If the attribute reported a value the whole window but it never parsed numeric, the
    // comparator can NEVER match it (e.g. gt 5 on switch="on") -- a distinct timeout cause
    // from "reported numbers but never crossed the threshold." Surfaced as nonNumericAttribute
    // on the timeout return. Only meaningful for the numeric comparators.
    def sawNumeric     = false
    // Latches true if any poll's per-device read threw (e.g. the device was removed mid-poll, so
    // currentStates faults). A read fault degrades that tick to an unread (null) value rather than
    // aborting the whole poll, and surfaces as readError on the return so the caller knows the
    // value is unreliable -- it is not silently indistinguishable from a never-reported attribute.
    def sawReadError   = false
    // Debounce tracking: the poll-clock time the match condition first became true in the
    // current contiguous run. Reset to null on any poll where the condition is false, so a
    // value that flaps out of range restarts the stability window. null while the condition is
    // not currently held; once held it is set even when stableForMs==0 (it is set, then the
    // >= stableForMs check is immediately satisfied on that same poll, so the engine converges).
    def conditionTrueSince = null

    while (true) {
        // Read the FRESH event store via currentStates (the LIST), not currentValue() OR
        // currentState(attr). currentValue() AND currentState(attr) are BOTH cached at request
        // start and never refresh within a request, so on a real async device (Matter/Zigbee/
        // Z-Wave/cloud) they return the PRE-command value for the whole poll and never converge
        // (confirmed on real hardware). Only device.currentStates (the full list) re-reads live --
        // the same source the snapshot's PRIMARY (currentStates-present) branch reads, so the
        // value here matches that snapshot path (the snapshot's currentValue FALLBACK branch only
        // runs when currentStates is empty). find(...) is null until the attribute has reported;
        // a State's .value is the reported value (a String in Hubitat).
        try {
            finalValue = _readPollValue(devices[0], deviceIdList[0], args.attribute)
        } catch (Exception e) {
            // A per-device read fault (e.g. the device was removed after up-front resolution)
            // must degrade this tick to an unread value, not abort the poll. Treat as null so
            // this poll does not match; latch readError for the return.
            finalValue = null
            if (!sawReadError) mcpLog("warn", "device", "poll_until_attribute read failed for '${deviceLabel}' on poll ${polledCount + 1}: ${e.message ?: e.toString()}")
            sawReadError = true
        }
        polledCount++
        if (finalValue != null) {
            everNonNull = true
            // Compare on the String form (a State's value is a String) to detect movement.
            def cur = finalValue.toString()
            if (lastNonNull != null && cur != lastNonNull) sawChange = true
            lastNonNull = cur
        }
        def elapsedMs = (now() - startMs) as Integer

        // Evaluate the match condition for this poll under the active comparator (shared with
        // the multi-device path so the two can never diverge). _evalAttrCondition returns
        // [matched, numeric]: numeric latches sawNumeric for the nonNumericAttribute timeout
        // signal under a numeric comparator. See _evalAttrCondition for the per-comparator rules.
        def evalResult = _evalAttrCondition(finalValue, comparator, matchSet, numericThreshold, betweenLow, betweenHigh)
        def condition = evalResult[0]
        if (evalResult[1]) sawNumeric = true   // evalResult[1] = parsed-numeric flag

        // Debounce: converge only once the condition has held continuously for stableForMs.
        // With stableForMs==0 this returns on the first poll the condition holds (today's
        // behavior). conditionTrueSince anchors the start of the current contiguous run; any
        // poll where the condition is false clears it so a flapping value restarts the window.
        if (condition) {
            if (conditionTrueSince == null) conditionTrueSince = now()
            if ((now() - conditionTrueSince) >= stableForMs) {
                def okResponse = [
                    success     : true,
                    finalValue  : finalValue,
                    elapsedMs   : elapsedMs,
                    polledCount : polledCount,
                    timedOut    : false
                ]
                // A read fault earlier in the window did not prevent convergence, but the value
                // was unreliable at least once -- surface it so the caller knows.
                if (sawReadError) okResponse.readError = true
                return okResponse
            }
        } else {
            conditionTrueSince = null
        }

        if (elapsedMs >= timeoutMs || polledCount >= maxPolls) {
            def response = [
                success     : false,
                finalValue  : finalValue,
                elapsedMs   : elapsedMs,
                polledCount : polledCount,
                timedOut    : true,
                // TIMEOUT-only honest signal: true if the value was still moving across polls
                // (>=2 distinct non-null values seen), so the caller can tell a slow-reporting
                // device that is likely still settling from a stable real mismatch. Best-effort
                // (see sawChange declaration). Deliberately omitted from the success path.
                transitioning : sawChange
            ]
            // A per-device read threw at least once during the window (e.g. the device was
            // removed mid-poll). The value is unreliable; surface it distinctly from a
            // never-reported attribute.
            if (sawReadError) response.readError = true
            // Attribute exists in supportedAttributes but never reported a value during
            // the entire poll window -- driver has not yet emitted a reading.
            if (!everNonNull) response.neverReported = true
            // Numeric comparator on an attribute that DID report but never parsed numeric:
            // the comparator can never match it (e.g. gt 5 on switch="on"). Distinct from
            // neverReported (a numeric comparator on a never-reported attribute is neverReported,
            // not this) -- the everNonNull && !sawNumeric pair separates the two causes.
            if (comparator != "eq" && comparator != "ne" && everNonNull && !sawNumeric) {
                response.nonNumericAttribute = true
                response.note = "comparator '${comparator}' can never match attribute '${args.attribute}' -- it reported a non-numeric value the whole window (use eq/ne for a string attribute)".toString()
                // "can never match" supersedes "still settling": a flapping non-numeric value
                // would set transitioning=true (sawChange), which reads as "retry/wait" and
                // contradicts nonNumericAttribute. Force it false so the signals agree.
                response.transitioning = false
            }
            return response
        }

        // Sleep for the poll interval (or the remaining time, whichever is less)
        def remaining = timeoutMs - elapsedMs
        def sleepMs   = Math.min(pollIntervalMs, remaining > 0 ? remaining : pollIntervalMs) as Integer
        try {
            if (sleepMs > 0) pauseExecution(sleepMs)
        } catch (InterruptedException e) {
            // pauseExecution wraps Thread.sleep() and throws InterruptedException
            // when the hub is restarting or the app is being reloaded.
            elapsedMs = (now() - startMs) as Integer
            mcpLog("warn", "device", "poll_until_attribute interrupted after ${polledCount} poll(s) (elapsed=${elapsedMs}ms): ${e.message}")
            def intResponse = [
                success     : false,
                interrupted : true,
                finalValue  : finalValue,
                elapsedMs   : elapsedMs,
                polledCount : polledCount
            ]
            if (sawReadError) intResponse.readError = true
            return intResponse
        }
    }
}

// Read the current value of `attribute` for one poll slot. Source-agnostic over the
// (device, deviceId) pair the caller resolved up front:
//   - listed/MCP device (dev != null) -> the live currentStates LIST. NOT currentValue() or
//     currentState(attr): both are request-cached at request start and never refresh within a
//     request, so on a real async device they return the pre-command value and never converge.
//     Only device.currentStates re-reads live; a State's .value is the reported value (a String).
//   - bypass device (dev == null) -> re-fetch /device/fullJson each poll via _readBypassAttrValue.
private _readPollValue(dev, deviceId, attribute) {
    return (dev != null)
        ? dev.currentStates?.find { it.name == attribute }?.value
        : _readBypassAttrValue(deviceId, attribute)
}

// Multi-device poll: await the mode predicate (any/all) across devices, the SAME condition
// applied to each. Mirrors the single-device loop's control flow -- aggregate predicate drives
// the stableForMs debounce window and the converge/timeout return -- but reports a compact
// per-device result array (never full device objects). everNonNull / sawNumeric / sawChange are
// tracked PER DEVICE so the timeout result can name which devices never reported / are non-numeric
// / are still transitioning. Called only from toolPollUntilAttribute after validation; all args
// are pre-validated there.
def _pollMultiDevice(args, devices, deviceLabels, deviceIdList, mode, comparator,
                     matchSet, numericThreshold, betweenLow, betweenHigh,
                     timeoutMs, pollIntervalMs, stableForMs) {
    // Defense-in-depth for this private helper: the caller already validates these, so this is
    // a no-op for valid input -- it just guards against a 0/null reaching the maxPolls divide.
    // Defaults match the single-device path.
    timeoutMs      = (timeoutMs && timeoutMs > 0) ? timeoutMs : 5000
    pollIntervalMs = (pollIntervalMs && pollIntervalMs > 0) ? pollIntervalMs : 200
    stableForMs    = (stableForMs && stableForMs > 0) ? stableForMs : 0
    def n           = devices.size()
    def maxPolls    = ((timeoutMs / pollIntervalMs) as Integer) + 1
    def startMs     = now()
    def polledCount = 0
    // Per-device honesty tracking, index-aligned with devices/deviceIdList/deviceLabels.
    def everNonNull = (0..<n).collect { false }
    def sawNumeric  = (0..<n).collect { false }
    def sawChange   = (0..<n).collect { false }
    def lastNonNull = (0..<n).collect { null }
    def finalValue  = (0..<n).collect { null }
    def matched     = (0..<n).collect { false }
    // Latches per device if its read threw on any poll (e.g. removed mid-poll). A read fault on
    // one device degrades only THAT device's tick to an unread value -- the poll continues and
    // every other device's converged/honest state is still returned, never discarded by a throw.
    def sawReadError = (0..<n).collect { false }
    // Aggregate-debounce anchor: the whole any/all predicate must hold continuously for stableForMs.
    def conditionTrueSince = null

    while (true) {
        // Read EVERY device's live event store (currentStates, the list -- the same freshness
        // reasoning as the single path: currentValue()/currentState(attr) are request-cached and
        // never refresh on a real async device, so they would never converge).
        for (int i = 0; i < n; i++) {
            def v
            try {
                v = _readPollValue(devices[i], deviceIdList[i], args.attribute)
            } catch (Exception e) {
                // Degrade only this device's tick to an unread (null) value; the loop continues
                // so the other devices' honest state is preserved. Latch readError for this device.
                v = null
                if (!sawReadError[i]) mcpLog("warn", "device", "poll_until_attribute (multi-device) read failed for '${deviceLabels[i]}' on poll ${polledCount + 1}: ${e.message ?: e.toString()}")
                sawReadError[i] = true
            }
            finalValue[i] = v
            if (v != null) {
                everNonNull[i] = true
                def cur = v.toString()
                if (lastNonNull[i] != null && cur != lastNonNull[i]) sawChange[i] = true
                lastNonNull[i] = cur
            }
            def evalResult = _evalAttrCondition(v, comparator, matchSet, numericThreshold, betweenLow, betweenHigh)
            if (evalResult[1]) sawNumeric[i] = true   // evalResult[1] = parsed-numeric flag
            matched[i] = evalResult[0]
        }
        polledCount++
        def elapsedMs = (now() - startMs) as Integer

        // mode predicate: any = at least one device matched; all = every device matched.
        def convergedCount = matched.count { it }
        def aggregate = (mode == "any") ? (convergedCount > 0) : (convergedCount == n)

        // Debounce the AGGREGATE predicate: the whole any/all condition must hold continuously
        // for stableForMs before converging. A poll where it is false clears the anchor, so a
        // value that flaps out of the condition on any device restarts the window.
        if (aggregate) {
            if (conditionTrueSince == null) conditionTrueSince = now()
            if ((now() - conditionTrueSince) >= stableForMs) {
                return [
                    success        : true,
                    mode           : mode,
                    devices        : (0..<n).collect { i ->
                        def entry = [
                            deviceId  : deviceIdList[i],
                            device    : deviceLabels[i],
                            finalValue: finalValue[i],
                            matched   : matched[i]
                        ]
                        // A read fault on this device did not block aggregate convergence, but
                        // its value was unreliable at least once -- surface it.
                        if (sawReadError[i]) entry.readError = true
                        entry
                    },
                    convergedCount : convergedCount,
                    elapsedMs      : elapsedMs,
                    polledCount    : polledCount,
                    timedOut       : false
                ]
            }
        } else {
            conditionTrueSince = null
        }

        if (elapsedMs >= timeoutMs || polledCount >= maxPolls) {
            def numericComparator = (comparator != "eq" && comparator != "ne")
            def nonNumericCount = 0
            def anyTransitioning = false
            def deviceResults = (0..<n).collect { i ->
                def entry = [
                    deviceId  : deviceIdList[i],
                    device    : deviceLabels[i],
                    finalValue: finalValue[i],
                    matched   : matched[i]
                ]
                // TIMEOUT-only per-device honesty signals, only where true.
                if (sawReadError[i]) entry.readError = true
                if (!everNonNull[i]) entry.neverReported = true
                // Numeric comparator on an attribute that reported but never parsed numeric:
                // it can never match (distinct from neverReported -- the everNonNull && !sawNumeric
                // pair separates the two), so it supersedes a transitioning signal for that device.
                def deviceNonNumeric = numericComparator && everNonNull[i] && !sawNumeric[i]
                if (deviceNonNumeric) {
                    entry.nonNumericAttribute = true
                    nonNumericCount++
                } else if (sawChange[i]) {
                    anyTransitioning = true
                }
                entry
            }
            def response = [
                success        : false,
                mode           : mode,
                devices        : deviceResults,
                convergedCount : convergedCount,
                elapsedMs      : elapsedMs,
                polledCount    : polledCount,
                timedOut       : true,
                // Aggregate still-settling signal: at least one device was still moving (and is
                // not a can-never-match non-numeric). false when no device changed OR every change
                // was a non-numeric flap (which reads as can-never-match, not retry/wait).
                transitioning  : anyTransitioning
            ]
            // Aggregate guidance present only when >=1 device is can-never-match non-numeric.
            // Count-aware (the signal fires for >=1 device), no redundant .toString() (the
            // single-device note doesn't have one -- the GString coerces on map insertion).
            if (nonNumericCount > 0) {
                response.note = "comparator '${comparator}' can never match attribute '${args.attribute}' on ${nonNumericCount} device(s) that reported a non-numeric value the whole window (use eq/ne for a string attribute)"
            }
            return response
        }

        def remaining = timeoutMs - elapsedMs
        def sleepMs   = Math.min(pollIntervalMs, remaining > 0 ? remaining : pollIntervalMs) as Integer
        try {
            if (sleepMs > 0) pauseExecution(sleepMs)
        } catch (InterruptedException e) {
            elapsedMs = (now() - startMs) as Integer
            mcpLog("warn", "device", "poll_until_attribute (multi-device, ${n}) interrupted after ${polledCount} poll(s) (elapsed=${elapsedMs}ms): ${e.message}")
            return [
                success        : false,
                interrupted    : true,
                mode           : mode,
                devices        : (0..<n).collect { i ->
                    def entry = [
                        deviceId  : deviceIdList[i],
                        device    : deviceLabels[i],
                        finalValue: finalValue[i],
                        matched   : matched[i]
                    ]
                    if (sawReadError[i]) entry.readError = true
                    entry
                },
                convergedCount : matched.count { it },
                elapsedMs      : elapsedMs,
                polledCount    : polledCount
            ]
        }
    }
}

// Resolve the history window start. `since` (absolute bookmark -- ISO-8601 in the
// same format this tool emits in `date`/`sinceTimestamp`, or epoch milliseconds)
// takes precedence over `hoursBack` (relative) when both are supplied. Returns
// [sinceDate, sinceMode, effectiveHoursBack, sinceEcho]: sinceMode is "explicit"
// when `since` drove the window (effectiveHoursBack null -- it did not bound
// anything) or "relative" when hoursBack did. sinceEcho (explicit mode only) is
// the value to surface back to the caller: the caller's String verbatim (so a
// round-tripped ISO bookmark comes back byte-for-byte, not reformatted into the
// JVM-local TZ), or canonical ISO when the caller passed epoch-ms (keeps the echo
// a presentable string regardless of input type). An unparseable `since` is a
// caller error.
def _resolveSinceWindow(args, hoursBack) {
    if (args.since == null) {
        return [new Date(now() - (hoursBack * 3600000L)), "relative", hoursBack, null]
    }
    def parsed = _parseSinceArg(args.since)
    if (parsed == null) {
        throw new IllegalArgumentException("since is not a valid timestamp: '${args.since}'. " +
            "Use the same ISO-8601 form this tool emits in 'date'/'sinceTimestamp' -- a NUMERIC " +
            "offset, e.g. 2026-06-23T10:00:00.000-0600 or -06:00 (a trailing 'Z' for UTC and a " +
            "millis-less variant are also accepted), or epoch milliseconds (an integer).")
    }
    // Echo a real ISO bookmark String verbatim (the round-trip case, trimmed so a
    // space-padded input does not echo back contaminated); format any epoch-ms input
    // -- Number OR all-digit String -- into canonical ISO so the echo is always a
    // presentable timestamp, never raw digits.
    def echo = (args.since instanceof Number || args.since.toString().trim().isLong()) ?
        parsed.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ") : args.since.toString().trim()
    return [parsed, "explicit", null, echo]
}

// Parse a `since` arg to a Date, or null if unparseable. Accepts epoch milliseconds
// (Number or all-digit String) and ISO-8601 strings -- the canonical round-trip
// format and a cheap millis-less variant, each with a numeric offset in either the
// colon-less (-0600) or colon (-06:00) spelling. A trailing 'Z' (Zulu/UTC) is
// normalized to +0000 first so it parses as UTC, not the hub's local zone. The
// 2-arg Date.parse(format, str) overload is sandbox-allowed (unlike
// Date.format(String, Locale)).
def _parseSinceArg(since) {
    if (since instanceof Number) {
        return new Date(since.toLong())
    }
    def s = since.toString().trim()
    if (s.isEmpty()) return null
    if (s.isLong()) return new Date(s.toLong())
    // Z means UTC -- swap it for the equivalent numeric offset so the offset-bearing
    // formats below interpret the wall-clock as UTC rather than hub-local.
    if (s.endsWith("Z")) s = s.substring(0, s.length() - 1) + "+0000"
    def formats = [
        "yyyy-MM-dd'T'HH:mm:ss.SSSZ",   // canonical round-trip: 2026-06-23T10:00:00.000-0600
        "yyyy-MM-dd'T'HH:mm:ssZ",       // no millis, offset:    2026-06-23T10:00:00-0600
        // Colon-bearing offsets (2026-06-23T10:00:00-06:00) -- the XXX form
        // formatLastActivity emits, so a lastActivity value round-trips into
        // changedSince on a non-UTC hub.
        "yyyy-MM-dd'T'HH:mm:ss.SSSXXX",
        "yyyy-MM-dd'T'HH:mm:ssXXX",
    ]
    // NOTE: Date.parse() is backed by a lenient SimpleDateFormat, so a structurally-valid
    // but out-of-range field (e.g. month 13) parses to a rolled-over date rather than
    // failing here -- a malformed bookmark shifts the window instead of erroring. Callers
    // should round-trip the emitted 'date'/'sinceTimestamp' strings, which are always valid.
    for (fmt in formats) {
        // probe-parse: any exception means this format didn't match -- try the next
        try { return Date.parse(fmt, s) } catch (Exception ignored) {}
    }
    return null
}

def toolGetDeviceHistory(args) {
    def hoursBack = Math.min(args.hoursBack ?: 24, 168)
    def limit = Math.min(args.limit ?: 100, 500)
    def attributeFilter = args.attribute
    def (sinceDate, sinceMode, effectiveHoursBack, sinceEcho) = _resolveSinceWindow(args, hoursBack)

    // App-scope branch: events an installed app/rule emitted, read from the same
    // endpoint the admin UI's per-app Events page uses. The endpoint takes no
    // query params and its row cap is server-side, so attribute/hoursBack/limit
    // are applied client-side exactly like the location branch below -- limit
    // enforced while collecting so an oversized event store can't balloon the
    // response. Rows carry {name, value, descriptionText, date}.
    if (args.appId != null) {
        def appIdStr = args.appId.toString().trim()
        if (!appIdStr.isInteger()) {
            throw new IllegalArgumentException("appId must be numeric: ${appIdStr}")
        }
        def rawJson
        try {
            rawJson = hubInternalGet("/installedapp/eventsJson/${appIdStr}")
        } catch (Exception e) {
            mcpLogError("monitoring", "/installedapp/eventsJson/${appIdStr} fetch failed", e)
            return [success: false, error: "App event history fetch failed: ${e.message}", source: "app", appId: appIdStr as Integer,
                    note: "Likely a transient hub blip -- retry. Verify the appId with hub_list_apps if it persists."]
        }
        def appRows
        try {
            def parsed = new groovy.json.JsonSlurper().parseText(rawJson?.toString() ?: "[]")
            appRows = (parsed instanceof List) ? parsed : []
        } catch (Exception e) {
            mcpLogError("monitoring", "/installedapp/eventsJson/${appIdStr} parse failed", e)
            return [success: false, error: "App event history parse failed: ${e.message}", source: "app", appId: appIdStr as Integer,
                    note: "Retry; if persistent, firmware may have changed the /installedapp/eventsJson format -- report with hub_report_issue."]
        }

        def appResults = []
        def timeFilterUnparseable = 0
        for (evt in appRows) {
            if (!(evt instanceof Map)) continue
            if (attributeFilter && evt.name != attributeFilter) continue
            // Strictly-after window, mirroring the location branch: drop events at or
            // before sinceDate when the date parses (so re-passing a returned `date`
            // as `since` never replays that same event); keep rows whose date doesn't
            // parse (don't silently lose history), counting them so the caller can see
            // the window was not fully enforced.
            def evtDate = null
            try { evtDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSSZ", evt.date?.toString()) }
            catch (Exception ignored) { timeFilterUnparseable++ }
            // Strictly-after (exclusive) -- uniform across relative and explicit windows so a
            // returned `date` fed back as `since` never replays itself. At the exact-millisecond
            // boundary this is a deliberate tightening from the prior inclusive behaviour.
            if (evtDate != null && !evtDate.after(sinceDate)) continue
            appResults << [
                name: evt.name,
                value: evt.value,
                description: evt.descriptionText,
                date: evt.date
            ]
            if (appResults.size() >= limit) break
        }

        mcpLog("info", "monitoring", "Retrieved ${appResults.size()} app history event${appResults.size() == 1 ? '' : 's'} for app ${appIdStr} (${sinceMode} window since ${sinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")}) from /installedapp/eventsJson")
        def appResult = [
            source: "app",
            appId: appIdStr as Integer,
            attributeFilter: attributeFilter,
            events: appResults,
            count: appResults.size(),
            sinceMode: sinceMode,
            sinceTimestamp: sinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
        ]
        // Echo only the field that actually bounded the window: hoursBack for a
        // relative window, the verbatim caller bookmark for an absolute one. Mixing
        // both would imply hoursBack bounded the result when `since` did.
        if (sinceMode == "relative") appResult.hoursBack = effectiveHoursBack
        else appResult.since = sinceEcho
        // Mirror the hub-log path: surface rows that escaped the time window
        // because their date would not parse (the window is always active here).
        if (timeFilterUnparseable > 0) appResult.timeFilterUnparseable = timeFilterUnparseable
        return appResult
    }

    // Location-scope branch: when deviceId is omitted, return location history
    // (mode / HSM / hub-variable / sunrise-sunset / system events). There is NO
    // Groovy accessor for this -- neither location.eventsSince(Date, Map) nor
    // getLocationEventsSince(Date) exist on the hub (both NoSuchMethod live). The
    // hub's own Logs page reads it from /logs/eventsJson (per the hub2 frontend),
    // so we hit the same endpoint and parse it. Each row is
    // {name, value, unit, descriptionText, isStateChange, type, date(ISO+offset)}.
    if (!args.deviceId) {
        def rawJson
        try {
            rawJson = hubInternalGet("/logs/eventsJson")
        } catch (Exception e) {
            mcpLogError("monitoring", "/logs/eventsJson fetch failed", e)
            return [success: false, error: "Location event history fetch failed: ${e.message}", source: "location",
                    note: "Likely a transient hub blip (the same endpoint feeds the hub's Logs page) -- retry."]
        }
        def rows
        try {
            def parsed = new groovy.json.JsonSlurper().parseText(rawJson?.toString() ?: "[]")
            rows = (parsed instanceof List) ? parsed : []
        } catch (Exception e) {
            mcpLogError("monitoring", "/logs/eventsJson parse failed", e)
            return [success: false, error: "Location event history parse failed: ${e.message}", source: "location",
                    note: "Retry; if persistent, firmware may have changed the /logs/eventsJson format -- report with hub_report_issue."]
        }

        def locResults = []
        def timeFilterUnparseable = 0
        for (evt in rows) {
            if (!(evt instanceof Map)) continue
            if (attributeFilter && evt.name != attributeFilter) continue
            // Strictly-after window: drop events at or before sinceDate when the
            // ISO+offset date parses (so re-passing a returned `date` as `since` never
            // replays that same event); keep rows whose date doesn't parse (don't
            // silently lose history), counting them. The numeric offset (e.g. -0400)
            // parses via the 'Z' pattern.
            def evtDate = null
            try { evtDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSSZ", evt.date?.toString()) }
            catch (Exception ignored) { timeFilterUnparseable++ }
            if (evtDate != null && !evtDate.after(sinceDate)) continue
            locResults << [
                name: evt.name,
                value: evt.value,
                unit: evt.unit,
                description: evt.descriptionText,
                date: evt.date,
                type: evt.type,
                isStateChange: evt.isStateChange
            ]
            if (locResults.size() >= limit) break
        }

        mcpLog("info", "monitoring", "Retrieved ${locResults.size()} location history event${locResults.size() == 1 ? '' : 's'} (${sinceMode} window since ${sinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")}) from /logs/eventsJson")
        def locResult = [
            source: "location",
            attributeFilter: attributeFilter,
            events: locResults,
            count: locResults.size(),
            sinceMode: sinceMode,
            sinceTimestamp: sinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
        ]
        if (sinceMode == "relative") locResult.hoursBack = effectiveHoursBack
        else locResult.since = sinceEcho
        // Mirror the hub-log path: surface rows that escaped the always-active
        // time window because their date would not parse.
        if (timeFilterUnparseable > 0) locResult.timeFilterUnparseable = timeFilterUnparseable
        return locResult
    }

    def device = findDevice(args.deviceId)
    if (!device) {
        // Allowlist bypass: read an unlisted device's windowed history from /device/eventsJson with
        // the SAME client-side attribute/strictly-after/limit filtering the app + location branches
        // use (no Groovy eventsSince available). The appId and location branches above are not
        // device-allowlist-gated, so only this device branch gains the fallback.
        if (_bypassEnabled()) {
            def fj = _fetchDeviceFullJson(args.deviceId)
            if (fj?.device != null) {
                return _deviceHistoryBypass(args, fj, sinceDate, sinceMode, effectiveHoursBack, sinceEcho, attributeFilter, limit)
            }
        }
        throw new IllegalArgumentException("Device not found: ${args.deviceId}. Device must be selected in MCP Rule Server app settings.")
    }

    def deviceLabel = device.label ?: device.name ?: "Device ${args.deviceId}"

    def events
    try {
        events = device.eventsSince(sinceDate, [max: limit])
    } catch (Exception e) {
        mcpLogError("monitoring", "eventsSince failed for ${deviceLabel}", e)
        return [success: false, error: "eventsSince not supported or failed: ${e.message}", device: deviceLabel, deviceId: args.deviceId,
                note: "Retry; if persistent, drop hoursBack/attribute to read the most-recent events instead, or check the device's Events page in the hub UI."]
    }

    // eventsSince inclusivity at the boundary is undocumented, so post-filter to
    // strictly-after sinceDate for parity with the app/location branches -- an event
    // whose timestamp equals `since` must not replay when a returned `date` is fed
    // back as the bookmark. A row with no usable date is kept (don't silently drop),
    // matching the other branches' parse-fail tolerance.
    def results = (events ?: []).findAll { evt ->
        evt.date == null || evt.date.after(sinceDate)
    }.collect { evt ->
        [
            name: evt.name,
            value: evt.value,
            unit: evt.unit,
            description: evt.descriptionText,
            date: evt.date?.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ"),
            isStateChange: evt.isStateChange
        ]
    }

    if (attributeFilter) {
        results = results.findAll { it.name == attributeFilter }
    }

    mcpLog("info", "monitoring", "Retrieved ${results.size()} history event${results.size() == 1 ? '' : 's'} for ${deviceLabel} (${sinceMode} window since ${sinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")})")
    def deviceResult = [
        source: "device",
        device: deviceLabel,
        deviceId: args.deviceId,
        attributeFilter: attributeFilter,
        events: results,
        count: results.size(),
        sinceMode: sinceMode,
        sinceTimestamp: sinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    ]
    if (sinceMode == "relative") deviceResult.hoursBack = effectiveHoursBack
    else deviceResult.since = sinceEcho
    return deviceResult
}

// Allowlist-bypass device-history branch: window an unlisted device's /device/eventsJson rows with
// the same attribute / strictly-after / limit filtering the app + location branches apply, and
// return the identical device-branch shape (source:"device", device, deviceId, attributeFilter,
// events, count, sinceMode, sinceTimestamp, hoursBack|since, optional timeFilterUnparseable).
// NOTE: like the app/location branches, this caps at `limit` AFTER the attribute filter (returns up
// to `limit` MATCHING rows), whereas the listed device branch caps the raw stream first
// (eventsSince max:limit) THEN filters -- so with an attributeFilter the bypass can surface more
// matching rows than the listed path. The window/shape are otherwise identical.
private Map _deviceHistoryBypass(args, Map fj, sinceDate, sinceMode, effectiveHoursBack, sinceEcho, attributeFilter, limit) {
    def deviceLabel = _bypassDeviceLabel(fj, args.deviceId)
    def rows = _fetchBypassDeviceEvents(args.deviceId)
    if (rows == null) {
        return [success: false, error: "Device event history fetch failed (/device/eventsJson/${args.deviceId})", source: "device", device: deviceLabel, deviceId: args.deviceId,
                note: "The device is reachable via the allowlist bypass but its event store could not be read -- likely a transient hub blip; retry."]
    }
    def results = []
    def timeFilterUnparseable = 0
    for (evt in rows) {
        if (!(evt instanceof Map)) continue
        if (attributeFilter && evt.name != attributeFilter) continue
        // Strictly-after window, mirroring the app/location branches: drop events at or before
        // sinceDate when the ISO+offset date parses; keep (and count) rows whose date doesn't.
        def evtDate = null
        try { evtDate = Date.parse("yyyy-MM-dd'T'HH:mm:ss.SSSZ", evt.date?.toString()) }
        catch (Exception ignored) { timeFilterUnparseable++ }
        if (evtDate != null && !evtDate.after(sinceDate)) continue
        results << _mapBypassEventRow(evt)
        if (results.size() >= limit) break
    }
    mcpLog("info", "monitoring", "Retrieved ${results.size()} history event${results.size() == 1 ? '' : 's'} for ${deviceLabel} via allowlist bypass (${sinceMode} window since ${sinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")})")
    def deviceResult = [
        source: "device",
        device: deviceLabel,
        deviceId: args.deviceId,
        attributeFilter: attributeFilter,
        events: results,
        count: results.size(),
        sinceMode: sinceMode,
        sinceTimestamp: sinceDate.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    ]
    if (sinceMode == "relative") deviceResult.hoursBack = effectiveHoursBack
    else deviceResult.since = sinceEcho
    if (timeFilterUnparseable > 0) deviceResult.timeFilterUnparseable = timeFilterUnparseable
    return deviceResult
}

// /device/preference/save expects a numeric deviceId in its JSON body (the Vue posts
// this.device.id, a number). Coerce the string id to a Long; leave a non-numeric id as-is.
def _prefSaveDeviceId(deviceId) {
    try { return (deviceId != null) ? (deviceId.toString() as Long) : deviceId }
    catch (Exception ignored) { return deviceId }
}

def toolUpdateDevice(args) {
    def deviceId = args.deviceId
    if (!deviceId) throw new IllegalArgumentException("deviceId is required")

    def device = findDevice(deviceId)
    if (!device) {
        if (_bypassEnabled()) {
            def fj = _fetchDeviceFullJson(deviceId)
            if (fj?.device != null) return _toolUpdateDeviceBypass(args, deviceId, fj)
        }
        throw new IllegalArgumentException("Device not found: ${deviceId}. The device must be in your selected devices or be an MCP-managed virtual device.")
    }

    def deviceLabel = device.label ?: device.name ?: "Device ${deviceId}"
    def changes = []
    def errors = []

    def requestedProps = []
    if (args.label != null) requestedProps << "label"
    if (args.name != null) requestedProps << "name"
    if (args.deviceNetworkId != null) requestedProps << "deviceNetworkId"
    if (args.dataValues) requestedProps << "dataValues(${args.dataValues.size()})"
    if (args.preferences) requestedProps << "preferences(${args.preferences.size()})"
    if (args.room != null) requestedProps << "room"
    if (args.enabled != null) requestedProps << "enabled"
    if (args.showOnHome != null) requestedProps << "showOnHome"
    if (args.defaultCurrentState != null) requestedProps << "defaultCurrentState"
    if (args.tags != null) requestedProps << "tags"
    mcpLog("debug", "device", "hub_update_device called for '${deviceLabel}' (ID: ${deviceId}), properties: ${requestedProps.join(', ')}")

    // Label (official API)
    if (args.label != null) {
        try {
            def oldLabel = deviceLabel
            device.setLabel(args.label)
            changes << [property: "label", oldValue: oldLabel, newValue: args.label]
            deviceLabel = args.label
            mcpLog("debug", "device", "hub_update_device label: '${oldLabel}' -> '${args.label}'")
        } catch (Exception e) {
            mcpLog("debug", "device", "hub_update_device label: error: ${e.message}")
            errors << [property: "label", error: e.message]
        }
    }

    // Name (official API)
    if (args.name != null) {
        try {
            def oldName = device.name
            device.setName(args.name)
            changes << [property: "name", oldValue: oldName, newValue: args.name]
            mcpLog("debug", "device", "hub_update_device name: '${oldName}' -> '${args.name}'")
        } catch (Exception e) {
            mcpLog("debug", "device", "hub_update_device name: error: ${e.message}")
            errors << [property: "name", error: e.message]
        }
    }

    // Device Network ID (official API)
    if (args.deviceNetworkId != null) {
        try {
            def oldDni = device.deviceNetworkId
            device.setDeviceNetworkId(args.deviceNetworkId)
            changes << [property: "deviceNetworkId", oldValue: oldDni, newValue: args.deviceNetworkId]
            mcpLog("debug", "device", "hub_update_device DNI: '${oldDni}' -> '${args.deviceNetworkId}'")
        } catch (Exception e) {
            mcpLog("debug", "device", "hub_update_device DNI: error: ${e.message}")
            errors << [property: "deviceNetworkId", error: e.message]
        }
    }

    // Data Values (official API)
    if (args.dataValues) {
        args.dataValues.each { key, value ->
            try {
                device.updateDataValue(key.toString(), value?.toString())
                changes << [property: "dataValue.${key}", newValue: value?.toString()]
                mcpLog("debug", "device", "hub_update_device dataValue: ${key}='${value}'")
            } catch (Exception e) {
                mcpLog("debug", "device", "hub_update_device dataValue ${key}: error: ${e.message}")
                errors << [property: "dataValue.${key}", error: e.message]
            }
        }
    }

    // Preferences (official API). updateSetting can SILENTLY no-op (e.g. a pref name the driver
    // does not declare) yet not throw, so -- mirroring the bypass pref leg -- confirm the value
    // actually landed via a FRESH fullJson read before recording the change.
    if (args.preferences) {
        args.preferences.each { key, setting ->
            def keyStr = key.toString()
            try {
                def rawValue
                if (setting instanceof Map && setting.type && setting.containsKey("value")) {
                    device.updateSetting(keyStr, [type: setting.type.toString(), value: setting.value])
                    rawValue = setting.value
                    mcpLog("debug", "device", "hub_update_device preference: ${keyStr}={type:${setting.type}, value:${setting.value}}")
                } else {
                    device.updateSetting(keyStr, setting?.toString())
                    rawValue = setting
                    mcpLog("debug", "device", "hub_update_device preference: ${keyStr}='${setting}'")
                }
                // Mandatory read-back. A FAILED re-fetch returns null, which for a CLEAR is
                // indistinguishable from a confirmed (null/empty) value -- so guard the fetch
                // first and report a DISTINCT error rather than recording a false success.
                def valueStr = rawValue?.toString()
                def cleared = (valueStr == null || valueStr == "")
                def fjReadback = _fetchDeviceFullJson(deviceId)
                if (fjReadback?.device == null) {
                    errors << [property: "preference.${keyStr}", error: "Update accepted but could not confirm the preference -- the read-back fetch failed."]
                } else {
                    def got = _fullJsonSettingValue(fjReadback.device, keyStr)
                    def gotStr = (got == null) ? null : got.toString()
                    def ok = cleared ? (gotStr == null || gotStr == "") : (gotStr == valueStr)
                    if (ok) {
                        changes << [property: "preference.${keyStr}", newValue: setting]
                    } else {
                        errors << [property: "preference.${keyStr}", error: "Update accepted but the preference read back as '${gotStr}' (expected '${cleared ? '(cleared)' : valueStr}')."]
                    }
                }
            } catch (Exception e) {
                mcpLog("debug", "device", "hub_update_device preference ${keyStr}: error: ${e.message}")
                errors << [property: "preference.${keyStr}", error: e.message]
            }
        }
    }

    // Room (internal API — write; Write master enforced centrally in executeTool)
    if (args.room != null) {
        if (settings.enableWrite == false) {
            errors << [property: "room", error: "Requires 'Enable Write Tools' to be turned on in MCP Rule Server app settings"]
        } else {
            try {
                mcpLog("debug", "device", "hub_update_device room: starting room assignment for device ${deviceId}")

                // Find room ID by name
                def targetRoomId = null
                // The MATCHED room's canonical name (the hub's casing). Recorded as the change's
                // newValue so the listed path reports the same canonical casing the bypass path does,
                // not the caller's raw casing.
                def canonicalRoomName = null
                if (args.room == "" || args.room == "none" || args.room == "null") {
                    targetRoomId = "0"
                    mcpLog("debug", "device", "hub_update_device room: unassigning device from room")
                } else {
                    def cachedRooms = null
                    try {
                        cachedRooms = getRooms()
                        mcpLog("debug", "device", "hub_update_device room: getRooms() returned ${cachedRooms?.size() ?: 0} rooms")
                        if (cachedRooms) {
                            def targetRoom = cachedRooms.find { it.name?.toString()?.toLowerCase() == args.room?.toString()?.toLowerCase() }
                            if (targetRoom) {
                                targetRoomId = targetRoom.id?.toString()
                                canonicalRoomName = targetRoom.name?.toString()
                                mcpLog("debug", "device", "hub_update_device room: resolved '${args.room}' -> roomId=${targetRoomId}")
                            }
                        }
                    } catch (Exception e) {
                        mcpLog("debug", "device", "hub_update_device room: getRooms() failed: ${e.message}")
                    }

                    if (targetRoomId == null) {
                        def allRoomNames = cachedRooms ? cachedRooms.collect { it.name } : []
                        throw new RuntimeException("Room '${args.room}' not found.${allRoomNames ? ' Available rooms: ' + allRoomNames.join(', ') : ''}")
                    }
                }

                // Room assignment via POST /room/save with JSON body.
                // API uses "roomId" field (not "id"). Content-Type must be application/json.

                def saveSuccess = false
                def saveError = null
                def deviceIdLong = deviceId as Long
                def deviceIdInt = deviceId as Integer

                // Helper: POST JSON to /room/save and check for errors
                // Routed through hubInternalPostJson so room writes share the Hub Security
                // cookie-refresh retry (a stale cookie no longer fails the save outright).
                // It returns the parsed body (or null on empty/non-JSON); the
                // verify-after-write step below is the real safety net for this path.
                def roomSavePost = { Map bodyMap ->
                    def jsonStr = groovy.json.JsonOutput.toJson(bodyMap)
                    def parsed = hubInternalPostJson("/room/save", jsonStr, 30)
                    if (parsed?.error) {
                        throw new RuntimeException("Room API error: ${parsed.error}")
                    }
                    return parsed
                }

                // Helper: check if device is in a room's device list
                def deviceInRoom = { room ->
                    room?.deviceIds?.contains(deviceIdLong) || room?.deviceIds?.contains(deviceIdInt)
                }

                // Get current room data
                def allRooms = getRooms()
                mcpLog("debug", "device", "hub_update_device room: getRooms() returned ${allRooms?.size() ?: 0} rooms")

                if (targetRoomId == "0") {
                    // --- UNASSIGN: remove device from its current room ---
                    def currentRoom = allRooms?.find { deviceInRoom(it) }
                    if (!currentRoom) {
                        saveSuccess = true
                        mcpLog("debug", "device", "hub_update_device room: device not in any room, nothing to unassign")
                    } else {
                        mcpLog("debug", "device", "hub_update_device room: removing device ${deviceId} from room '${currentRoom.name}' (${currentRoom.id})")
                        def updatedDeviceIds = currentRoom.deviceIds?.findAll { it != deviceIdLong && it != deviceIdInt }?.collect { it as Integer } ?: []
                        def body = [roomId: currentRoom.id as Integer, name: currentRoom.name, deviceIds: updatedDeviceIds]
                        mcpLog("debug", "device", "hub_update_device room: POST /room/save (remove) body: ${groovy.json.JsonOutput.toJson(body)}")
                        try {
                            roomSavePost(body)
                            saveSuccess = true
                        } catch (Exception e) {
                            mcpLog("debug", "device", "hub_update_device room: remove failed: ${e.message}")
                            saveError = e.message
                        }
                    }
                } else {
                    // --- ASSIGN: add device to target room ---
                    mcpLog("debug", "device", "hub_update_device room: assigning device ${deviceId} to room ${targetRoomId}")

                    // Check if device is already in the target room
                    def targetRoom = allRooms?.find { it.id?.toString() == targetRoomId }
                    if (targetRoom && deviceInRoom(targetRoom)) {
                        mcpLog("debug", "device", "hub_update_device room: device already in target room '${targetRoom.name}'")
                        saveSuccess = true
                    } else {
                        // Safe Move pattern: add to new room FIRST, then remove from old room.
                        // This prevents "device limbo" where a device ends up in no room if
                        // the second API call fails after the first succeeds.
                        // Worst case (remove fails): device appears in both rooms temporarily,
                        // which is recoverable. The old pattern (remove first) could orphan the device.

                        // Locate old room (if any) before mutations
                        def oldRoom = allRooms?.find { room ->
                            deviceInRoom(room) && room.id?.toString() != targetRoomId
                        }

                        // Step 1: Add device to target room
                        def freshTarget = allRooms?.find { it.id?.toString() == targetRoomId }
                        def targetDeviceIds = freshTarget?.deviceIds?.collect { it as Integer } ?: []
                        def devIdInt = deviceId as Integer
                        if (!targetDeviceIds.contains(devIdInt)) {
                            targetDeviceIds << devIdInt
                        }

                        def roomData = [roomId: targetRoomId as Integer, name: freshTarget?.name ?: targetRoom?.name ?: "", deviceIds: targetDeviceIds]
                        mcpLog("debug", "device", "hub_update_device room: POST /room/save (add) body: ${groovy.json.JsonOutput.toJson(roomData)}")
                        try {
                            roomSavePost(roomData)
                            mcpLog("debug", "device", "hub_update_device room: added to target room '${freshTarget?.name ?: targetRoomId}'")
                            saveSuccess = true
                        } catch (Exception e) {
                            // Add failed — device stays safely in its old room (no change made)
                            mcpLog("debug", "device", "hub_update_device room: add to room failed: ${e.message}")
                            saveError = e.message
                        }

                        // Step 2: Remove from old room (only if add succeeded)
                        if (saveSuccess && oldRoom) {
                            mcpLog("debug", "device", "hub_update_device room: removing from old room '${oldRoom.name}' (${oldRoom.id})")
                            // Re-fetch rooms to get fresh data after the add mutation
                            def freshRooms = getRooms()
                            def freshOldRoom = freshRooms?.find { it.id?.toString() == oldRoom.id?.toString() }
                            if (freshOldRoom) {
                                def oldDeviceIds = freshOldRoom.deviceIds?.findAll { it != deviceIdLong && it != deviceIdInt }?.collect { it as Integer } ?: []
                                def oldBody = [roomId: freshOldRoom.id as Integer, name: freshOldRoom.name, deviceIds: oldDeviceIds]
                                mcpLog("debug", "device", "hub_update_device room: POST /room/save (remove) body: ${groovy.json.JsonOutput.toJson(oldBody)}")
                                try {
                                    roomSavePost(oldBody)
                                    mcpLog("debug", "device", "hub_update_device room: removed from old room '${oldRoom.name}'")
                                } catch (Exception oldErr) {
                                    // Device is in both rooms — not ideal but it IS in the target room.
                                    // Log a warning so the user is aware.
                                    mcpLog("warn", "device", "hub_update_device room: device added to new room but removal from old room '${oldRoom.name}' failed: ${oldErr.message}. Device may appear in both rooms.")
                                }
                            }
                        }
                    }
                }

                // Verify the room actually changed
                if (saveSuccess) {
                    def verified = false
                    try {
                        def verifyRooms = getRooms()
                        if (targetRoomId == "0") {
                            def stillInRoom = verifyRooms?.find { room -> deviceInRoom(room) }
                            verified = (stillInRoom == null)
                            if (!verified) {
                                mcpLog("debug", "device", "hub_update_device room: VERIFICATION FAILED - device still in room '${stillInRoom?.name}'")
                            }
                        } else {
                            def tRoom = verifyRooms?.find { it.id?.toString() == targetRoomId }
                            verified = deviceInRoom(tRoom)
                            if (!verified) {
                                mcpLog("debug", "device", "hub_update_device room: VERIFICATION FAILED - device not in target room '${tRoom?.name}' deviceIds: ${tRoom?.deviceIds}")
                            }
                            // Also verify device is NOT still in the old room
                            if (verified) {
                                def dualRoom = verifyRooms?.find { room -> deviceInRoom(room) && room.id?.toString() != targetRoomId }
                                if (dualRoom) {
                                    mcpLog("warn", "device", "hub_update_device room: WARNING - device also still in room '${dualRoom.name}' (dual-room state)")
                                }
                            }
                        }
                    } catch (Exception verErr) {
                        mcpLog("debug", "device", "hub_update_device room: verification error: ${verErr.message}")
                    }

                    if (verified) {
                        def oldRoomName = device.roomName ?: "none"
                        def newRoomName = (targetRoomId == "0") ? "none" : (canonicalRoomName ?: args.room)
                        changes << [property: "room", oldValue: oldRoomName, newValue: newRoomName]
                        mcpLog("info", "device", "Room changed for '${deviceLabel}': ${oldRoomName} -> ${newRoomName} (VERIFIED)")
                    } else {
                        throw new RuntimeException("Room assignment endpoint returned success but room did not actually change.")
                    }
                } else {
                    throw new RuntimeException("Room assignment failed. Last error: ${saveError}")
                }
            } catch (Exception e) {
                mcpLog("debug", "device", "hub_update_device room: error: ${e.message}")
                errors << [property: "room", error: e.message]
            }
        }
    }

    // Enable/Disable (internal API — write; Write master enforced centrally in executeTool)
    // Hubitat's /device/disable endpoint requires POST with body params, not GET with query params
    if (args.enabled != null) {
        if (settings.enableWrite == false) {
            errors << [property: "enabled", error: "Requires 'Enable Write Tools' to be turned on in MCP Rule Server app settings"]
        } else {
            try {
                def disableValue = args.enabled ? "false" : "true"
                mcpLog("debug", "device", "hub_update_device enabled: POSTing to /device/disable with id=${deviceId}, disable=${disableValue}")
                hubInternalPost("/device/disable", [id: deviceId, disable: disableValue])
                // Confirm the flip before recording success -- a 200 from /device/disable does not
                // prove the state changed, and the request-scoped device handle's disabled flag is
                // execution-cached (stale to a same-request POST), so confirm via a FRESH re-read.
                def res = _confirmDisabledFlip(device.id.toString(), !args.enabled)
                if (res.fetchFailed) {
                    errors << [property: "enabled", error: "POST accepted but could not confirm the change -- the read-back fetch failed."]
                } else if (res.ok) {
                    changes << [property: "enabled", newValue: args.enabled]
                    mcpLog("info", "device", "Device '${deviceLabel}' ${args.enabled ? 'enabled' : 'disabled'}")
                } else {
                    errors << [property: "enabled", error: "POST accepted but the device read back as ${res.actualDisabled ? 'disabled' : 'enabled'} (expected ${!args.enabled ? 'disabled' : 'enabled'})."]
                }
            } catch (Exception e) {
                mcpLog("debug", "device", "hub_update_device enabled: error: ${e.message}")
                errors << [property: "enabled", error: e.message]
            }
        }
    }

    // Show-on-Home flag (internal API -- no SDK setter; Write master enforced centrally).
    // Controls whether the device appears on the hub Home page and counts toward its quick
    // status-bar summaries. Prefer the dedicated GET (clean, single-purpose) but fall back to
    // /device/preference/save when it's absent: /device/setShowOnHome answers on some hubs and
    // 404s on others (observed 404 on a 2.5.0.157 hub, 200 on 2.5.0.159 -- cause not established,
    // and NOT attributable to any documented release-notes change), whereas /device/preference/save
    // also carries showOnHome and was present on both. A partial body touches only the named field.
    if (args.showOnHome != null) {
        if (settings.enableWrite == false) {
            errors << [property: "showOnHome", error: "Requires 'Enable Write Tools' to be turned on in MCP Rule Server app settings"]
        } else {
            try {
                def showVal = args.showOnHome ? "true" : "false"
                try {
                    hubInternalGet("/device/setShowOnHome", [deviceId: deviceId, show: showVal])
                } catch (IllegalStateException guardErr) {
                    throw guardErr   // ?-in-path guard: a coding bug, never a fallback trigger
                } catch (Exception primaryErr) {
                    mcpLog("debug", "device", "hub_update_device showOnHome: dedicated endpoint failed (${primaryErr.message}); falling back to /device/preference/save")
                    hubInternalPostJson("/device/preference/save", groovy.json.JsonOutput.toJson([deviceId: _prefSaveDeviceId(deviceId), showOnHome: args.showOnHome]))
                }
                // Confirm via a FRESH read-back: a 200 from either endpoint does not prove the flag
                // flipped, and /device/preference/save returns {success} even on a no-op. fullJson
                // carries device.showOnHome as a Boolean (robust to the JSON string "true").
                def fjReadback = _fetchDeviceFullJson(deviceId)
                if (fjReadback?.device == null) {
                    errors << [property: "showOnHome", error: "POST accepted but could not confirm the change -- the read-back fetch failed."]
                } else {
                    def rawShow = fjReadback.device.showOnHome
                    def gotShow = (rawShow == true || rawShow?.toString() == "true")
                    if (gotShow == (args.showOnHome == true)) {
                        changes << [property: "showOnHome", newValue: args.showOnHome]
                        mcpLog("info", "device", "Device '${deviceLabel}' showOnHome -> ${args.showOnHome}")
                    } else {
                        errors << [property: "showOnHome", error: "POST accepted but showOnHome read back as ${gotShow} (expected ${args.showOnHome == true})."]
                    }
                }
            } catch (Exception e) {
                mcpLog("debug", "device", "hub_update_device showOnHome: error: ${e.message}")
                errors << [property: "showOnHome", error: e.message]
            }
        }
    }

    // Default Current State -- which Current-States attribute shows in the Status column on the
    // Devices/Rooms pages ("" selects None). Same endpoint-availability split as showOnHome:
    // prefer the dedicated GET (returns `true`), fall back to /device/preference/save where absent.
    if (args.defaultCurrentState != null) {
        if (settings.enableWrite == false) {
            errors << [property: "defaultCurrentState", error: "Requires 'Enable Write Tools' to be turned on in MCP Rule Server app settings"]
        } else {
            try {
                def csVal = args.defaultCurrentState.toString()
                def applied = false
                try {
                    // The dedicated endpoint returns the literal `true` on success. A 200 carrying
                    // anything else (e.g. `false` for an unknown attribute name) is a real rejection
                    // -- record an error, do NOT fall back (the endpoint exists, the value is bad).
                    def result = hubInternalGet("/device/setDefaultCurrentState", [id: deviceId, currentState: csVal])
                    if (result?.toString()?.trim()?.toLowerCase() == "true") {
                        applied = true
                    } else {
                        errors << [property: "defaultCurrentState", error: "Hub did not accept defaultCurrentState='${csVal}' (returned '${result?.toString()?.take(120)}'). Use an attribute name from the device's current states."]
                    }
                } catch (IllegalStateException guardErr) {
                    throw guardErr   // ?-in-path guard: a coding bug, never a fallback trigger
                } catch (Exception primaryErr) {
                    // Dedicated endpoint absent on some hubs (404) -- fall back to the Preferences-pane save.
                    mcpLog("debug", "device", "hub_update_device defaultCurrentState: dedicated endpoint failed (${primaryErr.message}); falling back to /device/preference/save")
                    hubInternalPostJson("/device/preference/save", groovy.json.JsonOutput.toJson([deviceId: _prefSaveDeviceId(deviceId), defaultCurrentState: csVal]))
                    applied = true
                }
                if (applied) {
                    // Confirm via a FRESH read-back before recording: the /device/preference/save
                    // fallback returns {success} on a no-op. fullJson carries device.defaultCurrentState
                    // as the attribute-name string, or null/"" for None (the empty-string request).
                    def fjReadback = _fetchDeviceFullJson(deviceId)
                    if (fjReadback?.device == null) {
                        errors << [property: "defaultCurrentState", error: "POST accepted but could not confirm the change -- the read-back fetch failed."]
                    } else {
                        def got = fjReadback.device.defaultCurrentState
                        def gotStr = (got == null) ? null : got.toString()
                        def cleared = (csVal == "")
                        def ok = cleared ? (gotStr == null || gotStr == "") : (gotStr == csVal)
                        if (ok) {
                            changes << [property: "defaultCurrentState", newValue: csVal]
                            mcpLog("info", "device", "Device '${deviceLabel}' defaultCurrentState -> '${csVal}'")
                        } else {
                            errors << [property: "defaultCurrentState", error: "POST accepted but defaultCurrentState read back as '${gotStr}' (expected '${cleared ? '(none)' : csVal}')."]
                        }
                    }
                }
            } catch (Exception e) {
                mcpLog("debug", "device", "hub_update_device defaultCurrentState: error: ${e.message}")
                errors << [property: "defaultCurrentState", error: e.message]
            }
        }
    }

    // Tags (internal API -- no SDK setter and no dedicated endpoint; the ONLY path is the
    // wholesale /device/update form, which BLANKS any field it omits. So read the full
    // device-edit model, change only tags, re-POST the COMPLETE form, then verify the tags
    // landed and the identity fields survived (restoring label/name/DNI via the SDK if the
    // hub dropped them).
    if (args.tags != null) {
        if (settings.enableWrite == false) {
            errors << [property: "tags", error: "Requires 'Enable Write Tools' to be turned on in MCP Rule Server app settings"]
        } else {
            try {
                def tagsCsv = (args.tags instanceof List) ? args.tags.collect { it?.toString()?.trim() }.findAll { it }.join(",") : args.tags.toString()
                def fjText = hubInternalGet("/device/fullJson/${deviceId}")
                def full = fjText ? new groovy.json.JsonSlurper().parseText(fjText) : null
                def d = full?.device
                if (!d) throw new RuntimeException("Could not read the device model from /device/fullJson to preserve fields")
                def oldLabel = d.label; def oldName = d.name; def oldDni = d.deviceNetworkId
                def dashIds = (full.dashboards ?: []).findAll { it?.selected }.collect { it?.id }
                // Faithful copy of the Vue device-edit form (deviceModel); omitting a field blanks it.
                def model = [
                    name: d.name, label: d.label, zigbeeId: d.zigbeeId,
                    maxEvents: d.maxEvents, maxStates: d.maxStates, spammyThreshold: d.spammyThreshold,
                    deviceNetworkId: d.deviceNetworkId, deviceTypeId: d.deviceTypeId,
                    deviceTypeReadableType: d.deviceTypeReadableType, roomId: d.roomId,
                    meshEnabled: d.meshEnabled, retryEnabled: d.retryEnabled, meshFullSync: d.meshFullSync,
                    homeKitEnabled: full.homeKitEnabled, locationId: d.locationId, hubId: d.hubId,
                    groupId: d.groupId, dashboardIds: dashIds, tags: tagsCsv,
                    defaultIcon: (d.defaultIcon ?: d.icon), notes: (d.notes ?: "")
                ]
                if (d.id != null) { model.id = d.id; model.version = d.version; model.controllerType = d.controllerType }
                def enc = { v ->
                    if (v == true) return "on"
                    if (v == null) return ""
                    if (v instanceof List) return v.collect { it?.toString() }.join(",")
                    return v.toString()
                }
                def body = model.collect { k, v -> "${java.net.URLEncoder.encode(k.toString(), 'UTF-8')}=${java.net.URLEncoder.encode(enc(v), 'UTF-8')}" }.join("&")
                hubInternalPostFormRaw("/device/update", body)
                // Verify: tags applied AND identity fields not blanked by the wholesale form
                def vText = hubInternalGet("/device/fullJson/${deviceId}")
                def vd = vText ? new groovy.json.JsonSlurper().parseText(vText)?.device : null
                // Identity-restore runs FIRST, regardless of whether tags matched: the wholesale
                // /device/update form blanks any field it omits, and that can happen on the
                // tag-mismatch path too -- so restore label/name/DNI whenever the read-back shows
                // them blanked, before branching on the tag result. A restore-setter failure is
                // surfaced as an actionable error (not swallowed) so the user knows to re-set it.
                if (oldLabel && !vd?.label) { try { device.setLabel(oldLabel) } catch (Exception re) { errors << [property: "label", error: "Tags processed but the device-edit form blanked the label and restoring it failed: ${re.message}. Verify and re-set the label."] } }
                if (oldName && !vd?.name) { try { device.setName(oldName) } catch (Exception re) { errors << [property: "name", error: "Tags processed but the device-edit form blanked the name and restoring it failed: ${re.message}. Verify and re-set the name."] } }
                if (oldDni && !vd?.deviceNetworkId) { try { device.setDeviceNetworkId(oldDni) } catch (Exception re) { errors << [property: "deviceNetworkId", error: "Tags processed but the device-edit form blanked the deviceNetworkId and restoring it failed: ${re.message}. Verify and re-set the deviceNetworkId."] } }
                def gotTags = vd?.tags?.toString() ?: ""
                if (gotTags != (tagsCsv ?: "")) {
                    errors << [property: "tags", error: "POST accepted but tags read back as '${gotTags}' (expected '${tagsCsv}'). Other fields were preserved."]
                } else {
                    changes << [property: "tags", oldValue: d.tags, newValue: tagsCsv]
                    mcpLog("info", "device", "Device '${deviceLabel}' tags -> '${tagsCsv}'")
                }
            } catch (Exception e) {
                mcpLog("debug", "device", "hub_update_device tags: error: ${e.message}")
                errors << [property: "tags", error: e.message]
            }
        }
    }

    if (!changes && !errors) {
        return [
            success: true,
            device: deviceLabel,
            deviceId: deviceId,
            message: "No properties were provided to update. Specify at least one property: label, name, deviceNetworkId, room, enabled, dataValues, preferences, showOnHome, defaultCurrentState, or tags."
        ]
    }

    mcpLog("info", "device", "Updated device '${deviceLabel}' (ID: ${deviceId}): ${changes.size()} changes, ${errors.size()} errors")
    if (errors) {
        mcpLog("debug", "device", "hub_update_device errors: ${errors.collect { "${it.property}: ${it.error}" }.join('; ')}")
    }

    return [
        success: errors.isEmpty(),
        device: deviceLabel,
        deviceId: deviceId,
        changes: changes,
        errors: errors.isEmpty() ? null : errors,
        message: errors.isEmpty()
            ? "Successfully updated ${changes.size()} ${changes.size() == 1 ? 'property' : 'properties'} on device '${deviceLabel}'."
            : "Updated ${changes.size()} ${changes.size() == 1 ? 'property' : 'properties'} with ${errors.size()} ${errors.size() == 1 ? 'error' : 'errors'} on device '${deviceLabel}'."
    ]
}

// Allowlist-bypass variant of toolUpdateDevice: edit an unlisted device (no Groovy device object)
// via the hub's id-keyed admin endpoints. Returns the SAME {success, device, deviceId, changes,
// errors, message} shape as the listed path. Routing per field:
//   label / name / deviceNetworkId -> POST /device/update (one wholesale device-model form, rebuilt
//                             FRESH; label rides this portable form because the dedicated GET
//                             /device/updateLabel setter 404s on some firmwares -- see below)
//   preferences            -> POST /device/preference/save ({preferences:[{name,type,value}]} array,
//                             read-back verified -- the {success} response lies on a no-op)
//   room (assign)          -> GET  /device/updateRoom (by room NAME, existence-checked)
//   room (unassign)        -> POST /device/update with roomId=0
//   enabled                -> POST /device/disable
// showOnHome / defaultCurrentState / tags / dataValues are NOT wired here (their listed-path flows
// lean on the Groovy device object, or on the wholesale /device/update form's unverified field
// encoding) -- requesting them yields a per-field error pointing the caller at the MCP device scope.
private Map _toolUpdateDeviceBypass(args, deviceId, Map fj) {
    def d = fj.device
    def deviceLabel = _bypassDeviceLabel(fj, deviceId)
    def changes = []
    def errors = []

    def requestedProps = []
    if (args.label != null) requestedProps << "label"
    if (args.name != null) requestedProps << "name"
    if (args.deviceNetworkId != null) requestedProps << "deviceNetworkId"
    if (args.preferences) requestedProps << "preferences(${args.preferences.size()})"
    if (args.room != null) requestedProps << "room"
    if (args.enabled != null) requestedProps << "enabled"
    mcpLog("warn", "device", "hub_update_device (allowlist bypass) for '${deviceLabel}' (ID: ${deviceId}), properties: ${requestedProps.join(', ')}")

    // dataValues is dropped from the bypass path: its only id-keyed route is the wholesale
    // /device/update form, and the form's data-value field encoding is unverified -- a wrong guess
    // could blank or mis-set fields. showOnHome/defaultCurrentState/tags lean on the Groovy device
    // object or the same unverified form. All four are refused with a per-field error.
    ["showOnHome", "defaultCurrentState", "tags", "dataValues"].each { p ->
        if (args[p] != null) errors << [property: p, error: "'${p}' is not supported when reaching a device via the allowlist bypass; add the device to the MCP device scope to edit it."]
    }

    // label / name / deviceNetworkId -> ONE wholesale /device/update form POST. The form blanks any
    // omitted field, so all three ride a single faithful device-model re-POST rebuilt from a FRESH
    // fullJson fetch inside _postBypassDeviceModel, then each is verified by read-back. label rides
    // this portable form rather than the dedicated GET /device/updateLabel setter: updateLabel 404s
    // on some firmwares (confirmed on 2.5.0.157) -- the same sometimes-absent dedicated-setter class
    // as /device/setShowOnHome and /device/setDefaultCurrentState (resources/hub2-source/README.md),
    // for which the wholesale /device/update form (which carries a `label` field) is the fallback.
    if (args.label != null || args.name != null || args.deviceNetworkId != null) {
        try {
            def overrides = [:]
            if (args.label != null) overrides.label = args.label.toString()
            if (args.name != null) overrides.name = args.name.toString()
            if (args.deviceNetworkId != null) overrides.deviceNetworkId = args.deviceNetworkId.toString()
            def vd = _postBypassDeviceModel(deviceId, overrides)
            if (args.label != null) {
                if (vd?.label?.toString() == overrides.label) {
                    changes << [property: "label", oldValue: d.label, newValue: overrides.label]
                    deviceLabel = overrides.label
                } else {
                    errors << [property: "label", error: "POST accepted but label read back as '${vd?.label}' (expected '${overrides.label}')."]
                }
            }
            if (args.name != null) {
                if (vd?.name?.toString() == overrides.name) changes << [property: "name", oldValue: d.name, newValue: overrides.name]
                else errors << [property: "name", error: "POST accepted but name read back as '${vd?.name}' (expected '${overrides.name}')."]
            }
            if (args.deviceNetworkId != null) {
                if (vd?.deviceNetworkId?.toString() == overrides.deviceNetworkId) changes << [property: "deviceNetworkId", oldValue: d.deviceNetworkId, newValue: overrides.deviceNetworkId]
                else errors << [property: "deviceNetworkId", error: "POST accepted but deviceNetworkId read back as '${vd?.deviceNetworkId}' (expected '${overrides.deviceNetworkId}')."]
            }
        } catch (Exception e) {
            errors << [property: "deviceModel", error: "${e.message ?: e.toString()}"]
        }
    }

    // Preferences -> POST /device/preference/save (one save per key). DRIVER prefs MUST ride the
    // `preferences:[{name,type,value}]` ARRAY -- a flat top-level key (e.g. {deviceId, logEnable})
    // is a SILENT NO-OP that still returns {success:true} (verified live), so the {success} response
    // CANNOT detect it. Hence the mandatory read-back: re-fetch fullJson and confirm the pref's
    // value actually changed before recording it as a change.
    if (args.preferences) {
        args.preferences.each { key, setting ->
            def keyStr = key.toString()
            try {
                def type = (setting instanceof Map && setting.type) ? setting.type.toString() : null
                def rawValue = (setting instanceof Map && setting.containsKey("value")) ? setting.value : setting
                if (type == null) type = _inferPrefType(rawValue)
                def valueStr = rawValue?.toString()
                // A null/empty target is a CLEAR. Send "" (not null) on the wire -- the form fields
                // are string-typed -- and the read-back is satisfied by a null OR empty value.
                def cleared = (valueStr == null || valueStr == "")
                def bodyValue = cleared ? "" : valueStr
                def body = groovy.json.JsonOutput.toJson([deviceId: _prefSaveDeviceId(deviceId),
                    preferences: [[name: keyStr, type: type, value: bodyValue]]])
                hubInternalPostJson("/device/preference/save", body)
                // Mandatory read-back. A FAILED re-fetch returns null, which for a CLEAR is
                // indistinguishable from a confirmed (null/empty) value -- so guard the fetch
                // first and report a DISTINCT error rather than recording a false success.
                def fjReadback = _fetchDeviceFullJson(deviceId)
                if (fjReadback?.device == null) {
                    errors << [property: "preference.${keyStr}", error: "POST accepted but could not confirm the preference -- the read-back fetch failed."]
                } else {
                    def got = _fullJsonSettingValue(fjReadback.device, keyStr)
                    def gotStr = (got == null) ? null : got.toString()
                    def ok = cleared ? (gotStr == null || gotStr == "") : (gotStr == valueStr)
                    if (ok) {
                        changes << [property: "preference.${keyStr}", newValue: setting]
                    } else {
                        errors << [property: "preference.${keyStr}", error: "POST accepted but the preference read back as '${gotStr}' (expected '${cleared ? '(cleared)' : valueStr}')."]
                    }
                }
            } catch (Exception e) {
                errors << [property: "preference.${keyStr}", error: "${e.message ?: e.toString()}"]
            }
        }
    }

    // Room. /device/updateRoom takes the room NAME (NOT the id -- live-verified: sending an id
    // makes the hub CREATE a spurious room named after the number). So for an assign, validate the
    // NAME exists first (parity with the listed path's "Room not found"; updateRoom would otherwise
    // silently create it) then send the name. For an unassign ("" / "none" / "null", matching the
    // listed path) DON'T send an empty name -- route through the wholesale /device/update form with
    // roomId=0 (live-verified to clear roomId/roomName cleanly).
    if (args.room != null) {
        try {
            if (args.room == "" || args.room == "none" || args.room == "null") {
                def vd = _postBypassDeviceModel(deviceId, [roomId: 0])
                if (vd == null) {
                    errors << [property: "room", error: "POST accepted but the read-back to confirm the unassign failed (/device/fullJson)."]
                } else if (!vd.roomName) {
                    changes << [property: "room", oldValue: d.roomName ?: "none", newValue: "none"]
                } else {
                    errors << [property: "room", error: "POST accepted but the device is still in room '${vd.roomName}' (expected unassigned)."]
                }
            } else {
                // Send the CANONICAL room name (the existing room's casing), not the caller's raw
                // casing -- /device/updateRoom is name-keyed and silently CREATES a spurious room
                // for a name it doesn't match exactly, so "foyer" vs an existing "Foyer" would
                // otherwise pass the case-insensitive existence check yet create a duplicate.
                def matchedRoom = _assertRoomExistsForBypass(args.room)
                def canonicalName = matchedRoom.name.toString()
                def r = hubInternalGet("/device/updateRoom", [deviceId: deviceId, room: canonicalName])
                if (r?.toString()?.trim()?.toLowerCase() == "true") {
                    // A "true" return doesn't prove the assignment landed -- re-read and confirm,
                    // mirroring the unassign leg.
                    def vd = _fetchDeviceFullJson(deviceId)?.device
                    if (vd == null) {
                        errors << [property: "room", error: "POST accepted but could not confirm the room change -- the read-back fetch failed."]
                    } else if (vd.roomName?.toString() == canonicalName) {
                        changes << [property: "room", oldValue: d.roomName ?: "none", newValue: canonicalName]
                    } else {
                        errors << [property: "room", error: "POST accepted but the device is in room '${vd.roomName}' (expected '${canonicalName}')."]
                    }
                } else {
                    errors << [property: "room", error: "Hub did not accept the room update (returned '${r?.toString()?.take(120)}')."]
                }
            }
        } catch (Exception e) {
            errors << [property: "room", error: "${e.message ?: e.toString()}"]
        }
    }

    // Enabled -> POST /device/disable (disable:true disables, false enables). Read back the
    // device's disabled flag from fullJson and confirm the flip before recording the change --
    // a 200 from /device/disable does not by itself prove the state changed.
    if (args.enabled != null) {
        try {
            hubInternalPost("/device/disable", [id: deviceId, disable: (args.enabled ? "false" : "true")])
            def res = _confirmDisabledFlip(deviceId, !args.enabled)
            if (res.fetchFailed) {
                errors << [property: "enabled", error: "POST accepted but could not confirm the change -- the read-back fetch failed."]
            } else if (res.ok) {
                changes << [property: "enabled", newValue: args.enabled]
            } else {
                errors << [property: "enabled", error: "POST accepted but the device read back as ${res.actualDisabled ? 'disabled' : 'enabled'} (expected ${!args.enabled ? 'disabled' : 'enabled'})."]
            }
        } catch (Exception e) {
            errors << [property: "enabled", error: "${e.message ?: e.toString()}"]
        }
    }

    if (!changes && !errors) {
        return [
            success: true,
            device: deviceLabel,
            deviceId: deviceId,
            message: "No properties were provided to update. Specify at least one property: label, name, deviceNetworkId, room, enabled, or preferences."
        ]
    }

    mcpLog("info", "device", "Updated device '${deviceLabel}' (ID: ${deviceId}) via allowlist bypass: ${changes.size()} changes, ${errors.size()} errors")
    return [
        success: errors.isEmpty(),
        device: deviceLabel,
        deviceId: deviceId,
        changes: changes,
        errors: errors.isEmpty() ? null : errors,
        message: errors.isEmpty()
            ? "Successfully updated ${changes.size()} ${changes.size() == 1 ? 'property' : 'properties'} on device '${deviceLabel}' (allowlist bypass)."
            : "Updated ${changes.size()} ${changes.size() == 1 ? 'property' : 'properties'} with ${errors.size()} ${errors.size() == 1 ? 'error' : 'errors'} on device '${deviceLabel}' (allowlist bypass)."
    ]
}

// Validate that a room NAME exists before the bypass /device/updateRoom call, and RETURN the
// matched room (canonical casing) so the caller sends the hub's own name, not the caller's raw
// casing. updateRoom takes the NAME, and /device/updateRoom SILENTLY CREATES a spurious room for
// a name it doesn't match exactly -- this case-insensitive existence check prevents that, giving
// the listed path's "Room not found" parity instead. Throws IllegalArgumentException (recorded as
// a per-field error). The getRooms()-failure case is reported distinctly from "room not found" so
// a hub-call blip isn't read as a bad name.
private Map _assertRoomExistsForBypass(room) {
    def rooms
    try {
        rooms = getRooms()
    } catch (Exception e) {
        throw new IllegalArgumentException("Unable to list rooms to resolve '${room}': ${e.message ?: e.toString()}")
    }
    def match = rooms?.find { it.name?.toString()?.toLowerCase() == room?.toString()?.toLowerCase() }
    if (match == null) {
        def names = rooms ? rooms.collect { it.name } : []
        throw new IllegalArgumentException("Room '${room}' not found.${names ? ' Available rooms: ' + names.join(', ') : ''}")
    }
    return match
}

// Rebuild the full device-edit model from a FRESH /device/fullJson fetch, apply fieldOverrides
// (e.g. [name:...], [roomId:0]), and POST the wholesale /device/update form (which blanks any
// field it omits, so the full model is reconstructed faithfully -- mirrors the listed-path tags
// flow). The fetch is FRESH (not a stale passed-in fj) so a prior leg's write in the same call --
// e.g. a label set via /device/updateLabel -- is reflected and NOT reverted by the re-POST. Throws
// when the fresh fetch fails (caller records a per-field error). Returns the read-back device map
// (or null on a read-back fetch failure) so the caller can verify the change landed. Live-verified:
// name/deviceNetworkId preserve all other fields; roomId=0 clears the room assignment.
private Map _postBypassDeviceModel(deviceId, Map fieldOverrides) {
    def fj = _fetchDeviceFullJson(deviceId)
    if (fj?.device == null) {
        // This is a PRE-write model read (the form is built from it, then POSTed) -- distinct from
        // the post-write read-back legs, so the diagnostic says model-read, not confirm.
        throw new RuntimeException("Could not read the device model from /device/fullJson to rebuild the /device/update form")
    }
    def d = fj.device
    def dashIds = (fj.dashboards ?: []).findAll { it?.selected }.collect { it?.id }
    def model = [
        name: d.name, label: d.label, zigbeeId: d.zigbeeId,
        maxEvents: d.maxEvents, maxStates: d.maxStates, spammyThreshold: d.spammyThreshold,
        deviceNetworkId: d.deviceNetworkId, deviceTypeId: d.deviceTypeId,
        deviceTypeReadableType: d.deviceTypeReadableType, roomId: d.roomId,
        meshEnabled: d.meshEnabled, retryEnabled: d.retryEnabled, meshFullSync: d.meshFullSync,
        homeKitEnabled: fj.homeKitEnabled, locationId: d.locationId, hubId: d.hubId,
        groupId: d.groupId, dashboardIds: dashIds, tags: (d.tags ?: ""),
        defaultIcon: (d.defaultIcon ?: d.icon), notes: (d.notes ?: "")
    ]
    if (d.id != null) { model.id = d.id; model.version = d.version; model.controllerType = d.controllerType }
    if (fieldOverrides) model.putAll(fieldOverrides)
    def enc = { v ->
        if (v == true) return "on"
        if (v == null) return ""
        if (v instanceof List) return v.collect { it?.toString() }.join(",")
        return v.toString()
    }
    def body = model.collect { k, v -> "${java.net.URLEncoder.encode(k.toString(), 'UTF-8')}=${java.net.URLEncoder.encode(enc(v), 'UTF-8')}" }.join("&")
    hubInternalPostFormRaw("/device/update", body)
    return _fetchDeviceFullJson(deviceId)?.device
}

def toolCreateDevice(args) {
    // Instantiate a device from a driver TYPE id (the hub's "add device by driver" path:
    // GET /device/sysDriverByIdJson/<deviceTypeId> -> {success, deviceId, errorMessage}).
    // This creates a real, non-radio-bound device -- useful for LAN/integration/cloud and
    // software/component drivers that have no pairing flow. Radio drivers created this way
    // are orphan shells (no node), so we warn. MCP-managed virtual devices have their own
    // tool (hub_manage_virtual_device); this is the broader catalog path.
    if (args?.confirm != true) {
        throw new IllegalArgumentException("confirm=true is required to create a device.")
    }
    def typeId = args?.deviceTypeId
    if (typeId == null || typeId.toString().trim() == "") {
        throw new IllegalArgumentException("deviceTypeId is required -- the driver-type id from hub_list_drivers(include='all') (the 'id' field).")
    }
    typeId = typeId.toString().trim()

    def resp
    try {
        def respText = hubInternalGet("/device/sysDriverByIdJson/${java.net.URLEncoder.encode(typeId, 'UTF-8')}", null, 30)
        // Parse INSIDE the try: a 200 carrying an HTML/login body (not JSON) makes parseText
        // throw, and it must return the same structured runtime-error shape as a fetch failure
        // rather than escaping as an unstructured tool error.
        resp = respText ? new groovy.json.JsonSlurper().parseText(respText) : null
    } catch (Exception e) {
        return [success: false, error: "Hub call failed creating device from driver-type ${typeId}: ${e.message}",
                note: "Verify the deviceTypeId via hub_list_drivers(include='all')."]
    }
    if (resp?.success != true || resp?.deviceId == null) {
        return [success: false, error: resp?.errorMessage ?: "Hub did not create a device for driver-type ${typeId}",
                note: "Verify the deviceTypeId via hub_list_drivers(include='all')."]
    }
    def newId = resp.deviceId.toString()

    def warnings = []

    // Inspect what was created (driver type, radio-ness) and optionally apply a label.
    def info = null
    try {
        def t = hubInternalGet("/device/fullJson/${newId}")
        info = t ? new groovy.json.JsonSlurper().parseText(t)?.device : null
    } catch (Exception e) {
        mcpLog("warn", "device", "hub_create_device: could not read back device ${newId} to confirm type: ${e.message}")
    }
    // A null read-back is non-fatal but must not be fully silent: without the type we cannot
    // tell whether this is a radio orphan shell, so the radio-shell warning would be lost.
    if (info == null) {
        warnings << "Created device ${newId} but could not read it back to confirm type -- if this is a radio driver it may be a non-functional orphan shell; verify with hub_get_device."
    }

    def appliedLabel = null
    if (args?.label != null && args.label.toString().trim()) {
        def wantLabel = args.label.toString()
        // Why the dedicated GET did not apply the label (non-"true" body or a thrown 404); drives the
        // fallback and, if that also fails, the warning text.
        def labelFailNote = null
        try {
            def labelResult = hubInternalGet("/device/updateLabel", [deviceId: newId, label: wantLabel])
            if (labelResult?.toString()?.trim()?.toLowerCase() == "true") {
                appliedLabel = wantLabel
            } else {
                labelFailNote = "hub returned '${labelResult?.toString()?.take(120)}'"
            }
        } catch (IllegalStateException guardErr) {
            throw guardErr   // ?-in-path guard: a coding bug, never a fallback trigger
        } catch (Exception e) {
            // The dedicated GET /device/updateLabel setter 404s on some firmwares (e.g. 2.5.0.157).
            labelFailNote = "${e.message ?: e.toString()}"
        }
        // Fallback, mirroring the setShowOnHome/setDefaultCurrentState dedicated-GET -> /device/update
        // pattern: if the dedicated setter did not apply the label, re-POST the wholesale device-edit
        // form with a label override. _postBypassDeviceModel is a general "re-fetch a FRESH fullJson +
        // re-POST the COMPLETE /device/update form with field overrides" helper (despite its bypass-era
        // name) -- the fresh re-read carries every other field, so nothing is blanked. The just-created
        // device's fullJson was already proven readable (the `info` read above). Non-fatal: a warning
        // is emitted only if BOTH the dedicated GET and this wholesale fallback fail to apply the label.
        if (appliedLabel == null) {
            try {
                def vd = _postBypassDeviceModel(newId, [label: wantLabel])
                if (vd?.label?.toString() == wantLabel) {
                    appliedLabel = wantLabel
                } else {
                    warnings << "Device created but label '${args.label}' could not be applied (${labelFailNote}; wholesale /device/update read back '${vd?.label}'). Set it with hub_update_device(label=...)."
                    mcpLog("warn", "device", "hub_create_device: label '${wantLabel}' not applied to ${newId} (${labelFailNote}; /device/update form read back '${vd?.label}')")
                }
            } catch (Exception e2) {
                warnings << "Device created but label '${args.label}' could not be applied (${labelFailNote}; fallback threw: ${e2.message ?: e2.toString()}). Set it with hub_update_device(label=...)."
                mcpLog("warn", "device", "hub_create_device: label '${wantLabel}' fallback /device/update threw for ${newId}: ${e2.message ?: e2.toString()}")
            }
        }
    }

    def readable = (info?.deviceTypeReadableType ?: "").toString().toLowerCase()
    def ctype = (info?.controllerType ?: "").toString().toUpperCase()
    if (ctype in ["ZWV", "ZGB"] || readable.contains("z-wave") || readable.contains("zwave") || readable.contains("zigbee") || readable.contains("matter")) {
        warnings << "This is a radio-type driver. Creating it here makes a non-functional orphan shell (no paired node). Add real Z-Wave/Zigbee/Matter devices by PAIRING (hub_call_zwave / hub_call_zigbee / hub_call_matter), then delete this shell with hub_delete_device."
    }

    mcpLog("info", "device", "hub_create_device: created device ${newId} from driver-type ${typeId}${appliedLabel ? " labeled '${appliedLabel}'" : ''}")
    return [
        success: true,
        deviceId: newId,
        label: appliedLabel ?: info?.label,
        name: info?.displayName ?: info?.name,
        deviceTypeId: typeId,
        deviceTypeName: info?.deviceTypeName,
        virtual: info?.virtual,
        capabilities: info?.capabilities,
        warnings: warnings ?: null,
        message: "Created device ${newId} from driver-type ${typeId}${appliedLabel ? " labeled '${appliedLabel}'" : ''}." + (warnings ? " WARNING: see warnings." : ""),
        note: "Set room/preferences/showOnHome with hub_update_device once the device is selectable, or delete it with hub_delete_device."
    ]
}

def toolGetCompatibleDevices(args) {
    // Hubitat's static "Compatible Devices" catalog (GET /hub/compatibleDevices): brands +
    // models with pairing/exclude/factory-reset instructions and the Hubitat driver each
    // maps to. ~1MB full, so this filters + paginates + projects -- never the whole blast.
    def cursor = args?.cursor
    def includeInstructions = (args?.includeInstructions == true)
    def q = args?.query?.toString()?.toLowerCase()
    def brandF = args?.brand?.toString()?.toLowerCase()
    def protoF = args?.protocol?.toString()?.toLowerCase()
    def typeF = args?.deviceType?.toString()?.toLowerCase()

    def list
    try {
        def txt = hubInternalGet("/hub/compatibleDevices", null, 30)
        list = txt ? new groovy.json.JsonSlurper().parseText(txt) : null
    } catch (Exception e) {
        return [success: false, error: "Could not read /hub/compatibleDevices: ${e.message}",
                note: "This is Hubitat's static compatibility catalog; it needs hub connectivity."]
    }
    if (!(list instanceof List)) {
        return [success: false, error: "Unexpected response shape from /hub/compatibleDevices.", devices: []]
    }

    def stripHtml = { s ->
        if (s == null) return null
        // Decode &amp; LAST (after &lt;/&gt;/&quot;/&#39;) so a single-encoded entity doesn't
        // double-decode (e.g. "&amp;lt;" must not collapse to "<").
        s.toString().replaceAll(/(?s)<[^>]+>/, " ")
            .replaceAll(/&nbsp;/, " ")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"').replace("&#39;", "'")
            .replace("&amp;", "&")
            .replaceAll(/\s+/, " ").trim()
    }
    def matched = list.findAll { r ->
        if (brandF && !((r?.brand ?: "").toString().toLowerCase().contains(brandF))) return false
        if (protoF && !((r?.protocol ?: "").toString().toLowerCase().contains(protoF))) return false
        if (typeF && !((r?.deviceType ?: "").toString().toLowerCase().contains(typeF))) return false
        if (q) {
            // ?: '' on each field so a null doesn't interpolate the literal "null" into the haystack.
            def hay = "${r?.brand ?: ''} ${r?.name ?: ''} ${r?.productNumber ?: ''} ${r?.deviceType ?: ''} ${r?.driverName ?: ''}".toLowerCase()
            if (!hay.contains(q)) return false
        }
        return true
    }
    def project = { r ->
        def m = [brand: r?.brand, name: r?.name, deviceType: r?.deviceType, productNumber: r?.productNumber,
                 protocol: r?.protocol, driverName: r?.driverName, deviceTypeId: r?.deviceTypeId, id: r?.id]
        if (includeInstructions) {
            m.joinInstructions = stripHtml(r?.joinInstructions)
            m.excludeInstructions = stripHtml(r?.excludeInstructions)
            m.factoryResetInstructions = stripHtml(r?.factoryResetInstructions)
            m.additionalHardware = r?.additionalHardware
            m.notes = r?.notes
        } else {
            m.hasInstructions = (r?.joinInstructions || r?.excludeInstructions || r?.factoryResetInstructions) ? true : false
        }
        return m
    }

    def pageSize = includeInstructions ? 12 : 40
    def effCursor = (cursor == null) ? "" : cursor
    def paged = _paginateList(matched, effCursor, pageSize, "hub_get_compatible_devices")
    def result = [success: true, total: matched.size(), count: paged.page.size(),
                  devices: paged.page.collect(project)]
    if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    if (matched.isEmpty()) {
        result.note = "No compatible-device records matched. Loosen the brand/protocol/deviceType/query filter."
    } else if (paged.nextCursor != null) {
        result.note = "Page of ${result.count} of ${result.total} matches. Iterate nextCursor, or narrow the filter. Set includeInstructions=true for pairing/reset steps."
    }
    return result
}

def toolDeleteDevice(args) {
    requireDestructiveConfirm(args.confirm)
    if (!args.deviceId) throw new IllegalArgumentException("deviceId is required")

    def deviceId = args.deviceId.toString()

    // Step 1: Gather device information for audit trail via hub internal API
    // We intentionally do NOT restrict to findDevice() (selectedDevices only) because
    // ghost/orphaned devices may not be in the selected device list
    def deviceInfo = null
    try {
        def responseText = hubInternalGet("/device/fullJson/${deviceId}")
        if (responseText) {
            deviceInfo = new groovy.json.JsonSlurper().parseText(responseText)
        }
    } catch (Exception e) {
        mcpLog("warn", "hub-admin", "Could not fetch device info for ${deviceId}: ${e.message}")
    }

    if (!deviceInfo) {
        throw new IllegalArgumentException("Device ${deviceId} not found on hub. Verify the device ID is correct.")
    }

    def deviceName = deviceInfo.label ?: deviceInfo.name ?: "Unknown"
    def deviceDNI = deviceInfo.deviceNetworkId ?: "unknown"
    def deviceType = deviceInfo.typeName ?: deviceInfo.type ?: "unknown"
    def warnings = []

    // Step 2: Check for recent activity (active device warning)
    try {
        def selectedDevice = findDevice(deviceId)
        if (selectedDevice) {
            def lastActivity = selectedDevice.lastActivity
            if (lastActivity) {
                def hoursAgo = (Math.round((now() - lastActivity.time) / 3600000.0 * 10) / 10.0) as double
                if (hoursAgo < 24) {
                    warnings << "ACTIVE DEVICE: Last activity was ${hoursAgo} hours ago at ${lastActivity.format("yyyy-MM-dd'T'HH:mm:ss")}. This device may still be functional."
                }
            }
            def recentEvents = selectedDevice.events(max: 3)
            if (recentEvents && recentEvents.size() > 0) {
                def lastEvent = recentEvents[0]
                warnings << "HAS RECENT EVENTS: Last event was ${lastEvent.name}=${lastEvent.value} at ${lastEvent.date?.format("yyyy-MM-dd'T'HH:mm:ss")}"
            }
        }
    } catch (Exception e) {
        // Device not in selected list or events unavailable — skip
    }

    // Step 3: Check Z-Wave/Zigbee radio membership
    def isRadioDevice = false
    try {
        // Check if device has a zigbeeId (Zigbee device)
        if (deviceInfo.zigbeeId) {
            isRadioDevice = true
            warnings << "ZIGBEE DEVICE: This device has Zigbee ID '${deviceInfo.zigbeeId}'. Force-deleting without proper Zigbee removal may leave an orphaned node on the mesh."
        }
        // Check if device network ID looks like a Z-Wave node (2-digit hex)
        if (deviceDNI && deviceDNI.matches(/^[0-9A-Fa-f]{2}$/)) {
            isRadioDevice = true
            warnings << "Z-WAVE DEVICE: Network ID '${deviceDNI}' suggests this is a Z-Wave node. Force-deleting without proper Z-Wave exclusion will leave a ghost node that degrades mesh performance."
        }
    } catch (Exception e) {
        // Skip radio check on error
    }

    // Step 4: Check if device is active on the Z-Wave/Zigbee radio node tables
    if (isRadioDevice) {
        try {
            // Check Z-Wave node table
            def zwaveEndpoints = ["/hub/zwaveDetails/json", "/hub2/zwaveInfo"]
            for (endpoint in zwaveEndpoints) {
                try {
                    def zwResponse = hubInternalGet(endpoint)
                    if (zwResponse) {
                        def zwData = new groovy.json.JsonSlurper().parseText(zwResponse)
                        def nodes = zwData?.nodes
                        if (nodes) {
                            def activeNode = nodes.find { it.deviceId?.toString() == deviceId }
                            if (activeNode) {
                                warnings << "ACTIVE ON Z-WAVE RADIO: Device is node ${activeNode.nodeId} with state '${activeNode.nodeState}'. It should be Z-Wave excluded BEFORE deletion."
                            }
                        }
                    }
                    break
                } catch (Exception e) { /* try next endpoint */ }
            }
        } catch (Exception e) {
            mcpLog("debug", "hub-admin", "Could not check Z-Wave radio for device ${deviceId}: ${e.message}")
        }
        try {
            // Check Zigbee device table
            def zigEndpoints = ["/hub/zigbeeDetails/json", "/hub2/zigbeeInfo"]
            for (endpoint in zigEndpoints) {
                try {
                    def zigResponse = hubInternalGet(endpoint)
                    if (zigResponse) {
                        def zigData = new groovy.json.JsonSlurper().parseText(zigResponse)
                        def devices = zigData?.devices
                        if (devices) {
                            def activeDevice = devices.find { it.id?.toString() == deviceId }
                            if (activeDevice && activeDevice.active) {
                                warnings << "ACTIVE ON ZIGBEE RADIO: Device '${activeDevice.name}' is active on the Zigbee mesh. It should be removed via Zigbee BEFORE deletion."
                            }
                        }
                    }
                    break
                } catch (Exception e) { /* try next endpoint */ }
            }
        } catch (Exception e) {
            mcpLog("debug", "hub-admin", "Could not check Zigbee radio for device ${deviceId}: ${e.message}")
        }
    }

    // Step 5: Check if any MCP rules reference this device
    try {
        def childApps = getChildApps()
        def referencingRules = []
        // Recursive search for device ID references without serializing to JSON
        def containsDeviceRef
        containsDeviceRef = { obj ->
            if (obj == null) return false
            if (obj instanceof String) return obj == deviceId
            if (obj instanceof Number) return obj.toString() == deviceId
            if (obj instanceof Map) return obj.values().any { containsDeviceRef(it) }
            if (obj instanceof Collection) return obj.any { containsDeviceRef(it) }
            return obj.toString() == deviceId
        }
        childApps?.each { childApp ->
            try {
                def ruleData = childApp.getRuleData()
                if (ruleData && containsDeviceRef(ruleData)) {
                    referencingRules << [id: ruleData.id, name: ruleData.name ?: "Unnamed"]
                }
            } catch (Exception e) { /* skip rule */ }
        }
        if (referencingRules) {
            warnings << "REFERENCED BY ${referencingRules.size()} MCP RULE(S): ${referencingRules.collect { "${it.name} (ID: ${it.id})" }.join(', ')}. These rules WILL BREAK after deletion."
        }
    } catch (Exception e) {
        mcpLog("debug", "hub-admin", "Could not check MCP rules for device ${deviceId}: ${e.message}")
    }

    // Step 6: Full audit log BEFORE deletion
    mcpLog("warn", "hub-admin", "DELETE DEVICE AUDIT: Deleting '${deviceName}' (ID: ${deviceId}, DNI: ${deviceDNI}, Type: ${deviceType}). Warnings: ${warnings.size() > 0 ? warnings.join(' | ') : 'none'}")

    // Step 7: Execute force delete via hub internal API
    try {
        def responseText = hubInternalGet("/device/forceDelete/${deviceId}/yes", null, 30)
        mcpLog("debug", "hub-admin", "Force delete response for device ${deviceId}: ${responseText?.take(500)}")
    } catch (Exception e) {
        mcpLogError("hub-admin", "Device force delete FAILED for '${deviceName}' (${deviceId})", e)
        return [
            success: false,
            error: "Force delete failed: ${e.message}",
            deviceId: deviceId,
            deviceName: deviceName,
            warnings: warnings
        ]
    }

    // Step 8: Verify deletion by attempting to re-fetch the device
    def verified = false
    try {
        def checkResponse = hubInternalGet("/device/fullJson/${deviceId}")
        if (checkResponse) {
            try {
                def checkParsed = new groovy.json.JsonSlurper().parseText(checkResponse)
                verified = !checkParsed?.id
            } catch (Exception parseErr) {
                // Non-JSON response or error page = likely deleted
                verified = true
            }
        } else {
            verified = true
        }
    } catch (Exception e) {
        // 404 or error = device is gone = success
        verified = true
    }

    mcpLog(verified ? "info" : "warn", "hub-admin", "Device delete ${verified ? 'VERIFIED' : 'UNVERIFIED'}: '${deviceName}' (ID: ${deviceId})")

    return [
        success: verified,
        deviceId: deviceId,
        deviceName: deviceName,
        message: verified
            ? "Device '${deviceName}' (ID: ${deviceId}) has been permanently deleted."
            : "Delete command was sent but device may still exist. Check Hubitat web UI to verify.",
        warnings: warnings,
        auditInfo: [
            deletedAt: formatTimestamp(now()),
            deviceType: deviceType,
            deviceNetworkId: deviceDNI,
            driverName: deviceType,
            lastHubBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
    ]
}

def toolCallDeviceSwap(args) {
    requireDestructiveConfirm(args?.confirm as Boolean)
    def fromId = args?.from_device_id?.toString()?.trim()
    def toId = args?.to_device_id?.toString()?.trim()
    if (!fromId) throw new IllegalArgumentException("from_device_id is required")
    if (!toId) throw new IllegalArgumentException("to_device_id is required")
    if (fromId == toId) throw new IllegalArgumentException("from_device_id and to_device_id must be different devices")
    def fromDevice = findDevice(fromId)
    if (!fromDevice) throw new IllegalArgumentException("Device not found: ${fromId}")
    def toDevice = findDevice(toId)
    if (!toDevice) throw new IllegalArgumentException("Device not found: ${toId}")

    // Before-count is the verification baseline AND the reported blast radius.
    def beforeCount = _deviceSwapDependentCount(fromId)
    mcpLog("info", "device-swap", "Swap requested: ${fromId} -> ${toId}; ${beforeCount == null ? 'unknown' : beforeCount} dependent app(s) before swap")

    def appId = _resolveDirectAppId("swapDevice")
    if (appId == null) {
        return [success: false,
                error: "Could not open the built-in Swap Device tool (direct/swapDevice did not resolve to an app instance).",
                note: "Likely causes: the firmware does not expose the direct/swapDevice alias, the redirect chain shape changed, or the hub auto-followed an absolute Location (200 with no Location header). A hub-admin warn log entry summarizes which; hub_set_log_level(level=info) captures per-hop detail on retry. Verify Settings > Swap Apps Device exists in the hub UI, then retry. Nothing was swapped."]
    }
    mcpLog("info", "device-swap", "Swap Device transient instance ${appId} opened")

    try {
        // Eligibility pre-check: the Swap Device page only offers oldDev candidates
        // that are referenced by at least one app AND not owned as another app's
        // child/component device (verified live on fw 2.5.0.143). Every MCP-created
        // virtual device is a child device of this app, so it never appears.
        def oldDevOptions = _deviceSwapEnumOptions(_deviceSwapFindInput(_rmFetchConfigJson(appId, "mainPage"), "oldDev"))
        if (!oldDevOptions.any { it.id == fromId }) {
            mcpLog("warn", "device-swap", "from_device_id ${fromId} not among ${oldDevOptions.size()} swappable oldDev option(s) -- closing instance ${appId}")
            _deviceSwapCleanup(appId)
            return [success: false,
                    error: "The hub's Swap Device tool does not offer device ${fromId} as swappable.",
                    oldDevOptionCount: oldDevOptions.size(),
                    note: "Swap Device only offers devices that are referenced by at least one app AND not owned as another app's child/component device. MCP-created virtual devices (hub_manage_virtual_device) are child devices and are always ineligible. Pick a free-standing from_device_id, or use hub_list_device_dependents(deviceId=${fromId}) to confirm it is referenced by an app. Nothing was swapped; the transient instance was closed."]
        }

        def applied = []
        def skipped = []
        _rmWriteSettingOnPage(appId, "mainPage", "oldDev", fromId, applied, null, skipped)
        def oldDevSkip = skipped.find { it.key == "oldDev" }
        if (oldDevSkip) {
            _deviceSwapCleanup(appId)
            return [success: false,
                    error: "Swap Device page did not accept the oldDev selection (${oldDevSkip.reason}).",
                    note: "Hub firmware may have renamed the device pickers on the Swap Device page. Nothing was swapped; the transient instance was closed."]
        }
        mcpLog("info", "device-swap", "oldDev=${fromId} written on instance ${appId}")

        // The hub fills newDev's options with compatible replacements only
        // after oldDev lands — this re-fetch IS the compatibility check.
        def cfg = _rmFetchConfigJson(appId, "mainPage")
        def options = _deviceSwapEnumOptions(_deviceSwapFindInput(cfg, "newDev"))
        if (!options.any { it.id == toId }) {
            mcpLog("warn", "device-swap", "to_device_id ${toId} not among ${options.size()} compatible replacement(s) for ${fromId} -- closing instance ${appId}")
            _deviceSwapCleanup(appId)
            return [success: false,
                    error: options.isEmpty()
                        ? "The hub offered NO compatible replacement devices for ${fromId}."
                        : "Device ${toId} is not a compatible replacement for ${fromId} -- the hub did not offer it.",
                    compatibleOptions: options.take(30),
                    compatibleOptionCount: options.size(),
                    note: "The Swap Device tool only offers devices with compatible capabilities, and excludes devices owned as another app's child/component device -- to_device_id may be an app child device (every MCP-created virtual device is one). Pick a to_device_id from compatibleOptions${options.size() > 30 ? " (showing first 30 of ${options.size()})" : ""}, or choose free-standing replacement hardware of the same device class. Nothing was swapped."]
        }

        _rmWriteSettingOnPage(appId, "mainPage", "newDev", toId, applied, null, skipped)
        def newDevSkip = skipped.find { it.key == "newDev" }
        if (newDevSkip) {
            _deviceSwapCleanup(appId)
            return [success: false,
                    error: "Swap Device page did not accept the newDev selection (${newDevSkip.reason}).",
                    note: "The replacement was offered but the write did not land -- likely a transient hub blip. Nothing was swapped; the transient instance was closed. Retry the call."]
        }
        mcpLog("info", "device-swap", "newDev=${toId} written on instance ${appId}")

        // The swap-action button only renders once both pickers are set, and
        // its name is firmware-defined — discover it instead of hardcoding.
        def buttons = _deviceSwapActionButtons(_rmFetchConfigJson(appId, "mainPage"))
        if (buttons.size() != 1) {
            mcpLog("warn", "device-swap", "Expected exactly one swap-action button, found ${buttons.size()} ${buttons} -- closing instance ${appId}")
            _deviceSwapCleanup(appId)
            return [success: false,
                    error: buttons.isEmpty()
                        ? "No swap-action button appeared after selecting both devices -- the hub did not unlock the swap."
                        : "Ambiguous Swap Device page: ${buttons.size()} action buttons found (${buttons.join(', ')}); refusing to click blindly.",
                    buttonsFound: buttons,
                    note: "Hub firmware may have changed the Swap Device page layout. Nothing was swapped; the transient instance was closed. Verify the swap manually via Settings > Swap Apps Device and report the button names with hub_report_issue if this persists."]
        }
        mcpLog("info", "device-swap", "Clicking swap action '${buttons[0]}' on instance ${appId}")
        _rmClickAppButton(appId, buttons[0], null, "mainPage")

        // Post-click: the swap action usually removes the transient instance
        // itself, but a transient read failure on the verify re-fetch is
        // indistinguishable from "instance gone", so the fetch only informs
        // LOGGING and never gates cleanup. The delete ALWAYS runs: it is
        // idempotent/harmless against an already-reaped instance, and
        // _deviceSwapCleanup swallows + logs its own failure -- skipping the
        // delete on a misread is the only way to leak an instance untraced.
        def instanceGone = false
        try {
            _rmFetchConfigJson(appId, "mainPage")
        } catch (Exception e) {
            instanceGone = true
            mcpLog("warn", "device-swap", "post-click verify fetch threw ${e.class.simpleName}: ${e.message} -- treating instance as present for cleanup (the delete is harmless if it already self-removed)")
        }
        _deviceSwapCleanup(appId)

        def afterCount = _deviceSwapDependentCount(fromId)
        if (beforeCount != null && afterCount != null && beforeCount > 0 && afterCount >= beforeCount) {
            return [success: false,
                    error: "Swap action was clicked but ${afterCount} app(s) still reference device ${fromId} (was ${beforeCount}).",
                    note: "The hub accepted the click but the dependents count did not drop. Inspect with hub_list_device_dependents(deviceId=${fromId}) before retrying -- some references may not be swappable."]
        }
        mcpLog("info", "device-swap", "Swap ${fromId} -> ${toId} complete; dependents ${beforeCount} -> ${afterCount}; transient instance ${instanceGone ? 'self-removed (verify fetch threw)' : 'survived the click'}; cleanup delete issued either way")
        def result = [success: true,
                      swapped: [from: fromId, to: toId],
                      verified: (beforeCount != null && afterCount != null),
                      note: "Every app that referenced ${fromId} now uses ${toId}. Verify with hub_list_device_dependents(deviceId=${toId}) and spot-check the most critical automations."]
        if (beforeCount != null) result.appsRewired = beforeCount
        if (afterCount != null) result.remainingDependents = afterCount
        if (beforeCount == null || afterCount == null) {
            result.note += " Before/after dependent counts could not be read from /device/fullJson, so the count verification is degraded."
        }
        return result
    } catch (Exception e) {
        mcpLogError("device-swap", "hub_call_device_swap ${fromId} -> ${toId} failed", e)
        _deviceSwapCleanup(appId)
        return [success: false,
                error: "Device swap failed: ${e.message}",
                note: "The swap may not have committed -- verify with hub_list_device_dependents(deviceId=${fromId}). The transient Swap Device instance was closed."]
    }
}

def toolCallDeviceReplace(args) {
    def oldId = args?.old_device_id?.toString()?.trim()
    if (!oldId) throw new IllegalArgumentException("old_device_id is required")

    // Read-only mode: list the hub's compatible replacement candidates (no write, no confirm).
    if (args?.list_options == true) {
        try {
            def raw = hubInternalGet("/device/getReplacementOptions/${java.net.URLEncoder.encode(oldId, 'UTF-8')}")
            def parsed = raw?.trim() ? new groovy.json.JsonSlurper().parseText(raw) : null
            // A genuine "no candidates" answer is an empty JSON array (a List). Anything else --
            // empty body, an HTML error page, a {error:...} object -- is a FAILED read, not "no
            // replacements"; reporting it as an empty success would mislead the caller into thinking
            // the device is unreplaceable. Distinguish the two rather than coalescing both to [].
            if (!(parsed instanceof List)) {
                mcpLog("warn", "device-replace", "getReplacementOptions for ${oldId} returned a non-list response: ${raw?.take(200)}")
                return [success: false, error: "Replacement-options read returned an unexpected (non-list) response.", response: raw?.take(300),
                        note: "Verify old_device_id (from hub_list_devices) and Hub Security credentials; the hub did not return a candidate list."]
            }
            def options = parsed.collect { [id: it?.id?.toString(), name: it?.name, deviceTypes: it?.deviceTypes] }
            return [success: true, listOptions: true, oldDeviceId: oldId, options: options, optionCount: options.size(),
                    note: options ? "Pick an option's id as new_device_id, then call again with confirm=true to replace." : "No compatible replacement devices found for this device."]
        } catch (Exception e) {
            mcpLogError("device-replace", "getReplacementOptions for ${oldId} failed", e)
            return [success: false, error: "Could not read replacement options: ${e.message}",
                    note: "Verify old_device_id (from hub_list_devices) and Hub Security credentials."]
        }
    }

    def newId = args?.new_device_id?.toString()?.trim()
    if (!newId) throw new IllegalArgumentException("new_device_id is required to replace (or pass list_options=true to list compatible candidates)")
    if (oldId == newId) throw new IllegalArgumentException("old_device_id and new_device_id must be different devices")
    requireDestructiveConfirm(args.confirm)

    mcpLog("warn", "device-replace", "Replacing device ${oldId} with ${newId} via /device/replace (old id + references preserved)")
    try {
        def raw = hubInternalGet("/device/replace", [oldId: oldId, newId: newId])
        def parsed = null
        try { parsed = raw ? new groovy.json.JsonSlurper().parseText(raw) : null } catch (Exception ignore) { }
        if (parsed instanceof Map && parsed.success == true) {
            return [success: true, replaced: [oldDeviceId: oldId, newDeviceId: newId], preservedDeviceId: oldId,
                    message: "Device ${oldId} now uses ${newId}'s hardware; its id and all app/rule references are preserved.",
                    note: "Verify with hub_get_device(deviceId=${oldId})."]
        }
        def errText = (parsed instanceof Map) ? (parsed.message ?: parsed.error) : null
        return [success: false, error: errText ?: "/device/replace did not report success", response: raw?.take(300),
                note: "new_device_id must be capability-compatible -- list valid candidates with list_options=true. Nothing was replaced."]
    } catch (Exception e) {
        mcpLogError("device-replace", "replace ${oldId} -> ${newId} failed", e)
        return [success: false, error: "Device replace failed: ${e.message}",
                note: "Verify the device ids and Hub Security credentials. The replace may not have committed -- check hub_get_device(deviceId=${oldId})."]
    }
}

private Integer _deviceSwapDependentCount(String deviceId) {
    try {
        def responseText = hubInternalGet("/device/fullJson/${deviceId}")
        if (!responseText) return null
        def parsed = new groovy.json.JsonSlurper().parseText(responseText)
        if (!(parsed instanceof Map)) return null
        def appsUsing = (parsed.appsUsing instanceof List) ? parsed.appsUsing : []
        try {
            return (parsed.appsUsingCount != null) ? (parsed.appsUsingCount as Integer) : appsUsing.size()
        } catch (NumberFormatException ignored) {
            return appsUsing.size()
        }
    } catch (Exception e) {
        mcpLog("warn", "device-swap", "dependent-count read failed for device ${deviceId} (${e.message}) -- before/after verification degraded")
        return null
    }
}

// Raw input descriptor lookup on a configure/json page. _rmCollectInputSchema
// drops `options`, which the compatibility check needs.
private Map _deviceSwapFindInput(Map cfg, String name) {
    for (s in (cfg?.configPage?.sections ?: [])) {
        for (i in (s?.input ?: [])) {
            if (i instanceof Map && i.name?.toString() == name) return i
        }
    }
    return null
}

// Normalize an enum input's options to [[id, label], ...]. The hub renders
// device options as a list of single-entry maps ([{<deviceId>: <label>}, ...]);
// tolerate a plain map too in case firmware flattens the shape.
private List _deviceSwapEnumOptions(Map input) {
    def out = []
    def opts = input?.options
    if (opts instanceof Map) {
        opts.each { k, v -> out << [id: k?.toString(), label: v?.toString()] }
    } else if (opts instanceof List) {
        for (opt in opts) {
            if (opt instanceof Map) {
                opt.each { k, v -> out << [id: k?.toString(), label: v?.toString()] }
            }
        }
    }
    return out
}

// All type:button inputs on the page except the Cancel button (closeApp).
// After both pickers are set the hub reveals exactly one swap-action button.
private List _deviceSwapActionButtons(Map cfg) {
    def names = []
    for (s in (cfg?.configPage?.sections ?: [])) {
        for (i in (s?.input ?: [])) {
            if (i instanceof Map && i.type?.toString() == "button" && i.name && i.name.toString() != "closeApp") {
                names << i.name.toString()
            }
        }
    }
    return names
}

// Remove the transient Swap Device instance. The Cancel button (closeApp) does NOT
// reap a pending (installed:false) instance -- verified live on fw 2.5.0.143; only
// /installedapp/delete/<id> does. Never throws: cleanup runs on failure paths where
// the original error must win.
private void _deviceSwapCleanup(Integer appId) {
    try {
        hubInternalGetRaw("/installedapp/delete/${appId}")
        mcpLog("info", "device-swap", "Transient Swap Device instance ${appId} deleted")
    } catch (Exception e) {
        // error (not warn) so the orphan-leak case is queryable at the default
        // error-only MCP log level.
        mcpLogError("device-swap", "Delete of Swap Device instance ${appId} failed -- a leftover transient instance is harmless but can be removed from the hub's Apps list", e)
    }
}

def _getAllToolDefinitions_partDevices() {
    return [
        // Device Tools
        [
            name: "hub_list_devices",
            description: """List all devices available to MCP with current states. format='context' returns a token-cheap plain-text house snapshot (mode + one line per device)[[FLAT_TRIM]] -- the best first call for broad "what's going on / what's in this house" questions[[/FLAT_TRIM]].

DEVICE AUTHORIZATION: Exact name match -> use directly. No exact match -> suggest similar, ASK USER before using. NEVER control unconfirmed devices (HVAC/locks risk). Report tool failures; don't silently fall back to existing devices.

[[FLAT_TRIM]]
Use detailed=false for discovery; detailed=true with limit=20-30. Sequential calls only.
[[/FLAT_TRIM]]
Call `hub_get_tool_guide(section='performance')` for response-shape details, filter/projection semantics, and field-name reference.""",
            inputSchema: [
                type: "object",
                properties: [
                    detailed: [type: "boolean", description: "Include full device details (capabilities, all attributes, commands).[[FLAT_TRIM]] WARNING: Resource-intensive for large device counts.[[/FLAT_TRIM]]"],
                    offset: [type: "integer", description: "Start from device at this index (0-based). Use for pagination.", default: 0],
                    limit: [type: "integer", description: "Maximum number of devices to return.[[FLAT_TRIM]] Recommended: 20-30 for detailed=true, higher values may slow hub.[[/FLAT_TRIM]]", default: 0],
                    filter: [type: "string", description: "Server-side filter (applied before pagination). 'all' (default) | 'enabled' | 'disabled' | 'stale:<hours>' | 'virtual'[[FLAT_TRIM]] (this MCP app's own virtual devices; use to find their IDs/DNIs)[[/FLAT_TRIM]]."],
                    labelFilter: [type: "string", description: "Case-insensitive substring match against device label; falls back to name for devices without a label set."],
                    capabilityFilter: [type: "string", description: "Case-insensitive exact match against capability name. Capability names are camelCase (e.g. 'ColorControl')."],
                    roomFilter: [type: "string", description: "Case-insensitive exact match against the device's assigned room name."],
                    onlyOn: [type: "boolean", description: "true = only devices whose switch currently reads 'on'.[[FLAT_TRIM]] \"What's on right now\" in one call; false is a no-op.[[/FLAT_TRIM]]"],
                    changedSince: [type: ["string", "integer"], description: "Only devices with activity at/after this timestamp: epoch ms, or ISO-8601 with a numeric offset (e.g. 2026-06-23T10:00:00Z; -0600 and -06:00 both accepted -- offset-less or date-only forms are rejected).[[FLAT_TRIM]] A returned lastActivity value round-trips. Inverse of filter='stale:<hours>'; devices with no readable lastActivity are excluded. Epoch-ms input echoes back as canonical ISO.[[/FLAT_TRIM]]"],
                    attributeNames: [type: "array", items: [type: "string"], description: "format='context' only (rejected on other formats): which attributes to show per device line[[FLAT_TRIM]], replacing the default set. Empty array = the default set[[/FLAT_TRIM]]."],
                    format: [type: "string", enum: ["summary", "detailed", "ids", "context"], description: "Response shape. 'summary' (default) = standard fields + currentStates. 'detailed' = capabilities/attributes/commands. 'ids' = flat array of device ID integers (cheapest, ignores fields arg). 'context' = plain-text house snapshot in `summary`[[FLAT_TRIM]] (mode + 'Label (id, room) - capabilities; attr=value' lines; page size 50 unless limit set; ignores fields arg)[[/FLAT_TRIM]]."],
                    fields: [type: "array", items: [type: "string"], description: "Field projection: only include named fields in each device object. Call `hub_get_tool_guide(section='performance')` for valid field names and projection semantics."],
                    cursor: [type: "string", description: "Opt-in opaque cursor (alias to offset). Pass \"\" for the first page (page size 50 when limit is unset), then iterate nextCursor."],
                    scope: [type: "string", enum: ["authorized", "all"], description: "Which devices to list. 'authorized' (default) = only devices granted to this MCP app (full detail/currentStates). 'all' = EVERY device on the hub, each tagged mcpAuthorized true/false."]
                ]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    devices: [type: "array", description: "Device objects (summary/detailed modes). Per-field projection applies", items: [type: "object", properties: [
                        id: [type: "string", description: "Device ID (always present)"],
                        name: [type: "string", description: "Driver type / device name"],
                        label: [type: "string", description: "User-assigned label"],
                        room: [type: "string", description: "Assigned room name"],
                        disabled: [type: "boolean", description: "Device disabled"],
                        deviceNetworkId: [type: "string", description: "Device network ID"],
                        lastActivity: [type: ["string", "null"], description: "Last-activity ISO timestamp, or null"],
                        parentDeviceId: [type: ["string", "null"], description: "Parent device ID, or null"],
                        mcpManaged: [type: "boolean", description: "Present and true for this app's virtual devices"],
                        mcpAuthorized: [type: "boolean", description: "scope='all' mode: whether the device is in this MCP app's authorized device list (false = exists on hub but not controllable until added)"],
                        currentStates: [type: "object", description: "Summary mode: common attribute values"],
                        capabilities: [type: "array", description: "Detailed mode: capability names", items: [type: "string"]],
                        attributes: [type: "array", description: "Detailed mode: attribute name/value pairs", items: [type: "object"]],
                        commands: [type: "array", description: "Detailed mode: command names", items: [type: "string"]]
                    ]]],
                    deviceIds: [type: "array", description: "format='ids' mode: flat array of integer device IDs", items: [type: "integer"]],
                    mode: [type: ["string", "null"], description: "format='context' mode: current location mode"],
                    summary: [type: "string", description: "format='context' mode: the plain-text house snapshot (header + one line per device)"],
                    hsmStatus: [type: "string", description: "format='context' mode: HSM status; present when the hub exposes one"],
                    count: [type: "integer", description: "Devices in this response"],
                    total: [type: "integer", description: "Total devices after filtering"],
                    unfilteredTotal: [type: "integer", description: "Total before filters; present when a filter is active"],
                    filter: [type: "string", description: "Echoed filter; present when non-default"],
                    labelFilter: [type: "string", description: "Echoed labelFilter; present when set"],
                    capabilityFilter: [type: "string", description: "Echoed capabilityFilter; present when set"],
                    roomFilter: [type: "string", description: "Echoed roomFilter; present when set"],
                    onlyOn: [type: "boolean", description: "Echoed onlyOn; present when true"],
                    changedSince: [type: "string", description: "Echoed changedSince (epoch-ms input echoes as canonical ISO); present when set"],
                    capabilityFilterMatchedKnownCapability: [type: "boolean", description: "When capabilityFilter yields 0: whether the capability exists on any device"],
                    roomFilterMatchedKnownRoom: [type: "boolean", description: "When the filtered total is 0 with roomFilter set: whether any MCP-visible device is assigned to that room (a hub room with no MCP-authorized device reads false)"],
                    attributeNamesMatchedNoAttributes: [type: "boolean", description: "format='context' with explicit attributeNames: present and true when the projection matched no attribute on any returned line (likely a mistyped attribute name)"],
                    scope: [type: "string", description: "Echoed 'all' when scope='all' was requested"],
                    mcpAuthorizedCount: [type: "integer", description: "scope='all': count over the full filtered (pre-pagination) set that ARE in the MCP authorized list; sums with unauthorizedCount to total, not to the returned page"],
                    unauthorizedCount: [type: "integer", description: "scope='all': count over the full filtered (pre-pagination) set NOT in the MCP authorized list"],
                    offset: [type: "integer", description: "Page start index; present when paginated"],
                    limit: [type: "integer", description: "Page size; present when paginated"],
                    hasMore: [type: "boolean", description: "More pages remain; present when paginated"],
                    nextOffset: [type: "integer", description: "Next page offset; present when more remain"],
                    nextCursor: [type: "string", description: "Opaque cursor; present in cursor mode when more remain"],
                    message: [type: "string", description: "Present when no devices or offset out of range"]
                ]
            ]
        ],
        [
            name: "hub_get_device",
            description: """Get one device's full detail: capabilities, all attributes with current values, and supported commands (with argument types).""",
            inputSchema: [
                type: "object",
                properties: [
                    deviceId: [type: "string", description: "Device ID from hub_list_devices, e.g. \"42\""]
                ],
                required: ["deviceId"]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    id: [type: "string", description: "Device ID"],
                    name: [type: "string", description: "Driver type / device name"],
                    label: [type: "string", description: "User-assigned label"],
                    room: [type: "string", description: "Assigned room name"],
                    capabilities: [type: "array", description: "Capability names", items: [type: "string"]],
                    attributes: [type: "array", description: "Attributes with current values", items: [type: "object", properties: [
                        name: [type: "string", description: "Attribute name"],
                        dataType: [type: "string", description: "Attribute data type"],
                        value: [description: "Current value"]
                    ]]],
                    commands: [type: "array", description: "Supported commands", items: [type: "object", properties: [
                        name: [type: "string", description: "Command name"],
                        arguments: [type: "array", description: "Argument name/type pairs, or null. Each `type` is Hubitat's raw declared arg type (e.g. NUMBER, STRING, ENUM, DATE) or 'unknown' when the driver doesn't declare one.", items: [type: "object"]]
                    ]]]
                ],
                required: ["id", "name", "label", "capabilities", "attributes", "commands"]
            ]
        ],
        [
            name: "hub_get_device_attribute",
            description: """Get a device attribute's current value, or block-poll until it reaches an expected value.

[[FLAT_TRIM]]
One-shot read by default (deviceId + attribute). Provide expectedValue or expectedValues (exactly one) to block-poll until currentValue matches, returning immediately on match or when timeoutMs elapses.
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    deviceId: [type: ["string", "integer"], description: "Device ID from hub_list_devices."],
                    deviceIds: [type: "array", items: [type: ["string", "integer"]], description: "Array of device IDs for a multi-device poll (mutually exclusive with deviceId; max 20)."],
                    mode: [type: "string", enum: ["any", "all"], description: "Multi-device aggregate.", default: "all"],
                    attribute: [type: "string", description: "Attribute name."],
                    expectedValue: [type: "string", description: "If set, block-poll until currentValue matches per comparator (enables poll mode). Single value, e.g. \"72\".[[FLAT_TRIM]] Provide exactly one of expectedValue or expectedValues.[[/FLAT_TRIM]]"],
                    expectedValues: [type: "array", items: [type: "string"], description: "If set, block-poll until currentValue matches per comparator (enables poll mode). For between, two numeric bounds [low, high].[[FLAT_TRIM]] Provide exactly one of expectedValue or expectedValues.[[/FLAT_TRIM]]"],
                    comparator: [type: "string", enum: ["eq", "ne", "gt", "gte", "lt", "lte", "between"], description: "Match operator. Default eq (value in the expected set).", default: "eq"],
                    stableForMs: [type: "integer", description: "Debounce: the match must hold continuously for this many MILLISECONDS before converging. Default 0 (first match).", default: 0, minimum: 0],
                    timeoutMs: [type: "integer", description: "Poll mode only: max wait in MILLISECONDS. Default 5000, min 100, max 60000. Requires expectedValue/expectedValues — passing a timeout without one is rejected.", default: 5000, minimum: 100, maximum: 60000],
                    pollIntervalMs: [type: "integer", description: "Poll mode: re-check interval in MILLISECONDS. Default 200, min 50, max 5000. Clamped to timeoutMs if larger.[[FLAT_TRIM]] (hub_call_device_command's waitFor defaults to 250 instead: a post-command poll follows a write, so wider spacing reduces read contention.)[[/FLAT_TRIM]]", default: 200, minimum: 50, maximum: 5000]
                ],
                required: ["attribute"]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    device: [type: "string", description: "One-shot mode: device label"],
                    attribute: [type: "string", description: "One-shot mode: attribute name"],
                    value: [description: "One-shot mode: current attribute value"],
                    success: [type: "boolean", description: "Poll mode: true if the condition converged (single-device match, or the mode predicate in multi-device mode)"],
                    finalValue: [description: "Poll mode, SINGLE-device only: last value read -- the live event-store value (a String, since it comes from the device's current state list). In multi-device mode it is per-device under devices[] (each device converges independently, so there is no single aggregate finalValue)."],
                    mode: [type: "string", description: "Poll mode, MULTI-device only (deviceIds): the aggregate mode that was applied (any/all)."],
                    devices: [type: "array", description: "Poll mode, MULTI-device only: per-device result, one entry per deviceIds element (compact -- never full device objects).", items: [type: "object", properties: [
                        deviceId: [type: "string", description: "The device ID from deviceIds"],
                        device: [type: "string", description: "Device label"],
                        finalValue: [description: "Last value read for this device (live event-store value)"],
                        matched: [type: "boolean", description: "Whether this device's condition was satisfied on the final poll"],
                        readError: [type: "boolean", description: "Present and true (success OR timeout) if reading this device threw on any poll (e.g. it was removed mid-poll); its value was treated as unread for that tick and the poll continued for the other devices"],
                        neverReported: [type: "boolean", description: "TIMEOUT only: present and true if this device never reported the attribute in the window"],
                        nonNumericAttribute: [type: "boolean", description: "TIMEOUT only: present and true if a numeric comparator was used on this device and it reported a non-numeric value the whole window (can never match)"]
                    ]]],
                    convergedCount: [type: "integer", description: "Poll mode, MULTI-device only: how many devices currently match the condition."],
                    elapsedMs: [type: "integer", description: "Poll mode: elapsed time in milliseconds"],
                    polledCount: [type: "integer", description: "Poll mode: number of poll iterations performed (one iteration reads every device in multi-device mode)"],
                    timedOut: [type: "boolean", description: "Poll mode: true if the timeout elapsed without convergence"],
                    readError: [type: "boolean", description: "Poll mode, SINGLE-device only: present and true (success OR timeout) if reading the device threw on any poll (e.g. it was removed mid-poll); that tick's value was treated as unread. Multi-device reports this per-device under devices[]."],
                    neverReported: [type: "boolean", description: "Poll mode, SINGLE-device only: present and true if the attribute never reported a value in the window (multi-device reports this per-device under devices[])"],
                    nonNumericAttribute: [type: "boolean", description: "Poll mode, SINGLE-device, TIMEOUT only: present and true when a numeric comparator (gt/gte/lt/lte/between) was used on an attribute that reported a non-numeric value the whole window, so the comparator can never match it (e.g. gt on switch=\"on\"). Distinct from neverReported. Multi-device reports this per-device under devices[]. Use eq/ne for a string attribute."],
                    note: [type: "string", description: "Poll mode, TIMEOUT only: human-readable recovery guidance. Single-device: present with nonNumericAttribute. Multi-device: present when at least one device is a can-never-match non-numeric (names the comparator/attribute, suggests eq/ne for a string attribute)."],
                    interrupted: [type: "boolean", description: "Poll mode: present and true if the poll was interrupted (hub reload). In multi-device mode the result still carries the per-device devices[] array (finalValue is per-device) plus convergedCount, and timedOut is omitted."],
                    transitioning: [type: "boolean", description: "Poll mode, TIMEOUT only: true if a value was still changing across polls (>=2 distinct non-null values seen) -- likely still settling -- vs false for a stable non-target (a real mismatch). In multi-device mode this is the aggregate (any device still changing). Best-effort: only reliable when the timeout spans a reporting jump."]
                ]
            ]
        ],
        [
            name: "hub_call_device_command",
            description: """Send a command (e.g. on, off, setLevel) to one device, or to SEVERAL at once via `commands`. Use to actuate or control a device; for read-only checks use hub_get_device_attribute instead.

For more than one device pass `commands` (max 20) rather than calling this repeatedly: one round trip instead of N. Entries are independent -- one failing entry does not stop the others; check results[] for per-entry success. Confirm a batch with hub_get_device_attribute's deviceIds form.[[FLAT_TRIM]] The round trip, not the hub actuating the device, is most of the wall-clock time, so this is the biggest win available on a multi-device intent; mixed devices and mixed commands go in one batch. For a set commanded repeatedly a group or scene is better still - one device to command, with the hub fanning out; `commands` is for the ad-hoc set nobody defined in advance.[[/FLAT_TRIM]]

If no exact device match: suggest similar devices and get user confirmation before sending any command.""",
            inputSchema: [
                type: "object",
                properties: [
                    deviceId: [type: ["string", "integer"], description: "Device ID from hub_list_devices - must be confirmed by user if not an exact match.[[FLAT_TRIM]] Omit when using commands.[[/FLAT_TRIM]]"],
                    command: [type: "string", description: "Command name, e.g. \"setLevel\". Must be one of the device's supported commands (see hub_get_device).[[FLAT_TRIM]] Omit when using commands.[[/FLAT_TRIM]]"],

                    // The nested item descriptions are terse by design: the three fields are
                    // described in full at the top level, and restating them here doubled this
                    // tool's schema bytes against the flat catalog's ~124KB cap.
                    commands: [
                        type: "array",
                        description: "Several devices in ONE call. Mutually exclusive with deviceId/command; no waitFor. Entries return no state snapshot. A bad entry is reported in its own results[] slot while the rest still go; malformed input is rejected before anything is sent.[[FLAT_TRIM]] Entries are sent in the order given.[[/FLAT_TRIM]]",
                        minItems: 1,
                        maxItems: 20,
                        items: [
                            type: "object",
                            properties: [
                                deviceId: [type: ["string", "integer"], description: "As deviceId above"],
                                command: [type: "string", description: "As command above"],
                                parameters: [type: "array", description: "As parameters above", items: [type: "string"]]
                            ],
                            required: ["deviceId", "command"]
                        ]
                    ],
                    parameters: [type: "array", description: "Ordered command arguments as an array of strings, in the order the command declares them, e.g. [\"75\"] for setLevel[[FLAT_TRIM]] or [\"#FF0000\"] for setColor[[/FLAT_TRIM]].", items: [type: "string"]],
                    waitFor: [type: "object", description: "Optional: after firing the command, block-poll the device until an attribute reaches an expected value, so the response confirms the RESULTING state.[[FLAT_TRIM]] (The `state` snapshot then reflects the converged value.) Omit for a fire-and-forget command with only the immediate pre-effect snapshot.[[/FLAT_TRIM]]", properties: [
                        attribute: [type: "string", description: "Attribute to poll until it converges, e.g. \"switch\". Must be a supported attribute of the device."],
                        expectedValue: [type: "string", description: "Awaited value: eq/ne in-set, or gt/gte/lt/lte numeric threshold."],
                        expectedValues: [type: "array", items: [type: "string"], description: "Awaited set: eq/ne value list (OR), or between's two bounds [low, high]."],
                        comparator: [type: "string", enum: ["eq", "ne", "gt", "gte", "lt", "lte", "between"], description: "Match operator, as on hub_get_device_attribute. Default eq.", default: "eq"],
                        stableForMs: [type: "integer", description: "Debounce ms; match must hold this long before converging. Default 0, < timeoutMs.", default: 0, minimum: 0],
                        timeoutMs: [type: "integer", description: "Max wait in MILLISECONDS. Default 5000, min 100, max 30000. BLOCKS a hub thread for the full timeout, so keep it tight.", default: 5000, minimum: 100, maximum: 30000],
                        pollIntervalMs: [type: "integer", description: "Re-check interval in MILLISECONDS. Default 250, min 50, max 5000. Clamped to timeoutMs if larger.", default: 250, minimum: 50, maximum: 5000]
                    ], required: ["attribute"]]
                ]

                // No `required` array: the two forms require different arguments (deviceId+command,
                // or commands), which JSON Schema cannot express here without oneOf. Enforced at
                // runtime instead, with a message naming the conflict.
            ],
            outputSchema: [
                type: "object",
                properties: [
                    success: [type: "boolean", description: "Whether the command was sent. In the commands form, true only when EVERY entry was attempted AND sent - check results[] (and stoppedEarly) when false."],
                    device: [type: "string", description: "Device label (single-device form)"],
                    command: [type: "string", description: "Command sent (single-device form)"],
                    parameters: [type: ["array", "null"], description: "Normalized parameters passed to the command; null for a parameterless command"],
                    count: [type: "integer", description: "commands form: number of entries attempted"],
                    sentCount: [type: "integer", description: "commands form: number of entries sent successfully"],
                    failedCount: [type: "integer", description: "commands form: number of attempted entries that failed (0 when all were sent)"],
                    failedDeviceIds: [type: "array", description: "commands form: the deviceIds of the failed entries, in request order -- the retry candidates. Check each entry's error/note before re-sending: an unconfirmed outcome may still have actuated.", items: [type: "string"]],
                    stoppedEarly: [type: "boolean", description: "commands form: present and true when the batch stopped early because the request was nearing the relay time budget; the entries in remainingCommands were NOT sent."],
                    remainingCommands: [type: "array", description: "commands form: present with stoppedEarly -- the untried tail of the request, verbatim, to re-send in a new call.", items: [type: "object"]],
                    results: [
                        type: "array",
                        description: "commands form: per-entry outcome, in request order. Entries carry no state snapshot -- confirm outcomes with hub_get_device_attribute's deviceIds form. A successful entry carries success, deviceId, device, command and parameters. A failed entry carries success:false, deviceId, command, error, and sometimes note.",
                        items: [
                            type: "object",
                            properties: [
                                success: [type: "boolean", description: "Whether this entry's command was sent"],
                                deviceId: [type: "string", description: "Device ID this entry targeted"],
                                device: [type: "string", description: "Device label (successful entries only)"],
                                command: [type: "string", description: "Command sent"],
                                parameters: [type: ["array", "null"], description: "Normalized parameters passed to the command; null for a parameterless command"],
                                error: [type: "string", description: "Present only on a FAILED entry: the error class and message, e.g. an unknown deviceId or an unsupported command. The other ATTEMPTED entries were still sent; entries a relay-budget stop left untried are in remainingCommands."],
                                note: [type: "string", description: "Present on a failed entry that carries recovery guidance"]
                            ],
                            required: ["success", "deviceId", "command"]
                        ]
                    ],
                    state: [type: "object", description: "Attribute snapshot keyed by attribute name; each entry is {value, timestamp}. Read AS OF the command: without waitFor this is the immediate (PRE-effect) value because the hub commits the change after this request returns; with waitFor it reflects the converged value. Includes the attributes that have a current state; timestamp is that attribute's last-event time (null if the attribute has never reported).", additionalProperties: [type: "object", properties: [
                        value: [type: ["string", "number", "boolean", "object", "null"], description: "Current attribute value (mixed-type across capabilities)"],
                        timestamp: [type: ["string", "null"], description: "Last-event timestamp for this attribute (yyyy-MM-dd HH:mm:ss), or null if the attribute has never reported"]
                    ]]],
                    stateError: [type: "string", description: "Present only when the post-command state read-back threw; state is then {} (an empty state with NO stateError means the device legitimately has no readable attributes). Carries the error class and message."],
                    partial: [type: "boolean", description: "Single-device form: present and true when the command fired but a confirmation step degraded -- the state read-back failed (see stateError) and/or the waitFor poll threw (see waitFor.error). commands form: present and true when some entries were sent and some failed (see failedDeviceIds). Absent on a fully clean result."],
                    waitFor: [type: "object", description: "Present only when the waitFor arg was supplied: the result of block-polling the attribute to its expected value.", properties: [
                        attribute  : [type: "string", description: "Attribute that was polled"],
                        expected   : [type: ["string", "array"], description: "The expectedValue string or expectedValues list that was awaited"],
                        converged  : [type: "boolean", description: "True if the attribute reached an expected value; false on timeout OR a hub-reload interrupt OR a poll error (see timedOut/interrupted/error)"],
                        finalValue : [type: ["string", "number", "boolean", "object", "null"], description: "Last value read (the converged value when converged=true, else the last non-matching read; null on a poll error)"],
                        elapsedMs  : [type: "integer", description: "Time spent polling, in milliseconds (absent on a poll error)"],
                        timedOut   : [type: "boolean", description: "Present and true if the poll timed out without a match"],
                        interrupted: [type: "boolean", description: "Present and true if the poll was interrupted (hub reload)"],
                        readError: [type: "boolean", description: "Present and true if reading the device threw on any poll (e.g. it was removed mid-poll); that tick's value was treated as unread"],
                        neverReported: [type: "boolean", description: "Present and true if the attribute never reported a value during the poll window"],
                        nonNumericAttribute: [type: "boolean", description: "Present and true on a TIMEOUT when a numeric comparator (gt/gte/lt/lte/between) was used on an attribute that reported a non-numeric value the whole window, so it can never match (use eq/ne for a string attribute). Distinct from neverReported."],
                        note       : [type: "string", description: "Present with nonNumericAttribute -- human-readable recovery guidance (names the comparator/attribute, suggests eq/ne for a string attribute)."],
                        transitioning: [type: "boolean", description: "Present only on a TIMEOUT: true if the value was still changing across polls (>=2 distinct non-null values seen) so the device is likely still settling, vs false for a stable non-target (a real mismatch). Best-effort: only reliable when the timeout spans a reporting jump."],
                        error      : [type: "string", description: "Present only if the poll loop threw after the command fired; the command still succeeded"]
                    ]],
                    error: [type: "string", description: "Failure reason (success=false)"],
                    note: [type: "string", description: "Recovery guidance -- on a failed batch, which entries already actuated and what to re-send"]
                ],

                // The commands form returns success/count/sentCount/results instead, so
                // device/command/state cannot be required overall.
                required: ["success"]
            ]
        ],
        [
            name: "hub_list_device_events",
            description: """Get event history for a device, an app or rule (the automation events it emitted), or the location.

[[FLAT_TRIM]]
Default: most-recent events for a device (deviceId + optional limit).
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    deviceId: [type: "string", description: "Device ID. Mutually exclusive with appId; omit both for location-level events (mode/HSM/hub variable)."],
                    appId: [type: "integer", description: "Installed-app ID for per-app events (what the app/rule emitted). Mutually exclusive with deviceId."],
                    hoursBack: [type: "integer", description: "If set, return up to this many hours of history (max 168 = 7 days) instead of just the most recent events.[[FLAT_TRIM]] Ignored when since is given.[[/FLAT_TRIM]]"],
                    since: [type: ["string", "integer"], description: "Absolute window start -- return only events AFTER this timestamp; ISO-8601 with a numeric offset (-0600 or -06:00; e.g. 2026-06-23T10:00:00.000-0600) or epoch milliseconds.[[FLAT_TRIM]] This is the format this tool emits in `date`/`sinceTimestamp`. Takes precedence over hoursBack; a future timestamp yields an empty list.[[/FLAT_TRIM]]"],
                    attribute: [type: "string", description: "Event-name filter. Device: an attribute (e.g. 'switch').[[FLAT_TRIM]] Location: 'mode', 'hsmStatus', 'hsmAlert', or a hub-variable name.[[/FLAT_TRIM]]"],
                    limit: [type: "integer", description: "Max events to return. Recent mode default 10; history mode default 100 (max 500).[[FLAT_TRIM]] Higher values may slow hub.[[/FLAT_TRIM]]", default: 10]
                ]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    events: [type: "array", description: "Event rows (most recent first)", items: [type: "object", properties: [
                        name: [type: "string", description: "Event/attribute name"],
                        value: [description: "Event value"],
                        unit: [type: "string", description: "Unit of measure, if any"],
                        description: [type: "string", description: "Human-readable description text"],
                        date: [type: "string", description: "Event timestamp (ISO)"],
                        type: [type: "string", description: "Location mode only: event type"],
                        isStateChange: [type: "boolean", description: "Whether this event was a state change"]
                    ]]],
                    count: [type: "integer", description: "Events returned"],
                    device: [type: "string", description: "Device label; present in device modes"],
                    deviceId: [type: "string", description: "Device ID; present in history mode"],
                    appId: [type: "integer", description: "App ID; present in app mode"],
                    source: [type: "string", description: "'device', 'app', or 'location'; present in history mode"],
                    sinceMode: [type: "string", enum: ["explicit", "relative"], description: "Which window drove the result: 'explicit' (since bookmark) or 'relative' (hoursBack); present in history mode"],
                    hoursBack: [type: "integer", description: "Relative history window in hours; present in history mode only when sinceMode='relative'"],
                    since: [type: "string", description: "Echoed absolute window start (ISO); present in history mode only when sinceMode='explicit'"],
                    attributeFilter: [type: "string", description: "Echoed attribute filter; present in history mode"],
                    sinceTimestamp: [type: "string", description: "Actual window start used (ISO); present in history mode"],
                    timeFilterUnparseable: [type: "integer", description: "App/location modes: rows kept despite unparseable dates (window not enforced for them); present when > 0"]
                ]
            ]
        ],
        [
            name: "hub_update_device",
            description: """Update device properties[[FLAT_TRIM]]: label, name, deviceNetworkId, room, enabled, dataValues, preferences, showOnHome, defaultCurrentState, tags[[/FLAT_TRIM]].

Only modify devices user explicitly requested. Writes require Write master. Call `hub_get_tool_guide(section='update_device')` for preferences format.""",
            inputSchema: [
                type: "object",
                properties: [
                    deviceId: [type: "string", description: "The device ID to update (from hub_list_devices or hub_list_devices(filter='virtual'))"],
                    label: [type: "string", description: "New display label for the device"],
                    name: [type: "string", description: "New device name"],
                    deviceNetworkId: [type: "string", description: "New device network ID (must be unique across all hub devices)"],
                    room: [type: "string", description: "Room name to assign the device to (case-sensitive, must match an existing room)"],
                    enabled: [type: "boolean", description: "Set to true to enable or false to disable the device"],
                    dataValues: [type: "object", description: "Key-value pairs to set in the device's Data section. Example: {\"firmware\": \"1.2.3\", \"model\": \"ABC\"}",
                        additionalProperties: [type: "string"]],
                    preferences: [type: "object", description: "Device preferences to update. Each value must be an object with 'type' and 'value'. Example: {\"pollInterval\": {\"type\": \"number\", \"value\": 30}}"],
                    showOnHome: [type: "boolean", description: "Show this device on the hub Home page.[[FLAT_TRIM]] Also counts it in the quick status-bar summaries (climate/lights/locks/etc.)[[/FLAT_TRIM]]"],
                    defaultCurrentState: [type: "string", description: "Which attribute appears in the Status column[[FLAT_TRIM]] (Devices/Rooms pages)[[/FLAT_TRIM]], e.g. \"switch\"; \"\" selects None."],
                    tags: [type: "array", description: "Free-form device tags; REPLACES the full set ([] clears all).", items: [type: "string"]]
                ],
                required: ["deviceId"]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    success: [type: "boolean", description: "True when all requested changes applied without error"],
                    device: [type: "string", description: "Device label"],
                    deviceId: [type: "string", description: "Device ID"],
                    changes: [type: "array", description: "Applied changes", items: [type: "object", properties: [
                        property: [type: "string", description: "Property changed"],
                        oldValue: [description: "Prior value, when known"],
                        newValue: [description: "New value"]
                    ]]],
                    errors: [type: "array", description: "Per-property failures, or null when none", items: [type: "object", properties: [
                        property: [type: "string", description: "Property that failed"],
                        error: [type: "string", description: "Failure reason"]
                    ]]],
                    message: [type: "string", description: "Human-readable summary"]
                ],
                required: ["success", "device", "deviceId", "message"]
            ]
        ],
        // Device Admin
        [
            name: "hub_delete_device",
            description: """⚠️ MOST DESTRUCTIVE: Permanently delete a device. NO UNDO. For ghost/orphaned/stuck devices only.

PRE-FLIGHT: 1) Backup <24h 2) hub_get_device to verify 3) Warn user 4) Z-Wave/Zigbee → exclusion first 5) Get confirmation
Device + history lost, automations break. Requires Write master.""",
            inputSchema: [
                type: "object",
                properties: [
                    deviceId: [type: "string", description: "The device ID to permanently delete"],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms backup was created, device was verified, and user explicitly approved the deletion."]
                ],
                required: ["deviceId", "confirm"]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    success: [type: "boolean", description: "Whether deletion was verified"],
                    deviceId: [type: "string", description: "Deleted device ID"],
                    deviceName: [type: "string", description: "Device label/name"],
                    message: [type: "string", description: "Human-readable result"],
                    warnings: [type: "array", description: "Pre-delete warnings (active device, radio membership, rule references)", items: [type: "string"]],
                    auditInfo: [type: "object", description: "Audit trail", properties: [
                        deletedAt: [type: "string", description: "Deletion timestamp"],
                        deviceType: [type: "string", description: "Driver/type name"],
                        deviceNetworkId: [type: "string", description: "Deleted device's DNI"],
                        driverName: [type: "string", description: "Driver name"],
                        lastHubBackup: [type: "string", description: "Last hub backup timestamp"]
                    ]]
                ],
                required: ["success", "deviceId", "deviceName", "message"]
            ]
        ],
        [
            name: "hub_call_device_swap",
            description: """⚠️ DESTRUCTIVE: Swap a device — replace from_device_id with to_device_id across ALL apps and rules that reference it, in one operation.

Pre-flight (mandatory): 1) hub backup <24h (hub_create_backup); 2) preview the blast radius with hub_list_device_dependents(deviceId=from_device_id) — every app listed gets rewired; 3) confirm with the user.""",
            inputSchema: [
                type: "object",
                properties: [
                    from_device_id: [type: "string", description: "Device ID whose references will be replaced everywhere (from hub_list_devices)."],
                    to_device_id: [type: "string", description: "Replacement device ID. Must be capability-compatible — on mismatch the error lists the compatible candidates."],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms a hub backup exists (<24h) and the user approved the swap."]
                ],
                required: ["from_device_id", "to_device_id", "confirm"]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    success: [type: "boolean", description: "Whether the swap completed"],
                    swapped: [type: "object", description: "The committed swap", properties: [
                        from: [type: "string", description: "Replaced device ID"],
                        to: [type: "string", description: "Replacement device ID"]
                    ]],
                    verified: [type: "boolean", description: "true when the before/after dependent counts were both read and confirmed the swap; false = swap clicked but count verification was degraded"],
                    appsRewired: [type: "integer", description: "Apps that referenced from_device_id before the swap (the rewired set); absent when the pre-count was unavailable"],
                    remainingDependents: [type: "integer", description: "Apps still referencing from_device_id after the swap (0 expected)"],
                    note: [type: "string", description: "Verification guidance"],
                    error: [type: "string", description: "Failure reason (success=false)"],
                    compatibleOptions: [type: "array", description: "Incompatible-target failure: compatible replacement devices the hub offered (first 30)", items: [type: "object", properties: [
                        id: [type: "string", description: "Device ID"],
                        label: [type: "string", description: "Device label"]
                    ]]],
                    compatibleOptionCount: [type: "integer", description: "Total compatible options offered (may exceed the 30 listed)"],
                    buttonsFound: [type: "array", description: "Button-discovery failure: action button names found on the swap page", items: [type: "string"]]
                ],
                required: ["success"]
            ]
        ],
        [
            name: "hub_call_device_replace",
            description: """⚠️ DESTRUCTIVE: Replace a device's hardware, KEEPING its id + all app/rule references.

[[FLAT_TRIM]]
Two-step: list_options=true to list candidates, then apply with confirm=true.
[[/FLAT_TRIM]]
Pre-flight: backup <24h (hub_create_backup) + user OK.""",
            inputSchema: [
                type: "object",
                properties: [
                    old_device_id: [type: "string", description: "Device to replace; its id is preserved."],
                    new_device_id: [type: "string", description: "Compatible replacement device."],
                    list_options: [type: "boolean", description: "Read-only: list compatible replacement candidates (no confirm)."],
                    confirm: [type: "boolean", description: "REQUIRED to apply (omit for list_options): confirms backup <24h + user approval."]
                ],
                required: ["old_device_id"]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    success: [type: "boolean", description: "Whether the replace (or options read) succeeded"],
                    listOptions: [type: "boolean", description: "True when this was a read-only list_options call"],
                    options: [type: "array", description: "Compatible replacement candidates (list_options); each {id, name, deviceTypes}", items: [type: "object", properties: [
                        id: [type: "string", description: "Candidate device ID"],
                        name: [type: "string", description: "Candidate device name"],
                        deviceTypes: [type: "array", description: "Dashboard/device types the candidate supports", items: [type: "string"]]
                    ]]],
                    optionCount: [type: "integer", description: "Number of compatible candidates"],
                    replaced: [type: "object", description: "The committed replace (apply path)", properties: [
                        oldDeviceId: [type: "string", description: "The preserved device id"],
                        newDeviceId: [type: "string", description: "The device whose hardware was adopted"]
                    ]],
                    preservedDeviceId: [type: "string", description: "The device id that survives (the old id)"],
                    message: [type: "string", description: "Human-readable result"],
                    error: [type: "string", description: "Failure reason (success=false)"],
                    note: [type: "string", description: "Next-step / recovery guidance"]
                ],
                required: ["success"]
            ]
        ],
        [
            name: "hub_create_device",
            description: """Create a device from a driver TYPE id. Requires Write master + confirm.[[FLAT_TRIM]] For LAN/integration/software drivers, NOT radio pairing (Z-Wave/Zigbee/Matter); for virtual devices use hub_manage_virtual_device.[[/FLAT_TRIM]]""",
            inputSchema: [
                type: "object",
                properties: [
                    deviceTypeId: [type: "string", description: "Driver-type id to instantiate (the 'id' from hub_list_drivers(include='all'))."],
                    label: [type: "string", description: "Optional display label for the new device."],
                    confirm: [type: "boolean", description: "REQUIRED: must be true to create the device."]
                ],
                required: ["deviceTypeId", "confirm"]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    success: [type: "boolean", description: "Whether the device was created"],
                    deviceId: [type: "string", description: "New device id"],
                    label: [type: "string", description: "Applied/current label"],
                    name: [type: "string", description: "Device name (driver default)"],
                    deviceTypeId: [type: "string", description: "Driver-type id used"],
                    deviceTypeName: [type: "string", description: "Driver type name"],
                    virtual: [type: "boolean", description: "Whether the hub flagged the new device virtual"],
                    capabilities: [type: "array", description: "Capability names", items: [type: "string"]],
                    warnings: [type: "array", description: "Non-fatal warnings (e.g. radio-driver orphan-shell)", items: [type: "string"]],
                    message: [type: "string", description: "Human-readable result"],
                    error: [type: "string", description: "Failure reason (success=false)"],
                    note: [type: "string", description: "Next-step guidance"]
                ],
                required: ["success"]
            ]
        ],
        [
            name: "hub_get_compatible_devices",
            description: """Search Hubitat's official compatible-devices catalog of brands/models[[FLAT_TRIM]] with pairing/exclusion/factory-reset instructions and the Hubitat driver each maps to[[/FLAT_TRIM]]. Read-only reference -- NOT your installed devices.""",
            inputSchema: [
                type: "object",
                properties: [
                    query: [type: "string", description: "Free-text match across brand, name, product number, device type, and driver name."],
                    brand: [type: "string", description: "Filter by brand (substring, case-insensitive)."],
                    protocol: [type: "string", description: "Filter by protocol (substring), e.g. 'Zigbee'."],
                    deviceType: [type: "string", description: "Filter by device type (substring), e.g. 'Dimmer'."],
                    includeInstructions: [type: "boolean", description: "Include join/exclude/factory-reset instructions[[FLAT_TRIM]] (HTML stripped) + notes[[/FLAT_TRIM]]. Default false (summaries)."],
                    cursor: [type: "string", description: "Pagination cursor. Pass \"\" (or omit) for the first page; iterate nextCursor."]
                ]
            ],
            outputSchema: [
                type: "object",
                properties: [
                    success: [type: "boolean", description: "True on a successful read"],
                    devices: [type: "array", description: "Matched catalog entries (projected; instructions only when includeInstructions=true)", items: [type: "object"]],
                    count: [type: "integer", description: "Entries on this page"],
                    total: [type: "integer", description: "Total entries matched by the filter"],
                    nextCursor: [type: "string", description: "Present when more results remain"],
                    note: [type: "string", description: "Pagination / filtering guidance"],
                    error: [type: "string", description: "Failure reason (success=false)"]
                ],
                required: ["success"]
            ]
        ],
    ]
}

def _readOnlyToolNames_partDevices() {
    // Read-only classification membership for this library's tools, contributed to the
    // app's getReadOnlyToolNames() aggregator (issue #209: per-tool metadata lives with
    // the tool). A tool absent from every part list is write+destructive by default.
    return [
        // Device introspection
        "hub_list_devices", "hub_get_device", "hub_get_device_attribute", "hub_list_device_events",
        // Compatible-devices catalog (static reference read)
        "hub_get_compatible_devices"
    ]
}

def _idempotentWriteToolNames_partDevices() {
    // Retry-safe writes (MCP idempotentHint) for this library's tools -- contributed to the
    // app's getIdempotentWriteToolNames() aggregator; see the classification rules there.
    return [
        // Devices
        "hub_update_device", "hub_delete_device"
    ]
}

def _toolDisplayMeta_partDevices() {
    // Human-facing title/summary per tool (MCP annotations.title + the Advanced per-tool
    // overrides menu) -- merged into the app's getToolDisplayMeta() aggregator (issue #209).
    return [
        // Devices
        hub_list_devices: [title: "List Devices", summary: "List accessible devices with filtering, pagination, and field projection."],
        hub_get_device: [title: "Get Device Details", summary: "Get one device's full details: attributes, commands, capabilities."],
        hub_get_device_attribute: [title: "Get Device Attribute", summary: "Read one attribute value, optionally waiting until it matches an expected value."],
        hub_list_device_events: [title: "List Device Events", summary: "Recent events for a device or app, or location events when neither is given."],
        hub_call_device_command: [title: "Send Device Command", summary: "Send a command like on, off, or setLevel to one device, or up to 20 in one call."],
        hub_call_device_swap: [title: "Swap Device", summary: "Replace a device across all apps and rules that reference it, in one operation."],
        hub_call_device_replace: [title: "Replace Device Hardware", summary: "Re-point a device to replacement hardware, keeping its id and all references."],
        hub_update_device: [title: "Update Device Properties", summary: "Update a device's label, room, preferences, show-on-home, status attribute, or tags."],
        hub_create_device: [title: "Create Device From Driver", summary: "Create a device from a driver-type id (LAN/integration/software drivers; not radio hardware)."],
        hub_get_compatible_devices: [title: "Search Compatible Devices", summary: "Search Hubitat's compatible-device catalog for models and pairing/reset instructions."],
        hub_delete_device: [title: "Delete Device", summary: "Permanently delete a device from the hub (no undo)."]
    ]
}
