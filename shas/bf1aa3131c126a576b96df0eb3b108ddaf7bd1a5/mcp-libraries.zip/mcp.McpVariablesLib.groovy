library(name: "McpVariablesLib", namespace: "mcp", author: "kingpanther13", description: "Hub variable + connector tool implementations (list/get/set/create/delete variables, connectors, change history) plus the variable event-subscription handlers for the MCP Rule Server; #include'd by the main app. Gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")

private boolean _refreshHubVarInUseRegistrations() {
    Set<String> currentVars = [] as Set
    Set<String> hubVarNames
    try {
        hubVarNames = (getAllGlobalVars()?.keySet() ?: []) as Set<String>
    } catch (Exception e) {
        mcpLogError("hub-vars", "Hub variable inventory failed -- in-use safety registrations remain stale until setup retries", e)
        return false
    }
    if (hubVarNames) {
        try {
            getChildApps()?.each { child ->
                def ruleData = null
                try { ruleData = child.getRuleData() } catch (Exception e) { /* not an MCP rule child */ }
                if (ruleData) {
                    def serialized = groovy.json.JsonOutput.toJson(ruleData)
                    hubVarNames.each { varName ->
                        // Match a whole JSON value so temp cannot match temperature.
                        def needle = "\"${varName}\""
                        if (serialized?.contains(needle)) currentVars << varName
                    }
                }
            }
        } catch (Exception e) {
            mcpLogError("hub-vars", "Child rule scan failed -- in-use safety registrations remain stale until setup retries", e)
            return false
        }
    }

    def previous = ((atomicState.inUseHubVars ?: []) as List<String>) as Set<String>
    def registered = previous + ([] as Set)
    def toAdd = currentVars - previous
    def toRemove = previous - currentVars
    boolean complete = true
    toAdd.each { name ->
        try {
            addInUseGlobalVar(name)
            registered << name
        } catch (Exception e) {
            complete = false
            mcpLogError("hub-vars", "addInUseGlobalVar('${name}') failed -- in-use safety warning will not surface for this var", e)
        }
    }
    toRemove.each { name ->
        try {
            removeInUseGlobalVar(name)
            registered.remove(name)
        } catch (Exception e) {
            complete = false
            mcpLogError("hub-vars", "removeInUseGlobalVar('${name}') failed -- stale in-use registration will linger", e)
        }
    }
    // Remember completed operations; failed additions/removals must remain eligible on retry.
    atomicState.inUseHubVars = (registered as List).sort()
    if (toAdd || toRemove) {
        mcpLog("info", "hub-vars", "in-use registrations refreshed: complete=${complete}, total=${registered.size()}")
    }
    return complete
}

private boolean _subscribeToAllHubVariables() {
    def vars
    try { vars = getAllGlobalVars() }
    catch (Exception e) {
        mcpLogError("hub-vars", "Hub variable inventory failed -- subscriptions remain incomplete until setup retries", e)
        return false
    }
    if (location == null) return false
    boolean complete = true
    vars?.keySet()?.each { varName ->
        try {
            subscribe(location, "variable:${varName}", "handleHubVariableEvent")
        } catch (Throwable e) {
            // Continue other subscriptions. The retry backoff also bounds persistent bad-name failures.
            // Catch Throwable because hubitat_ci's subscription validator throws AssertionError.
            complete = false
            mcpLog("error", "hub-vars", "subscribe to variable:${varName} failed: ${e.message} -- hub_list_variable_changes will not capture changes for this var")
        }
    }
    return complete
}

def renameVariable(String oldName, String newName) {
    mcpLog("info", "hub-vars", "renameVariable callback: '${oldName}' -> '${newName}'")
    def history = atomicState.variableHistory ?: []
    def rewrote = false
    history = history.collect { entry ->
        if (entry?.name == oldName) {
            rewrote = true
            // Groovy Map +: rightmost map's keys override; produces a new
            // map with `name` updated and other fields preserved.
            return entry + [name: newName]
        }
        return entry
    }
    if (rewrote) atomicState.variableHistory = history
    // Re-subscribe to the new name. The old "variable:OLD" event will
    // never fire again since the variable is gone, but Hubitat's
    // unsubscribe semantics mean it's harmless to leave it in place.
    // Catch Throwable because the hubitat_ci validator throws AssertionError
    // (not Exception) when location is null in unit-test environments;
    // history rewrite is the important part and shouldn't be aborted by a
    // subscription registration failure.
    if (location != null) {
        try { subscribe(location, "variable:${newName}", "handleHubVariableEvent") }
        catch (Throwable e) {
            mcpLog("error", "hub-vars", "post-rename subscribe to variable:${newName} failed: ${e.message} -- history capture for renamed var will lag until next initialize()")
        }
    }
}

def handleHubVariableEvent(evt) {
    if (evt == null) return
    def varName = evt.name?.toString()
    if (varName?.startsWith("variable:")) {
        varName = varName.substring("variable:".length())
    }
    if (!varName) return

    def entry = [
        name: varName,
        value: evt.value,
        timestamp: now(),
        descriptionText: evt.descriptionText?.toString()
    ]
    // Best-effort, non-transactional read-append-cap-write. atomicState gives
    // per-write durability, not read-then-write atomicity, and the sandbox has
    // no CAS primitive: concurrent variable: events may read the same snapshot
    // and drop an append. Acceptable for a best-effort history buffer.
    def history = atomicState.variableHistory ?: []
    history << entry
    // Cap the buffer. 200 entries is enough to survive an MCP-tool
    // round-trip plus a few minutes of bursty change activity without
    // blowing up state size on hubs with many vars.
    def cap = 200
    if (history.size() > cap) {
        history = history[(history.size() - cap)..-1]
    }
    atomicState.variableHistory = history
}

def toolGetVariableHistory(args) {
    def history = atomicState.variableHistory ?: []
    def filtered = history
    if (args?.name) {
        def n = args.name.toString()
        filtered = filtered.findAll { it?.name == n }
    }
    if (args?.sinceMs != null) {
        def since = args.sinceMs as Long
        filtered = filtered.findAll { (it?.timestamp ?: 0L) >= since }
    }
    def limit = (args?.limit != null) ? (args.limit as Integer) : 50
    if (limit < 1) limit = 1
    // Most-recent first; cap at limit.
    def recent = filtered.reverse().take(limit)
    return [
        entries: recent,
        total: recent.size(),
        bufferSize: history.size(),
        bufferCap: 200
    ]
}

def toolListVariables(args = null) {
    // Modern Hub Variable API (issue #92): getAllGlobalVars() sees every hub
    // variable, not just the connector-exposed subset that the legacy
    // getAllGlobalConnectorVariables() returned. Each entry is shaped like
    // [name, type, value, deviceId, attribute] — deviceId/attribute populated
    // when the variable has a Connector device, null otherwise.
    def hubVariables = []
    String hubVarsError = null
    try {
        def allVars = getAllGlobalVars()
        if (allVars) {
            hubVariables = allVars.collect { name, var ->
                [
                    name: name,
                    value: var?.value,
                    type: var?.type,
                    deviceId: var?.deviceId,
                    attribute: var?.attribute,
                    source: "hub"
                ]
            }
        }
    } catch (Exception e) {
        // Surface to mcpLog (not just logDebug) so a "no hub variables" response can be
        // distinguished from "hub variable API broke" via hub_get_logs(mode='mcp').
        hubVarsError = e.message ?: e.toString()
        mcpLog("warn", "hub-vars", "hub_list_variables: getAllGlobalVars() failed: ${hubVarsError} -- returning empty hubVariables", null, [details: [error: hubVarsError]])
    }

    def ruleVariables = state.ruleVariables?.collect { name, value ->
        [name: name, value: value, source: "rule_engine"]
    } ?: []

    // type filter: the hub-variable type as hub_create_variable names it, matched against the
    // hub's stored type (integer, bigdecimal, string, boolean, datetime).
    if (args?.type != null) {
        // Accepts the create names and the stored names the listing shows (integer, bigdecimal, ...).
        def hubType = [number: "integer", integer: "integer", decimal: "bigdecimal", bigdecimal: "bigdecimal", string: "string",
                       boolean: "boolean", datetime: "datetime"].get(args.type.toString().toLowerCase())
        if (hubType == null) throw new IllegalArgumentException("type must be one of Number, Decimal, String, Boolean, DateTime.")
        hubVariables = hubVariables.findAll { it.type?.toString()?.toLowerCase() == hubType }
        ruleVariables = []
    }

    def cursor = args?.cursor
    def paged = _paginateList(hubVariables, cursor, 100, "hub_list_variables")
    // Both per-list totals are always emitted so a caller can distinguish "1000 hub
    // vars + 0 rule vars" from "0 hub vars + 1000 rule vars" without needing cursor
    // context. `total` is the legacy summed field; the per-list fields are the
    // primary contract going forward.
    def result = [
        hubVariables: paged.page,
        ruleVariables: ruleVariables,
        totalHubVariables: hubVariables.size(),
        totalRuleVariables: ruleVariables.size(),
        total: hubVariables.size() + ruleVariables.size()
    ]
    if (hubVarsError) result.hubVariablesError = hubVarsError
    if (cursor != null && paged.nextCursor != null) result.nextCursor = paged.nextCursor
    return result
}

def toolGetVariable(args) {
    // Accept either a bare variable name (direct callers) or the dispatch args map
    // {name, includeDependents}.
    String name = (args instanceof Map) ? args.name : args
    boolean includeDependents = (args instanceof Map) && (args.includeDependents == true)

    def found = null
    try {
        def hubVar = getGlobalVar(name)
        if (hubVar != null) {
            found = [
                name: name,
                value: hubVar.value,
                type: hubVar.type,
                deviceId: hubVar.deviceId,
                attribute: hubVar.attribute,
                source: "hub"
            ]
        }
    } catch (Exception e) {
        mcpLog("debug", "hub-vars", "Hub variable '${name}' lookup threw ${e.class.simpleName}: ${e.message}")
    }

    if (found == null) {
        def ruleVar = state.ruleVariables?.get(name)
        if (ruleVar != null) found = [name: name, value: ruleVar, source: "rule_engine"]
    }

    if (found == null) throw new IllegalArgumentException("Variable not found: ${name}")

    // The in-use registry is hub-variable-only, so dependents apply only when the lookup resolved to a
    // hub variable -- a rule-engine variable gets no dependents fields.
    if (includeDependents && found.source == "hub") _attachHubVarDependents(found, name)
    return found
}

// Opt-in: attach the apps that reference this HUB variable (its in-use registry) to a hub_get_variable
// response. Opt-in because it CLICKS the Settings > Hub Variables "Show In Use Apps" wizard reveal (a
// transient UI toggle, dismissed afterward). Reports every failure IN the response -- it must never
// fail the whole hub_get_variable call.
private void _attachHubVarDependents(Map found, String name) {
    found.coverageNote = _hubVarDependentsCoverageNote()
    Integer hubVarsAppId = null
    try { hubVarsAppId = _findHubVariablesAppId() }
    catch (Exception e) {
        found.dependentsError = "Could not resolve the Hub Variables system app: ${e.message}"
        found.dependentsNote = "Check that Hub Variables is enabled (Settings > Hub Variables), then retry. See hub_get_tool_guide(section='variables')."
        return
    }
    def res = _hubVarInUseApps(hubVarsAppId, name)
    if (res.error) {
        found.dependentsError = res.error
        found.dependentsNote = res.note
        return
    }
    found.appsUsing = res.apps
    found.count = res.apps.size()
}

// Hub variable name validation. Hubitat's UI rejects ' " \ ~ [ : ] < > and
// blank names. Reproduced here so the create tool fails fast with a clean
// error before we touch the wizard. Returned via getters because the
// Hubitat sandbox rejects `private static final` at script scope.
private List getHubVarForbiddenChars() {
    return ["'", '"', '\\', '~', '[', ':', ']', '<', '>']
}

// Sentinel appended to the IllegalStateException message thrown by
// _rmClearActions on the retry-window-expired path. The action-mutation
// dispatcher catches the throw, detects this token, and routes to the
// structured eventual-consistency response shape (asyncCommitLikely:true).
// Centralized so the throw site and every strip site share a single source
// of truth -- a typo or drift would silently fall back to the legacy flat
// error shape and lose the data-loss-protection contract. Leading space is
// intentional: stripping " [asyncCommitLikely]" removes the separator too.
private String getAsyncCommitMarker() {
    return " [asyncCommitLikely]"
}

private List getHubVarTypes() {
    return ["Number", "Decimal", "String", "Boolean", "DateTime"]
}

private void _validateHubVarName(String name) {
    if (!name?.trim()) {
        throw new IllegalArgumentException("Variable name is required")
    }
    def bad = getHubVarForbiddenChars().findAll { c -> name.contains(c) }
    if (bad) {
        throw new IllegalArgumentException(
            "Variable name '${name}' contains forbidden character(s): ${bad.join(' ')}. " +
            "Hubitat rejects: ' \" \\ ~ [ : ] < >")
    }
}

private String _validateHubVarType(String type) {
    def types = getHubVarTypes()
    def match = types.find { it.equalsIgnoreCase(type) }
    if (!match) {
        throw new IllegalArgumentException(
            "Variable type '${type}' is invalid. Must be one of: ${types.join(', ')}")
    }
    return match  // canonical casing
}

// Wizard-priming for the Hub Variables system app. Verified on firmware
// 2.5.0.126: clicks via _rmClickAppButton silently no-op unless the app's
// wizard state is "warmed" first. The configure-json + statusJson GET pair
// reliably primes it; a single bare GET does not.
//
// Non-private so test specs can override via script.metaClass.
def _primeHubVarsWizard(Integer appId, String context) {
    try {
        hubInternalGet("/installedapp/configure/json/${appId}")
        hubInternalGet("/installedapp/statusJson/${appId}")
    } catch (Exception e) {
        mcpLog("debug", "hub-vars", "${context}: _primeHubVarsWizard for ${appId} threw ${e.class.simpleName}: ${e.message}")
    }
}

// Non-private so test specs can override via script.metaClass — internal calls
// from this script's other methods would bypass the metaClass dispatch on a
// private method and hit the real implementation, which makes mocking the
// hub-side discovery painful in unit tests.
def _findHubVariablesAppId() {
    // Stage 1: atomicState cache.
    def cached = atomicState.hubVarsAppId
    if (cached != null) {
        try { return cached.toString().toInteger() } catch (NumberFormatException e) {
            mcpLog("warn", "hub-vars", "Invalid cached hubVarsAppId '${cached}' -- rediscovering")
            atomicState.remove("hubVarsAppId")
        }
    }

    // Stage 2: name-addressed direct alias -- a single redirect chain, no
    // payload walking. Safe to probe: hubVariables is a singleton, so the
    // chain's create hop is get-or-create and never strands a transient
    // instance.
    def directId = _resolveDirectAppId("hubVariables")
    if (directId != null) {
        atomicState.hubVarsAppId = directId
        mcpLog("info", "hub-vars", "Discovered Hub Variables app id: ${directId} (via /installedapp/direct/hubVariables)")
        return directId
    }

    // Stage 3: /hub2/appsList walk.
    try {
        def responseText = hubInternalGet("/hub2/appsList")
        if (responseText) {
            def parsed = new groovy.json.JsonSlurper().parseText(responseText)
            def found = null
            def recurse
            recurse = { node ->
                def d = node?.data
                if (found == null && d?.type == "Hub Variables" && d?.id != null) {
                    found = d
                }
                node?.children?.each { c -> recurse(c) }
            }
            (parsed?.apps ?: []).each { a -> recurse(a) }
            if (found?.id != null) {
                def id = found.id.toString().toInteger()
                // The feed's type label is the only evidence on this path, so
                // confirm via configure/json before caching -- a wrong cached id
                // would break every wizard-driving tool until manually cleared.
                // Best-effort: a definitive name mismatch rejects; a fetch error
                // must NOT discard an otherwise name-keyed match (transient HTTP
                // trouble would lock the tools out entirely).
                def verified = true
                try {
                    def cfgText = hubInternalGet("/installedapp/configure/json/${id}")
                    if (cfgText) {
                        def cfg = new groovy.json.JsonSlurper().parseText(cfgText)
                        if (cfg?.app?.appType?.name != "Hub Variables") verified = false
                    }
                } catch (Exception e) {
                    mcpLog("debug", "hub-vars", "_findHubVariablesAppId: verify fetch for ${id} threw ${e.class.simpleName}: ${e.message}")
                }
                if (verified) {
                    atomicState.hubVarsAppId = id
                    mcpLog("info", "hub-vars", "Discovered Hub Variables app id: ${id} (via /hub2/appsList)")
                    return id
                }
                mcpLog("warn", "hub-vars", "appsList candidate ${id} failed configure/json verification -- not caching")
            }
        }
    } catch (Exception e) {
        mcpLog("debug", "hub-vars", "_findHubVariablesAppId: /hub2/appsList walk threw ${e.class.simpleName}: ${e.message}")
    }

    throw new IllegalStateException(
        "Hub Variables system app not found via the /installedapp/direct/hubVariables redirect chain " +
        "OR the /hub2/appsList walk. This should not happen on a normally-functioning hub -- the app " +
        "is system-installed. Check that Hub Variables is enabled (Settings > Hub Variables).")
}

def toolCreateVariable(args) {
    requireDestructiveConfirm(args.confirm)
    args = args ?: [:]

    // Hub Mesh LINK form: create a local variable linked to one a peer hub shares. Mutually exclusive
    // with every create form (single and bulk). Validation before any hub call. "Wants to link" is a
    // NON-BLANK source value, not key presence -- a mesh_source_*:null on a normal create must not be
    // pushed onto the link path.
    String meshHubId = args.mesh_source_hub_id?.toString()?.trim()
    String meshName = args.mesh_source_name?.toString()?.trim()
    boolean wantsMeshLink = meshHubId || meshName
    if (wantsMeshLink) {
        if (args.name != null || args.type != null || args.value != null || args.variables != null) {
            throw new IllegalArgumentException(
                "Provide EITHER a new-variable create (name/type/value or the variables array) OR a Hub Mesh link " +
                "(mesh_source_hub_id + mesh_source_name) -- not both.")
        }
        if (!meshHubId || !meshName) {
            throw new IllegalArgumentException(
                "Linking a Hub Mesh variable needs BOTH mesh_source_hub_id and mesh_source_name " +
                "(the hubId + name of one hub_get_hub_mesh availableLinkedHubVariables[] row).")
        }
        return _createLinkedMeshVariable(meshHubId, meshName)
    }

    // Bulk form: variables=[{name,type,value}, ...]. Mutually exclusive with
    // the single name/type/value form. Each item is created SEQUENTIALLY
    // through the shared Hub Variables system app -- the create wizard has a
    // known post-write race that makes rapid/parallel creates spuriously fail,
    // so the loop never parallelizes.
    if (args.variables != null) {
        if (args.name != null || args.type != null || args.value != null) {
            throw new IllegalArgumentException(
                "Provide EITHER the single name/type/value form OR the bulk variables array -- not both.")
        }
        return _createVariablesBulk(args.variables)
    }

    def name = args.name?.toString()?.trim()
    _validateHubVarName(name)
    def type = _validateHubVarType(args.type?.toString())
    def value = args.value
    _validateInitialValue(name, type, value)

    // Refuse to silently overwrite an existing variable — the UI's "Create"
    // path can't either; the wizard only progresses when the name is novel.
    try {
        def existing = getGlobalVar(name)
        if (existing != null) {
            throw new IllegalArgumentException(
                "Hub variable '${name}' already exists (type=${existing.type}, value=${existing.value}). " +
                "Use hub_set_variable to change the value, or pick a different name.")
        }
    } catch (IllegalArgumentException reraise) { throw reraise }
    catch (Exception e) {
        mcpLog("debug", "hub-vars", "hub_create_variable: getGlobalVar('${name}') threw ${e.class.simpleName}: ${e.message}")
    }

    def appId = _findHubVariablesAppId()
    return _createOneVariable(appId, name, type, value)
}

// Hub Mesh: create a LOCAL linked variable from one a peer hub shares (GET
// /hub2/createLinkedHubVar/<hubId>/<name>). A 200 is NOT proof of success -- the endpoint returns an
// empty body even when the link silently no-ops (seen live while the mesh was still re-establishing a
// recently-rebooted peer). The read-back keys on the SOURCE pair and classifies three outcomes: linked
// (success), a confirmed no-op (FAILURE), and an unreadable mesh list (the only warn-not-fail). A local
// linked row's display `name` is DECORATED ("<name> on <peer>"); the bare source name is in
// `sourceVarName`, so the confirmation signal is a localLinkedHubVariables row whose sourceVarName +
// sourceHubId match this pair (NOT a name match). The id/name are passed literally: the platform HTTP
// layer encodes the path, so pre-encoding here would double-encode.
private Map _createLinkedMeshVariable(String meshHubId, String meshName) {
    Map beforeJson = _meshJson()
    def availBefore = (beforeJson?.availableLinkedHubVariables instanceof List) ? beforeJson.availableLinkedHubVariables : null
    def localBefore = (beforeJson?.localLinkedHubVariables instanceof List) ? beforeJson.localLinkedHubVariables : null

    def resolveLocal = { List rows ->
        (rows instanceof List) ? rows.find {
            it?.sourceVarName?.toString() == meshName && it?.sourceHubId?.toString() == meshHubId } : null
    }

    // Pre-validate BEFORE the GET (validation-before-side-effect). Two short-circuits, in order:
    //  (a) already linked -- a linked source LEAVES availableLinkedHubVariables (it moves to
    //      localLinkedHubVariables), so check the local mirror by source FIRST; also honor a
    //      still-offered row flagged linkedLocally. No fresh GET, no fresh-success claim.
    //  (b) not offered -- pool readable but no matching row AND not already linked -> reject (an
    //      unoffered pair would otherwise read as "linked" in the read-back and false-succeed).
    def srcBeforeRow = (availBefore != null)
        ? availBefore.find { it.hubId?.toString() == meshHubId && it.name?.toString() == meshName }
        : null
    boolean sourceWasOffered = (srcBeforeRow != null)
    def existingLocal = resolveLocal(localBefore)
    if (existingLocal != null || srcBeforeRow?.linkedLocally == true) {
        def existing = existingLocal
        mcpLog("info", "variables", "hub_create_variable: Hub Mesh variable '${meshName}' from hub ${meshHubId} is already linked${existing ? " as '${existing.name}'" : ''}")
        def already = [
            success: true,
            alreadyLinked: true,
            name: existing?.name?.toString() ?: meshName,
            sourceName: meshName,
            sourceHubId: meshHubId,
            linked: true,
            message: "Hub Mesh variable '${meshName}' shared by hub ${meshHubId} was already linked here${existing ? " as '${existing.name}'" : ''}.",
            note: "This is a local mirror of a variable on the peer hub. Read all linked variables via hub_get_hub_mesh."
        ]
        if (existing == null) already.warnings = ["Already linked, but the local mirror name did not resolve from hub_get_hub_mesh localLinkedHubVariables; the returned name is the bare source name and may not identify the mirror. Verify it with hub_get_hub_mesh."]
        return already
    }
    if (availBefore != null && !sourceWasOffered) {
        throw new IllegalArgumentException(
            "No shared variable with hubId ${meshHubId} + name '${meshName}' is offered in " +
            "hub_get_hub_mesh availableLinkedHubVariables[], and it is not already linked here. Copy the " +
            "hubId + name from an availableLinkedHubVariables[] row and retry.")
    }

    // A 30s read timeout can fire AFTER the hub applied the link, so a throw is an UNKNOWN outcome, not
    // a definite failure: capture it and let the read-back decide (like the no-op path).
    String linkThrew = null
    try {
        hubInternalGet("/hub2/createLinkedHubVar/${meshHubId}/${meshName}", null, 30)
    } catch (Exception e) {
        mcpLogError("variables", "hub_create_variable Hub Mesh link GET errored (hub ${meshHubId}, variable ${meshName})", e)
        linkThrew = e.message ?: e.toString()
    }

    // Read-back with a short backoff. Tri-state `linked`: true (proven linked), false (proven still
    // unlinked = silent no-op), null (could not decide -- mesh list unreadable). The link took if a
    // localLinkedHubVariables row now mirrors this source OR the source's availableLinkedHubVariables
    // row is gone / flagged linkedLocally; it did NOT take if that row is still present-and-unlinked.
    Boolean linked = null
    def matchedLocalRow = null
    for (int attempt = 0; attempt < 3; attempt++) {
        Map j = _meshJson()
        def afterRows = (j?.localLinkedHubVariables instanceof List) ? j.localLinkedHubVariables : null
        def avail = (j?.availableLinkedHubVariables instanceof List) ? j.availableLinkedHubVariables : null
        def localRow = resolveLocal(afterRows)
        boolean localHasLink = (localRow != null)
        if (localRow != null) matchedLocalRow = localRow
        Boolean availLinked = null
        if (avail != null) {
            def srcRow = avail.find { it.hubId?.toString() == meshHubId && it.name?.toString() == meshName }
            if (srcRow == null) {
                // Source row absent: "took" only when the pair was offered before this call
                // (sourceWasOffered). A pair that was never offered is absent for a different reason,
                // so its absence is inconclusive here -- fall back to the local-link signal.
                availLinked = sourceWasOffered ? true : null
            } else {
                availLinked = (srcRow.linkedLocally == true)
            }
        }
        if (localHasLink || availLinked == true) {
            linked = true; break
        } else if (availLinked == false) {
            // available list is readable and still offers this source as unlinked, and the name has
            // not appeared locally -> confirmed no-op.
            linked = false
        }
        if (attempt < 2) pauseExecution(500)
    }

    // Outcome 2: confirmed silent no-op.
    if (linked == false) {
        mcpLogError("variables", "hub_create_variable Hub Mesh link was a silent no-op (hub ${meshHubId}, variable ${meshName}): source still in availableLinkedHubVariables with linkedLocally=false", null)
        return [success: false, isError: true,
                error: "Linking the shared variable (hub ${meshHubId}, name ${meshName}) did not take: the hub accepted the request but the variable is still unlinked (availableLinkedHubVariables shows linkedLocally=false).",
                note: "This is usually transient: Hub Mesh takes time to re-establish a peer connection after that peer " +
                      "reboots or updates, and a link briefly no-ops during that window before clearing itself. Wait a bit " +
                      "and retry. Check the peer in hub_get_hub_mesh peers[] (offline=false, warning=null). If it persists, " +
                      "confirm this hub holds the peer's mesh token: get it from the peer's OWN hub_get_hub_mesh(include_token=true) " +
                      "and store it with hub_update_hub_mesh(peer_hub_id, peer_token)."]
    }

    // Outcome 3a: the GET errored AND the read-back could not prove it linked -- unknown, not a definite
    // failure (the timeout may have fired after the hub applied it). Fail, but say it MAY have applied.
    if (linked == null && linkThrew != null) {
        return [success: false, isError: true,
                error: "Hub call errored linking the shared variable (hub ${meshHubId}, name ${meshName}): ${linkThrew}",
                note: "The link MAY have applied (a read timeout can fire after the hub commits) -- verify with " +
                      "hub_get_hub_mesh before retrying. If it did not take, this is usually transient: Hub Mesh takes " +
                      "time to re-establish a peer connection after that peer reboots or updates. If it persists, confirm " +
                      "the peer in hub_get_hub_mesh peers[] (offline=false, warning=null) and that this hub holds its mesh " +
                      "token (store it with hub_update_hub_mesh(peer_hub_id, peer_token), read from the peer's OWN " +
                      "hub_get_hub_mesh(include_token=true))."]
    }

    // Outcome 3b: could not prove linked OR not-linked (mesh list unreadable) -- warn, don't fail.
    def warnings = []
    if (linked == null) {
        warnings << "Sent the link request, but could not confirm it against hub_get_hub_mesh (read-back lag or an unreadable mesh list). Verify with hub_get_hub_mesh."
    } else if (matchedLocalRow == null) {
        // linked==true via the availableLinkedHubVariables "source row disappeared" path, but the local
        // mirror row never resolved in the retry window -- so `name` below falls back to the bare source
        // name, which does NOT identify the decorated mirror (and could collide with an unrelated local
        // var of the same name). Warn the caller to confirm the real name before using it.
        warnings << "The link was confirmed, but the local mirror name did not resolve within the retry window; the returned name is the bare source name and may not identify the mirror in hub_get_variable / hub_delete_variable. Verify the mirror's actual name with hub_get_hub_mesh (localLinkedHubVariables[])."
    }

    // The local mirror is stored under a DECORATED name ("<name> on <peer>"); return THAT as `name`
    // so it can be fed straight to hub_get_variable / hub_delete_variable (the bare source name would
    // not resolve locally). Fall back to the source name only if the decorated row was unresolved.
    def localName = matchedLocalRow?.name?.toString()
    mcpLog("info", "variables", "hub_create_variable: linked Hub Mesh variable '${meshName}' from hub ${meshHubId}")
    return [
        success: true,
        name: localName ?: meshName,
        sourceName: meshName,
        sourceHubId: meshHubId,
        linked: true,
        warnings: warnings ?: null,
        message: "Linked the Hub Mesh variable '${meshName}' shared by hub ${meshHubId}." + (warnings ? " WARNING: see warnings." : ""),
        note: "This is a local mirror of a variable on the peer hub. Read all linked variables via hub_get_hub_mesh."
    ]
}

// Bulk create driver: requires a non-empty List at the batch level, resolves the
// Hub Variables app id ONCE, then creates each item sequentially. Per-item
// try/catch so one failure never aborts the rest -- a malformed (non-Map) item or
// a bad name/type/value fails only itself and carries its own `error`.
private Map _createVariablesBulk(variables) {
    if (!(variables instanceof List) || variables.isEmpty()) {
        throw new IllegalArgumentException("variables must be a non-empty array of {name, type, value} objects.")
    }

    def appId = _findHubVariablesAppId()
    def results = []
    int createdCount = 0
    int failedCount = 0

    variables.eachWithIndex { item, idx ->
        // A malformed (non-Map) item fails only itself, never the whole batch --
        // same per-item isolation as a bad name/type/value below.
        def itemName = (item instanceof Map) ? item.name?.toString()?.trim() : null
        try {
            if (!(item instanceof Map)) {
                throw new IllegalArgumentException("variables[${idx}] must be an object with name, type, and value.")
            }
            _validateHubVarName(itemName)
            def itemType = _validateHubVarType(item.type?.toString())
            _validateInitialValue(itemName, itemType, item.value)

            // Pre-flight existence check (matches the single-create refusal).
            def existing = null
            try { existing = getGlobalVar(itemName) } catch (Exception e) {
                mcpLog("debug", "hub-vars", "hub_create_variable bulk: getGlobalVar('${itemName}') threw ${e.class.simpleName}: ${e.message}")
            }
            if (existing != null) {
                throw new IllegalArgumentException(
                    "Hub variable '${itemName}' already exists (type=${existing.type}). Use hub_set_variable to change the value, or pick a different name.")
            }

            def created = _createOneVariable(appId, itemName, itemType, item.value)
            results << [name: itemName, success: true, type: created.type, value: created.value]
            createdCount++
        } catch (Exception e) {
            // Fall back to the array index when the item carried no usable name, so
            // every failed entry is traceable to its request position. Guard the
            // .name read behind the Map check -- a non-Map item has no name property.
            def rawName = (item instanceof Map) ? item.name : null
            results << [name: (itemName ?: rawName ?: "variables[${idx}]"), success: false, error: e.message ?: e.toString()]
            failedCount++
        }
    }

    return [
        success: failedCount == 0,
        results: results,
        createdCount: createdCount,
        failedCount: failedCount
    ]
}

// Validate the initial value for a hub variable create. A null value is always
// rejected; additionally a String variable created with an empty/blank value
// reports success but never actually persists (getGlobalVar stays null --
// deterministic), so reject that up front with an actionable error.
private void _validateInitialValue(String name, String type, value) {
    if (value == null) {
        throw new IllegalArgumentException("Initial value is required")
    }
    if (type == "String" && !value.toString().trim()) {
        throw new IllegalArgumentException(
            "String variable '${name}' requires a non-empty initial value. " +
            "Hubitat reports success for an empty String value but the variable never persists; supply any non-empty initial value.")
    }
}

// Names of the inputs the Hub Variables form shows now, or null when the page cannot be read.
// Non-private so specs can stub it.
def _hubVarsFormFields(Integer appId) {
    try {
        return (_rmCollectInputSchema(_rmFetchConfigJson(appId, "hubVar")?.configPage) ?: [:]).keySet() as Set
    } catch (Exception e) {
        mcpLog("debug", "hub-vars", "_hubVarsFormFields(${appId}) could not read the form: ${e.message}")
        return null
    }
}

// Hub Variables button clicks land asynchronously (live: a read right after the click can still show
// the old form, and the change appears a moment later). Wait for the form to show the click's effect,
// clicking once more if it never does. A form that cannot be read counts as landed.
private boolean _hubVarsClickAndWait(Integer appId, String button, String stateAttribute, Closure landed) {
    for (int attempt = 0; attempt < 2; attempt++) {
        _rmClickAppButton(appId, button, stateAttribute, "hubVar")
        for (int poll = 0; poll < 12; poll++) {
            def fields = _hubVarsFormFields(appId)
            if (fields == null || landed(fields)) return true
            try { pauseExecution(250) } catch (Exception ignored) { }
        }
        _primeHubVarsWizard(appId, "hub vars ${button} retry")
    }
    return false
}

// Canonical hub DateTime text for a create value: the format RM stores, in hub-local time. Accepts
// "yyyy-MM-ddTHH:mm[:ss[.fraction]][offset]", a space instead of T, or {date,time}; any
// offset in the input is ignored, as the UI's date and time pickers are hub-local.
private String _dateTimeVariableValue(String name, value) {
    def dateStr, timeStr
    if (value instanceof Map) {
        dateStr = value.date?.toString()
        timeStr = value.time?.toString()
    } else {
        def s = value.toString().trim()
        def parts = s.contains("T") ? s.split("T", 2) : (s.contains(" ") ? s.split(" ", 2) : [s, null])
        dateStr = parts[0]
        timeStr = parts.size() > 1 ? parts[1] : null
    }
    // Validate the entire input before reducing it to the form's minute precision.
    boolean validTime = timeStr != null && (timeStr ==~ /(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,9})?)?(?:Z|[+-](?:[01]\d|2[0-3]):?[0-5]\d)?/)
    def zone = location.timeZone
    def when = null
    if (dateStr && validTime) {
        timeStr = timeStr.take(5)
        try { when = Date.parse("yyyy-MM-dd HH:mm", "${dateStr} ${timeStr}", zone) } catch (Exception ignored) { }
    }
    // Round-trip check: a lenient parse would accept 2026-13-45 or a DST gap.
    if (when == null || when.format("yyyy-MM-dd HH:mm", zone) != "${dateStr} ${timeStr}".toString()) {
        throw new IllegalArgumentException(
            "DateTime variable '${name}' requires a valid date and time. " +
            "Pass an ISO string like '2026-05-06T12:00:00' or a {date,time} map. Got: ${value}")
    }
    return when.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ", zone)
}

// Shared per-variable create core: drives the Hub Variables system app wizard
// (prime -> moreVar -> write name/type/value or DateTime date/time + Done),
// verifies the variable landed with a verify-backoff, and subscribes to its
// change event. Returns the single-create success map; throws on validation
// or verification failure. Both the single and bulk paths call this; `appId`
// is resolved once by the caller and reused.
private Map _createOneVariable(Integer appId, String name, String type, value) {
    def applied = []
    def skipped = []

    // Validate a DateTime value before the wizard opens, so a bad value writes nothing.
    String dtValue = (type == "DateTime") ? _dateTimeVariableValue(name, value) : null
    _primeHubVarsWizard(appId, "hub_create_variable pre-moreVar")
    if (!_hubVarsClickAndWait(appId, "moreVar", "moreVar") { it.contains("hbVar") }) {
        throw new IllegalStateException("hub_create_variable: the Hub Variables create form did not open, so '${name}' was not created. Retry the call.")
    }
    _rmWriteSettingOnPage(appId, "hubVar", "hbVar",   name, applied, "text", skipped)
    _rmWriteSettingOnPage(appId, "hubVar", "varType", type, applied, "enum", skipped)
    if (dtValue != null) {
        // Date and time go in one POST, as the UI sends them. The form then either commits or waits
        // for its Done button (both seen live); the value is checked, and set if needed, below.
        def dtCfg = _rmFetchConfigJson(appId, "hubVar")
        def dtSchema = _rmCollectInputSchema(dtCfg?.configPage)
        def missing = ["varDate", "varTime"].findAll { !dtSchema?.containsKey(it) }
        if (missing) {
            throw new IllegalStateException("hub_create_variable: the Hub Variables form did not offer ${missing.join(' and ')} for DateTime variable '${name}', so it was not created.")
        }
        def dtBody = _rmBuildSettingsBody(appId, [varDate: dtValue.substring(0, 10), varTime: dtValue.substring(11, 16)], dtSchema)
        dtBody.formAction = "update"
        dtBody.currentPage = "hubVar"
        dtBody.pageBreadcrumbs = _rmPageBreadcrumbs(appId, "hubVar", '["mainPage"]')
        if (dtCfg?.app?.version != null) dtBody.version = dtCfg.app.version.toString()
        _rmPostSettings(appId, dtBody)
        applied.addAll(["varDate", "varTime"])
        if (_hubVarsFormFields(appId)?.contains("dateTimeDone")) {
            _primeHubVarsWizard(appId, "hub_create_variable DateTime pre-Done")
            _hubVarsClickAndWait(appId, "dateTimeDone", null) { !it.contains("dateTimeDone") }
        }
    } else {
        _rmWriteSettingOnPage(appId, "hubVar", "varValue", value, applied, "textarea", skipped)
    }

    // Verify the variable landed. The wizard commits on the varValue write (DateTime: on the
    // date/time POST or its Done click); the var becomes visible to getGlobalVar
    // shortly after. Check immediately, then retry with bounded backoff.
    def created = null
    // A Done click commits asynchronously, so a DateTime create gets a longer window (live: ~3s).
    int verifyAttempts = (dtValue != null) ? 16 : 8
    for (int attempt = 0; attempt < verifyAttempts; attempt++) {
        try { created = getGlobalVar(name) } catch (Exception e) {
            mcpLog("debug", "hub-vars", "hub_create_variable: post-write getGlobalVar('${name}') threw ${e.class.simpleName}: ${e.message}")
        }
        if (created != null) break
        // Only wait after a missing read; DateTime commits receive a longer window.
        if (attempt < verifyAttempts - 1) {
            try { pauseExecution(300) } catch (Exception e) { mcpLog("debug", "hub-vars", "pauseExecution interrupted: ${e.class.simpleName}: ${e.message}") }
        }
    }
    if (created == null) {
        throw new IllegalStateException(
            "hub_create_variable: wizard completed but '${name}' is not visible via getGlobalVar. " +
            "Settings applied: ${applied.join(', ')}. Skipped: ${skipped}")
    }
    // Compare date and hour:minute only: RM stores local time, and its offset text is not ours to match.
    if (dtValue != null && created.value?.toString()?.take(16) != dtValue.take(16)) {
        try { setGlobalVar(name, dtValue) } catch (Exception e) {
            mcpLog("debug", "hub-vars", "hub_create_variable: setGlobalVar('${name}') threw ${e.class.simpleName}: ${e.message}")
        }
        created = getGlobalVar(name)
        if (created?.value?.toString()?.take(16) != dtValue.take(16)) {
            throw new IllegalStateException("hub_create_variable: '${name}' was created, but its time could not be set (it reads ${created?.value}). Set it with hub_set_variable(name='${name}', value='${dtValue}').")
        }
    }

    // Subscribe to the new variable's location event so changes show up in
    // hub_list_variable_changes without waiting for the next updated() pass.
    // Null-check + Throwable catch mirrors renameVariable: hubitat_ci's
    // validator throws AssertionError (not Exception) when location is null
    // in unit-test environments, and the create itself shouldn't be aborted
    // by a subscription-registration failure.
    if (location != null) {
        try { subscribe(location, "variable:${name}", "handleHubVariableEvent") }
        catch (Throwable e) {
            mcpLog("error", "hub-vars", "post-create subscribe to variable:${name} failed: ${e.message} -- hub_list_variable_changes won't capture this var's changes until next initialize()")
        }
    }

    mcpLog("info", "hub-vars", "Created hub variable '${name}' type=${type} value=${value}")
    return [
        success: true,
        name: name,
        type: type,
        value: created.value,
        source: "hub",
        message: "Variable '${name}' (${type}) created with initial value ${created.value}."
    ]
}

def toolCreateConnector(args) {
    requireDestructiveConfirm(args.confirm)
    def name = args.name?.toString()?.trim()
    if (!name) throw new IllegalArgumentException("Variable name is required")
    def requestedType = args.connectorType?.toString()?.trim()

    def existing
    try { existing = getGlobalVar(name) }
    catch (Exception e) { existing = null }
    if (existing == null) {
        throw new IllegalArgumentException("Hub variable '${name}' does not exist. Create it first with hub_create_variable.")
    }
    if (existing.deviceId != null) {
        return [
            success: true,
            name: name,
            deviceId: existing.deviceId,
            attribute: existing.attribute,
            alreadyExists: true,
            message: "Connector for '${name}' already exists (deviceId=${existing.deviceId})."
        ]
    }

    def appId = _findHubVariablesAppId()
    _primeHubVarsWizard(appId, "hub_create_connector pre-click")
    _rmClickAppButton(appId, name, "createCon", "hubVar")

    // For Number/Decimal vars Hubitat opens a chooser sub-wizard requiring
    // a 'capab' enum pick (Dimmer / Variable / etc.); for String/Boolean/
    // DateTime the click commits the connector immediately and the capab
    // input isn't in the schema, so the write is a schema-skip no-op.
    // Prime the wizard fresh (the chooser sub-page is its own wizard step
    // and benefits from the same priming as the parent click).
    def chosenType = requestedType?.trim() ?: "Variable"
    def applied = []
    def skipped = []
    _primeHubVarsWizard(appId, "hub_create_connector pre-capab")
    _rmWriteSettingOnPage(appId, "hubVar", "capab", chosenType, applied, "enum", skipped)

    def after
    for (int v = 0; v < 8; v++) {
        try { after = getGlobalVar(name) } catch (Exception e) { after = null }
        if (after?.deviceId != null) break
        // Check-FIRST (see hub_create_variable's verify loop): zero happy-path sleep.
        if (v < 7) {
            try { pauseExecution(300) } catch (Exception e) { mcpLog("debug", "hub-vars", "pauseExecution interrupted: ${e.class.simpleName}: ${e.message}") }
        }
    }
    if (after?.deviceId == null) {
        throw new IllegalStateException(
            "hub_create_connector: wizard completed but '${name}' still has no deviceId. " +
            "Tried capab='${chosenType}' (only relevant for Number/Decimal). The connector did not bake.")
    }

    mcpLog("info", "hub-vars", "Created connector for '${name}' (deviceId=${after.deviceId}, attribute=${after.attribute}, capab=${chosenType})")
    return [
        success: true,
        name: name,
        deviceId: after.deviceId,
        attribute: after.attribute,
        connectorType: chosenType,
        message: "Connector created for '${name}' (deviceId=${after.deviceId})."
    ]
}

def toolRemoveConnector(args) {
    requireDestructiveConfirm(args?.confirm as Boolean)
    def name = args?.name?.toString()?.trim()
    if (!name) throw new IllegalArgumentException("Variable name is required")

    def existing
    try { existing = getGlobalVar(name) }
    catch (Exception e) { existing = null }
    if (existing == null) {
        throw new IllegalArgumentException("Hub variable '${name}' does not exist.")
    }
    if (existing.deviceId == null) {
        return [
            success: true,
            name: name,
            alreadyRemoved: true,
            message: "Variable '${name}' has no connector to remove."
        ]
    }

    def deviceId = existing.deviceId
    // Known Hubitat platform bug (confirmed 2026-06-02, fw 2.5.0.143, via Hubitat's
    // own UI "Remove Device"): removing a variable-connector child makes Hubitat's
    // BUILT-IN "Variable Connectors" parent driver recurse in childRemoved() and log
    // a java.lang.StackOverflowError (the child's uninstalled() fires ~10x first).
    // NOT ours -- the official Remove Device button triggers the identical crash, and
    // the device is removed either way. We surface it in the response `note` so the
    // logged error isn't mistaken for a hub_delete_connector failure.
    def res = toolDeleteDevice([deviceId: deviceId.toString(), confirm: true])
    if (res?.success != true) {
        throw new IllegalStateException(
            "hub_delete_connector: toolDeleteDevice failed for deviceId=${deviceId}: ${res?.error ?: 'unknown error'}")
    }

    // Verify the variable's deviceId linkage is cleared. Without this, a
    // hub_delete_device that returned success but didn't actually remove (or the
    // hub didn't propagate the unlinking) would silently report success here.
    def after = null
    for (int v = 0; v < 8; v++) {
        try { after = getGlobalVar(name) } catch (Exception e) { after = null }
        if (after?.deviceId == null) break
        // Check-FIRST (see hub_create_variable's verify loop): zero happy-path sleep.
        if (v < 7) {
            try { pauseExecution(300) } catch (Exception e) { mcpLog("debug", "hub-vars", "pauseExecution interrupted: ${e.class.simpleName}: ${e.message}") }
        }
    }
    if (after?.deviceId != null) {
        throw new IllegalStateException(
            "hub_delete_connector: device ${deviceId} delete returned success but variable '${name}' still has deviceId=${after.deviceId}")
    }

    mcpLog("info", "hub-vars", "Removed connector for '${name}' (deviceId=${deviceId})")
    return [
        success: true,
        name: name,
        deviceId: deviceId,
        deviceDeleted: true,
        message: "Connector for '${name}' (deviceId=${deviceId}) removed. Variable itself is unchanged.",
        note: "A java.lang.StackOverflowError from Hubitat's built-in 'Variable Connectors' driver (childRemoved) may appear in the hub log during this removal. It is a known Hubitat platform bug -- the same crash occurs via the UI's Remove Device button -- and is harmless: the connector is removed regardless."
    ]
}

// Atomic numeric add on a Number/Decimal hub variable via the platform's addValueToGlobalVar(), so
// concurrent increments cannot lose an update the way a read-then-set can.
private Map _incrementHubVariable(String name, increment) {
    def amount
    try { amount = (increment instanceof Number) ? increment : new BigDecimal(increment.toString().trim()) }
    catch (Exception e) { throw new IllegalArgumentException("increment must be a number (negative to subtract), got: ${increment}") }
    def hv
    try { hv = getGlobalVar(name) } catch (Exception e) {
        mcpLogError("variables", "getGlobalVar failed for '${name}'", e)
        return [success: false, name: name, error: "Could not read hub variable '${name}': ${e.message ?: e}", note: "Nothing was changed. Retry."]
    }
    if (hv == null) throw new IllegalArgumentException("increment applies only to hub variables; '${name}' is not a hub variable.")
    def type = hv.type?.toString()?.toLowerCase()
    if (!(type in ["integer", "bigdecimal"])) throw new IllegalArgumentException("increment needs a Number or Decimal hub variable; '${name}' is ${hv.type}.")
    def before = hv.value
    def ok
    try {
        ok = addValueToGlobalVar(name, amount)
    } catch (Exception e) {
        mcpLogError("variables", "addValueToGlobalVar failed for '${name}'", e)
        String why = e.message?.toString() ?: ""
        def note = why.contains("excessive hub load") ? "The hub's load limiter refused the call. Wait a moment, check the value with hub_get_variable, then retry if it did not change." :
                   "Check the value with hub_get_variable before retrying."
        if (why.toLowerCase().contains("mesh") || why.toLowerCase().contains("linked")) note += " A variable linked from another hub over Hub Mesh is changed on its source hub."
        return [success: false, name: name, error: "Increment failed: ${why}", note: note]
    }
    def after = null
    boolean readBack = true
    try { after = getGlobalVar(name)?.value } catch (Exception e) {
        readBack = false
        mcpLog("warn", "variables", "increment of '${name}' applied but the read-back failed: ${e.message}")
    }
    if (ok == false) {
        return [success: false, name: name, value: after, error: "The hub did not apply the increment.",
                note: "A variable linked from another hub over Hub Mesh cannot be incremented here; change it on its source hub."]
    }
    def out = [success: true, name: name, source: "hub", type: hv.type, increment: amount, previousValue: before, value: after]
    if (!readBack) {
        out.verified = false
        out.note = "The increment was applied but the new value could not be read back; check it with hub_get_variable before changing it again."
        return out
    }
    if (type == "integer" && (amount as BigDecimal).stripTrailingZeros().scale() > 0) out.note = "A Number variable stores whole numbers; the hub rounded the result."
    return out
}

def toolSetVariable(Map args) {
    args = args ?: [:]
    def name = args.name
    if (name == null || name.toString().trim() == "") {
        throw new IllegalArgumentException("name is required")
    }
    // A `value` key that is PRESENT (even null) is a value write -- omitting the key entirely is the
    // only way to skip the value leg. This preserves the legacy "set a rule_engine var to null" path
    // while still letting mesh_shared stand alone.
    boolean hasValue = args.containsKey("value")
    boolean hasMeshShared = args.containsKey("mesh_shared")

    // VALIDATION FIRST -- everything below throws before any hub call / state write, so a rejected
    // call can be corrected and retried without a half-applied change.
    if (args.containsKey("increment")) {
        if (hasValue || hasMeshShared) throw new IllegalArgumentException("increment runs on its own; send value or mesh_shared on a separate call.")
        return _incrementHubVariable(name.toString(), args.increment)
    }
    if (!hasValue && !hasMeshShared) {
        throw new IllegalArgumentException("Provide value, mesh_shared, or both (or increment on its own).")
    }
    if (hasMeshShared && !(args.mesh_shared instanceof Boolean)) {
        throw new IllegalArgumentException("mesh_shared must be a boolean (true or false), got: ${args.mesh_shared}")
    }
    // Hub Mesh sharing applies only to HUB variables -- reject it on a rule-only var up front (before
    // the value leg runs), so mesh_shared never silently no-ops against a rule_engine variable. A THROW
    // from getGlobalVar is transient/unknown, NOT proof the name is not a hub variable -- distinguish it
    // from a genuine null so a lookup blip does not misreport the variable as absent.
    if (hasMeshShared) {
        def hv = null
        boolean lookupThrew = false
        String lookupErr = null
        try { hv = getGlobalVar(name) } catch (Exception e) {
            lookupThrew = true
            lookupErr = e.message ?: e.toString()
            mcpLog("debug", "hub-vars", "hub_set_variable: getGlobalVar('${name}') threw ${e.class.simpleName}: ${e.message}")
        }
        if (lookupThrew) {
            throw new IllegalArgumentException(
                "Unable to verify whether '${name}' is a hub variable (getGlobalVar errored: ${lookupErr}). " +
                "Retry, or drop mesh_shared.")
        }
        if (hv == null) {
            throw new IllegalArgumentException(
                "mesh_shared applies only to hub variables; '${name}' is not a hub variable. " +
                "Create it with hub_create_variable first, or drop mesh_shared.")
        }
    }

    def result = hasValue ? _setVariableValueLeg(name, args.value) : [success: true, name: name, source: "hub"]

    if (hasMeshShared) {
        boolean share = (args.mesh_shared == true)
        // Name passed literally: the platform HTTP layer encodes the path, so pre-encoding double-encodes.
        // A throw is an UNKNOWN outcome (a read timeout can fire after the hub applied it), not proof the
        // change did not happen -- capture it and let the sharedHubVariables read-back classify.
        String meshThrew = null
        try {
            hubInternalGet(share ? "/hub2/addVarToMesh/${name}" : "/hub2/removeVarFromMesh/${name}", null, 30)
        } catch (Exception e) {
            mcpLogError("variables", "hub_set_variable Hub Mesh ${share ? 'share' : 'unshare'} errored for '${name}'", e)
            meshThrew = e.message ?: e.toString()
        }
        result.meshShared = share
        // Read-back against sharedHubVariables (THIS hub's own state, so a readable disagreement is a real
        // no-op, not lag). present: true/false readable, null unreadable.
        def sharedNames = _meshSharedHubVarNames()
        Boolean present = (sharedNames != null) ? sharedNames.contains(name.toString()) : null
        String verb = share ? 'share' : 'unshare'
        def valueLegNote = "The value leg${hasValue ? ' committed' : ' was not requested'}"

        if (meshThrew != null) {
            if (present != null && present == share) {
                // The call errored but the hub applied it anyway (timeout fired post-commit).
                result.meshShareConfirmed = true
                result.note = "The Hub Mesh ${verb} call errored (${meshThrew}) but the sharedHubVariables read-back confirms it applied."
            } else if (present != null && present != share) {
                // Errored AND provably not applied -> a real failure.
                return [success: false, isError: true, name: name, meshShared: share, meshShareConfirmed: false,
                        valueApplied: hasValue ? result.value : null,
                        error: "Failed to ${verb} hub variable '${name}' over Hub Mesh: ${meshThrew}",
                        note: "${valueLegNote}; the mesh ${verb} did not take (sharedHubVariables shows '${name}' is ${present ? 'still shared' : 'not shared'}). Retry, and verify Hub Mesh is enabled; read the state with hub_get_hub_mesh."]
            } else {
                // Errored and unreadable -> UNKNOWN; may have applied, so do not claim it did not happen.
                return [success: false, isError: true, name: name, meshShared: share, meshShareConfirmed: null,
                        valueApplied: hasValue ? result.value : null,
                        error: "The Hub Mesh ${verb} of hub variable '${name}' errored: ${meshThrew}",
                        note: "${valueLegNote}. The mesh ${verb} MAY have applied (a read timeout can fire after the hub commits) -- verify with hub_get_hub_mesh rather than assuming it failed. This is usually transient: Hub Mesh takes time to re-establish a peer connection after a peer reboots or updates."]
            }
        } else if (present == null) {
            // No throw, but the read-back is unreadable -> warn-not-fail (confirmation unknown).
            result.meshShareConfirmed = null
            result.note = "Hub Mesh ${verb} was sent, but the sharedHubVariables list was unreadable so it could not be confirmed. Re-check with hub_get_hub_mesh."
        } else if (present == share) {
            result.meshShareConfirmed = true
        } else {
            // No throw, readable, and it DISAGREES with the request. This is this hub's own state, so a
            // confirmed mismatch is a real failure (mirroring the link paths' confirmed no-op).
            return [success: false, isError: true, name: name, meshShared: share, meshShareConfirmed: false,
                    valueApplied: hasValue ? result.value : null,
                    error: "Hub Mesh ${verb} of '${name}' did not take: sharedHubVariables shows it is ${present ? 'still shared' : 'not shared'} after the request.",
                    note: "This is this hub's own state, so the change did not apply. Retry, and verify Hub Mesh is enabled; read the state with hub_get_hub_mesh."]
        }
        if (!share) {
            // Why warn on unshare: the owner hub cannot see which peers linked the variable, so a linking
            // hub keeps a STALE local copy after unsharing. Warn, never block.
            def caution = ("Unshared over Hub Mesh: this hub cannot see which peers linked '${name}', and any hub that linked it " +
                "keeps a STALE local copy (its last value, no orphan flag; a consuming app there keeps reading it). For a clean " +
                "teardown, unlink the copy on those hubs first (hub_delete_variable there), then unshare here.").toString()
            result.note = result.note ? "${result.note} ${caution}".toString() : caution
        }
    }
    return result
}

// Value-write leg extracted from the legacy toolSetVariable: setGlobalVar returns true on success,
// false when the variable doesn't exist (Hubitat will not auto-create vars from setGlobalVar --
// creation requires the Hub Variables UI or our toolCreateVariable tool). Falling back to the
// rule_engine namespace on false OR exception preserves the legacy behavior callers depend on.
private Map _setVariableValueLeg(name, value) {
    try {
        if (setGlobalVar(name, value)) {
            return [success: true, name: name, value: value, source: "hub"]
        }
    } catch (Exception e) {
        mcpLog("debug", "hub-vars", "setGlobalVar('${name}') threw ${e.class.simpleName}: ${e.message}")
    }
    if (!state.ruleVariables) state.ruleVariables = [:]
    state.ruleVariables.put(name, value)
    return [success: true, name: name, value: value, source: "rule_engine"]
}

// Returns the NAMES of hub variables shared INTO the mesh (sharedHubVariables[].name), off the single
// _meshJson() snapshot. Null when the mesh JSON is unreadable or the section is missing/misshaped --
// callers treat null as "unreadable".
private List _meshSharedHubVarNames() {
    def j = _meshJson()
    if (!(j?.sharedHubVariables instanceof List)) return null
    return j.sharedHubVariables.collect { it?.name?.toString() }
}

def toolDeleteHubVariable(args) {
    requireDestructiveConfirm(args?.confirm as Boolean)
    def varName = args?.name?.toString()?.trim()
    if (!varName) throw new IllegalArgumentException("name is required")
    def force = args?.force == true

    // Source detection: hub vs rule_engine namespace. Hub vars are deleted
    // through the Hub Variables system app's wizard; rule_engine vars are a
    // map in state we can rewrite directly. The child-rule scan applies to
    // both; a hub var is also checked against the hub's in-use registry.
    def hubVar = null
    try { hubVar = getGlobalVar(varName) }
    catch (Exception e) {
        mcpLog("debug", "hub-vars", "hub_delete_variable: getGlobalVar('${varName}') threw ${e.class.simpleName}: ${e.message}")
    }
    def isHubVar = (hubVar != null)
    def isRuleVar = state.ruleVariables?.containsKey(varName) ?: false

    if (!isHubVar && !isRuleVar) {
        throw new IllegalArgumentException(
            "Variable '${varName}' not found in either the hub-variables namespace or the rule_engine namespace.")
    }

    // Pre-deletion safety scan: child rule apps that reference this variable will silently
    // break on next access (null lookup → conditions flip false, %varname% substitution
    // leaves literal text). Block by default — caller must opt in via force=true after
    // acknowledging the breakage. Match heuristic: variable name appears in the rule's
    // serialized triggers/conditions/actions JSON, as a quoted value or a %name% substitution.
    def consumers = []
    try {
        // Word-boundary match: the JSON-quoted name or a %name% substitution, so a
        // var named `temp` doesn't match rules referencing `temperature` etc.
        def needles = ["\"${varName}\"".toString(), "%${varName}%".toString()]
        getChildApps()?.each { child ->
            def ruleData = null
            try { ruleData = child.getRuleData() } catch (Exception e) { /* not an MCP rule child */ }
            if (ruleData) {
                def serialized = groovy.json.JsonOutput.toJson(ruleData)
                if (needles.any { serialized?.contains(it) }) {
                    consumers << [id: child.id, label: child.label]
                }
            }
        }
    } catch (Exception e) {
        // Defensive: if the scan itself errors, fall through to apply normal force gate
        // rather than blocking deletion entirely. Log so investigators know the scan
        // didn't run.
        mcpLog("debug", "hub-vars", "hub_delete_variable: getChildApps() scan failed: ${e.class.simpleName}: ${e.message}")
    }
    // Rule Machine and the other apps that register Hub Variable use with the hub are
    // not MCP children, so ask the hub itself. Unreadable means unknown, not unused.
    def hubVarsAppId = null
    Boolean platformInUse = null
    def linkedMirrorRow = null
    if (isHubVar) {
        // A linked mirror's display name is DECORATED ("<sourceVar> on <peer>") -- the caller passes that,
        // so match localLinkedHubVariables[].name against varName (the create/link read-back instead keys
        // on sourceVarName+sourceHubId). Why the mirror needs its own path: the platform ALWAYS registers
        // the mesh link itself as an in-use consumer, so the generic guard would force-gate every unlink;
        // the row's inUseByApps is the accurate signal. Unreadable -> null, fall through to the generic guard.
        Map meshJson = _meshJson()
        def meshRows = (meshJson?.localLinkedHubVariables instanceof List) ? meshJson.localLinkedHubVariables : null
        if (meshRows != null) {
            linkedMirrorRow = meshRows.find { it instanceof Map && it.name?.toString() == varName }
        }
        try {
            hubVarsAppId = _findHubVariablesAppId()
            platformInUse = _hubVarPlatformInUse(hubVarsAppId, varName)
        } catch (Exception e) {
            mcpLog("debug", "hub-vars", "hub_delete_variable: platform in-use check failed: ${e.class.simpleName}: ${e.message}")
        }
        if (linkedMirrorRow != null) {
            def srcHub = linkedMirrorRow.sourceHubName?.toString() ?: 'the source hub'
            // Relax the force-gate ONLY on a POSITIVE inUseByApps==false. inUseByApps==true means a
            // real app depends on the mirror; null/absent means we couldn't confirm -- both stay
            // cautious and require force (codebase convention: unknown = treat as in-use). The generic
            // in-use registry always reads "true" for a mirror (the mesh link itself), so inUseByApps
            // is the accurate signal; a clean unlink still removes only the local copy (peer untouched).
            if (linkedMirrorRow.inUseByApps != false && !force) {
                String why = (linkedMirrorRow.inUseByApps == true) ?
                    "But at least one real app on this hub uses the mirror and will break when it is removed." :
                    "This hub could not confirm whether a real app uses the mirror, so it is treated as in use."
                throw new IllegalArgumentException(
                    "Hub Variable '${varName}' is a Hub Mesh linked mirror of '${linkedMirrorRow.sourceVarName}' on ${srcHub}: " +
                    "deleting it UNLINKS the mirror -- only this hub's local copy is removed, the source variable on ${srcHub} is untouched. " +
                    "${why} Update or remove the consuming apps first, or pass force=true to unlink anyway.")
            }
            // Clean unlink (inUseByApps==false) or forced: bypass the generic in-use force-gate -- that
            // refusal is only the mesh-link registration, not a real consumer. requireDestructiveConfirm
            // (confirm + recent backup) still applied above; force is NOT required for the clean case.
        } else if (platformInUse != false && !force) {
            throw new IllegalArgumentException(platformInUse ?
                "Hub Variable '${varName}' is registered as in use by at least one app (Settings > Hub Variables shows it in orange; click its name to see which). Deleting it breaks those apps, which is why the hub's own delete prompt warns. Update or remove the consuming apps first, or pass force=true to delete anyway." :
                "Could not read the hub's in-use registry for Hub Variable '${varName}', so whether an app uses it is unknown. Check Settings > Hub Variables (an in-use variable is shown in orange), then retry, or pass force=true to delete anyway.")
        }
    }
    if (consumers && !force) {
        def consumerCount = consumers.size()
        def consumerWord = consumerCount == 1 ? "rule" : "rules"
        throw new IllegalArgumentException(
            "Variable '${varName}' is referenced by ${consumerCount} ${consumerWord}: " +
            "${consumers.collect { "${it.label} (id=${it.id})" }.join(', ')}. " +
            "Deleting will silently break ${consumerCount == 1 ? 'that rule' : 'those rules'} (null lookups, false conditions, " +
            "literal %${varName}% in substitutions). Pass force=true to proceed anyway, " +
            "or update/remove the consuming ${consumerWord} first."
        )
    }

    if (isHubVar) {
        // Hub-namespace deletion: drive the Hub Variables system app's
        // wizard. Two clicks: deleteGV opens the confirm prompt, delConfirm
        // commits. Hubitat also deletes the connector device when one
        // exists, surfacing the resulting deviceId in the audit log so the
        // caller knows what else just disappeared.
        def previousValue = hubVar.value
        def previousType  = hubVar.type
        def hadConnector  = hubVar.deviceId != null
        def appId = hubVarsAppId ?: _findHubVariablesAppId()
        // The two clicks only arm the delete (state deleteGV + deleteConfirm); the hub performs it on
        // the page's next render, which the UI gets from its reload after the click. Render it here so
        // the delete runs now -- an armed delete left behind would remove a same-named variable created
        // later, the next time anything renders the page.
        def stillThere = null
        for (int attempt = 0; attempt < 2; attempt++) {
            _primeHubVarsWizard(appId, "hub_delete_variable pre-click attempt-${attempt + 1}")
            _rmClickAppButton(appId, varName, "deleteGV", "hubVar")
            _rmClickAppButton(appId, "delConfirm", null, "hubVar")
            try { hubInternalGet("/installedapp/configure/json/${appId}/hubVar") } catch (Exception renderExc) {
                mcpLog("warn", "hub-vars", "hub_delete_variable: rendering the Hub Variables page after the confirm failed (${renderExc.message})")
            }
            // Brief pause + verification. If the var is gone, we're done.
            for (int v = 0; v < 8; v++) {
                try { stillThere = getGlobalVar(varName) } catch (Exception e) { stillThere = null }
                if (stillThere == null) break
                // Check-FIRST (see hub_create_variable's verify loop): zero happy-path sleep.
                if (v < 7) {
                    try { pauseExecution(300) } catch (Exception e) { mcpLog("debug", "hub-vars", "pauseExecution interrupted: ${e.class.simpleName}: ${e.message}") }
                }
            }
            if (stillThere == null) break
        }
        if (stillThere != null) {
            throw new IllegalStateException(
                "hub_delete_variable: wizard completed but '${varName}' still exists in getGlobalVar after 2 click-sequence attempts.")
        }

        def prevStr = previousValue?.toString()
        def auditValue = prevStr == null ? "null" : (prevStr.length() > 80 ? "${prevStr.take(80)} [truncated, original length: ${prevStr.length()}]" : prevStr)
        def connectorNote = hadConnector ? " (connector deviceId=${hubVar.deviceId} also deleted)" : ""
        def consumerNote = ""
        if (consumers) {
            def cc = consumers.size()
            consumerNote = " (forced; ${cc} ${cc == 1 ? 'rule' : 'rules'} now broken: ${consumers.collect { "id=${it.id}" }.join(', ')})"
        }
        // For a linked mirror the platform in-use registry always reads "true" (the mesh link itself),
        // so suppress the generic forced-registry note and record the unlink instead.
        boolean unlinked = (linkedMirrorRow != null)
        String unlinkNote = null
        String meshNote = ""
        if (unlinked) {
            def srcHub = linkedMirrorRow.sourceHubName?.toString() ?: 'the source hub'
            unlinkNote = "Unlinked the Hub Mesh variable '${varName}' — removed this hub's local copy; the source variable on ${srcHub} is untouched.".toString()
            meshNote = " (mesh unlink; source '${linkedMirrorRow.sourceVarName}' on ${srcHub} untouched)"
        }
        def registryNote = (platformInUse != false && !unlinked) ? " (forced; hub in-use registry: ${platformInUse == null ? 'unreadable' : 'true'})" : ""
        mcpLog("warn", "developer-mode", "hub_delete_variable: removed hub var '${varName}' (type=${previousType}, previous value: ${auditValue})${connectorNote}${registryNote}${consumerNote}${meshNote}")
        return [
            success: true,
            name: varName,
            deleted: true,
            unlinked: unlinked ?: null,
            source: "hub",
            type: previousType,
            previousValue: previousValue,
            connectorDeleted: hadConnector,
            brokenConsumers: consumers ?: null,
            platformInUse: platformInUse,
            coverageNote: _hubVarDeleteCoverageNote(),
            note: unlinkNote
        ]
    }

    // rule_engine fallback (legacy MCP-managed rule variables): replace the map
    // with a filtered copy so sibling variables are preserved.
    def previousValue = state.ruleVariables.get(varName)
    def updated = state.ruleVariables.findAll { k, v -> k != varName }
    state.ruleVariables = updated

    def prevStr = previousValue?.toString()
    def auditValue = prevStr == null ? "null" : (prevStr.length() > 80 ? "${prevStr.take(80)} [truncated, original length: ${prevStr.length()}]" : prevStr)
    def consumerNote = ""
    if (consumers) {
        def cc = consumers.size()
        consumerNote = " (forced; ${cc} ${cc == 1 ? 'rule' : 'rules'} now broken: ${consumers.collect { "id=${it.id}" }.join(', ')})"
    }
    mcpLog("warn", "developer-mode", "hub_delete_variable: removed '${varName}' (previous value: ${auditValue})${consumerNote}")
    return [success: true, name: varName, deleted: true, source: "rule_engine", previousValue: previousValue, brokenConsumers: consumers ?: null]
}

// How the Hub Variables page marks this variable: the hub renders a "Show In Use Apps" button for a
// registered variable and a plain table row otherwise. Returns a distinguishing status so callers can
// tell an unreadable page apart from a variable that simply is not listed:
//   "inUse"      - the Show-In-Use marker is present
//   "notInUse"   - the plain <td>var</td> row is present (registered, no consumers)
//   "unreadable" - appId/var missing, the GET threw, or the page body was empty
//   "notListed"  - the page read fine but names neither marker (the variable is not on the page)
String _hubVarPlatformInUseStatus(Integer hubVarsAppId, String varName) {
    if (hubVarsAppId == null || !varName) return "unreadable"
    def text
    try { text = hubInternalGet("/installedapp/configure/json/${hubVarsAppId}")?.toString() }
    catch (Exception e) { return "unreadable" }
    if (!text) return "unreadable"
    def escaped = varName.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;").replace('"', "&quot;")
    def forms = [varName, escaped].unique()
    if (forms.any { text.contains("Show In Use Apps for ${it}'".toString()) }) return "inUse"
    if (forms.any { text.contains("<td>${it}</td>".toString()) }) return "notInUse"
    return "notListed"
}

// Whether the Hub Variables page marks this variable as in use. Thin Boolean wrapper over
// _hubVarPlatformInUseStatus: true (in use), false (listed but not in use), null (unreadable OR not
// listed -- both collapse to "unknown" for callers that only need the tri-state).
Boolean _hubVarPlatformInUse(Integer hubVarsAppId, String varName) {
    switch (_hubVarPlatformInUseStatus(hubVarsAppId, varName)) {
        case "inUse": return true
        case "notInUse": return false
        default: return null
    }
}

String _hubVarDeleteCoverageNote() {
    return "Checked the hub's in-use registry and this server's own rules. Apps that do not register Hub Variable use with the hub, such as webCoRE pistons, are not covered."
}

String _hubVarDependentsCoverageNote() {
    return "Lists apps that register Hub Variable use with the hub -- what Settings > Hub Variables shows in orange (Rule Machine, Room Lighting, Thermostat Scheduler, and other registering apps). Apps that do not register their use, such as webCoRE pistons, are not covered."
}

// Apps that reference a hub variable. Returns a Map: [apps: [[id,label],...]] on success (apps is []
// only when the variable is registered but has no listed consumers), or [error, note] when the registry
// could not be read or trusted (UNKNOWN -- never proof of "no consumers"). The wizard renders the
// consuming apps only after the per-variable "Show In Use Apps" reveal is clicked, so: read the page
// (the reveal link appears only for an in-use variable), click the reveal, re-fetch, then parse the
// revealed <a> anchors. The reveal is a transient wizard-UI toggle (like _primeHubVarsWizard), not a
// data mutation -- dismissed with a best-effort cancelDel click so the page returns to its plain table.
Map _hubVarInUseApps(Integer hubVarsAppId, String varName) {
    if (hubVarsAppId == null || !varName) {
        return [error: "Could not read the hub's in-use registry for Hub Variable '${varName}'.",
                note: "The Settings > Hub Variables app could not be located; verify it is enabled and retry. See hub_get_tool_guide(section='variables')."]
    }
    String inUseStatus = _hubVarPlatformInUseStatus(hubVarsAppId, varName)
    if (inUseStatus == "unreadable") {
        return [error: "Could not read the hub's in-use registry for Hub Variable '${varName}' (the Hub Variables page was unreadable).",
                note: "Retry; if it persists, read the consumers in Settings > Hub Variables. See hub_get_tool_guide(section='variables')."]
    }
    if (inUseStatus == "notListed") {
        return [error: "Could not read the hub's in-use registry for Hub Variable '${varName}' (the variable is not listed on the Hub Variables page).",
                note: "Verify it exists (hub_list_variables) and retry. See hub_get_tool_guide(section='variables')."]
    }
    if (inUseStatus == "notInUse") return [apps: []]   // registered but no consumers

    // The reveal panel is a single shared wizard toggle, so a parallel includeDependents call for a
    // different variable can race its panel into our re-fetch. Only trust a panel whose marker names
    // THIS variable (match raw and escaped forms, like _hubVarPlatformInUse). A panel naming another
    // variable -> not our panel -> keep polling -> fall through to UNKNOWN.
    def escaped = varName.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;").replace('"', "&quot;")
    def markerForms = [varName, escaped].unique().collect { "<b>${it}</b> is in use by these apps".toString() }

    def apps = []
    boolean panelForThisVar = false
    boolean clickFailed = false
    try {
        _primeHubVarsWizard(hubVarsAppId, "hub_get_variable includeDependents reveal")
        _rmClickAppButton(hubVarsAppId, varName, "inUse", "hubVar")
        // The reveal click lands asynchronously: a single re-fetch right after the click can still
        // return the unrevealed table. Poll the re-fetch with a bounded retry until this variable's
        // panel marker appears; only then are the parsed anchors trustworthy.
        for (int poll = 0; poll < 8 && !panelForThisVar; poll++) {
            if (poll > 0) { try { pauseExecution(250) } catch (Exception ignored) { } }
            // Decode the JSON page before scanning. The hub embeds the rendered HTML inside the
            // configPage JSON, so JSON string escapes (\", \n, ...) would otherwise leak into the
            // captured labels. Parse first, then regex-scan the real HTML (older firmware / a raw-HTML
            // body falls back to the raw text).
            def html = _hubVarRevealHtml(hubInternalGet("/installedapp/configure/json/${hubVarsAppId}")?.toString())
            if (!html) continue
            if (!markerForms.any { html.contains(it) }) continue   // not our panel yet (or another var's)
            panelForThisVar = true
            apps = _parseHubVarConsumerAnchors(html)
        }
    } catch (Exception e) {
        clickFailed = true
        mcpLog("warn", "variables", "hub_get_variable includeDependents: reveal/parse threw ${e.class.simpleName}: ${e.message}")
    } finally {
        try { _rmClickAppButton(hubVarsAppId, "cancelDel", null, "hubVar") }
        catch (Exception e) {
            mcpLog("warn", "variables", "hub_get_variable includeDependents: reveal dismiss (cancelDel) failed: ${e.class.simpleName}: ${e.message}")
        }
    }

    if (clickFailed) {
        return [error: "Could not read the hub's in-use registry for Hub Variable '${varName}' (the reveal click or page re-read failed).",
                note: "Retry; if it persists, read the consumers in Settings > Hub Variables. See hub_get_tool_guide(section='variables')."]
    }
    if (!panelForThisVar) {
        mcpLog("warn", "variables", "hub_get_variable includeDependents: reveal panel for '${varName}' never rendered after polling")
        return [error: "Could not read the hub's in-use registry for Hub Variable '${varName}' (the reveal panel did not render).",
                note: "Retry (the reveal lands asynchronously); if it persists, read the consumers in Settings > Hub Variables. See hub_get_tool_guide(section='variables')."]
    }
    if (apps.isEmpty()) {
        // The registry marked the variable in use and its panel rendered, yet no consumer anchors
        // parsed -- a contradiction, so report UNKNOWN rather than a false "no consumers".
        mcpLog("warn", "variables", "hub_get_variable includeDependents: '${varName}' marked in use but no consumer anchors parsed from the reveal")
        return [error: "Could not read the hub's in-use registry for Hub Variable '${varName}' (marked in use, but no consumer apps parsed from the reveal).",
                note: "Read the consumers in Settings > Hub Variables. See hub_get_tool_guide(section='variables')."]
    }
    return [apps: apps]
}

// Parse the revealed consumer anchors into [[id, label], ...]. The hub renders each as
// <a href='/installedapp/configure/<id>' target='_blank' title='Open <label>'><label></a> with the
// label RAW (not entity-escaped), so < > & ' in a label appear literally. The tag-bearing anchor text
// is unparseable (a label's own < > read as tags), so read the id from the href and the label from the
// title attribute, which is delimited by '> (the quote that closes title plus the tag's own >).
private List _parseHubVarConsumerAnchors(String html) {
    def apps = []
    def m = html =~ /<a\s+href='\/installedapp\/configure\/(\d+)'[^>]*?title='Open (.*?)'>.*?<\/a>/
    while (m.find()) {
        apps << [id: m.group(1), label: m.group(2)?.trim()]
    }
    return apps
}

// Extract the rendered HTML from the Hub Variables configPage JSON so label capture scans true HTML
// rather than JSON-escaped text. Pulls the body/paragraph descriptions out of
// {configPage:{sections:[...]}} and joins them; falls back to the raw string when the body is not
// that JSON shape (older firmware, or a plain-HTML response).
private String _hubVarRevealHtml(String raw) {
    if (!raw?.trim()) return null
    def parsed
    try { parsed = new groovy.json.JsonSlurper().parseText(raw) }
    catch (Exception e) { return raw }   // not JSON -> scan as-is
    if (!(parsed instanceof Map) || parsed.configPage == null) return raw
    def chunks = (parsed.configPage?.sections ?: []).collectMany { sect ->
        def fromBody = (sect?.body ?: [])
            .findAll { it instanceof Map && it.description != null }
            .collect { it.description.toString() }
        def fromParagraphs = (sect?.paragraphs ?: []).collect { it?.toString() ?: "" }
        fromBody + fromParagraphs
    }
    return chunks ? chunks.join("\n") : raw
}

def _getAllToolDefinitions_partVariables() {
    return [
        [
            name: "hub_list_variables",
            description: "List all hub variables and rule-engine variables.[[FLAT_TRIM]] Includes every type, even ones without connectors.[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    type: [type: "string", enum: ["Number", "Decimal", "String", "Boolean", "DateTime"], description: "[[FLAT_TRIM]]Optional: only hub variables of this type.[[/FLAT_TRIM]]"],
                    cursor: [type: "string", description: "Opt-in pagination cursor for the hubVariables list.[[FLAT_TRIM]] Omit for unbounded; pass \"\" for the first page, iterate nextCursor (page size 100).[[/FLAT_TRIM]]"]
                ]
            ]
        ],
        [
            name: "hub_get_variable",
            description: "Get one variable's current value by name; includeDependents=true also lists the apps referencing a hub variable.[[FLAT_TRIM]] Searches the hub-variable namespace first, then falls back to rule-engine variables; use hub_list_variables to enumerate. includeDependents reads the hub's in-use registry by clicking the Settings > Hub Variables wizard reveal, returning appsUsing as {id, label} plus coverageNote — apps that never register their use (e.g. webCoRE) are not covered, and a failed registry read is reported via dependentsError without failing the call. See hub_get_tool_guide(section='variables').[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Exact variable name to look up, e.g. \"vacationMode\". Case-sensitive."],
                    includeDependents: [type: "boolean", description: "Opt-in: also list the apps that reference this hub variable.[[FLAT_TRIM]] Returns appsUsing + coverageNote; clicks the Hub Variables wizard reveal, so off by default.[[/FLAT_TRIM]]", default: false]
                ],
                required: ["name"]
            ]
        ],
        [
            name: "hub_set_variable",
            description: "Set an existing variable's value[[FLAT_TRIM]], or add to a Number/Decimal hub variable with increment[[/FLAT_TRIM]]. For hub variables, value type must match the variable's declared type.[[FLAT_TRIM]] Falls back to the rule_engine namespace when no hub variable matches. Creating new hub variables requires hub_create_variable — Hubitat does not allow setGlobalVar to create. mesh_shared shares/unshares a HUB variable over Hub Mesh (rule-only vars rejected); provide value, mesh_shared, or both — see hub_get_tool_guide(section='variables').[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Variable name"],
                    value: [type: "string", description: "Variable value (string, number, or boolean as string).[[FLAT_TRIM]] Optional when mesh_shared is given.[[/FLAT_TRIM]]"],
                    increment: [type: "number", description: "[[FLAT_TRIM]]Add this amount atomically to a Number/Decimal hub variable (instead of value; send alone).[[/FLAT_TRIM]]"],
                    mesh_shared: [type: "boolean", description: "Hub Mesh: share/unshare this hub variable.[[FLAT_TRIM]] true shares into the mesh, false unshares; hub variables only; may accompany value or stand alone.[[/FLAT_TRIM]]"]
                ],
                required: ["name"]
            ]
        ],
        [
            name: "hub_create_variable",
            description: "Create a new hub variable[[FLAT_TRIM]] (global variable visible to apps and Rule Machine)[[/FLAT_TRIM]], one at a time or several in one call.[[FLAT_TRIM]] Single form: name + type + value. Or LINK a variable a peer hub shares over Hub Mesh: mesh_source_hub_id + mesh_source_name from hub_get_hub_mesh availableLinkedHubVariables[], instead of name/type/value/variables; see hub_get_tool_guide(section='variables').[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "New variable name, e.g. \"vacationMode\".[[FLAT_TRIM]] Omit when using variables or the Hub Mesh link form.[[/FLAT_TRIM]]"],
                    type: [type: "string", enum: ["Number", "Decimal", "String", "Boolean", "DateTime"], description: "Variable type.[[FLAT_TRIM]] Omit when using variables.[[/FLAT_TRIM]]"],
                    value: [description: "Initial value, must match the type.[[FLAT_TRIM]] DateTime uses hub-local time, e.g. 2026-02-04T14:00 or {date,time}; offsets are ignored and seconds/fractions discarded. Omit when using variables.[[/FLAT_TRIM]]"],
                    mesh_source_hub_id: [type: "string", description: "Hub Mesh: peer hubId.[[FLAT_TRIM]] From hub_get_hub_mesh availableLinkedHubVariables[]; send with mesh_source_name, not name/type/value.[[/FLAT_TRIM]]"],
                    mesh_source_name: [type: "string", description: "Hub Mesh: peer variable name.[[FLAT_TRIM]] From the same availableLinkedHubVariables[] row.[[/FLAT_TRIM]]"],
                    variables: [type: "array", description: "Bulk form: several variables in one call.", items: [
                        type: "object",
                        properties: [
                            name: [type: "string", description: "New variable name"],
                            type: [type: "string", enum: ["Number", "Decimal", "String", "Boolean", "DateTime"], description: "Variable type"],
                            value: [description: "Initial value, must match the type"]
                        ],
                        required: ["name", "type", "value"]
                    ]],
                    confirm: [type: "boolean", description: "REQUIRED: must be true to perform the creation"]
                ],
                required: ["confirm"]
            ]
        ],
        [
            name: "hub_delete_variable",
            description: "Permanently delete a variable (DESTRUCTIVE — no undo). Auto-detects whether the target is a hub variable (also deletes its connector device when one exists) or a rule_engine variable. Gated on the Write master + confirm=true + a recent backup.[[FLAT_TRIM]]\n\n**Reference safety:** for a hub variable the tool first reads the hub's own in-use registry (what Settings > Hub Variables shows in orange, covering Rule Machine and other registering apps) and refuses when it is in use or when the registry cannot be read. It also scans this server's child rules for the name, quoted or as a %name% substitution. Apps that never register use, such as webCoRE pistons, are not covered (see `coverageNote`). To proceed anyway, pass `force=true` after acknowledging the breakage; `brokenConsumers` then lists the affected child rules.\n\nThe consumer scan makes this call slow; if the transport drops, verify whether the variable still exists before retrying.[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Variable name to delete"],
                    confirm: [type: "boolean", description: "REQUIRED: must be true to confirm the deletion"],
                    force: [type: "boolean", description: "OPTIONAL: must be true to proceed when the hub reports the variable in use, the in-use registry cannot be read, or a child rule references it. Without force, the tool refuses and says why."],
                ],
                required: ["name", "confirm"]
            ]
        ],
        [
            name: "hub_create_connector",
            description: "Create a virtual-device connector for an existing hub variable[[FLAT_TRIM]] so apps that only consume devices can read/write it. No-op if a connector already exists; see hub_get_tool_guide(section='variables').[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Existing hub-variable name"],
                    connectorType: [type: "string", description: "Optional connector type for Number/Decimal vars (e.g. 'Dimmer', 'Variable'); defaults to 'Variable'.[[FLAT_TRIM]] Other options: 'Volume', 'ColorTemp', 'Humidity', 'Illuminance'. Ignored for vars that don't show a chooser.[[/FLAT_TRIM]]"],
                    confirm: [type: "boolean", description: "REQUIRED: must be true"]
                ],
                required: ["name", "confirm"]
            ]
        ],
        [
            name: "hub_delete_connector",
            description: "Delete the connector device backing a hub variable. DESTRUCTIVE and not undoable. confirm=true required.[[FLAT_TRIM]] The connector device is removed, but the hub variable itself and its value are unchanged. No-op if the variable has no connector; see hub_get_tool_guide(section='variables').[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Hub-variable name whose connector device to remove, e.g. \"vacationMode\""],
                    confirm: [type: "boolean", description: "REQUIRED: must be true to perform the deletion"]
                ],
                required: ["name", "confirm"]
            ]
        ],
        [
            name: "hub_list_variable_changes",
            description: "List recent hub-variable change events captured by the MCP app's location-event subscription, most-recent first.[[FLAT_TRIM]] Use this to audit or debug what changed a variable and when, without polling hub_get_variable. The buffer holds at most the 200 most recent changes (oldest dropped) and survives app and hub restarts, but it is not a complete history — an empty or partial result does NOT mean the variable never changed. For the hub's separately retained location-event history call hub_list_device_events with no deviceId (location-event mode).[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Optional: filter to changes for this variable name only, e.g. \"vacationMode\".[[FLAT_TRIM]] Omit to include all variables.[[/FLAT_TRIM]]"],
                    sinceMs: [type: "integer", description: "Optional: only return changes whose timestamp >= this epoch-millis value, e.g. 1717459200000"],
                    limit: [type: "integer", description: "Optional: max entries to return (default 50)"]
                ]
            ]
        ],
    ]
}

def _readOnlyToolNames_partVariables() {
    // Read-only classification membership for this library's tools, contributed to the
    // app's getReadOnlyToolNames() aggregator (issue #209: per-tool metadata lives with
    // the tool). A tool absent from every part list is write+destructive by default.
    return [
        // Variables (reads); hub_get_variable folds in the dependents read via includeDependents
        "hub_list_variables", "hub_get_variable", "hub_list_variable_changes"
    ]
}

def _idempotentWriteToolNames_partVariables() {
    // Retry-safe writes (MCP idempotentHint) for this library's tools -- contributed to the
    // app's getIdempotentWriteToolNames() aggregator; see the classification rules there.
    return [
        // Variables + connectors. hub_set_variable is not here: its increment re-adds on a retry.
        "hub_delete_variable", "hub_create_connector", "hub_delete_connector"
    ]
}

def _toolDisplayMeta_partVariables() {
    // Human-facing title/summary per tool (MCP annotations.title + the Advanced per-tool
    // overrides menu) -- merged into the app's getToolDisplayMeta() aggregator (issue #209).
    return [
        // Variables
        hub_list_variables: [title: "List Variables", summary: "List hub and rule-engine variables, optionally only hub variables of one type."],
        hub_get_variable: [title: "Get Variable", summary: "Get a variable's value and metadata (optionally the apps that reference it)."],
        hub_set_variable: [title: "Set Variable", summary: "Set an existing variable's value or atomically add to a numeric hub variable."],
        hub_create_variable: [title: "Create Variable", summary: "Create a new hub variable."],
        hub_delete_variable: [title: "Delete Variable", summary: "Permanently delete a hub variable and any connector it has."],
        hub_create_connector: [title: "Create Variable Connector", summary: "Create a virtual-device connector for a hub variable."],
        hub_delete_connector: [title: "Delete Variable Connector", summary: "Remove a hub variable's connector device."],
        hub_list_variable_changes: [title: "List Variable Changes", summary: "Recent hub-variable changes from the retained 200-entry history."]
    ]
}
