library(name: "McpBundlesLib", namespace: "mcp", author: "kingpanther13", description: "Bundle management tool implementations for the MCP Rule Server (hub_list_bundles/hub_delete_bundle/hub_export_bundle); included by the main app. Gateway entries and dispatch stay in the app; tool definitions live here alongside the impl.")
// Developer comments are blanked in this hub copy so the hub's code pages stay fast -- Groovy discards them anyway. Below this line, a line number here is the repository file's plus one. Full source: https://github.com/kingpanther13/Hubitat-local-MCP-server/blob/main/libraries/mcp-bundles-lib.groovy

private Map _parseBundleContent(String content) {



    if (!content) return null
    def out = [apps: [], drivers: [], libraries: []]
    boolean matched = false
    ["apps", "drivers", "libraries"].each { key ->
        def token = "${key} ["
        int s = content.indexOf(token)
        if (s >= 0) {
            int open = s + token.length() - 1
            int close = content.indexOf("]", open)
            if (close > open) {
                matched = true
                def inner = content.substring(open + 1, close).trim()
                out[key] = inner ? inner.split(/\s*,\s*/).collect { it.trim() }.findAll { it } : []
            }
        }
    }
    return matched ? out : null
}

def toolListBundles(args) {



    def cursor = args?.cursor
    def result = [:]
    try {
        def responseText = hubInternalGet("/hub2/userBundles")
        if (responseText) {
            try {
                def parsed = new groovy.json.JsonSlurper().parseText(responseText)
                if (parsed instanceof List) {


                    result.bundles = parsed.findAll { it instanceof Map }.collect { b ->
                        def entry = [
                            id: b.id?.toString(),
                            name: b.name,
                            namespace: b.namespace,
                            "private": (b["private"] == true)
                        ]
                        def contains = _parseBundleContent(b.content?.toString())
                        if (contains != null) entry.contains = contains
                        else if (b.content != null) entry.content = b.content?.toString()
                        entry
                    }
                    result.count = result.bundles.size()
                    result.source = "hub_api"
                    def noId = result.bundles.count { it.id == null }
                    if (noId > 0) {
                        result.note = "${noId} bundle${noId == 1 ? '' : 's'} returned by the hub had no id and cannot be targeted by hub_delete_bundle / hub_export_bundle (possible firmware shape change)."
                    }
                } else {
                    result.bundles = []
                    result.count = 0
                    result.rawResponse = responseText?.take(2000)
                    result.source = "hub_api_raw"
                    result.note = "Response was not a JSON array. This endpoint may return a different shape on your firmware version."
                }
            } catch (Exception parseErr) {
                result.bundles = []
                result.count = 0
                result.rawResponse = responseText?.take(2000)
                result.source = "hub_api_raw"
                result.note = "Response was not JSON. This endpoint may return HTML on your firmware version."
            }
        } else {
            result.bundles = []
            result.count = 0
            result.source = "unavailable"
            result.note = "Empty response from hub API"
        }
    } catch (Exception e) {
        mcpLog("warn", "hub-admin", "hub_list_bundles API call failed: ${e.message}")
        result.bundles = []
        result.count = 0
        result.source = "unavailable"
        result.note = "Hub internal API unavailable (${e.message}). This may require Hub Security credentials or a firmware update."
    }

    if (cursor != null && result.bundles instanceof List) {
        def paged = _paginateList(result.bundles, cursor, 50, "hub_list_bundles")
        result.total = result.bundles.size()
        result.bundles = paged.page
        result.count = paged.page.size()
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }

    mcpLog("info", "hub-admin", "Listed hub bundles (source: ${result.source})")
    return result
}

def toolDeleteBundle(args) {



    requireDestructiveConfirm(args.confirm)
    def rawId = args?.bundleId
    if (rawId == null || !rawId.toString().trim()) {
        throw new IllegalArgumentException("bundleId is required (the numeric id from hub_list_bundles).")
    }
    def bundleId = rawId.toString().trim()
    if (!(bundleId ==~ /\d+/)) {
        throw new IllegalArgumentException("bundleId must be a positive integer (got '${bundleId.take(40)}'). Use hub_list_bundles to find it.")
    }

    def before = toolListBundles([:])
    def target = (before.bundles ?: []).find { it.id?.toString() == bundleId }



    def confirmedPresentBefore = (before.source == "hub_api" && target != null)
    if (before.source == "hub_api" && !target) {
        return [success: false, error: "No bundle with id ${bundleId} found on the hub. Use hub_list_bundles to see installed bundles.", bundleId: bundleId]
    }
    if (before.source != "hub_api") {
        mcpLog("warn", "hub-admin", "hub_delete_bundle: could not validate bundle ${bundleId} against the live list (source=${before.source}); proceeding on the supplied id, but the result will be reported unverified")
    }
    def bundleName = target?.name
    mcpLog("info", "hub-admin", "Deleting bundle ${bundleId} (${bundleName ?: 'name unknown'})")

    def resp
    try {
        resp = hubInternalGetRaw("/bundle/delete/${bundleId}")
    } catch (Exception e) {
        mcpLog("warn", "hub-admin", "hub_delete_bundle threw: ${e.toString()}")
        return [success: false, error: "Bundle delete request failed: ${e.message ?: e.toString()}", bundleId: bundleId, lastBackup: formatTimestamp(state.lastBackupTimestamp)]
    }


    def after = toolListBundles([:])
    if (after.source != "hub_api") {

        return [
            success: false,
            verified: false,
            error: "Delete request was sent for bundle ${bundleId}${bundleName ? " ('${bundleName}')" : ''}, but removal could not be verified -- the bundle list API returned a degraded shape (${after.source}). Re-run hub_list_bundles to check whether it was removed.",
            bundleId: bundleId,
            status: resp?.status,
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
    }
    def stillThere = (after.bundles ?: []).any { it.id?.toString() == bundleId }
    if (stillThere) {
        return [success: false, error: "Bundle ${bundleId}${bundleName ? " ('${bundleName}')" : ''} is still present after the delete request -- the hub may have refused it (status=${resp?.status}).", bundleId: bundleId, status: resp?.status, lastBackup: formatTimestamp(state.lastBackupTimestamp)]
    }

    if (!confirmedPresentBefore) {




        return [
            success: true,
            verified: false,
            message: "Bundle ${bundleId} is not present in the current bundle list. The pre-delete list was degraded, so I could not confirm the bundle existed beforehand -- if you expected a specific bundle removed, re-run hub_list_bundles to confirm.",
            bundleId: bundleId,
            bundleName: bundleName,
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
    }

    return [
        success: true,
        message: "Bundle ${bundleId}${bundleName ? " ('${bundleName}')" : ''} deleted. This removes the bundle container; libraries/apps/drivers it delivered may remain in Code -- verify with hub_list_libraries / hub_list_apps and delete separately if needed.",
        bundleId: bundleId,
        bundleName: bundleName,
        verified: true,
        lastBackup: formatTimestamp(state.lastBackupTimestamp)
    ]
}

def toolExportBundle(args) {




    def rawId = args?.bundleId
    if (rawId == null || !rawId.toString().trim()) {
        throw new IllegalArgumentException("bundleId is required (the numeric id from hub_list_bundles).")
    }
    def bundleId = rawId.toString().trim()
    if (!(bundleId ==~ /\d+/)) {
        throw new IllegalArgumentException("bundleId must be a positive integer (got '${bundleId.take(40)}'). Use hub_list_bundles to find it.")
    }

    def listed = toolListBundles([:])
    def target = (listed.bundles ?: []).find { it.id?.toString() == bundleId }
    if (listed.source == "hub_api" && !target) {
        return [success: false, error: "No bundle with id ${bundleId} found on the hub. Use hub_list_bundles to see installed bundles.", bundleId: bundleId]
    }

    def baseName = (args?.saveAs ?: target?.name ?: "bundle-${bundleId}").toString().trim()
    if (!baseName) baseName = "bundle-${bundleId}"
    def fileName = baseName.replaceAll(/[^A-Za-z0-9._-]/, "_")
    if (!fileName.toLowerCase().endsWith(".zip")) fileName += ".zip"

    def zipBytes = null
    def httpStatus = null
    def unexpectedBodyDesc = null
    try {
        def cookie = getHubSecurityCookie()
        def params = [
            uri: hubBaseUri(),
            path: "/bundle/export/${bundleId}",
            textParser: false,
            ignoreSSLIssues: true,
            timeout: 120
        ]
        if (cookie) params.headers = [Cookie: cookie]
        httpGet(params) { resp ->
            httpStatus = resp?.status
            def d = resp?.data
            if (d instanceof byte[]) {
                zipBytes = d
            } else if (d instanceof CharSequence) {

                unexpectedBodyDesc = "likely an HTML error page"
            } else if (d != null) {





                def streamBytes = null
                try {
                    streamBytes = d.bytes
                } catch (Exception streamErr) {
                    streamBytes = null
                }
                if (streamBytes instanceof byte[] && streamBytes.length > 0) {
                    zipBytes = streamBytes
                } else {
                    unexpectedBodyDesc = "an unrecognized type"
                }
            }
        }
    } catch (Exception e) {
        mcpLog("warn", "hub-admin", "hub_export_bundle fetch threw: ${e.toString()}")
        return [success: false, error: "Failed to fetch bundle ${bundleId} export zip: ${e.message ?: e.toString()}", bundleId: bundleId]
    }



    if (httpStatus != null && !(httpStatus >= 200 && httpStatus < 300)) {
        return [success: false, error: "Bundle ${bundleId} export returned HTTP ${httpStatus} -- not a bundle zip. Nothing saved.", bundleId: bundleId, status: httpStatus]
    }
    if (unexpectedBodyDesc) {
        return [success: false, error: "Bundle ${bundleId} export returned a non-binary body (${unexpectedBodyDesc}); nothing saved -- a binary zip was expected.", bundleId: bundleId]
    }
    if (!zipBytes || zipBytes.length == 0) {
        return [success: false, error: "Bundle ${bundleId} export returned no data (the bundle id may not exist on the hub).", bundleId: bundleId]
    }
    if (!(zipBytes.length >= 2 && zipBytes[0] == (byte) 0x50 && zipBytes[1] == (byte) 0x4B)) {
        return [success: false, error: "Bundle ${bundleId} export did not return a ZIP (no PK signature) -- the hub likely returned an error page. Nothing saved.", bundleId: bundleId]
    }
    try {
        uploadHubFile(fileName, zipBytes)
    } catch (Exception e) {
        return [success: false, error: "Fetched bundle ${bundleId} (${zipBytes.length} bytes) but saving to File Manager as ${fileName} failed: ${e.message ?: e.toString()}", bundleId: bundleId]
    }

    mcpLog("info", "hub-admin", "Exported bundle ${bundleId} to File Manager as ${fileName} (${zipBytes.length} bytes)")
    return [
        success: true,
        message: "Bundle ${bundleId}${target?.name ? " ('${target.name}')" : ''} exported to the File Manager as ${fileName} (${zipBytes.length} bytes). Download at /local/${fileName}.",
        bundleId: bundleId,
        fileName: fileName,
        bytes: zipBytes.length,
        directDownload: "/local/${fileName}"
    ]
}

def toolInstallBundle(args) {



    requireDestructiveConfirm(args.confirm)
    def importUrl = args.importUrl
    if (!(importUrl instanceof String) || !importUrl.trim()) {
        throw new IllegalArgumentException("importUrl is required: the URL of the bundle .zip the hub fetches and installs.")
    }
    importUrl = importUrl.trim()
    def lower = importUrl.toLowerCase()
    if (!(lower.startsWith("http://") || lower.startsWith("https://"))) {
        throw new IllegalArgumentException("importUrl scheme must be http or https (got '${importUrl.take(40)}')")
    }
    boolean installer = (args.installer == true)

    String fw = null
    try { fw = location?.hub?.firmwareVersionString?.toString() } catch (Exception ignored) { }
    if (!fw) mcpLog("warn", "hub-admin", "hub_install_bundle: could not read firmware version; defaulting bundle endpoint to modern (/bundle2/uploadZipFromUrl)")




    boolean modern = _firmwareAtLeast(fw, "2.3.8.108")
    String endpoint = modern ? "/bundle2/uploadZipFromUrl" : "/bundle/uploadZipFromUrl"

    mcpLog("info", "hub-admin", "Installing bundle (endpoint: ${endpoint}, fw: ${fw}, installer: ${installer}, url: ${importUrl})")
    try {
        def resp
        if (modern) {


            resp = hubInternalGet("/bundle2/uploadZipFromUrl", [url: importUrl, pwd: "", "private": installer.toString()], 300)
        } else {
            def body = groovy.json.JsonOutput.toJson([url: importUrl, installer: installer, pwd: ""])
            resp = hubInternalPostJson("/bundle/uploadZipFromUrl", body)
        }
        boolean ok = _bundleResponseSucceeded(resp)
        if (!ok) {
            mcpLog("warn", "hub-admin", "Bundle install did not report success (endpoint ${endpoint})")
            return [
                success: false,
                error: "Bundle install failed: the hub returned no success signal. The zip may be malformed/unreachable, or the firmware endpoint unavailable.",
                endpoint: endpoint,
                rawResponse: resp?.toString()?.take(500),
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
        }
        mcpLog("info", "hub-admin", "Bundle installed successfully from ${importUrl}")
        return [
            success: true,
            message: "Bundle installed from ${importUrl}. Its libraries/apps/drivers are now in Code -- verify with hub_list_libraries / hub_list_apps.",
            endpoint: endpoint,
            installer: installer,
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
    } catch (Exception e) {
        mcpLog("warn", "hub-admin", "Bundle install threw: ${e.toString()}")
        return [
            success: false,
            error: "Bundle install failed: ${e.message ?: e.toString()}",
            endpoint: endpoint,
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
    }
}

def _bundleResponseSucceeded(resp) {



    if (resp == null) return false
    if (resp instanceof Map) return resp.success == true || resp.success?.toString() == "true"
    String text = resp.toString().trim()
    if (!text) return false
    try {
        def parsed = new groovy.json.JsonSlurper().parseText(text)
        if (parsed instanceof Map) return parsed.success == true || parsed.success?.toString() == "true"
    } catch (Exception ignored) { }
    return text.equalsIgnoreCase("true")
}



def _getAllToolDefinitions_partBundles() {
    return [
        [
            name: "hub_install_bundle",
            description: "Install a Hubitat code bundle (.zip) from a URL the way Hubitat Package Manager does -- the hub fetches the zip and unpacks it into Libraries/Apps/Drivers Code (how a package delivers the libraries an app #includes). Use it to prove on the real hub that a package installs the HPM way before users update. Requires Write master + confirm=true + a recent backup; the hub does not deep-validate the zip.[[FLAT_TRIM]] Verify the result with hub_list_libraries / hub_get_source. Uses /bundle2/uploadZipFromUrl on firmware >= 2.3.8.108, else legacy /bundle/uploadZipFromUrl.[[/FLAT_TRIM]][[FLAT_TRIM]] A transport drop can lose the response while the hub still commits this install; verify current hub state before retrying. See hub_get_tool_guide(section='slow_ops').[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    importUrl: [type: "string", description: "URL of the bundle .zip the hub fetches and installs (http:// or https://)."],
                    installer: [type: "boolean", description: "OPTIONAL. Mark the bundle's contents as installed-by-this-package (HPM's installer/private flag). Default false."],
                    confirm: [type: "boolean", description: "REQUIRED: must be true. Confirms a recent backup exists and the user approved installing this bundle."],
                ],
                required: ["importUrl", "confirm"]
            ]
        ],
        [
            name: "hub_list_bundles",
            description: "List installed code bundles -- the Bundle-Manager containers HPM delivers code in, distinct from Libraries Code.[[FLAT_TRIM]] Each entry: id, name, namespace, private flag, and a 'contains' summary of the apps/drivers/libraries it delivered.[[/FLAT_TRIM]] Use to find a bundle's id for hub_delete_bundle/hub_export_bundle, or to verify a bundle installed. Read-only.",
            inputSchema: [
                type: "object",
                properties: [
                    cursor: [type: "string", description: "Opt-in pagination cursor. Omit for unbounded; pass \"\" for the first page, iterate nextCursor (page size 50)."]
                ]
            ]
        ],
        [
            name: "hub_delete_bundle",
            description: "Delete an installed code bundle by id (the Bundle-Manager container; find the id with hub_list_bundles). DESTRUCTIVE: requires Write master + confirm=true + a recent backup; verifies by re-listing that the id is gone. Removes only the container -- the libraries/apps/drivers it delivered may remain in Code, so delete those separately with hub_delete_item if needed.",
            inputSchema: [
                type: "object",
                properties: [
                    bundleId: [type: "string", description: "The numeric bundle id from hub_list_bundles (e.g. \"4\")."],
                    confirm: [type: "boolean", description: "REQUIRED: must be true. Confirms a recent backup exists and the user approved deleting this bundle."]
                ],
                required: ["bundleId", "confirm"]
            ]
        ],
        [
            name: "hub_export_bundle",
            description: "Export an installed bundle's .zip to the hub File Manager (downloadable at /local/<fileName>; find the id with hub_list_bundles). A write (creates a File Manager file), not destructive -- needs Write master, no confirm.",
            inputSchema: [
                type: "object",
                properties: [
                    bundleId: [type: "string", description: "The numeric bundle id from hub_list_bundles (e.g. \"4\")."],
                    saveAs: [type: "string", description: "OPTIONAL File Manager filename for the exported .zip. Defaults to the bundle's name.[[FLAT_TRIM]] '.zip' is appended if missing; non-filename characters are replaced with '_'.[[/FLAT_TRIM]]"],
                ],
                required: ["bundleId"]
            ]
        ]
    ]
}

def _readOnlyToolNames_partBundles() {



    return [

        "hub_list_bundles"
    ]
}

def _idempotentWriteToolNames_partBundles() {


    return [

        "hub_install_bundle", "hub_delete_bundle", "hub_export_bundle"
    ]
}

def _openWorldToolNames_partBundles() {


    return [
        "hub_install_bundle"
    ]
}

def _toolDisplayMeta_partBundles() {


    return [

        hub_list_bundles: [title: "List Bundles", summary: "List installed code bundles and what they contain."],
        hub_install_bundle: [title: "Install Bundle", summary: "Install a code bundle (.zip) from a URL."],
        hub_delete_bundle: [title: "Delete Bundle", summary: "Delete an installed code bundle."],
        hub_export_bundle: [title: "Export Bundle", summary: "Export an installed bundle's zip to the File Manager."]
    ]
}
