library(name: "McpDiagnosticsLib", namespace: "mcp", author: "kingpanther13", description: "Diagnostics + maintenance tool implementations (hub logs/performance/jobs/metrics/memory/radio/device-health/GC/Z-Wave repair/captured states) for the MCP Rule Server; #include'd by the main app. Gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")
// Developer comments are blanked in this hub copy so the hub's code pages stay fast -- Groovy discards them anyway. Below this line, a line number here is the repository file's plus one. Full source: https://github.com/kingpanther13/Hubitat-local-MCP-server/blob/main/libraries/mcp-diagnostics-lib.groovy





def toolGetRadioDetails(args) {

    def radio = args.radio?.toString()?.toLowerCase()
    if (radio != null && !(radio in ["zwave", "zigbee", "matter"]))
        throw new IllegalArgumentException("radio must be 'zwave', 'zigbee', or 'matter' (or omit for both Z-Wave and Zigbee)")
    def result
    if (radio == "zwave") result = toolGetZwaveDetails(args)
    else if (radio == "zigbee") result = toolGetZigbeeDetails(args)
    else if (radio == "matter") result = toolGetMatterDetails(args)


    else result = [zwave: toolGetZwaveDetails(args), zigbee: toolGetZigbeeDetails(args)]
    _attachRadioIncludes(result, args)
    return result
}








private void _attachRadioIncludes(result, args) {
    if (!(result instanceof Map)) return



    def radio = args?.radio?.toString()?.toLowerCase()
    def nodeId = args?.node_id?.toString()?.trim()
    if (nodeId) {
        if (radio == "matter") {
            result.matterPairStatus = _radioGetSafe("/hub/matterPairDeviceStatus", [nodeId: nodeId])
        } else {
            result.nodeState = _radioGetSafe("/hub/zwave2/getNodeState", [node: nodeId])
        }
    }




    if (args?.include_status) {
        result.status = [
            zwaveRepair: _radioGetSafe("/hub/zwaveRepair2Status"),
            zwaveRepairRunning: _radioGetSafe("/hub/checkZwaveRepairRunning"),
            zwaveExclude: _radioGetSafe("/hub/zwaveExclude/status"),
            zwaveJoinDiscovery: _radioGetSafe("/hub/searchZwaveDevices"),
            zwaveAntennaTest: _radioGetSafe("/hub/zwave2/antennaTestProgress"),
            zwaveNodeReplace: [
                status: _radioGetSafe("/hub/zwave/nodeReplace/status"),
                info: _radioGetSafe("/hub/zwave/nodeReplace/info")
            ],
            zigbee: _radioGetSafe("/hub/zigbeeInfo/status")
        ]
    }


    if (args?.include_logs) result.matterLogs = _radioGetSafe("/hub/matterLogs/json")


    if (args?.include_channel_scan) result.channelScan = _radioGetSafe("/hub/zigbeeChannelScanJson")


    if (args?.include_smartstart) result.smartStart = _radioGetSafe("/mobileapi/zwave/smartstart/list", [t: now()])


    if (args?.include_firmware) {
        result.firmware = [
            devices: _radioGetSafe("/hub/zwave/deviceFirmware/devices"),
            files: _radioGetSafe("/hub/zwave/deviceFirmware/files")
        ]
    }
}









private _radioGet(String path, Map query = null) {
    def txt = hubInternalGet(path, query)
    if (!txt) return null
    try { return new groovy.json.JsonSlurper().parseText(txt) }
    catch (Exception parseErr) { return txt.take(8000) }
}




private _radioGetSafe(String path, Map query = null) {
    try { return _radioGet(path, query) }
    catch (IllegalStateException guardErr) {



        throw guardErr
    }
    catch (Exception e) {
        mcpLog("debug", "hub-admin", "_radioGetSafe ${path} failed: ${e.message}")
        return [error: "Failed to fetch ${path}: ${e.message}"]
    }
}






private _radioPost(String path, body = null) {
    String txt
    if (body == null) {
        txt = hubInternalPost(path)
    } else if (body instanceof Map) {
        txt = hubInternalPostForm(path, body)?.data
    } else {

        return hubInternalPostJson(path, body.toString())
    }
    if (!txt) return null
    try { return new groovy.json.JsonSlurper().parseText(txt) }
    catch (Exception parseErr) { return txt.take(2000) }
}

def toolGetMatterDetails(args) {

    def result = [:]




    def endpoint = "/hub/matterDetails/json"
    def matterSuccess = false
    def matterFault = null
    try {
        def responseText = hubInternalGet(endpoint)
        if (responseText) {
            try {
                result.matterData = new groovy.json.JsonSlurper().parseText(responseText)
                result.source = "hub_api"
                result.endpoint = endpoint
                matterSuccess = true
            } catch (Exception parseErr) {
                result.rawResponse = responseText?.take(3000)
                result.source = "hub_api_raw"
                result.endpoint = endpoint
                result.note = "Response was not JSON format"
                matterSuccess = true
            }
        }
    } catch (Exception e) {




        matterFault = e.message
        mcpLog("warn", "hub-admin", "Matter endpoint ${endpoint} failed: ${matterFault}")
    }

    if (!matterSuccess) {
        result.source = "sdk_only"
        if (matterFault) {
            result.error = "Matter query failed: ${matterFault}"
            result.note = "The Matter endpoint returned an error rather than the benign 'no Matter radio' signal. On a C-8/C-8 Pro this is a transient/connectivity fault -- retry."
        } else {
            result.note = "Matter details unavailable. Matter requires a Hubitat C-8 or C-8 Pro on supported firmware with the Matter integration enabled."
        }
    }

    mcpLog("info", "hub-admin", "Retrieved Matter details")
    return result
}

def toolGetZwaveDetails(args) {

    def hub = location.hub
    def result = [:]


    try { result.zwaveVersion = hub?.zwaveVersion } catch (Exception e) { result.zwaveVersion = "unavailable" }



    def zwaveEndpoints = ["/hub/zwaveDetails/json", "/hub2/zwaveInfo"]
    def zwaveSuccess = false
    for (endpoint in zwaveEndpoints) {
        try {
            def responseText = hubInternalGet(endpoint)
            if (responseText) {
                try {
                    def parsed = new groovy.json.JsonSlurper().parseText(responseText)
                    result.zwaveData = parsed
                    result.source = "hub_api"
                    result.endpoint = endpoint
                    zwaveSuccess = true
                } catch (Exception parseErr) {
                    result.rawResponse = responseText?.take(3000)
                    result.source = "hub_api_raw"
                    result.endpoint = endpoint
                    result.note = "Response was not JSON format"
                    zwaveSuccess = true
                }
            }
            if (zwaveSuccess) break
        } catch (Exception e) {
            mcpLog("debug", "hub-admin", "Z-Wave endpoint ${endpoint} failed: ${e.message}")

        }
    }

    if (!zwaveSuccess) {
        result.source = "sdk_only"
        result.note = "Extended Z-Wave info unavailable from all endpoints. Showing basic info from hub SDK."
    }

    if (args?.include_topology) result.topology = _fetchRadioTopology("zwave")

    mcpLog("info", "hub-admin", "Retrieved Z-Wave details")
    return result
}





private Map _fetchRadioTopology(String radio) {
    def topo = [:]
    def jsonEndpoint = (radio == "zwave") ? "/hub/zwave/getChildAndRouteInfoJson" : "/hub/zigbee/getChildAndRouteInfoJson"
    topo.endpoint = jsonEndpoint
    try {
        def txt = hubInternalGet(jsonEndpoint)
        if (txt) {
            try { topo.routes = new groovy.json.JsonSlurper().parseText(txt) }
            catch (Exception parseErr) { topo.rawRoutes = txt?.take(8000); topo.note = "Route info was not JSON format" }
        }
    } catch (Exception e) {
        topo.error = "Failed to fetch ${jsonEndpoint}: ${e.message}"
    }
    if (radio == "zwave") {
        try {
            def t = hubInternalGet("/hub/zwaveTopology")
            if (t) topo.zwaveTopologyTable = t.take(8000)
        } catch (Exception e) {


            topo.zwaveTopologyTableError = "Failed to fetch /hub/zwaveTopology: ${e.message}"
            mcpLog("debug", "hub-admin", "_fetchRadioTopology zwaveTopology miss: ${e.message}")
        }
    }
    return topo
}

def toolGetZigbeeDetails(args) {

    def hub = location.hub
    def result = [:]


    try { result.zigbeeChannel = hub?.zigbeeChannel } catch (Exception e) { result.zigbeeChannel = "unavailable" }
    try { result.zigbeeId = hub?.zigbeeId } catch (Exception e) { result.zigbeeId = "unavailable" }



    def zigbeeEndpoints = ["/hub/zigbeeDetails/json", "/hub2/zigbeeInfo"]
    def zigbeeSuccess = false
    for (endpoint in zigbeeEndpoints) {
        try {
            def responseText = hubInternalGet(endpoint)
            if (responseText) {
                try {
                    def parsed = new groovy.json.JsonSlurper().parseText(responseText)
                    result.zigbeeData = parsed
                    result.source = "hub_api"
                    result.endpoint = endpoint
                    zigbeeSuccess = true
                } catch (Exception parseErr) {
                    result.rawResponse = responseText?.take(3000)
                    result.source = "hub_api_raw"
                    result.endpoint = endpoint
                    result.note = "Response was not JSON format"
                    zigbeeSuccess = true
                }
            }
            if (zigbeeSuccess) break
        } catch (Exception e) {
            mcpLog("debug", "hub-admin", "Zigbee endpoint ${endpoint} failed: ${e.message}")

        }
    }

    if (!zigbeeSuccess) {
        result.source = "sdk_only"
        result.note = "Extended Zigbee info unavailable from all endpoints. Showing basic info from hub SDK."
    }

    if (args?.include_topology) result.topology = _fetchRadioTopology("zigbee")

    mcpLog("info", "hub-admin", "Retrieved Zigbee details")
    return result
}

private Map _parseHubLogLine(String line) {
    if (!line?.trim()) return null
    def parts = line.split("\t", -1)
    if (parts.size() < 2) return null
    if (parts.size() >= 3 && (parts.size() == 3 || parts[2].startsWith('app|') || parts[2].startsWith('dev|')) &&
        (parts[0] ==~ /\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}(\.\d+)?/)) {
        String message = parts[2..-1].join("\t").trim()
        def source = message.split("\\|", 4)
        boolean identified = source.size() == 4 && (source[0] in ["app", "dev"])
        return [name: identified ? source[2] : "", level: parts[1].trim(), message: message,
                time: parts[0].trim(), type: identified ? source[0] : "",
                sourceId: identified ? source[1] : null, hubLocalTime: true]
    }
    def entry = [name: parts[0].trim(), level: parts[1].trim(),
                 message: parts.size() > 2 ? parts[2].trim() : "",
                 time: parts.size() > 3 ? parts[3].trim() : "",
                 type: parts.size() > 4 ? parts[4].trim() : ""]
    if (parts.size() > 5) {
        entry.message = parts[2..(parts.size() - 3)].join("\t")
        entry.time = parts[-2].trim()
        entry.type = parts[-1].trim()
    }
    return entry
}



def _nativeLogSnapshot(Map query, Map args) {
    if (!_mrtrReadContinuationActive()) {
        return [state: "ready", text: hubInternalGet("/logs/past/json", query, 30)]
    }
    return _hubReadSnapshot(query, args, null)
}

private String _deviceReadAccessScope() {
    return groovy.json.JsonOutput.toJson([
        selected: (settings.selectedDevices ?: []).collect { it.id.toString() }.sort(),
        children: (getChildDevices() ?: []).collect { it.id.toString() }.sort(),
        bypass: _bypassEnabled()
    ])
}

private def _deviceReadSnapshot(String tool, Map args, Map context) {
    Map work = [id: context.id, fresh: context.fresh, tool: tool,
                outerTool: context.outerTool ?: tool,
                args: _mrtrCopyMap(args), scope: _deviceReadAccessScope()]
    Map snapshot = _hubReadSnapshot(null, args, work)
    if (work.scope != _deviceReadAccessScope()) {
        throw new IllegalArgumentException("Device access changed during this read; start a fresh call.")
    }
    if (snapshot.state == "pending") return [status: "in_progress", tool: tool]
    context.fetchedAt = snapshot.fetchedAt
    return new groovy.json.JsonSlurper().parseText(snapshot.text)
}

private Map _hubReadSnapshot(Map query, Map args, Map deviceRead) {
    String owner = app?.id?.toString() ?: "0"
    String key = deviceRead != null ? "${owner}:device:${deviceRead.id}".toString() :
        "${owner}:${query?.type ?: 'all'}:${query?.id ?: ''}".toString()
    Map job = null
    String fetchId
    synchronized (NATIVE_LOG_SNAPSHOTS) {
        NATIVE_LOG_SNAPSHOTS.entrySet().findAll { entry ->
            Map value = entry.value as Map


            long pendingTtl = value.work?.tool == "hub_get_device_health" ? 240000L : 90000L
            long ttl = value.pending == true ? pendingTtl : 30000L




            long age = now() - (value.at as Long)
            age >= 600000L || (age >= ttl && ((value.readers ?: 0) as Integer) == 0)
        }.collect { it.key }.each { NATIVE_LOG_SNAPSHOTS.remove(it) }
        if (deviceRead != null) {
            def current = NATIVE_LOG_SNAPSHOTS[key]
            if (current instanceof Map && current.scope != deviceRead.scope) {
                throw new IllegalArgumentException("Device access changed during this read; start a fresh call.")
            }
            if (!(current instanceof Map) && deviceRead.fresh != true) {
                throw new IllegalArgumentException("Device read snapshot expired or was lost; start a fresh call.")
            }
        }


        if (!(NATIVE_LOG_SNAPSHOTS[key] instanceof Map) && NATIVE_LOG_SNAPSHOTS.size() >= 8) {
            def ready = NATIVE_LOG_SNAPSHOTS.findAll { k, v ->
                v.pending != true && v.replayProtected != true && ((v.readers ?: 0) as Integer) == 0
            }
            if (ready) NATIVE_LOG_SNAPSHOTS.remove(ready.min { it.value.at }.key)
            else throw new IllegalStateException("Background read capacity is full; retry after existing snapshots expire.")
        }
        if (!(NATIVE_LOG_SNAPSHOTS[key] instanceof Map) && NATIVE_LOG_SNAPSHOTS.size() < 8) {
            fetchId = java.util.UUID.randomUUID().toString()
            NATIVE_LOG_SNAPSHOTS.put(key, [at: now(), pending: true, fetchId: fetchId])
            if (deviceRead != null) {
                NATIVE_LOG_SNAPSHOTS[key].work = deviceRead
                NATIVE_LOG_SNAPSHOTS[key].scope = deviceRead.scope
            }
            job = [key: key, owner: owner, fetchId: fetchId, query: query]
        }
        def snapshot = NATIVE_LOG_SNAPSHOTS[key]
        fetchId = snapshot.fetchId
        snapshot.readers = ((snapshot.readers ?: 0) as Integer) + 1
    }
    try {
        return _observeHubReadSnapshot(key, fetchId, job, args)
    } finally {
        synchronized (NATIVE_LOG_SNAPSHOTS) {
            def snapshot = NATIVE_LOG_SNAPSHOTS[key]
            if (snapshot instanceof Map && snapshot.fetchId == fetchId) {
                snapshot.readers = Math.max(0, ((snapshot.readers ?: 0) as Integer) - 1)
            }
        }
    }
}

private Map _observeHubReadSnapshot(String key, String fetchId, Map job, Map args) {
    if (job != null) {
        try {
            runInMillis(200, "runNativeLogFetch", [overwrite: false, data: job])
        } catch (Exception scheduleError) {
            synchronized (NATIVE_LOG_SNAPSHOTS) {
                if (NATIVE_LOG_SNAPSHOTS[key]?.fetchId == job.fetchId) NATIVE_LOG_SNAPSHOTS.remove(key)
            }
            throw scheduleError
        }
    }
    long t0 = args?.__reqT0 instanceof Number ? args.__reqT0 as Long : now()
    long deadline = t0 + _logsJsonObserveWaitMs()
    long remainingBudget = Math.max(0L, deadline - now())
    while (true) {
        long remaining
        synchronized (NATIVE_LOG_SNAPSHOTS) {
            def snapshot = NATIVE_LOG_SNAPSHOTS[key]
            if (!(snapshot instanceof Map) || snapshot.fetchId != fetchId) {
                throw new IllegalStateException("Background read snapshot expired or was lost; start a fresh call.")
            }
            if (snapshot.pending != true) {
                if (snapshot.error) {
                    NATIVE_LOG_SNAPSHOTS.remove(key)
                    if (snapshot.invalid == true) throw new IllegalArgumentException(snapshot.error.toString())
                    throw new IllegalStateException(snapshot.error.toString())
                }
                return [state: "ready", text: snapshot.text, fetchedAt: snapshot.at]
            }
            remaining = Math.min(remainingBudget, Math.max(0L, deadline - now()))
            if (remaining <= 0L) {
                snapshot.replayProtected = true
                return [state: "pending"]
            }
        }
        long waitMs = Math.min(250L, remaining)
        pauseExecution(waitMs)
        remainingBudget -= waitMs
    }
}

def runNativeLogFetch(Map job = [:]) {
    if (job.owner != (app?.id?.toString() ?: "0")) return
    Map work = null
    synchronized (NATIVE_LOG_SNAPSHOTS) {
        def current = NATIVE_LOG_SNAPSHOTS[job.key]
        if (!(current instanceof Map) || current.fetchId != job.fetchId || current.pending != true || current.started == true) return
        current.started = true
        work = current.work as Map
    }
    Map result
    try {
        if (work != null) {
            if (work.scope != _deviceReadAccessScope()) {
                throw new IllegalArgumentException("Device access changed during this read; start a fresh call.")
            }


            String outer = work.outerTool?.toString() ?: work.tool.toString()
            Map outerArgs = outer == work.tool ? work.args as Map : [tool: work.tool, args: work.args]
            def payload = _executeWithDeviceReadContext(outer, outerArgs, null)
            String text = groovy.json.JsonOutput.toJson(payload)
            int bytes = text.getBytes("UTF-8").length
            if (bytes > 120000) text = groovy.json.JsonOutput.toJson(
                _responseTooLargeEnvelope(work.tool.toString(), bytes, 120000))
            result = [text: text, scope: work.scope]
        } else {
            result = [text: hubInternalGet("/logs/past/json", job.query as Map, 30)]
        }
    } catch (Exception fetchError) {
        boolean invalid = fetchError instanceof IllegalArgumentException
        result = [error: work != null && !invalid ? "Device read failed (${fetchError.class.simpleName})".toString() :
                    (fetchError.message ?: fetchError.toString()), invalid: invalid]
        if (work != null) result.scope = work.scope
    }
    synchronized (NATIVE_LOG_SNAPSHOTS) {
        if (NATIVE_LOG_SNAPSHOTS[job.key]?.fetchId == job.fetchId) {
            NATIVE_LOG_SNAPSHOTS.put(job.key, result + [at: now(), fetchId: job.fetchId, pending: false,
                replayProtected: NATIVE_LOG_SNAPSHOTS[job.key].replayProtected == true,
                readers: NATIVE_LOG_SNAPSHOTS[job.key].readers ?: 0])
        }
    }
}

def toolGetHubLogs(args) {
    String mode = args.mode == null ? "hub" : args.mode.toString().toLowerCase()
    if (!(mode in ["hub", "mcp", "status"])) throw new IllegalArgumentException("Invalid log mode: ${args.mode}. Valid modes: hub, mcp, status")
    def incompatible = mode == "hub" ? ["component", "ruleId"] :
        mode == "mcp" ? ["source", "appId", "deviceId", "pattern", "patterns", "patternMode", "since", "until"] :
        ["component", "ruleId", "source", "appId", "deviceId", "pattern", "patterns", "patternMode", "since", "until", "level", "limit", "cursor"]
    def supplied = incompatible.findAll { args[it] != null }
    if (supplied) throw new IllegalArgumentException("Parameters ${supplied.join(', ')} do not apply to log mode '${mode}'")
    if (mode == "mcp") return toolGetDebugLogs(args)
    if (mode == "status") return toolGetLoggingStatus(args)

    def maxLimit = 500
    def limit = Math.min(args.limit ?: 100, maxLimit)
    def levelFilter = args.level?.toString()?.toLowerCase() == "all" ? null : args.level
    def sourceFilter = args.source
    def deviceIdFilter = args.deviceId?.toString()?.trim()
    def appIdFilter = args.appId?.toString()?.trim()

    if (deviceIdFilter && appIdFilter) {
        throw new IllegalArgumentException("deviceId and appId are mutually exclusive: set only one")
    }



    if (args.pattern != null && !(args.pattern instanceof String)) {
        throw new IllegalArgumentException("pattern must be a string (got ${args.pattern instanceof List ? 'list' : 'non-string'})")
    }

    if (args.patterns != null && !(args.patterns instanceof List)) {
        throw new IllegalArgumentException("patterns must be a list of strings (got ${args.patterns instanceof String ? 'string' : 'non-list'})")
    }

    if (args.patterns instanceof List) {
        for (int i = 0; i < args.patterns.size(); i++) {
            def pi = args.patterns[i]
            if (pi != null && !(pi instanceof String)) {
                throw new IllegalArgumentException("patterns[${i}] must be a string (got ${pi instanceof List ? 'list' : pi instanceof Number ? 'number' : 'non-string'})")
            }
        }
    }


    if (args.since != null && !(args.since instanceof String)) {
        throw new IllegalArgumentException("since must be a string (ISO-8601 timestamp or relative offset like '30m', '2h', '1d')")
    }
    if (args.until != null && !(args.until instanceof String)) {
        throw new IllegalArgumentException("until must be a string (same format as since)")
    }




    def compiledPattern = null
    if (args.pattern != null) {
        def rawPat = args.pattern.toString()
        if (rawPat.isEmpty()) {
            throw new IllegalArgumentException("pattern must not be empty (got empty string); omit pattern arg to skip pattern filter")
        }
        if (rawPat.length() > 100) {
            throw new IllegalArgumentException("pattern exceeds 100 char limit (was ${rawPat.length()} chars)")
        }
        try {
            compiledPattern = java.util.regex.Pattern.compile(rawPat, java.util.regex.Pattern.CASE_INSENSITIVE)
        } catch (java.util.regex.PatternSyntaxException e) {
            throw new IllegalArgumentException("Invalid regex pattern '${rawPat}': ${e.message}")
        }
    }


    def compiledPatterns = []
    def patternModeAll = (args.patternMode?.toString()?.toLowerCase() == "all")
    if (args.patternMode != null) {
        def pm = args.patternMode.toString().toLowerCase()
        if (pm != 'any' && pm != 'all') {
            throw new IllegalArgumentException("patternMode must be 'any' or 'all' (got '${args.patternMode}')")
        }
    }
    if (args.patterns instanceof List && args.patterns) {
        for (int pi = 0; pi < args.patterns.size(); pi++) {
            def rawPat = args.patterns[pi]
            if (rawPat == null) {
                throw new IllegalArgumentException("patterns[${pi}] must not be null or empty")
            }
            rawPat = rawPat.toString()
            if (rawPat.isEmpty()) {
                throw new IllegalArgumentException("patterns[${pi}] must not be null or empty")
            }
            if (rawPat.length() > 100) {
                throw new IllegalArgumentException("patterns[${pi}] exceeds 100 char limit (was ${rawPat.length()} chars)")
            }
            try {
                compiledPatterns << java.util.regex.Pattern.compile(rawPat, java.util.regex.Pattern.CASE_INSENSITIVE)
            } catch (java.util.regex.PatternSyntaxException e) {
                throw new IllegalArgumentException("Invalid regex pattern '${rawPat}' (patterns[${pi}]): ${e.message}")
            }
        }
    }




    def maxRelativeMs = 30L * 24 * 60 * 60 * 1000  // 30 days in ms


    def logTimeFmts = [
        "yyyy-MM-dd HH:mm:ss.SSS",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd'T'HH:mm:ss.SSSZ",
        "yyyy-MM-dd'T'HH:mm:ssZ",
        "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
        "yyyy-MM-dd'T'HH:mm:ss'Z'",
        "yyyy-MM-dd'T'HH:mm:ss"
    ]

    Closure parseTimeArg = { String argName, String val ->
        if (!val) return null

        def relMatcher = val =~ /^(\d+)([mhd])$/
        if (relMatcher.matches()) {
            long n = relMatcher.group(1).toLong()
            def unit = relMatcher.group(2)
            long ms
            switch (unit) {
                case 'm': ms = n * 60L * 1000; break
                case 'h': ms = n * 3600L * 1000; break
                case 'd': ms = n * 86400L * 1000; break
                default: ms = 0
            }
            if (ms > maxRelativeMs) {
                throw new IllegalArgumentException("${argName} exceeds 30d cap (got '${val}'); use ISO-8601 for longer ranges (e.g. '2024-01-15T00:00:00Z')")
            }
            return new Date(now() - ms)
        }





        if (val.endsWith("Z")) {
            def utcTz = TimeZone.getTimeZone("UTC")

            def bare = val[0..-2]
            def isoFmtsNoZ = ["yyyy-MM-dd'T'HH:mm:ss.SSS", "yyyy-MM-dd'T'HH:mm:ss"]
            for (fmt in isoFmtsNoZ) {
                try {
                    def sdf2 = new java.text.SimpleDateFormat(fmt)
                    sdf2.setTimeZone(utcTz)
                    sdf2.setLenient(false)
                    return sdf2.parse(bare)
                } catch (java.text.ParseException ignored) {}
            }
        }




        if (val.contains('T') && !val.endsWith('Z')) {
            def utcTz = TimeZone.getTimeZone("UTC")
            def isoNoTzFmts = ["yyyy-MM-dd'T'HH:mm:ss.SSS", "yyyy-MM-dd'T'HH:mm:ss"]
            for (fmt in isoNoTzFmts) {
                try {
                    def sdf = new java.text.SimpleDateFormat(fmt)
                    sdf.setTimeZone(utcTz)
                    sdf.setLenient(false)
                    return sdf.parse(val)
                } catch (java.text.ParseException ignored) {}
            }
        }





        def utcTzFallback = TimeZone.getTimeZone("UTC")
        for (fmt in logTimeFmts) {
            try {
                if (!fmt.contains("Z") && !fmt.contains("'Z'")) {
                    def sdf = new java.text.SimpleDateFormat(fmt)
                    sdf.setTimeZone(utcTzFallback)
                    sdf.setLenient(false)
                    return sdf.parse(val)
                }
                return Date.parse(fmt, val)
            } catch (java.text.ParseException ignored) {}
        }
        throw new IllegalArgumentException("Cannot parse ${argName}='${val}' -- use ISO-8601 (e.g. '2024-01-15T10:30:00Z') or a relative offset like '30m', '2h', '1d'")
    }

    def sinceDate = parseTimeArg("since", args.since?.toString()?.trim())
    def untilDate = parseTimeArg("until", args.until?.toString()?.trim())




    if (sinceDate != null && untilDate != null && sinceDate.after(untilDate)) {
        throw new IllegalArgumentException("since='${args.since}' resolves later than until='${args.until}' -- window is empty (relative offsets are subtracted from now, so since='2h' means 2 hours ago)")
    }










    def query = null
    if (deviceIdFilter) {
        _validateNativeDeviceId(deviceIdFilter)
        query = [type: "dev", id: deviceIdFilter]
    } else if (appIdFilter) {
        if (!appIdFilter.isInteger()) {
            throw new IllegalArgumentException("appId must be numeric: ${appIdFilter}")
        }
        query = [type: "app", id: appIdFilter]
    }

    mcpLog("info", "monitoring", "Fetching hub logs (level=${levelFilter}, source=${sourceFilter}, deviceId=${deviceIdFilter}, appId=${appIdFilter}, limit=${limit})")

    def responseText = null
    def fetchedAt = null
    try {
        def snapshot = _nativeLogSnapshot(query, args)
        if (snapshot.state == "pending") {
            return [status: "in_progress", tool: "hub_get_logs", retryable: true,
                    note: "Native log history is still loading. Continue with requestState, or repeat the same call on a legacy client."]
        }
        responseText = snapshot.text
        fetchedAt = snapshot.fetchedAt
    } catch (Exception e) {
        mcpLogError("monitoring", "Failed to fetch hub logs", e)
        throw new IllegalStateException("Failed to fetch hub logs: ${e.message}")
    }

    if (!responseText) {
        return [logs: [], message: "No log data returned from hub", count: 0] +
            (fetchedAt == null ? [:] : [snapshot: [fetchedAt: fetchedAt]])
    }


    def logs = []
    def logArray = []
    try {
        logArray = new groovy.json.JsonSlurper().parseText(responseText)
    } catch (Exception e) {

        mcpLog("debug", "monitoring", "Hub logs response not JSON, falling back to line-split: ${e.message}")
        logArray = responseText.split("\n").toList()
    }






    if (!(logArray instanceof List)) {
        return [logs: [], error: "Unexpected log format from hub", count: 0]
    }
    logArray = logArray.reverse()

    def totalParsed = logArray.size()






    def hubLogUtcTz = TimeZone.getTimeZone("UTC")
    def hubLogSdfs = logTimeFmts
        .findAll { !it.contains("Z") && !it.contains("'Z'") }
        .collect { fmt ->
            def sdf = new java.text.SimpleDateFormat(fmt)
            sdf.setTimeZone(hubLogUtcTz)
            sdf.setLenient(false)
            sdf
        }







    def hubLogIsoFmts = logTimeFmts.findAll { it.contains("Z") && !it.contains("'Z'") }
    def hubLogLocalSdfs = hubLogSdfs.collect { utcParser ->
        def parser = new java.text.SimpleDateFormat(utcParser.toPattern())
        parser.setTimeZone(location?.timeZone ?: TimeZone.getTimeZone("UTC"))
        parser.setLenient(false)
        return parser
    }



    def timeFilterUnparseable = 0




    def filterExcluded = 0

    for (logEntry in logArray) {
        def entry = _parseHubLogLine(logEntry?.toString())
        if (entry == null) continue
        boolean hubLocalTime = entry.remove("hubLocalTime") == true
        entry.remove("sourceId")




        if (levelFilter && entry.level?.toLowerCase() != levelFilter.toLowerCase()) { filterExcluded++; continue }
        if (sourceFilter) {
            def src = sourceFilter.toLowerCase()

            if (!entry.message?.toLowerCase()?.contains(src) && !entry.name?.toLowerCase()?.contains(src)) { filterExcluded++; continue }
        }


        if (compiledPattern != null) {
            if (!compiledPattern.matcher(entry.message ?: "").find()) { filterExcluded++; continue }
        }


        if (compiledPatterns) {
            def msg = entry.message ?: ""
            if (patternModeAll) {
                if (!compiledPatterns.every { it.matcher(msg).find() }) { filterExcluded++; continue }
            } else {
                if (!compiledPatterns.any { it.matcher(msg).find() }) { filterExcluded++; continue }
            }
        }




        if (sinceDate != null || untilDate != null) {
            def entryTime = null
            def timeStr = entry.time?.trim() ?: entry.name?.trim()
            if (timeStr) {

                for (sdf in (hubLocalTime ? hubLogLocalSdfs : hubLogSdfs)) {
                    try {
                        entryTime = sdf.parse(timeStr)
                        break
                    } catch (java.text.ParseException ignored) {}
                }

                if (entryTime == null) {
                    for (fmt in hubLogIsoFmts) {
                        try {
                            entryTime = Date.parse(fmt, timeStr)
                            break
                        } catch (java.text.ParseException ignored) {}
                    }
                }
                if (entryTime == null) {
                    mcpLog("debug", "monitoring", "Could not parse log entry time '${timeStr?.take(30)}' for time-window filter -- entry not excluded")
                    timeFilterUnparseable++
                }
            } else {

                timeFilterUnparseable++
            }

            if (entryTime != null) {
                if (sinceDate != null && entryTime.before(sinceDate)) { filterExcluded++; continue }
                if (untilDate != null && entryTime.after(untilDate)) { filterExcluded++; continue }
            }
        }

        logs << entry
        if (logs.size() >= limit) break
    }


    def cursor = args?.cursor
    def fullLogs = logs.toList()
    def paged = _paginateList(fullLogs, cursor, 100, "hub_get_logs")




    def result = [logs: paged.page, count: paged.page.size(), totalParsed: totalParsed, appliedLimit: limit]
    if (deviceIdFilter) {



        result.deviceIdResolved = fullLogs ? true :
            (_fetchDeviceFullJson(deviceIdFilter)?.device?.id?.toString() == deviceIdFilter)
    }
    if (fetchedAt != null) result.snapshot = [fetchedAt: fetchedAt, ageMs: Math.max(0L, now() - (fetchedAt as Long))]
    if (cursor != null) {
        result.total = fullLogs.size()
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }



    def estimatedJsonSize = paged.page.sum(0) { (it.message?.length() ?: 0) + (it.name?.length() ?: 0) + 120 }
    if (estimatedJsonSize > hubResponseCapBytes() - 11072) {  // =120000; matches handleToolsCall responseSizeLimit
        paged.page.each { it.message = it.message?.take(200) }
        result.truncated = true
        result.note = "Log messages truncated to fit response size limit"
    }






    def hasFilters = levelFilter || sourceFilter || compiledPattern != null || compiledPatterns || sinceDate != null || untilDate != null
    if (hasFilters) {
        if (filterExcluded > 0) result.filteredOut = filterExcluded
        def applied = [:]
        if (levelFilter)                applied.level       = levelFilter
        if (sourceFilter)               applied.source      = sourceFilter
        if (args.pattern != null)       applied.pattern     = args.pattern
        if (args.patterns instanceof List && args.patterns) applied.patterns = args.patterns
        if (compiledPatterns)           applied.patternMode = args.patternMode ?: 'any'
        if (args.since != null)         applied.since       = args.since
        if (args.until != null)         applied.until       = args.until
        result.appliedFilters = applied
    }

    if ((sinceDate != null || untilDate != null) && timeFilterUnparseable > 0) {
        result.timeFilterUnparseable = timeFilterUnparseable
    }





    def benignRmNoiseCount = paged.page.count { _isBenignRmInternalNoise(it.message) }
    if (benignRmNoiseCount > 0) {
        result.benignRmNoiseCount = benignRmNoiseCount
        result.benignRmNoiseNote = "${benignRmNoiseCount} of these entr${benignRmNoiseCount == 1 ? 'y is' : 'ies are'} known-benign RM-internal noise (RM 5.1's own 'periodic' method logging an NPE on params.n while it renders the periodic sub-page during a periodic-trigger build). NON-FATAL, NOT an MCP-tool failure -- the trigger bakes correctly. Safe to ignore."
    }

    mcpLog("info", "monitoring", "Retrieved ${logs.size()} hub log entries (${totalParsed} total parsed)")
    return result
}









def _logsJsonSnapshotTtlMs() { 30000L }



def _logsJsonFetchStaleMs() { 45000L }





def _logsJsonObserveWaitMs() {
    boolean cloud = _isCloudRequest()
    long cap = cloud ? 4500L : 6000L
    long budget = cloud ? _relayBudgetMs() : _lanBudgetMs()
    if (budget <= 0L) return cap
    return Math.max(1L, Math.min(cap, budget - 1500L))
}

def _logsJsonUsesBackgroundFetch() { _mrtrReadContinuationActive() }

private List _logsJsonTrimStats(statsList) {
    if (!(statsList instanceof List)) return []
    return statsList.collect { stat ->
        def trimmed = [
            id: stat.id, name: stat.name, count: stat.count, pct: stat.pct, total: stat.total,
            average: stat.average, stateSize: stat.stateSize, formattedPct: stat.formattedPct,
            formattedPctTotal: stat.formattedPctTotal, hubActionCount: stat.hubActionCount,
            pendingEventsCount: stat.pendingEventsCount, cloudCallCount: stat.cloudCallCount
        ]
        if (stat.customAttributes instanceof Map) {
            trimmed.customAttributes = [eventsCount: stat.customAttributes.eventsCount,
                                        statesCount: stat.customAttributes.statesCount]
        }
        if (stat.largeState) trimmed.largeState = true
        return trimmed
    }
}



private List _logsJsonTable(Map data, String key) {
    def table = data[key]
    if (table == null) return []
    if (!(table instanceof List)) throw new IllegalStateException("Unexpected /logs/json response: '${key}' is not an array")
    if (key != "hubCommands" && table.any { !(it instanceof Map) }) {
        throw new IllegalStateException("Unexpected /logs/json response: '${key}' contains a non-object entry")
    }
    return table
}




def _logsJsonFetchAndPublish(Long fetchId = null, boolean background = false) {
    long t0 = now()
    def responseText = hubInternalGet("/logs/json", null, 30)
    if (!responseText) throw new RuntimeException("No data returned from /logs/json")
    def data = new groovy.json.JsonSlurper().parseText(responseText)
    if (!(data instanceof Map)) throw new IllegalStateException("Unexpected /logs/json response: expected a JSON object")
    if (data.jobs == null && data.deviceStats == null && data.appStats == null) {
        throw new IllegalStateException("Unexpected /logs/json response: no jobs or stats tables (page shape changed?)")
    }
    def snap = [
        at: now(), fetchMs: now() - t0, background: background,
        uptime: data.uptime,
        totalDevicesRuntime: data.totalDevicesRuntime, devicePct: data.devicePct,
        totalAppsRuntime: data.totalAppsRuntime, appPct: data.appPct,
        deviceStats: _logsJsonTrimStats(_logsJsonTable(data, "deviceStats")),
        appStats: _logsJsonTrimStats(_logsJsonTable(data, "appStats")),
        jobs: _logsJsonTable(data, "jobs").collect { job ->
            [id: job.id, name: job.name, recurring: job.recurring, method: job.methodName, nextRun: job.nextRun]
        },
        runningJobs: _logsJsonTable(data, "runningJobs").collect { job ->
            [id: job.id, name: job.name, method: job.methodName]
        },
        hubCommands: _logsJsonTable(data, "hubCommands")
    ]
    synchronized (LOGS_JSON_SNAPSHOT) {
        if (fetchId != null && LOGS_JSON_SNAPSHOT.fetchId != fetchId) return snap
        LOGS_JSON_SNAPSHOT.snapshot = snap
        LOGS_JSON_SNAPSHOT.remove("fetchError")
    }
    return snap
}



private Map _logsJsonProvenance(Map snap) {
    return [fetchedAt: snap.at, ageMs: Math.max(0L, now() - (snap.at as Long)),
            fetchMs: snap.fetchMs, background: snap.background == true,
            budgeted: _logsJsonUsesBackgroundFetch()]
}

private Map _logsJsonFreshSnapshot() {
    synchronized (LOGS_JSON_SNAPSHOT) {
        def snap = LOGS_JSON_SNAPSHOT.snapshot
        if (snap instanceof Map && snap.at instanceof Long
                && now() - (snap.at as Long) < _logsJsonSnapshotTtlMs()) return snap
        return null
    }
}



private void _logsJsonEnsureFetchScheduled() {
    long fetchId
    synchronized (LOGS_JSON_SNAPSHOT) {
        def startedAt = LOGS_JSON_SNAPSHOT.fetchStartedAt
        if (startedAt instanceof Long && now() - (startedAt as Long) < _logsJsonFetchStaleMs()) return
        fetchId = ((LOGS_JSON_SNAPSHOT.fetchId instanceof Long) ? (LOGS_JSON_SNAPSHOT.fetchId as Long) : 0L) + 1L
        LOGS_JSON_SNAPSHOT.fetchId = fetchId
        LOGS_JSON_SNAPSHOT.fetchStartedAt = now()
    }
    try {
        runInMillis(200, "runLogsJsonFetch", [overwrite: false, data: [fetchId: fetchId]])
    } catch (Exception scheduleErr) {
        synchronized (LOGS_JSON_SNAPSHOT) {
            if (LOGS_JSON_SNAPSHOT.fetchId == fetchId) LOGS_JSON_SNAPSHOT.remove("fetchStartedAt")
        }
        throw scheduleErr
    }
}

def runLogsJsonFetch(Map job = [:]) {
    Long fetchId = null
    try { fetchId = job?.fetchId as Long } catch (Exception ignored) { fetchId = null }
    try {
        _logsJsonFetchAndPublish(fetchId, true)
    } catch (Exception e) {
        mcpLogError("monitoring", "Background /logs/json fetch failed", e)
        String detail = e.message?.toString()?.trim()
        if (!detail) detail = "${e.class.simpleName} while fetching /logs/json".toString()
        synchronized (LOGS_JSON_SNAPSHOT) {
            if (fetchId == null || LOGS_JSON_SNAPSHOT.fetchId == fetchId) {
                LOGS_JSON_SNAPSHOT.fetchError = [at: now(), message: detail]
            }
        }
    } finally {
        synchronized (LOGS_JSON_SNAPSHOT) {
            if (fetchId == null || LOGS_JSON_SNAPSHOT.fetchId == fetchId) LOGS_JSON_SNAPSHOT.remove("fetchStartedAt")
        }
    }
}




private Map _logsJsonRecentFetchError() {
    synchronized (LOGS_JSON_SNAPSHOT) {
        def failure = LOGS_JSON_SNAPSHOT.fetchError
        if (!(failure instanceof Map)) return null
        if (!(failure.at instanceof Long) || now() - (failure.at as Long) >= _logsJsonFetchStaleMs()) {
            LOGS_JSON_SNAPSHOT.remove("fetchError")
            return null
        }
        return [:] + failure
    }
}





def _logsJsonSnapshot(Map args) {
    def fresh = _logsJsonFreshSnapshot()
    if (fresh != null) return [state: "ready", snapshot: fresh]
    if (!_logsJsonUsesBackgroundFetch()) return [state: "ready", snapshot: _logsJsonFetchAndPublish()]
    def failure = _logsJsonRecentFetchError()
    if (failure != null) {
        _logsJsonEnsureFetchScheduled()
        return [state: "failed", error: failure.message]
    }
    long t0 = (args?.__reqT0 instanceof Number) ? (args.__reqT0 as Long) : now()
    _logsJsonEnsureFetchScheduled()
    long deadline = t0 + _logsJsonObserveWaitMs()

    long remainingBudget = Math.max(0L, deadline - now())
    while (true) {
        fresh = _logsJsonFreshSnapshot()
        if (fresh != null) return [state: "ready", snapshot: fresh]
        failure = _logsJsonRecentFetchError()
        if (failure != null) return [state: "failed", error: failure.message]
        long remaining = Math.min(remainingBudget, Math.max(0L, deadline - now()))
        if (remaining <= 0L) return [state: "pending"]
        long sleepMs = Math.min(250L, remaining)
        try {
            pauseExecution(sleepMs as Long)
        } catch (Exception waitErr) {


            mcpLog("warn", "monitoring", "Snapshot wait interrupted (${waitErr.class.simpleName}): ${waitErr.message}")
            return [state: "pending"]
        }
        remainingBudget -= sleepMs
    }
}



private Map _logsJsonInProgress(String tool) {
    return [
        status: "in_progress", tool: tool, retryable: true,
        note: "The hub is still producing its Logs page payload (every device and app stat plus the job tables, which grows with hub size). Call ${tool} again with the same arguments; once the fetch finishes, its result is served from a ${(_logsJsonSnapshotTtlMs() / 1000L) as Long} s cache."
    ]
}


private Map _logsJsonFailure(String tool, String detail) {
    String reason = detail?.toString()?.trim() ?: "unknown /logs/json fetch failure"
    return [
        success: false, isError: true, tool: tool,
        error: "${tool} could not read the hub's Logs page: ${reason}",
        note: "Repeat the identical call once; a fresh fetch is already scheduled. If it fails again, check hub_get_logs for the hub-side error, then see hub_get_tool_guide(section='slow_ops')."
    ]
}

def toolGetPerformanceStats(args) {
    def type = args.type ?: "device"
    def sortBy = args.sortBy ?: "pct"
    def limit = args.limit != null ? args.limit : 20

    mcpLog("info", "monitoring", "Fetching performance stats (type=${type}, sortBy=${sortBy}, limit=${limit})")

    def data
    try {
        def snap = _logsJsonSnapshot(args)
        if (snap.state == "failed") return _logsJsonFailure("hub_get_performance_stats", snap.error)
        if (snap.state == "pending") return _logsJsonInProgress("hub_get_performance_stats")
        data = snap.snapshot
    } catch (Exception e) {
        mcpLogError("monitoring", "Failed to fetch performance stats", e)
        return _logsJsonFailure("hub_get_performance_stats", e.message ?: e.class.simpleName)
    }

    def result = [
        uptime: data.uptime,
        snapshot: _logsJsonProvenance(data)
    ]

    def formatStats = { cached ->
        if (!cached) return []

        def statsList = new ArrayList(cached)
        switch (sortBy) {
            case "count": statsList = statsList.sort { -(it.count ?: 0) }; break
            case "stateSize": statsList = statsList.sort { -(it.stateSize ?: 0) }; break
            case "totalMs": statsList = statsList.sort { -(it.total ?: 0) }; break
            case "name": statsList = statsList.sort { (it.name ?: "").toLowerCase() }; break
            default: statsList = statsList.sort { -(it.pct ?: 0) }; break
        }

        if (limit > 0 && statsList.size() > limit) {
            statsList = statsList.take(limit)
        }

        return statsList.collect { entry ->
            def item = [
                id: entry.id,
                name: entry.name,
                count: entry.count,
                pctBusy: entry.formattedPct,
                pctTotal: entry.formattedPctTotal,
                stateSize: entry.stateSize,
                totalMs: entry.total,
                averageMs: entry.average != null ? Math.round(entry.average * 100) / 100.0 : null,
                totalEvents: entry.customAttributes?.eventsCount,
                states: entry.customAttributes?.statesCount,
                hubActions: entry.hubActionCount,
                pendingEvents: entry.pendingEventsCount,
                cloudCalls: entry.cloudCallCount
            ]
            if (entry.largeState) item.largeState = true
            return item
        }
    }

    if (type == "device" || type == "both") {
        result.deviceSummary = [
            totalRuntime: data.totalDevicesRuntime,
            pctOfUptime: data.devicePct,
            deviceCount: data.deviceStats?.size() ?: 0
        ]
        result.deviceStats = formatStats(data.deviceStats)
    }

    if (type == "app" || type == "both") {
        result.appSummary = [
            totalRuntime: data.totalAppsRuntime,
            pctOfUptime: data.appPct,
            appCount: data.appStats?.size() ?: 0
        ]
        result.appStats = formatStats(data.appStats)
    }


    def statsCount = (result.deviceStats?.size() ?: 0) + (result.appStats?.size() ?: 0)
    if (limit == 0) {
        result.note = "Returning all ${statsCount} entries. Use limit parameter to reduce response size."
    }

    mcpLog("info", "monitoring", "Retrieved performance stats: ${statsCount} entries (type=${type})")
    return result
}

def toolGetHubJobs(args) {
    def cursor = args?.cursor
    mcpLog("info", "monitoring", "Fetching hub jobs")

    def data
    try {
        def snap = _logsJsonSnapshot(args)
        if (snap.state == "failed") return _logsJsonFailure("hub_get_jobs", snap.error)
        if (snap.state == "pending") return _logsJsonInProgress("hub_get_jobs")
        data = snap.snapshot
    } catch (Exception e) {
        mcpLogError("monitoring", "Failed to fetch hub jobs", e)
        return _logsJsonFailure("hub_get_jobs", e.message ?: e.class.simpleName)
    }


    def scheduledJobs = data.jobs
    def runningJobs = data.runningJobs
    def hubActions = data.hubCommands




    def paged = _paginateList(scheduledJobs, cursor, 100, "hub_get_jobs")
    def result = [
        uptime: data.uptime,
        snapshot: _logsJsonProvenance(data),
        scheduledJobs: [
            count: paged.page.size(),
            jobs: paged.page
        ],
        runningJobs: [
            count: runningJobs.size(),
            jobs: runningJobs
        ],
        hubActions: [
            count: hubActions.size(),
            actions: hubActions
        ]
    ]
    if (cursor != null) {
        result.scheduledJobs.total = scheduledJobs.size()
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }
    return result
}

def toolGetHubPerformance(args) {

    def recordSnapshot = args.recordSnapshot == true
    def trendPoints = Math.min(args.trendPoints ?: 10, 50)


    def current = [timestamp: formatTimestamp(now()), timestampEpoch: now()]

    try {
        current.freeMemoryKB = hubInternalGet("/hub/advanced/freeOSMemory")?.trim()
        try {
            def memKB = current.freeMemoryKB as Integer
            if (memKB < 50000) current.memoryWarning = "LOW MEMORY: ${memKB}KB free. Consider rebooting the hub."
            else if (memKB < 100000) current.memoryNote = "Memory is moderate: ${memKB}KB free."
        } catch (Exception nfe) { /* non-numeric */ }
    } catch (Exception e) { current.freeMemoryKB = "unavailable" }

    try {
        current.internalTempC = hubInternalGet("/hub/advanced/internalTempCelsius")?.trim()
        try {
            def temp = current.internalTempC as Double
            if (temp > 70) current.temperatureWarning = "HIGH TEMPERATURE: ${temp}°C. Hub may need better ventilation."
            else if (temp > 60) current.temperatureNote = "Temperature is warm: ${temp}°C."
        } catch (Exception nfe) { /* non-numeric */ }
    } catch (Exception e) { current.internalTempC = "unavailable" }

    try {
        current.databaseSizeKB = hubInternalGet("/hub/advanced/databaseSize")?.trim()
        try {
            def dbKB = current.databaseSizeKB as Integer
            if (dbKB > 500000) current.databaseWarning = "LARGE DATABASE: ${(dbKB / 1024).toInteger()}MB. Consider cleaning up old data."
        } catch (Exception nfe) { /* non-numeric */ }
    } catch (Exception e) { current.databaseSizeKB = "unavailable" }

    try { current.uptimeSeconds = location.hub?.uptime } catch (Exception e) { current.uptimeSeconds = "unavailable" }
    if (current.uptimeSeconds && current.uptimeSeconds instanceof Number) {
        def days = (current.uptimeSeconds / 86400).toInteger()
        def hours = ((current.uptimeSeconds % 86400) / 3600).toInteger()
        def mins = ((current.uptimeSeconds % 3600) / 60).toInteger()
        current.uptimeFormatted = "${days}d ${hours}h ${mins}m"
    }


    def csvFileName = "mcp-performance-history.csv"
    def csvHeader = "timestamp,freeMemoryKB,internalTempC,databaseSizeKB,uptimeSeconds"
    def history = []


    try {
        def existingBytes = downloadHubFile(csvFileName)
        if (existingBytes) {
            def csvText = new String(existingBytes, "UTF-8")
            def csvLines = csvText.split("\n")
            for (int i = 1; i < csvLines.size(); i++) {
                if (csvLines[i]?.trim()) history << csvLines[i].trim()
            }
        }
    } catch (Exception e) {

        mcpLog("debug", "monitoring", "No existing performance CSV: ${e.message}")
    }


    if (recordSnapshot) {
        def csvRow = "${now()},${current.freeMemoryKB},${current.internalTempC},${current.databaseSizeKB},${current.uptimeSeconds}"
        history << csvRow


        if (history.size() > 500) {
            history = history.drop(history.size() - 500)
        }


        def csvContent = csvHeader + "\n" + history.join("\n") + "\n"
        try {
            uploadHubFile(csvFileName, csvContent.getBytes("UTF-8"))
        } catch (Exception e) {
            mcpLog("warn", "monitoring", "Failed to write performance CSV: ${e.message}")
        }
    }


    def trends = []
    def startIdx = Math.max(0, history.size() - trendPoints)
    for (int i = startIdx; i < history.size(); i++) {
        def parts = history[i].split(",", -1)
        if (parts.size() >= 5) {
            try {
                trends << [
                    timestamp: formatTimestamp(parts[0] as Long),
                    freeMemoryKB: parts[1],
                    internalTempC: parts[2],
                    databaseSizeKB: parts[3],
                    uptimeSeconds: parts[4]
                ]
            } catch (Exception e) {

            }
        }
    }

    mcpLog("info", "monitoring", "Hub performance snapshot recorded=${recordSnapshot}, trendPoints=${trends.size()}")
    return [
        current: current,




        healthAlerts: _healthAlertsFromHub2(_getHub2HubData()),
        trends: trends,
        trendPointsAvailable: history.size(),
        historyFile: csvFileName
    ]
}

def toolGetMemoryHistory(args) {

    def limit = args.limit != null ? args.limit : 100

    def rawText = hubInternalGet("/hub/advanced/freeOSMemoryHistory")
    if (!rawText) {
        return [entries: [], summary: [message: "No memory history data available"]]
    }

    def lines = rawText.trim().split("\n")
    def allEntries = []
    def memValues = []

    for (line in lines) {
        def trimmed = line?.trim()
        if (!trimmed) continue


        def parts = trimmed.split(",", -1)
        if (parts.size() >= 3) {

            def memKB = null
            try {
                memKB = parts[1]?.trim() as Integer
            } catch (Exception e) {

                continue
            }

            def entry = [
                timestamp: parts[0]?.trim(),
                freeMemoryKB: memKB,
                cpuLoad5min: parts[2]?.trim()
            ]


            if (parts.size() >= 6) {
                try { entry.totalJavaKB = parts[3]?.trim() as Integer } catch (Exception e) {}
                try { entry.freeJavaKB = parts[4]?.trim() as Integer } catch (Exception e) {}
                try { entry.directJavaKB = parts[5]?.trim() as Integer } catch (Exception e) {}
            }

            allEntries << entry
            memValues << memKB
        }
    }


    def summary = [totalEntries: allEntries.size()]
    if (memValues) {
        summary.currentMemoryKB = memValues[-1]
        summary.minMemoryKB = memValues.min()
        summary.maxMemoryKB = memValues.max()
        summary.avgMemoryKB = (memValues.sum() / memValues.size()).toInteger()

        if (summary.currentMemoryKB < 50000) {
            summary.memoryWarning = "LOW MEMORY: ${summary.currentMemoryKB}KB free. Consider rebooting or running hub_call_gc."
        }


        def latest = allEntries[-1]
        if (latest.totalJavaKB != null) summary.totalJavaKB = latest.totalJavaKB
        if (latest.freeJavaKB != null) summary.freeJavaKB = latest.freeJavaKB
        if (latest.directJavaKB != null) {
            summary.directJavaKB = latest.directJavaKB

            def directValues = allEntries.findAll { it.directJavaKB != null }.collect { it.directJavaKB }
            if (directValues.size() >= 2) {
                summary.directJavaMinKB = directValues.min()
                summary.directJavaMaxKB = directValues.max()
            }
        }
    }


    def entries = allEntries
    if (limit > 0 && allEntries.size() > limit) {
        entries = allEntries.takeRight(limit)
        summary.truncated = true
        summary.showing = "${entries.size()} of ${allEntries.size()} (most recent)"
    }


    def cursor = args?.cursor
    def paged = _paginateList(entries, cursor, 100, "hub_get_memory_history")
    def result = [entries: paged.page, summary: summary]
    if (cursor != null) {
        result.total = entries.size()
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }

    mcpLog("info", "server", "Memory history retrieved: ${paged.page.size()} entries (${allEntries.size()} total)")
    return result
}

def toolForceGarbageCollection(args) {


    def beforeKB = null
    try {
        beforeKB = hubInternalGet("/hub/advanced/freeOSMemory")?.trim() as Integer
    } catch (Exception e) {
        beforeKB = null
    }


    hubInternalGet("/hub/forceGC")


    pauseExecution(1000)


    def afterKB = null
    try {
        afterKB = hubInternalGet("/hub/advanced/freeOSMemory")?.trim() as Integer
    } catch (Exception e) {
        afterKB = null
    }

    def result = [
        beforeFreeMemoryKB: beforeKB,
        afterFreeMemoryKB: afterKB,
        timestamp: formatTimestamp(now())
    ]

    if (beforeKB != null && afterKB != null) {
        result.deltaKB = afterKB - beforeKB
        result.memoryReclaimed = result.deltaKB > 0
        result.summary = "GC complete: ${beforeKB}KB → ${afterKB}KB (${result.deltaKB > 0 ? '+' : ''}${result.deltaKB}KB)"
    } else {
        result.summary = "GC triggered but could not read memory values for comparison"
    }

    mcpLog("info", "server", "Forced GC: before=${beforeKB}KB, after=${afterKB}KB")
    return result
}

private Map _deviceHealthInventory() {
    boolean bypass = _bypassEnabled()
    def allowedIds = ((settings.selectedDevices ?: []) + (getChildDevices() ?: [])).collect { it.id.toString() } as Set
    if (!bypass && !allowedIds) {
        return [devices: [], message: "No devices selected for MCP access and no MCP-managed virtual devices"]
    }

    def text = hubInternalGet("/hub2/devicesList")
    def parsed = new groovy.json.JsonSlurper().parseText(text ?: "{}")
    def records = _flattenHub2DeviceTree(parsed instanceof Map ? parsed.devices : null)
    if (!(records instanceof List)) throw new IllegalStateException("Native device tree is unavailable or malformed")
    def byId = [:]
    records.each { record ->
        String id = record.id.toString()
        if (bypass || allowedIds.contains(id)) {
            byId.put(id, [id: id, label: record.label, lastActivity: record.lastActivity,
                metadataUnavailable: !record.containsKey('lastActivity')])
        }
    }

    allowedIds.each { id ->
        if (!byId.containsKey(id)) byId.put(id, [id: id, metadataUnavailable: true])
    }
    return [devices: byId.values() as List]
}

def toolDeviceHealthCheck(args) {
    def staleHours = args.staleHours ?: 24
    def includeHealthy = args.includeHealthy ?: false
    def cursor = args.cursor
    def pingHosts = (args.pingHosts ?: []) as List


    def pingCount
    if (args.pingCount == null) {
        pingCount = 3
    } else if (args.pingCount instanceof Number) {
        pingCount = ((Number) args.pingCount).intValue()
    } else {
        throw new IllegalArgumentException("pingCount must be an integer between 1 and 5 (got ${args.pingCount})")
    }

    if (pingHosts.size() > 5) {
        throw new IllegalArgumentException("pingHosts is limited to 5 entries per call (got ${pingHosts.size()})")
    }
    if (pingCount < 1 || pingCount > 5) {
        throw new IllegalArgumentException("pingCount must be between 1 and 5 (got ${pingCount})")
    }

    def pingResults = pingHosts ? runPingChecks(pingHosts, pingCount) : null


    Map tracerouteResult = null
    if (args?.tracerouteHost != null) {
        def host = args.tracerouteHost.toString().trim()


        if (!(host ==~ /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/)) {
            throw new IllegalArgumentException("traceroute must be a dotted-quad IPv4 literal (hostnames not supported, pass an IP), got '${host}'")
        }
        def endpoint = "/hub/networkTest/traceroute/${host}"
        tracerouteResult = [host: host, endpoint: endpoint]
        try {
            def txt = hubInternalGet(endpoint, [:], 30)
            tracerouteResult.output = txt?.take(8000)
        } catch (Exception e) {
            tracerouteResult.error = "traceroute failed: ${e.message}"
            mcpLog("warn", "monitoring", "hub_get_device_health traceroute to ${host} failed: ${e.message}")
        }
    }

    Map speedtestResult = null
    if (args?.speedtest == true) {
        def endpoint = "/hub/networkTest/speedtest"
        speedtestResult = [endpoint: endpoint]
        try {


            def txt = hubInternalGet(endpoint, [:], 90)
            speedtestResult.output = txt?.take(8000)
        } catch (Exception e) {
            speedtestResult.error = "speedtest failed: ${e.message}"
            mcpLog("warn", "monitoring", "hub_get_device_health speedtest failed: ${e.message}")
        }
    }

    Map identifyHubFields = null
    if (args?.identifyHub == true) {
        try {
            hubInternalGet("/hub/advanced/blinkLED")
            identifyHubFields = [identifyHubTriggered: true]
        } catch (Exception e) {
            def msg = e.message ?: e.toString()
            identifyHubFields = [identifyHubTriggered: false, identifyHubError: msg]
            mcpLog("warn", "monitoring", "hub_get_device_health identifyHub blinkLED request failed [${e.class.simpleName}]: ${msg}")
        }
    }

    def inventory
    try {
        inventory = _deviceHealthInventory()
    } catch (Exception e) {

        mcpLog("error", "monitoring", "hub_get_device_health native inventory failed (${e.class.simpleName})")
        inventory = [success: false, error: "Native device inventory could not be read (${e.class.simpleName})."]
    }
    if (inventory?.success == false || !(inventory?.devices instanceof List)) {
        def failedResult = [success: false,
            error: inventory?.error ?: "Native device inventory returned an unexpected response.",
            note: inventory?.note ?: "Retry the native inventory read; device health could not be assessed."]
        if (pingResults != null) failedResult.pingResults = pingResults
        if (tracerouteResult != null) failedResult.traceroute = tracerouteResult
        if (speedtestResult != null) failedResult.speedtest = speedtestResult
        if (identifyHubFields != null) failedResult.putAll(identifyHubFields)
        return failedResult
    }
    def devices = inventory.devices
    if (!devices) {
        def emptyResult = [
            message: inventory.message ?: "No devices available for MCP access",
            summary: [totalDevices: 0, healthyCount: 0, staleCount: 0, unknownCount: 0]
        ]
        if (pingResults != null) emptyResult.pingResults = pingResults
        if (tracerouteResult != null) emptyResult.traceroute = tracerouteResult
        if (speedtestResult != null) emptyResult.speedtest = speedtestResult
        if (identifyHubFields != null) emptyResult.putAll(identifyHubFields)
        return emptyResult
    }

    def staleThreshold = now() - (staleHours * 3600000L)

    def healthy = []
    def stale = []
    def unknown = []

    devices.each { device ->
        try {
            def deviceLabel = device.label ?: device.name ?: "Device ${device.id}"
            def entry = [
                id: device.id.toString(),
                name: deviceLabel
            ]
            if (device.metadataUnavailable == true) {
                entry.lastActivity = "unavailable"
                entry.hoursAgo = null
                entry.metadataUnavailable = true
                unknown << entry
                return
            }

            def lastActivity = device.lastActivity != null ? _parseSinceArg(device.lastActivity) : null
            if (device.lastActivity != null && lastActivity == null) {
                mcpLog("error", "monitoring", "hub_get_device_health could not parse native lastActivity for device ${device.id}")
                entry.lastActivity = "unavailable"
                entry.hoursAgo = null
                entry.metadataUnavailable = true
                unknown << entry
                return
            }

            if (lastActivity) {
                try {
                    entry.lastActivity = lastActivity.format("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
                    def activityTime = lastActivity.getTime()


                    entry.hoursAgo = (Math.round((now() - activityTime) / 3600000.0 * 10) / 10.0) as double

                    if (activityTime < staleThreshold) {
                        stale << entry
                    } else {
                        healthy << entry
                    }
                } catch (Exception e) {
                    entry.lastActivity = "error: ${e.message}"
                    unknown << entry
                }
            } else {
                entry.lastActivity = "never"
                entry.hoursAgo = null
                unknown << entry
            }
        } catch (Exception e) {




            mcpLog("warn", "monitoring", "hub_get_device_health failed to inspect device ${device?.id}: ${e.class.simpleName}: ${e.message}")
            unknown << [id: device.id?.toString() ?: "unknown", name: "Error: ${e.message}", lastActivity: "error", errorClass: e.class.simpleName]
        }
    }


    stale.sort { a, b -> (b.hoursAgo ?: 0) <=> (a.hoursAgo ?: 0) }


    def paged = _paginateList(stale, cursor, 100, "hub_get_device_health")

    def result = [
        summary: [
            totalDevices: devices.size(),
            healthyCount: healthy.size(),
            staleCount: stale.size(),
            unknownCount: unknown.size(),
            staleThresholdHours: staleHours,
            checkedAt: formatTimestamp(now())
        ],
        staleDevices: paged.page,
        unknownDevices: unknown
    ]
    if (cursor != null) {
        result.total = stale.size()


        result.summary.staleDevicesInPage = paged.page.size()
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }

    if (includeHealthy) {
        result.healthyDevices = healthy
    }

    if (stale.size() > 0 || unknown.size() > 0) {
        result.recommendation = "Found ${stale.size()} stale and ${unknown.size()} unknown devices. " +
            "Stale devices may have dead batteries, be out of range, or be orphaned/ghost devices. " +
            "Use 'hub_get_device' on individual devices for more details."
    }

    if (pingResults != null) {
        result.pingResults = pingResults
    }

    if (tracerouteResult != null) {
        result.traceroute = tracerouteResult
    }

    if (speedtestResult != null) {
        result.speedtest = speedtestResult
    }

    if (identifyHubFields != null) {
        result.putAll(identifyHubFields)
    }

    mcpLog("info", "monitoring", "Device health check: ${healthy.size()} healthy, ${stale.size()} stale, ${unknown.size()} unknown (threshold: ${staleHours}h)")
    return result
}

def runPingChecks(List rawHosts, Integer count) {
    def results = []
    rawHosts.each { rawHost ->
        if (rawHost == null || !(rawHost instanceof CharSequence)) {
            results << [ipAddress: rawHost, reachable: false, error: "missing or non-string host"]
            return
        }
        def host = rawHost.toString().trim()

        if (!(host ==~ /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/)) {
            results << [ipAddress: host, reachable: false, error: "not a dotted-quad IPv4 literal (hostnames not supported, pass an IP)"]
            return
        }
        try {
            def pd = hubitat.helper.NetworkUtils.ping(host, count)

            def transmitted = (pd?.packetsTransmitted == null ? count : pd.packetsTransmitted) as Integer
            def received = (pd?.packetsReceived == null ? 0 : pd.packetsReceived) as Integer
            results << [
                ipAddress: host,
                reachable: transmitted > 0 && received > 0,
                packetsTransmitted: transmitted,
                packetsReceived: received,
                packetLoss: pd?.packetLoss,
                rttAvg: pd?.rttAvg,
                rttMin: pd?.rttMin,
                rttMax: pd?.rttMax
            ]
        } catch (Exception e) {
            def errorType
            if (e instanceof java.net.UnknownHostException) errorType = "unknown_host"
            else if (e instanceof java.net.SocketException) errorType = "socket"
            else if (e instanceof SecurityException) errorType = "security"
            else errorType = "other"
            mcpLog("warn", "monitoring", "ping failed for ${host} (count=${count}, type=${errorType}): ${e.message}")
            results << [ipAddress: host, reachable: false, errorType: errorType, error: e.message ?: e.toString()]
        }
    }
    return results
}







def toolSetZwave(args) {
    def hasEnabled = args.containsKey("enabled")
    def hasConfig = (args.region != null || args.long_range_channel != null)
    if (!hasEnabled && !hasConfig) {
        throw new IllegalArgumentException("Specify enabled (true/false) and/or region + long_range_channel.")
    }

    if (hasEnabled) {
        boolean enabled = (args.enabled == true)
        if (!enabled) requireDestructiveConfirm(args.confirm)
        try {
            def resp = _radioGet("/hub/zwave/enable/${enabled}")
            mcpLog("info", "hub-admin", "Z-Wave radio ${enabled ? 'enabled' : 'disabled'} via MCP")
            return [success: true, radio: "zwave", enabled: enabled,
                    message: "Z-Wave radio ${enabled ? 'enabled' : 'disabled'}.",
                    note: "Disabling the radio may require a hub reboot to fully take effect. Verify with hub_get_radio_details(radio='zwave').",
                    response: resp]
        } catch (Exception e) {
            mcpLogError("hub-admin", "Z-Wave enable/disable failed", e)
            return [success: false, error: "Z-Wave enable/disable failed: ${e.message}", note: "Check Hub Security credentials."]
        }
    }


    try {
        def current = _radioGet("/hub/zwaveDetails/json")
        def cur = (current instanceof Map) ? current : [:]
        def params = [:]
        params.enabled = (cur.enabled != null) ? cur.enabled : true
        params.region = (args.region != null) ? args.region : cur.region
        params.secureJoin = (cur.secureJoin != null) ? cur.secureJoin : 0
        if (args.long_range_channel != null) {
            params.longRangeChannel = args.long_range_channel
        } else if (cur.longRangeChannel != null) {
            params.longRangeChannel = cur.longRangeChannel
        }


        def resp = _radioGet("/hub/zwaveDetails/update", params.findAll { k, v -> v != null })
        mcpLog("info", "hub-admin", "Z-Wave region/long-range config updated via MCP")
        return [success: true, radio: "zwave", region: params.region, longRangeChannel: params.longRangeChannel,
                message: "Z-Wave radio configuration updated.", response: resp]
    } catch (Exception e) {
        mcpLogError("hub-admin", "Z-Wave config update failed", e)
        return [success: false, error: "Z-Wave config update failed: ${e.message}", note: "Check region/channel values and Hub Security credentials."]
    }
}




def toolSetZigbee(args) {
    def hasEnabled = args.containsKey("enabled")
    def hasChannel = (args.channel != null || args.power_level != null)
    def hasSettings = (args.rebuild_on_reboot != null || args.ping_inactive != null)
    def hasPingDevice = (args.ping_device != null)
    if (!hasEnabled && !hasChannel && !hasSettings && !hasPingDevice) {
        throw new IllegalArgumentException("Specify enabled, channel + power_level, rebuild_on_reboot/ping_inactive, or ping_device.")
    }

    if (hasEnabled) {
        boolean enabled = (args.enabled == true)
        if (!enabled) requireDestructiveConfirm(args.confirm)
        try {
            def resp = _radioGet("/hub/zigbee/enable/${enabled}")
            mcpLog("info", "hub-admin", "Zigbee radio ${enabled ? 'enabled' : 'disabled'} via MCP")
            return [success: true, radio: "zigbee", enabled: enabled,
                    message: "Zigbee radio ${enabled ? 'enabled' : 'disabled'}.",
                    response: resp]
        } catch (Exception e) {
            mcpLogError("hub-admin", "Zigbee enable/disable failed", e)
            return [success: false, error: "Zigbee enable/disable failed: ${e.message}", note: "Check Hub Security credentials."]
        }
    }

    if (hasPingDevice) {
        def pd = args.ping_device
        if (!(pd instanceof Map) || pd.device_id == null || pd.enabled == null) {
            throw new IllegalArgumentException("ping_device requires {device_id, enabled} -- toggle keep-alive pinging for one Zigbee device.")
        }
        _requireDeviceToolAccess(pd.device_id)
        if (!(_fetchDeviceFullJson(pd.device_id)?.device instanceof Map)) {
            return [success: false, isError: true,
                error: "Native device identity is unavailable for ${pd.device_id}; keep-alive ping was not changed.",
                note: "Use the numeric Hubitat device ID and verify the device exists before retrying."]
        }
        try {
            boolean on = (pd.enabled == true)
            def resp = _radioGet("/hub/zigbee/updatePingDevice/${java.net.URLEncoder.encode(pd.device_id.toString(), 'UTF-8')}/${on}")
            mcpLog("info", "hub-admin", "Zigbee keep-alive ping ${on ? 'on' : 'off'} for device ${pd.device_id} via MCP")
            return [success: true, radio: "zigbee", pingDevice: [deviceId: pd.device_id.toString(), enabled: on],
                    message: "Zigbee keep-alive ping ${on ? 'enabled' : 'disabled'} for device ${pd.device_id}.", response: resp]
        } catch (Exception e) {
            mcpLogError("hub-admin", "Zigbee ping-device update failed", e)
            return [success: false, error: "Zigbee ping-device update failed: ${e.message}", note: "Check the device id and Hub Security credentials."]
        }
    }

    if (hasSettings) {




        try {
            def current = _radioGet("/hub/zigbeeDetails/json")
            def cur = (current instanceof Map) ? current : [:]
            def rebuildCur = cur.rebuildNetworkOnReboot
            def pingCur = cur.inactiveDevicePingEnabled
            if (args.rebuild_on_reboot == null && !(rebuildCur instanceof Boolean)) {
                return [success: false, error: "Could not read the current rebuild-on-reboot setting to preserve it.",
                        note: "Pass rebuild_on_reboot explicitly, or read hub_get_radio_details(radio='zigbee') first."]
            }
            if (args.ping_inactive == null && !(pingCur instanceof Boolean)) {
                return [success: false, error: "Could not read the current ping-inactive setting to preserve it.",
                        note: "Pass ping_inactive explicitly, or read hub_get_radio_details(radio='zigbee') first."]
            }
            boolean rebuild = (args.rebuild_on_reboot != null) ? (args.rebuild_on_reboot == true) : (rebuildCur == true)
            boolean ping = (args.ping_inactive != null) ? (args.ping_inactive == true) : (pingCur == true)
            def resp = _radioGet("/hub/zigbee/updateSettings",
                              [rebuildNetworkOnReboot: rebuild, inactiveDevicePingEnabled: ping])
            mcpLog("info", "hub-admin", "Zigbee radio settings updated via MCP")
            return [success: true, radio: "zigbee", rebuildNetworkOnReboot: rebuild, inactiveDevicePingEnabled: ping,
                    message: "Zigbee radio settings updated.", response: resp]
        } catch (Exception e) {
            mcpLogError("hub-admin", "Zigbee settings update failed", e)



            def resp = null
            try { resp = e.response } catch (Exception ignore) { resp = null }
            Integer st = null
            try { st = resp?.status as Integer } catch (Exception ignore) { st = null }
            def note = (st == 404)
                ? "A 404 here usually means this hub has no active Zigbee radio (absent/disabled). Verify via hub_get_radio_details(radio='zigbee')."
                : "Check Hub Security credentials."
            return [success: false, error: "Zigbee settings update failed: ${e.message}", note: note]
        }
    }

    if (args.channel == null || args.power_level == null) {
        throw new IllegalArgumentException("channel and power_level must be set together.")
    }
    try {
        def resp = _radioGet("/hub/zigbee/updateChannelAndPower",
                             [channel: args.channel, powerLevel: args.power_level])
        mcpLog("info", "hub-admin", "Zigbee channel/power updated via MCP")
        return [success: true, radio: "zigbee", channel: args.channel, powerLevel: args.power_level,
                message: "Zigbee radio channel/power updated.",
                warning: "Changing the Zigbee channel can drop Zigbee devices that do not follow; they may need re-pairing.",
                response: resp]
    } catch (Exception e) {
        mcpLogError("hub-admin", "Zigbee config update failed", e)
        return [success: false, error: "Zigbee config update failed: ${e.message}", note: "Check channel/power values and Hub Security credentials."]
    }
}






def toolCallZwave(args) {
    def action = args.action?.toString()
    if (!action) throw new IllegalArgumentException("action is required. See hub_get_tool_guide for the full action list.")
    def nodeId = args.node_id?.toString()?.trim()
    def needsNode = action in ["repair_node", "node_refresh", "node_rediscover", "node_reinitialize", "node_remove", "node_replace"]
    if (needsNode && !nodeId) {
        throw new IllegalArgumentException("node_id is required for action '${action}'.")
    }

    try {
        def resp
        switch (action) {
            case "repair_start":





                resp = _radioGetSafe("/hub/zwaveRepair2", [resetStats: false, maxHealth: 10])
                if (resp instanceof Map && resp.error) {
                    mcpLog("debug", "hub-admin", "zwaveRepair2 missed (${resp.error}); trying legacy /hub/zwaveRepair")
                    resp = _radioGet("/hub/zwaveRepair")
                }
                return [success: true, action: action,
                        message: "Z-Wave network repair started (runs in the background).",
                        duration: "Typically 5-30 minutes depending on network size.",
                        warning: "Z-Wave devices may be temporarily unresponsive during repair. Do not start another repair until this one completes.",
                        note: "Poll hub_get_radio_details(include_status=true) for repair stage.", response: resp]
            case "repair_cancel":
                resp = _radioGet("/hub/zwaveCancelRepair")
                return [success: true, action: action, message: "Z-Wave repair cancel requested.", response: resp]
            case "repair_node":
                resp = _radioGet("/hub/zwaveNodeRepair2", [zwaveNodeId: nodeId])
                return [success: true, action: action, nodeId: nodeId, message: "Per-node Z-Wave repair started for node ${nodeId}.", response: resp]
            case "inclusion_start":
                resp = _radioGet("/hub/startZwaveJoin")
                return [success: true, action: action,
                        message: "Z-Wave inclusion (join) started. Put the device into pairing mode now.",
                        note: "Poll hub_get_radio_details(include_status=true). For S2 devices, follow with grant_keys / grant_code once the hub requests them.", response: resp]
            case "inclusion_stop":
                resp = _radioGet("/hub/stopJoin")
                return [success: true, action: action, message: "Z-Wave inclusion stopped.", response: resp]
            case "grant_keys":
                if (!(args.security_keys instanceof Map)) throw new IllegalArgumentException("grant_keys requires security_keys: a map of S2 grant booleans (e.g. {S2AccessControl:true, S2Authenticated:true, S2Unauthenticated:false, S0Unauthenticated:false}).")
                resp = _radioPost("/hub/zwave/securityKeys", groovy.json.JsonOutput.toJson(args.security_keys))
                return [success: true, action: action, message: "S2 security key grants submitted.", response: resp]
            case "grant_code":
                if (!(args.security_code instanceof Map)) throw new IllegalArgumentException("grant_code requires security_code: a map (e.g. {accept:true, securityCode:'12345'}).")
                resp = _radioPost("/hub/zwave/securityCode", groovy.json.JsonOutput.toJson(args.security_code))
                return [success: true, action: action, message: "S2 DSK / security code submitted.", response: resp]
            case "exclusion_start":
                requireDestructiveConfirm(args.confirm)
                resp = _radioGet("/hub/zwaveExclude")
                return [success: true, action: action,
                        message: "Z-Wave exclusion started. Activate the device to remove it from the mesh.",
                        warning: "Exclusion unpairs a device from the hub. Triggering a generic exclusion can remove a device from ANOTHER controller too.",
                        note: "Poll hub_get_radio_details(include_status=true) for exclusion status.", response: resp]
            case "exclusion_stop":
                resp = _radioGet("/hub/stopZWaveExclude")
                return [success: true, action: action, message: "Z-Wave exclusion stopped.", response: resp]
            case "node_refresh":
                resp = _radioPost("/hub/zwave/refreshNodeStatus", [zwaveNodeId: nodeId])
                return [success: true, action: action, nodeId: nodeId, message: "Refreshed status for node ${nodeId}.", response: resp]
            case "node_rediscover":
                resp = _radioPost("/hub/zwave/discoverDevice", [zwaveNodeId: nodeId])
                return [success: true, action: action, nodeId: nodeId, message: "Rediscovery started for node ${nodeId}.", response: resp]
            case "node_reinitialize":
                resp = _radioPost("/hub/zwave/nodeReinitialize", [zwaveNodeId: nodeId])
                return [success: true, action: action, nodeId: nodeId, message: "Reinitialize started for node ${nodeId}.", response: resp]
            case "refresh_stats":

                resp = _radioGet("/hub/zwaveNodeDetailGet")
                return [success: true, action: action, message: "Z-Wave statistics refresh requested.", response: resp]
            case "node_replace":
                resp = _radioPost("/hub2/zwave/nodeReplace", groovy.json.JsonOutput.toJson([zwaveNodeId: nodeId]))
                return [success: true, action: action, nodeId: nodeId,
                        message: "Node replace started for node ${nodeId}.",
                        note: "Poll hub_get_radio_details(include_status=true) (status.zwaveNodeReplace) and add the replacement device; abort with action='node_replace_stop'.", response: resp]
            case "node_replace_stop":
                resp = _radioPost("/hub/zwave/nodeReplace/stop")   // bare POST (UI sends empty body)
                return [success: true, action: action, message: "Z-Wave node replace stopped.", response: resp]
            case "node_remove":
                requireDestructiveConfirm(args.confirm)
                resp = _radioPost("/hub/zwave/nodeRemove", [zwaveNodeId: nodeId])
                return [success: true, action: action, nodeId: nodeId,
                        message: "Failed-node removal requested for node ${nodeId}.",
                        warning: "This force-removes a non-responding node from the Z-Wave mesh; it does not gracefully exclude a live device.", response: resp]
            case "antenna_test_start":
                if (!nodeId) throw new IllegalArgumentException("antenna_test_start requires node_id (the device to test against).")
                resp = _radioGet("/hub/zwave2/startAntennaTest", [node: nodeId])
                return [success: true, action: action, nodeId: nodeId, message: "Z-Wave antenna test started.", response: resp]
            case "antenna_test_continue":
                resp = _radioGet("/hub/zwave2/antennaTestContinue")
                return [success: true, action: action, message: "Z-Wave antenna test continued.", response: resp]
            case "smartstart_delete":
                if (!args.node_dsk) throw new IllegalArgumentException("smartstart_delete requires node_dsk (the DSK from hub_get_radio_details(include_smartstart=true)).")
                resp = _radioPost("/mobileapi/zwave/smartstart/delete", groovy.json.JsonOutput.toJson([nodeDSK: args.node_dsk.toString()]))
                return [success: true, action: action, message: "SmartStart entry deleted.", response: resp]
            default:
                throw new IllegalArgumentException("Unknown action '${action}'. See hub_get_tool_guide for valid Z-Wave actions.")
        }
    } catch (IllegalArgumentException iae) {
        throw iae
    } catch (Exception e) {
        mcpLogError("hub-admin", "hub_call_zwave action '${action}' failed", e)
        return [success: false, action: action, error: "Z-Wave action '${action}' failed: ${e.message}", note: "Check Hub Security credentials and that the radio is enabled."]
    }
}



def toolCallZigbee(args) {
    def action = args.action?.toString()
    if (!action) throw new IllegalArgumentException("action is required: radio_reboot, rebuild_network, or channel_scan.")
    try {
        def resp
        switch (action) {
            case "radio_reboot":

                resp = _radioGet("/hub/rebootZigbeeRadio")
                return [success: true, action: action, message: "Zigbee radio reboot requested.",
                        note: "Verify with hub_get_radio_details(radio='zigbee', include_status=true).", response: resp]
            case "rebuild_network":
                resp = _radioGet("/hub/rebuildZigbeeNetwork")
                return [success: true, action: action, message: "Zigbee network rebuild started.",
                        warning: "Rebuilding takes time; Zigbee devices may be briefly unresponsive.", response: resp]
            case "channel_scan":
                resp = _radioGet("/hub/zigbeeChannelScan")
                return [success: true, action: action, message: "Zigbee channel scan triggered.",
                        note: "Read results with hub_get_radio_details(include_channel_scan=true).", response: resp]
            default:
                throw new IllegalArgumentException("Unknown action '${action}'. Valid: radio_reboot, rebuild_network, channel_scan.")
        }
    } catch (IllegalArgumentException iae) {
        throw iae
    } catch (Exception e) {
        mcpLogError("hub-admin", "hub_call_zigbee action '${action}' failed", e)
        return [success: false, action: action, error: "Zigbee action '${action}' failed: ${e.message}", note: "Check Hub Security credentials."]
    }
}



def toolCallMatter(args) {
    def action = args.action?.toString()
    if (!action) throw new IllegalArgumentException("action is required: enable, disable, pair, or open_pairing_window.")
    try {
        def resp
        switch (action) {
            case "enable":
            case "disable":
                boolean enable = (action == "enable")
                if (!enable) requireDestructiveConfirm(args.confirm)
                resp = _radioGet("/hub/matter/enable/${enable}")
                return [success: true, action: action,
                        message: "Matter ${enable ? 'enable' : 'disable'} requested.",
                        warning: "Matter enable/disable requires a HUB REBOOT to take effect. Reboot via hub_reboot when ready.", response: resp]
            case "pair":
                if (!args.setup_code) throw new IllegalArgumentException("pair requires setup_code (the 11- or 21-digit Matter setup code / pairing code).")
                resp = _radioGet("/hub/matter/pair", [setupCode: args.setup_code.toString()])
                return [success: true, action: action,
                        message: "Matter commissioning started for the given setup code.",
                        note: "Poll hub_get_radio_details(radio='matter', include_status=true) for commissioning progress.", response: resp]
            case "open_pairing_window":
                if (!args.node_id) throw new IllegalArgumentException("open_pairing_window requires node_id (the commissioned Matter node to share).")
                resp = _radioGet("/hub/matter/openPairingWindow", [node: args.node_id.toString()])
                return [success: true, action: action, nodeId: args.node_id?.toString(),
                        message: "Matter pairing/share window opened.",
                        note: "The response carries the setup code for sharing this device to another fabric.", response: resp]
            default:
                throw new IllegalArgumentException("Unknown action '${action}'. Valid: enable, disable, pair, open_pairing_window.")
        }
    } catch (IllegalArgumentException iae) {
        throw iae
    } catch (Exception e) {
        mcpLogError("hub-admin", "hub_call_matter action '${action}' failed", e)
        return [success: false, action: action, error: "Matter action '${action}' failed: ${e.message}", note: "Matter requires a C-8/C-8 Pro on supported firmware."]
    }
}





def toolCallDestructiveOps(args) {
    requireDestructiveConfirm(args.confirm)
    def target = args.target?.toString()
    def action = args.action?.toString()
    if (!target) throw new IllegalArgumentException("target is required: zwave, zigbee, matter, network, or cloud.")
    if (!action) throw new IllegalArgumentException("action is required (depends on target): radio reset/firmware actions, network disconnect_wifi/disconnect_ethernet, or cloud disable/enable.")


    if (target == "network") return _destructiveNetworkOp(action)
    if (target == "cloud") return _destructiveCloudOp(action)


    def radio = target
    try {
        def resp

        if (action == "reset") {
            def path
            switch (radio) {
                case "zwave": path = "/hub/zwave/resetJson"; break
                case "zigbee": path = "/hub/zigbee/reset"; break
                case "matter": path = "/hub/matter/reset"; break
                default: throw new IllegalArgumentException("target must be zwave, zigbee, or matter for reset.")
            }
            resp = _radioGet(path)
            mcpLog("warn", "hub-admin", "DESTRUCTIVE: ${radio} radio reset via MCP")
            return [success: true, target: radio, action: action,
                    message: "${radio} radio/fabric reset. ALL ${radio} devices have been unpaired.",
                    warning: "This is irreversible. Every ${radio} device must be re-paired.",
                    lastBackup: formatTimestamp(state.lastBackupTimestamp), response: resp]
        }


        switch (action) {
            case "device_firmware_start":
                if (radio != "zwave") throw new IllegalArgumentException("device_firmware_start is Z-Wave only.")
                if (args.node_id == null || !args.file_name) throw new IllegalArgumentException("device_firmware_start requires node_id and file_name (from hub_get_radio_details(include_firmware=true)).")
                def startBody = [nodeId: args.node_id, target: (args.target_index != null ? args.target_index : args.node_id), fileName: args.file_name.toString()]
                resp = _radioPost("/hub/zwave/deviceFirmware/start", groovy.json.JsonOutput.toJson(startBody))
                return [success: true, target: radio, action: action,
                        message: "Z-Wave device firmware update started for node ${args.node_id}.",
                        warning: "Do NOT power-cycle the device or hub during the flash; interruption can brick the device.",
                        note: "Poll hub_get_radio_details(node_id=${args.node_id}). Abort with action='device_firmware_abort'.", response: resp]
            case "device_firmware_abort":
                if (radio != "zwave") throw new IllegalArgumentException("device_firmware_abort is Z-Wave only.")
                if (args.node_id == null) throw new IllegalArgumentException("device_firmware_abort requires node_id.")
                resp = _radioPost("/hub/zwave/deviceFirmware/abort", groovy.json.JsonOutput.toJson([nodeId: args.node_id]))
                return [success: true, target: radio, action: action, message: "Z-Wave device firmware update aborted for node ${args.node_id}.", response: resp]
            case "zwave_chip_firmware":
                if (radio != "zwave") throw new IllegalArgumentException("zwave_chip_firmware is Z-Wave only.")
                resp = _radioGet("/hub/zwave/startUpdateHubFirmware")
                return [success: true, target: radio, action: action,
                        message: "Z-Wave chip (hub radio) firmware update started.",
                        warning: "Do NOT power-cycle the hub during the flash; interruption can brick the radio.", response: resp]
            case "zigbee_firmware":
                if (radio != "zigbee") throw new IllegalArgumentException("zigbee_firmware is Zigbee only.")
                resp = _radioGet("/hub/zigbee/updateFirmware/latest")
                return [success: true, target: radio, action: action,
                        message: "Zigbee radio firmware update to latest started.",
                        warning: "Do NOT power-cycle the hub during the flash; interruption can brick the radio.", response: resp]
            default:
                throw new IllegalArgumentException("Unknown action '${action}' for target '${radio}'. Valid: reset, device_firmware_start, device_firmware_abort, zwave_chip_firmware, zigbee_firmware.")
        }
    } catch (IllegalArgumentException iae) {
        throw iae
    } catch (Exception e) {
        mcpLogError("hub-admin", "hub_call_destructive_ops ${radio}/${action} failed", e)
        return [success: false, target: radio, action: action, error: "Destructive radio op '${action}' on ${radio} failed: ${e.message}", note: "Check Hub Security credentials."]
    }
}



private _destructiveNetworkOp(String action) {
    def path
    switch (action) {
        case "disconnect_wifi": path = "/hub/advanced/disconnectWiFi"; break
        case "disconnect_ethernet": path = "/hub/advanced/disconnectEthernet"; break
        default: throw new IllegalArgumentException("Unknown action '${action}' for target 'network'. Valid: disconnect_wifi, disconnect_ethernet.")
    }
    try {



        def resp = _radioGet(path)
        mcpLog("warn", "hub-admin", "DESTRUCTIVE: hub ${action} via MCP")
        return [success: true, target: "network", action: action,
                message: "Hub ${action == 'disconnect_wifi' ? 'WiFi' : 'Ethernet'} disconnect command accepted.",
                warning: "The hub may become unreachable over the disconnected interface until it is reconnected.",
                note: "Command accepted (HTTP 2xx); there is no read-back to confirm the link dropped.",
                response: resp]
    } catch (Exception e) {
        mcpLogError("hub-admin", "hub_call_destructive_ops network/${action} failed", e)
        return [success: false, target: "network", action: action, error: "Network op '${action}' failed: ${e.message}", note: "The hub may already be unreachable over this interface. Check Hub Security credentials."]
    }
}



private _destructiveCloudOp(String action) {
    def path
    switch (action) {
        case "disable": path = "/hub/advanced/disableCloudController"; break
        case "enable": path = "/hub/advanced/enableCloudController"; break
        default: throw new IllegalArgumentException("Unknown action '${action}' for target 'cloud'. Valid: disable, enable.")
    }
    try {



        def resp = _radioGet(path)
        mcpLog("warn", "hub-admin", "DESTRUCTIVE: cloud controller ${action} via MCP")
        def disabling = (action == "disable")
        return [success: true, target: "cloud", action: action,
                message: "Hub cloud controller ${disabling ? 'disable' : 'enable'} command accepted.",
                warning: disabling
                    ? "Cloud features are expected to go OFF: Alexa/Google voice integrations, cloud dashboards, cloud firmware updates, and Hub Protect/subscription features will not work until re-enabled."
                    : "Cloud features are being re-enabled; allow a short time for cloud services to reconnect.",
                note: "Command accepted (HTTP 2xx); there is no read-back to confirm the controller's new state.",
                response: resp]
    } catch (Exception e) {
        mcpLogError("hub-admin", "hub_call_destructive_ops cloud/${action} failed", e)
        return [success: false, target: "cloud", action: action, error: "Cloud op '${action}' failed: ${e.message}", note: "Check Hub Security credentials."]
    }
}


def getMaxCapturedStates() {
    def max = settings.maxCapturedStates ?: 20

    return max < 1 ? 1 : (max > 100 ? 100 : max)
}

private Map _captureStore() {
    String owner = app?.id?.toString()
    if (!owner) throw new IllegalStateException("Capture storage requires an installed app ID")
    synchronized (CAPTURE_STORES) {
        if (!CAPTURE_STORES.containsKey(owner)) {
            CAPTURE_STORES.put(owner, [entries: [:], loaded: false])
        }
        return CAPTURE_STORES[owner]
    }
}

private void _resetCaptureStore() {
    if (!app?.id) return
    synchronized (CAPTURE_STORES) { CAPTURE_STORES.remove(app.id.toString()) }
}

private Map _captureEntriesLocked(Map store) {
    if (!store.loaded) {


        Map legacy = [:]
        if (state.capturedDeviceStates instanceof Map) legacy.putAll(state.capturedDeviceStates)
        if (atomicState.capturedDeviceStates instanceof Map) legacy.putAll(atomicState.capturedDeviceStates)
        Map entries = [:]
        legacy.each { id, raw ->
            def devices = raw instanceof Map && raw.containsKey("devices") ? raw.devices : raw
            if (!(devices instanceof Map) && !(devices instanceof List)) {
                throw new IllegalStateException("Legacy capture has an invalid device payload")
            }
            entries.put(id.toString(), [text: groovy.json.JsonOutput.toJson(devices),
                timestamp: raw instanceof Map ? raw.timestamp : null, deviceCount: devices.size()])
        }
        store.entries = entries
        store.loaded = true
    }

    if (atomicState.containsKey("capturedDeviceStates")) atomicState.remove("capturedDeviceStates")
    if (state.containsKey("capturedDeviceStates")) state.remove("capturedDeviceStates")
    return store.entries
}

def countCapturedStates() {
    if (!app?.id) return 0
    Map store = _captureStore()
    synchronized (store) { return _captureEntriesLocked(store).size() }
}

def saveCapturedState(stateId, capturedStates) {
    String id = stateId?.toString()
    if (id == null || (!(capturedStates instanceof Map) && !(capturedStates instanceof List))) {
        throw new IllegalArgumentException("A state ID and device map or list are required")
    }

    String text = groovy.json.JsonOutput.toJson(capturedStates)
    Map store = _captureStore()
    synchronized (store) {
        Map entries = _captureEntriesLocked(store)
        entries.put(id, [text: text, timestamp: now(), deviceCount: capturedStates.size()])
        List deleted = []
        int max = getMaxCapturedStates()
        while (entries.size() > max) {
            def oldest = entries.findAll { key, row -> key != id }.min { it.value.timestamp ?: 0 }
            deleted << oldest.key
            entries.remove(oldest.key)
        }
        return [stateId: stateId, deviceCount: capturedStates.size(), totalStored: entries.size(),
                maxLimit: max, deletedStates: deleted, nearLimit: entries.size() >= max - 4]
    }
}

def getCapturedState(stateId) {
    Map store = _captureStore()
    String text
    synchronized (store) { text = _captureEntriesLocked(store)[stateId?.toString()]?.text }
    return text == null ? null : new groovy.json.JsonSlurper().parseText(text)
}

def listCapturedStates() {
    Map store = _captureStore()
    synchronized (store) {
        return _captureEntriesLocked(store).entrySet().toList().sort { a, b ->
            (b.value.timestamp ?: 0) <=> (a.value.timestamp ?: 0)
        }.collect { item ->
            [stateId: item.key, deviceCount: item.value.deviceCount, timestamp: item.value.timestamp,
             capturedAt: formatTimestamp(item.value.timestamp)]
        }
    }
}

def deleteCapturedState(stateId) {
    Map store = _captureStore()
    synchronized (store) {
        Map entries = _captureEntriesLocked(store)
        String id = stateId?.toString()
        if (!entries) return [success: false, message: "No captured states exist"]
        if (!entries.containsKey(id)) return [success: false, message: "Captured state '${stateId}' not found"]
        entries.remove(id)
        return [success: true, message: "Captured state '${stateId}' deleted", remaining: entries.size()]
    }
}

def clearAllCapturedStates() {
    Map store = _captureStore()
    synchronized (store) {
        Map entries = _captureEntriesLocked(store)
        int count = entries.size()
        entries.clear()
        return [success: true, message: "Cleared ${count} captured state(s)", cleared: count]
    }
}

def toolListCapturedStates(args = null) {
    def states = listCapturedStates()
    def count = states.size()
    def cursor = args?.cursor
    def paged = _paginateList(states, cursor, 50, "hub_list_captured_states")
    def result = [
        capturedStates: paged.page,
        count: paged.page.size(),
        maxLimit: getMaxCapturedStates()
    ]
    if (cursor != null) {
        result.total = count
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }


    if (count >= getMaxCapturedStates()) {
        result.warning = "At maximum capacity (${getMaxCapturedStates()}). New captures will delete the oldest entry."
    } else if (count >= getMaxCapturedStates() - 4) {
        result.warning = "Approaching limit: ${count}/${getMaxCapturedStates()} slots used. Consider cleaning up unused captures."
    }

    return result
}




def toolDeleteCapturedState(args) {
    def stateId = (args instanceof Map) ? args.stateId : args
    return stateId ? deleteCapturedState(stateId) : clearAllCapturedStates()
}

def _getAllToolDefinitions_partDiagnostics() {
    return [
        [
            name: "hub_get_logs",
            description: """Read log history and MCP logging status. mode='hub' (default) returns native hub logs; mode='mcp' returns structured MCP entries with component/rule filters; mode='status' returns MCP log level, counts, and capacity. MCP history recovers from native Past Logs after reload; retention follows the hub's shared log limit. Requires Read master.""",
            inputSchema: [
                type: "object",
                properties: [
                    mode: [type: "string", enum: ["hub", "mcp", "status"], default: "hub", description: "hub = native app/device logs; mcp = structured MCP history; status = MCP logging configuration and counts."],
                    component: [type: "string", description: "MCP mode: component substring filter (for example server or rule)."],
                    ruleId: [type: "string", description: "MCP mode: filter by custom rule ID."],
                    level: [type: "string", description: "Filter by log level. Default: all levels.", enum: ["trace", "debug", "info", "warn", "error", "all"]],
                    source: [type: "string", description: "Hub mode: Filter by source/app name (case-insensitive substring match against the log entry)"],
                    deviceId: [type: "string", description: "Hub mode: Filter hub-wide history by numeric device ID, regardless of device selection or bypass (mutually exclusive with appId)."],
                    appId: [type: "string", description: "Hub mode: Scope to a single app's log entries (server-side filter, mutually exclusive with deviceId)"],
                    limit: [type: "integer", description: "Max entries: hub default 100/max 500; MCP default 50/max 100."],
                    pattern: [type: "string", description: "Hub mode: Case-insensitive regex applied to the log message field only.[[FLAT_TRIM]] Use source for app/device-name substring matching.[[/FLAT_TRIM]]"],
                    patterns: [type: "array", items: [type: "string"], description: "Hub mode: Multiple regex patterns; combine via patternMode. Same matching rules and caveats as `pattern`."],
                    patternMode: [type: "string", description: "Hub mode: How patterns array is combined: 'any' (default) = OR; 'all' = AND.", enum: ["any", "all"]],
                    since: [type: "string", description: "Hub mode: Return only entries at or after this time; ISO-8601 or relative offset like '2h'.[[FLAT_TRIM]] Full forms: ISO-8601 timestamp (e.g. '2024-01-15T10:30:00Z') or relative '30m'/'2h'/'1d'/'7d'; max relative offset 30d.[[/FLAT_TRIM]][[FLAT_TRIM]] Timestamps without a TZ marker (e.g. '2024-01-15T10:30:00' or '2024-01-15 10:30:00.000') are parsed as UTC. Use '0m' / '0d' as a degenerate since to filter out everything older than now -- useful for testing harnesses but rarely otherwise.[[/FLAT_TRIM]]"],
                    until: [type: "string", description: "Hub mode: Return only entries at or before this time. Same format as since. Default: now (no upper bound)."],
                    cursor: [type: "string", description: "Opt-in pagination cursor.[[FLAT_TRIM]] Pass \"\" for the first page, iterate nextCursor (page size 100).[[/FLAT_TRIM]]"]
                ]
            ]
        ],

        [
            name: "hub_get_performance_stats",
            description: "Get device and/or app performance stats from the hub's logs page. Requires Read master.",
            inputSchema: [
                type: "object",
                properties: [
                    type: [type: "string", description: "Which stats to return. Default: device.", enum: ["device", "app", "both"], default: "device"],
                    sortBy: [type: "string", description: "Sort results by field. Default: pct (% busy).", enum: ["pct", "count", "stateSize", "totalMs", "name"], default: "pct"],
                    limit: [type: "integer", description: "Max entries to return. Default: 20, 0 for all.", default: 20]
                ]
            ]
        ],
        [
            name: "hub_get_jobs",
            description: "Get scheduled jobs, running jobs, and hub actions from the hub's logs page. Requires Read master.",
            inputSchema: [
                type: "object",
                properties: [
                    cursor: [type: "string", description: "Opaque pagination cursor for scheduledJobs. Omit for the full list; pass '' for the first page of 100, then the returned nextCursor. runningJobs and hubActions stay in full on every page. Pages read a snapshot cached for 30 s, so a traversal that takes longer is best-effort."]
                ]
            ]
        ],
        [
            name: "hub_get_metrics",
            description: "Retrieve hub metrics (memory, temp, DB size) with CSV trend history. Trend history is sparse/stale[[FLAT_TRIM]] — the hub never auto-samples, so points exist only from earlier recordSnapshot=true calls[[/FLAT_TRIM]]. Requires Read master.",
            inputSchema: [
                type: "object",
                properties: [
                    recordSnapshot: [type: "boolean", description: "If true, also append this snapshot to the performance-history CSV in the hub File Manager — the tool's only write side-effect. Default: false (read-only).", default: false],
                    trendPoints: [type: "integer", description: "Number of recent historical data points to include. Default: 10, max: 50.", default: 10]
                ]
            ]
        ],
        [
            name: "hub_get_memory_history",
            description: "Get the hub's free-memory and CPU-load history (the platform's own timestamped ring buffer[[FLAT_TRIM]], each entry with freeMemoryKB and cpuLoad5min[[/FLAT_TRIM]]). Use to diagnose memory leaks or load trends over time.[[FLAT_TRIM]] For a single current snapshot plus temp/DB-size, use hub_get_metrics instead.[[/FLAT_TRIM]] Requires Read master.",
            inputSchema: [
                type: "object",
                properties: [
                    limit: [type: "integer", description: "Max entries to return (most recent); 0 for all.[[FLAT_TRIM]] Hub may have thousands of entries.[[/FLAT_TRIM]]", default: 100],
                    cursor: [type: "string", description: "Opt-in pagination cursor.[[FLAT_TRIM]] Pages within the limit-filtered entries. Pass \"\" for the first page, iterate nextCursor (page size 100).[[/FLAT_TRIM]]"]
                ]
            ]
        ],
        [
            name: "hub_get_device_health",
            description: "Hub network diagnostics + device-staleness checks. Checks selected devices and MCP-managed children, or all hub devices when allowlist bypass is enabled, for no activity in staleHours.",
            inputSchema: [
                type: "object",
                properties: [
                    staleHours: [type: "integer", description: "Flag devices with no activity in this many hours. Default: 24.", default: 24],
                    includeHealthy: [type: "boolean", description: "Include healthy devices in the response (can be large). Default: false.", default: false],
                    pingHosts: [type: "array", items: [type: "string"], description: "Optional IPv4 addresses to ICMP-ping (max 5 per call)."],
                    pingCount: [type: "integer", description: "Packets to send per host (1-5). Default: 3.", default: 3],
                    tracerouteHost: [type: "string", description: "Optional single IPv4 dotted-quad host (e.g. '8.8.8.8') to traceroute; plain-text route table returned under traceroute.output."],
                    speedtest: [type: "boolean", description: "If true, run the hub's WAN download speedtest; plain-text wget log with the measured speed returned under speedtest.output. Default: false."],
                    identifyHub: [type: "boolean", description: "Blink hub LED to identify hub. Default: false.", default: false],
                    cursor: [type: "string", description: "Opt-in pagination cursor for the staleDevices array.[[FLAT_TRIM]] Omit to get all stale devices in one response (subject to the universal response-size guard). Pass nextCursor from a prior call to fetch the next page (page size 100). unknownDevices and healthyDevices are always returned in full alongside the page.[[/FLAT_TRIM]]"]
                ]
            ]
        ],
        [
            name: "hub_get_radio_details",
            description: """Get Z-Wave/Zigbee/Matter radio info and the read-only radio surface. The include_* flags and node_id attach extra read blocks. Requires Read master.""",
            inputSchema: [
                type: "object",
                properties: [
                    radio: [type: "string", enum: ["zwave", "zigbee", "matter"], description: "Which radio to query. Omit to return both Z-Wave and Zigbee; pass 'matter' for the Matter fabric and commissioned-device list."],
                    include_topology: [type: "boolean", description: "Also include the mesh route/topology map. Z-Wave/Zigbee only. Default false."],
                    node_id: [type: "string", description: "Per-node status for this id: Z-Wave node state, or Matter commissioning status when radio='matter'."],
                    include_status: [type: "boolean", description: "Attach lifecycle status pollers under result.status. Default false."],
                    include_logs: [type: "boolean", description: "Attach Matter chip-tool logs ({text}, ANSI) under result.matterLogs. Default false."],
                    include_channel_scan: [type: "boolean", description: "Attach Zigbee channel energy-scan results under result.channelScan. Default false."],
                    include_smartstart: [type: "boolean", description: "Attach the Z-Wave SmartStart provisioning list under result.smartStart. Default false."],
                    include_firmware: [type: "boolean", description: "Attach firmware-eligible Z-Wave devices + available files under result.firmware. Default false."]
                ]
            ]
        ],
        [
            name: "hub_call_gc",
            description: "Force JVM garbage collection to reclaim memory. Non-destructive but may cause a brief pause. Requires the Write master.",
            inputSchema: [
                type: "object",
                properties: [:]
            ]
        ],
        [
            name: "hub_set_zwave",
            description: "Configure the Z-Wave radio (idempotent)[[FLAT_TRIM]]: enable/disable it, or set region and long-range channel[[/FLAT_TRIM]]. Read current values with hub_get_radio_details(radio='zwave'). Requires Write master.",
            inputSchema: [
                type: "object",
                properties: [
                    enabled: [type: "boolean", description: "Enable (true) or disable (false) the Z-Wave radio."],
                    region: [type: "string", description: "Z-Wave RF region (e.g. 'US', 'EU'). Must match a region your hub hardware supports."],
                    long_range_channel: [type: "integer", enum: [0, 1, 255], description: "Z-Wave Long Range channel: 255=Auto, 0=Channel A, 1=Channel B (US_LR hubs)."],
                    confirm: [type: "boolean", description: "Required true to DISABLE the radio (backup <24h also enforced). Not needed for enable or config-only changes."]
                ]
            ]
        ],
        [
            name: "hub_set_zigbee",
            description: "Configure the Zigbee radio (idempotent)[[FLAT_TRIM]]: enable/disable, channel + power, radio settings (rebuild-on-reboot / inactive-device ping), or per-device keep-alive ping[[/FLAT_TRIM]]. One operation per call. Read current values with hub_get_radio_details(radio='zigbee'). Requires Write master.",
            inputSchema: [
                type: "object",
                properties: [
                    enabled: [type: "boolean", description: "Enable (true) or disable (false) the Zigbee radio. Disable requires confirm=true."],
                    channel: [description: "Zigbee channel (typically 11-26). Set together with power_level."],
                    power_level: [description: "Zigbee transmit power level (hub-dependent dBm scale). Set together with channel."],
                    rebuild_on_reboot: [type: "boolean", description: "Radio setting: rebuild the Zigbee network on each hub reboot."],
                    ping_inactive: [type: "boolean", description: "Radio setting: keep-alive ping inactive Zigbee devices."],
                    ping_device: [type: "object", description: "Toggle keep-alive ping for one authorized device: {device_id: numeric Hubitat device ID, enabled}. Allowlist bypass permits unselected devices."],
                    confirm: [type: "boolean", description: "Required true to DISABLE the radio (backup <24h also enforced). Not needed for the other changes."]
                ]
            ]
        ],
        [
            name: "hub_call_zwave",
            description: "Z-Wave network lifecycle operations (NOT idempotent)[[FLAT_TRIM]]: repair, device inclusion (join + S2 grants), exclusion, per-node maintenance, node replace/remove, antenna test, and SmartStart delete[[/FLAT_TRIM]]. Pick the operation with action. Requires Write master.",
            inputSchema: [
                type: "object",
                properties: [
                    action: [type: "string", enum: ["repair_start", "repair_cancel", "repair_node", "inclusion_start", "inclusion_stop", "grant_keys", "grant_code", "exclusion_start", "exclusion_stop", "node_refresh", "node_rediscover", "node_reinitialize", "refresh_stats", "node_replace", "node_replace_stop", "node_remove", "antenna_test_start", "antenna_test_continue", "smartstart_delete"], description: "The Z-Wave operation."],
                    node_id: [type: "string", description: "Z-Wave node id; required for repair_node, node_refresh/rediscover/reinitialize, node_remove, node_replace, antenna_test_start."],
                    security_keys: [type: "object", description: "grant_keys only: S2 grant booleans, e.g. {S2Authenticated:true}."],
                    security_code: [type: "object", description: "grant_code only: S2 DSK, e.g. {accept:true, securityCode:'12345'}."],
                    node_dsk: [type: "string", description: "smartstart_delete only: the DSK from hub_get_radio_details(include_smartstart=true)."],
                    confirm: [type: "boolean", description: "Required true for exclusion_start and node_remove (backup <24h also enforced)."]
                ],
                required: ["action"]
            ]
        ],
        [
            name: "hub_call_zigbee",
            description: "Zigbee radio operations (NOT idempotent); select with action. Requires Write master.",
            inputSchema: [
                type: "object",
                properties: [
                    action: [type: "string", enum: ["radio_reboot", "rebuild_network", "channel_scan"], description: "radio_reboot (restart the Zigbee chip), rebuild_network (rebuild the mesh), or channel_scan (trigger an energy scan)."],
                ],
                required: ["action"]
            ]
        ],
        [
            name: "hub_call_matter",
            description: "Matter radio operations (NOT idempotent); select with action. Requires Write master.",
            inputSchema: [
                type: "object",
                properties: [
                    action: [type: "string", enum: ["enable", "disable", "pair", "open_pairing_window"], description: "enable/disable the Matter radio (needs a hub reboot), pair a device by setup_code, or open_pairing_window to share a commissioned node_id."],
                    setup_code: [type: "string", description: "pair only: the 11- or 21-digit Matter setup/pairing code."],
                    node_id: [type: "string", description: "open_pairing_window only: the commissioned Matter node id to share."],
                    confirm: [type: "boolean", description: "Required true to disable Matter (backup <24h also enforced)."]
                ],
                required: ["action"]
            ]
        ],
        [
            name: "hub_call_destructive_ops",
            description: """⚠️ DESTRUCTIVE hub ops by `target` + `action` (no defaults — both required): radio WIPE/FIRMWARE, network DISCONNECT, or cloud DISABLE.

PRE-FLIGHT: 1) Backup <24h old 2) Tell the user what is affected (irreversible / can brick / disconnects) 3) Get explicit confirmation 4) Set confirm=true.
Requires Write master.""",
            inputSchema: [
                type: "object",
                properties: [
                    target: [type: "string", enum: ["zwave", "zigbee", "matter", "network", "cloud"], description: "REQUIRED: what to act on."],
                    action: [type: "string", enum: ["reset", "device_firmware_start", "device_firmware_abort", "zwave_chip_firmware", "zigbee_firmware", "disconnect_wifi", "disconnect_ethernet", "disable", "enable"], description: "REQUIRED: depends on target."],
                    node_id: [description: "Z-Wave node id."],
                    file_name: [type: "string", description: "Firmware file name; required for action=device_firmware_start."],
                    target_index: [description: "Optional Z-Wave firmware target index."],
                    confirm: [type: "boolean", description: "REQUIRED: must be true.[[FLAT_TRIM]] Confirms backup was created and the user approved this destructive op.[[/FLAT_TRIM]]"]
                ],
                required: ["target", "action", "confirm"]
            ]
        ],

        [
            name: "hub_list_captured_states",
            description: "List temporary device-state snapshots used by the legacy custom rule engine. Captures are held only in memory and are lost on hub restart or app code reload.",
            inputSchema: [
                type: "object",
                properties: [
                    cursor: [type: "string", description: "Opt-in pagination cursor.[[FLAT_TRIM]] Omit for unbounded; pass \"\" for the first page, iterate nextCursor (page size 50).[[/FLAT_TRIM]]"]
                ]
            ]
        ],
        [
            name: "hub_delete_captured_state",
            description: "Delete a saved device-state snapshot by its stateId, OR delete ALL captured states when stateId is omitted (get stateIds from hub_list_captured_states). Cannot be undone; use the delete-all mode with caution.",
            inputSchema: [
                type: "object",
                properties: [
                    stateId: [type: "string", description: "The ID of the captured state to delete. Omit to delete ALL captured states."],
                ]
            ]
        ],
    ]
}

def _readOnlyToolNames_partDiagnostics() {



    return [

        "hub_list_captured_states",

        "hub_get_logs", "hub_get_performance_stats", "hub_get_jobs", "hub_get_memory_history", "hub_get_radio_details",


        "hub_get_metrics",



        "hub_get_device_health"
    ]
}

def _idempotentWriteToolNames_partDiagnostics() {


    return [

        "hub_delete_captured_state",



        "hub_set_zwave", "hub_set_zigbee"
    ]
}

def _openWorldToolNames_partDiagnostics() {


    return [



        "hub_get_device_health"
    ]
}

def _toolDisplayMeta_partDiagnostics() {


    return [

        hub_get_logs: [title: "Get Logs", summary: "Hub log history, structured MCP history, or MCP logging status."],
        hub_get_performance_stats: [title: "Get Performance Stats", summary: "Device and app performance statistics."],
        hub_get_jobs: [title: "Get Scheduled Jobs", summary: "Scheduled jobs, running jobs, and hub actions."],
        hub_get_metrics: [title: "Get Hub Metrics", summary: "Hub metrics with CSV trend history."],
        hub_get_memory_history: [title: "Get Memory History", summary: "Free-memory and CPU-load history with summary stats."],
        hub_call_gc: [title: "Force Garbage Collection", summary: "Force JVM garbage collection and report freed memory."],
        hub_get_device_health: [title: "Get Device Health", summary: "Find stale devices, ICMP-ping LAN hosts, run traceroute/WAN speedtest, and optionally blink the hub identify LED."],
        hub_get_radio_details: [title: "Get Radio Details", summary: "Z-Wave/Zigbee/Matter details, topology, per-node state, status, channel scan, SmartStart, firmware."],
        hub_set_zwave: [title: "Set Z-Wave Radio", summary: "Enable/disable the Z-Wave radio or set its region and long-range channel."],
        hub_set_zigbee: [title: "Set Zigbee Radio", summary: "Enable/disable the radio, set channel/power, radio settings (rebuild-on-reboot, ping-inactive), or per-device keep-alive ping."],
        hub_call_zwave: [title: "Z-Wave Operations", summary: "Z-Wave repair, inclusion, exclusion, node maintenance, replace/remove, antenna test, SmartStart delete."],
        hub_call_zigbee: [title: "Zigbee Operations", summary: "Reboot the Zigbee radio, rebuild the network, or trigger a channel scan."],
        hub_call_matter: [title: "Matter Operations", summary: "Enable/disable Matter, pair a device by setup code, or open a pairing window."],
        hub_call_destructive_ops: [title: "Destructive Hub Ops", summary: "Reset a radio, flash firmware, disconnect WiFi/Ethernet, or disable the cloud controller (irreversible)."],
        hub_list_captured_states: [title: "List Captured States", summary: "List saved device state snapshots."],
        hub_delete_captured_state: [title: "Delete Captured State", summary: "Delete one or all captured device state snapshots."]
    ]
}
