library(name: "McpSelfAdminLib", namespace: "mcp", author: "kingpanther13", description: "MCP self-administration tool implementations (hub_update_mcp_settings + the hub_update_package Developer Mode deploy) for the MCP Rule Server; #include'd by the main app. Gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")
// Developer comments are blanked in this hub copy so the hub's code pages stay fast -- Groovy discards them anyway. Below this line, a line number here is the repository file's plus one. Full source: https://github.com/kingpanther13/Hubitat-local-MCP-server/blob/main/libraries/mcp-self-admin-lib.groovy

def toolUpdateMcpSettings(args) {




    if (!settings.enableDeveloperMode) {
        throw new IllegalArgumentException("Developer Mode tools are disabled. Enable 'Developer Mode Tools' in MCP rule app settings to use hub_update_mcp_settings.")
    }
    requireDestructiveConfirm(args.confirm)

    if (!args.settings || !(args.settings instanceof Map) || args.settings.isEmpty()) {
        throw new IllegalArgumentException("settings must be a non-empty map of {settingName: newValue}")
    }























    def allowedSettings = [
        "mcpLogLevel":            "enum",
        "debugLogging":           "bool",
        "maxCapturedStates":      "number",
        "loopGuardMax":           "number",
        "loopGuardWindowSec":     "number",
        "enableRead":             "bool",
        "enableCustomRuleEngine": "bool",
        "useGateways":            "bool",
        "enableMandatoryBPS":     "bool",
        "bypassDeviceAllowlist":  "bool",
        "maxConcurrentWrites":    "number",
        "backupEveryRuleWrite":   "bool"
    ]

    def allowedKeyNames = ((allowedSettings.keySet() + ["selectedDevices"]) as List).sort()












    def updates = [:]
    boolean hasDeviceScope = false
    def deviceScopeRaw = null
    args.settings.each { key, value ->
        def keyStr = key.toString()
        if (keyStr == "selectedDevices") {






            hasDeviceScope = true
            deviceScopeRaw = value
            return  // continue the each-closure
        }
        if (!allowedSettings.containsKey(keyStr)) {
            throw new IllegalArgumentException("Setting '${keyStr}' is not allowed for self-modification via hub_update_mcp_settings. Allowed: ${allowedKeyNames.join(', ')}")
        }
        def coerced = coerceSettingValue(keyStr, value, allowedSettings.get(keyStr))




        if (keyStr == "mcpLogLevel" && !getLogLevels().contains(coerced)) {
            throw new IllegalArgumentException("Setting 'mcpLogLevel' must be one of ${getLogLevels()}, got: ${coerced}")
        }
        if (keyStr == "maxConcurrentWrites") {
            BigDecimal numeric = coerced as BigDecimal
            if (numeric < 0 || numeric > 100 || numeric.remainder(BigDecimal.ONE) != BigDecimal.ZERO) {
                throw new IllegalArgumentException("Setting 'maxConcurrentWrites' must be an integer between 0 and 100 (0 disables the cap), got: ${coerced}")
            }
            coerced = numeric.intValue()
        }
        updates.put(keyStr, coerced)
    }





    def deviceScopeResult = null
    if (hasDeviceScope) {
        deviceScopeResult = _validateMcpDeviceScope(deviceScopeRaw)
        if (deviceScopeResult?.success != true) {
            return deviceScopeResult
        }
    }














    mcpLog("warn", "developer-mode", "hub_update_mcp_settings: attempted=${updates}")
    if (hasDeviceScope) {
        mcpLog("warn", "developer-mode", "hub_update_mcp_settings selectedDevices: attempted mode=${deviceScopeResult.mode} resulting=${deviceScopeResult.resultIds} added=${deviceScopeResult.added} removed=${deviceScopeResult.removed}")





        app.updateSetting("selectedDevices", [type: "capability.*", value: deviceScopeResult.resultIds])
    }









    updates.each { key, value ->
        if (key == "mcpLogLevel") {

            toolSetLogLevel([level: value.toString()])
        } else {
            app.updateSetting(key, [type: allowedSettings.get(key), value: value])
        }
    }



    mcpLog("warn", "developer-mode", "hub_update_mcp_settings: applied=${updates}")
    if (hasDeviceScope) {
        mcpLog("warn", "developer-mode", "hub_update_mcp_settings selectedDevices: applied mode=${deviceScopeResult.mode} authorizedCount=${deviceScopeResult.resultIds.size()}")
    }

    def updateCount = updates.size() + (hasDeviceScope ? 1 : 0)
    def settingWord = updateCount == 1 ? "setting" : "settings"









    def schemaAffectingKeys = ["enableRead", "enableCustomRuleEngine", "useGateways"] as Set
    def touchedSchemaKey = updates.keySet().any { schemaAffectingKeys.contains(it) }
    def message = "Updated ${updateCount} ${settingWord}."
    if (touchedSchemaKey) {
        message += " MCP clients (Claude Code, etc.) may need to reconnect to refresh cached tool schemas if you toggled an enable* flag or useGateways."
    }
    def result = [
        success: true,
        updated: updates,
        message: message
    ]
    if (hasDeviceScope) {


        result.selectedDevices = [
            mode: deviceScopeResult.mode,
            authorizedDeviceIds: deviceScopeResult.authorizedDeviceIds,
            authorizedCount: deviceScopeResult.authorizedCount,
            added: deviceScopeResult.added,
            removed: deviceScopeResult.removed
        ]
        result.message = result.message + " " + deviceScopeResult.message
    }
    return result
}






















private Map _validateMcpDeviceScope(scopeValue) {

    def mode = "replace"
    def rawIds
    def allowEmpty = false
    if (scopeValue instanceof List) {
        rawIds = scopeValue
    } else if (scopeValue instanceof Map) {
        mode = (scopeValue.mode == null) ? "replace" : scopeValue.mode.toString().trim()
        rawIds = scopeValue.ids
        allowEmpty = (scopeValue.allowEmpty == true)
    } else {
        throw new IllegalArgumentException("selectedDevices must be an array of device ID strings, or an object {mode, ids, allowEmpty}")
    }

    if (!(mode in ["replace", "add", "remove"])) {
        throw new IllegalArgumentException("selectedDevices mode must be one of: replace, add, remove (got: '${mode}')")
    }
    if (rawIds == null || !(rawIds instanceof List)) {
        throw new IllegalArgumentException("selectedDevices ids is required and must be an array of device ID strings")
    }


    def requestedIds = []
    rawIds.each { raw ->
        if (raw == null || raw instanceof Map || raw instanceof List) {
            throw new IllegalArgumentException("selectedDevices ids entries must be device ID strings or integers, got: ${raw}")
        }
        def s = raw.toString().trim()
        if (!s) {
            throw new IllegalArgumentException("selectedDevices ids entries must be non-empty device IDs")
        }
        if (!requestedIds.contains(s)) requestedIds << s
    }







    if (mode in ["replace", "add"] && !requestedIds.isEmpty()) {












        def inventory = _fetchAllHubDeviceRecords("developer-mode", "hub_update_mcp_settings selectedDevices")
        if (inventory.failure == "fetch") {
            return [success: false, isError: true, error: "Failed to fetch the all-hub device list (${inventory.source}) to validate selectedDevices: ${inventory.fetchError}", note: "Endpoint may be unavailable on this firmware; nothing was changed."]
        }
        if (inventory.failure) {
            return [success: false, isError: true, error: "Unexpected ${inventory.source} response; cannot validate selectedDevices.", note: "Hub firmware may have changed the endpoint contract; nothing was changed."]
        }
        def hubDeviceIds = (inventory.records.findAll { it instanceof Map }.collect { it.id?.toString() }.findAll { it != null }) as Set
        def unknown = requestedIds.findAll { !hubDeviceIds.contains(it) }
        if (!unknown.isEmpty()) {
            if (inventory.idsComplete == false) {
                return [success: false, isError: true,
                        error: "Could not validate device id(s) ${unknown.join(', ')}: the all-hub device inventory is incomplete, so they may be real devices it omitted. ${inventory.partialNote ?: ''}".toString().trim(),
                        note: "Nothing was changed. Retry once /hub2/devicesList answers; hub_list_devices(scope='all') reports the same inventory and its capabilitiesNote says what is missing."]
            }
            throw new IllegalArgumentException("Unknown device id(s): ${unknown.join(', ')}. Use hub_list_devices(scope='all') to see valid ids. Nothing was changed.")
        }
    }






    def currentIds = (settings.selectedDevices ?: []).collect { dev ->
        def id = (dev instanceof String || dev instanceof Number) ? dev.toString() : dev?.id?.toString()
        if (id == null) {
            throw new IllegalArgumentException("settings.selectedDevices contains an unrecognized element (neither a device with an id nor a String/Number id): ${dev}. Nothing was changed.")
        }
        id
    } as List
    def currentSet = currentIds as Set



    def resultIds
    switch (mode) {
        case "replace": resultIds = new ArrayList(requestedIds); break
        case "add":     def u = new LinkedHashSet(currentIds); u.addAll(requestedIds); resultIds = new ArrayList(u); break
        case "remove":  resultIds = currentIds.findAll { !requestedIds.contains(it) }; break
    }
    def resultSet = resultIds as Set





    if (resultSet.isEmpty() && !allowEmpty) {
        throw new IllegalArgumentException("Refusing to empty the MCP device-access scope: the resulting set is empty, which blinds the MCP server to every selected device. Pass selectedDevices.allowEmpty:true to confirm you intend to clear the scope.")
    }

    def added = (resultSet - currentSet) as List
    def removed = (currentSet - resultSet) as List


    def dw = { n -> n == 1 ? "device" : "devices" }
    return [
        success: true,
        mode: mode,
        resultIds: resultIds,
        authorizedDeviceIds: resultIds,
        authorizedCount: resultIds.size(),
        added: added,
        removed: removed,
        message: "MCP device-access scope updated (mode=${mode}): ${resultIds.size()} ${dw(resultIds.size())} authorized, ${added.size()} ${dw(added.size())} added, ${removed.size()} ${dw(removed.size())} removed. Device visibility changed -- MCP clients may need to reconnect to refresh which devices are exposed."
    ]
}










private coerceSettingValue(String key, value, String type) {
    if (value == null) {
        throw new IllegalArgumentException("Setting '${key}' value cannot be null")
    }
    switch (type) {
        case "bool":
            if (value instanceof Boolean) return value
            def s = value.toString().toLowerCase()
            if (s == "true") return true
            if (s == "false") return false
            throw new IllegalArgumentException("Setting '${key}' expects a boolean (true/false), got: ${value} (${value.class.simpleName})")

        case "number":
            if (value instanceof Number) return value
            def s = value.toString()
            if (s.isInteger()) return s.toInteger()
            if (s.isLong()) return s.toLong()
            if (s.isBigDecimal()) return s.toBigDecimal()
            throw new IllegalArgumentException("Setting '${key}' expects a number, got: ${value} (${value.class.simpleName})")

        case "enum":

            return value.toString()

        default:

            return value
    }
}




def getPackageSourceBase() {
    return "https://raw.githubusercontent.com/kingpanther13/Hubitat-local-MCP-server"
}









def _reanchorToRef(location, String base, String ref) {
    if (!(location instanceof String) || !location.trim()) return null
    def loc = location.trim()
    def rel = loc.replaceFirst(/^https?:\/\/[^\/]+\/[^\/]+\/[^\/]+\/[^\/]+\//, '')
    if (rel == loc || !rel) return null
    return "${base}/${ref}/${rel}".toString()
}









def _bundleArtifactUrlForRef(location, String base, String ref) {
    if (!(location instanceof String) || !location.trim() || !ref) return null
    def loc = location.trim()
    def rel = loc.replaceFirst(/^https?:\/\/[^\/]+\/[^\/]+\/[^\/]+\/[^\/]+\//, '')
    if (rel == loc || !rel) return null
    def baseName = rel.tokenize('/').last()



    def keyPath = (ref ==~ /[0-9a-f]{40}/) ? "shas/${ref}" : "branches/${ref}"
    return "${base}/bundle-artifacts/${keyPath}/${baseName}".toString()
}





def _bundleArtifactExists(String artifactUrl) {
    try {
        def r = _httpFetchUrl("${artifactUrl}.size")
        return ((r?.status as Integer) == 200) && (r?.body?.toString()?.trim() ==~ /\d+/)
    } catch (Exception e) {



        mcpLog("warn", "developer-mode", "_bundleArtifactExists: probe of ${artifactUrl}.size failed (${e.toString()}) -- treating as no artifact; the bundle leg falls back to the committed zip")
        return false
    }
}




def _parseIncludeDirectives(String source) {
    def tokens = []
    def seen = [] as Set
    def matcher = (source =~ /(?m)^[ \t]*#include[ \t]+([A-Za-z0-9_]+\.[A-Za-z0-9_]+)[ \t]*$/)
    while (matcher.find()) {
        def tok = matcher.group(1)
        if (!seen.contains(tok)) { seen << tok; tokens << tok }
    }
    return tokens
}





def _resolveSelfAppClassId() {
    try {
        def responseText = hubInternalGet("/hub2/userAppTypes")
        if (!responseText) return null
        def parsed = new groovy.json.JsonSlurper().parseText(responseText)
        if (!(parsed instanceof List)) return null
        def match = parsed.find { it?.namespace == "mcp" && it?.name == "MCP Rule Server" }
        return match?.id?.toString()
    } catch (Exception e) {

        mcpLog("warn", "hub-admin", "_resolveSelfAppClassId: self app-class lookup failed (${e.toString()}) -- self-deploy detection / #237 compile-error capture is skipped for this update")
        return null
    }
}





def toolUpdatePackage(args) {
    if (!settings.enableDeveloperMode) {
        throw new IllegalArgumentException("Developer Mode tools are disabled. Enable 'Developer Mode Tools' in MCP rule app settings to use hub_update_package.")
    }
    def ref = args?.ref
    if (!(ref instanceof String) || !ref.trim()) {
        throw new IllegalArgumentException("ref is required: a branch, tag, or commit SHA to deploy (e.g. 'main' or a PR head SHA).")
    }
    ref = ref.trim()
    if (args?.dryRun == true) return _updatePackageBody(args as Map, ref, true)

    requireDestructiveConfirm(args?.confirm)
    long startedAt = now()
    String requestId = "pkg-${java.util.UUID.randomUUID()}".toString()
    def storedArgs = [ref: ref, confirm: true]
    if (args?.baseUrl instanceof String && args.baseUrl.trim()) storedArgs.baseUrl = args.baseUrl.trim()
    Map refusal = null
    synchronized (WRITE_RESERVATION_LOCK) {
        _packageSweepMarkerLocked()
        def inFlight = _writeStateValueLocked("packageDeployInFlight")
        if (inFlight instanceof Map) {
            def summary = [ref: inFlight.ref, requestId: inFlight.requestId,
                           startedAt: inFlight.startedAt]
            if (inFlight.startedAt != null) {
                try { summary.elapsedMs = now() - (inFlight.startedAt as Long) }
                catch (Exception ignored) { }
            }
            refusal = [
                success: false, isError: true, status: "duplicate_in_flight",
                inFlight: summary,
                error: "A package deploy (ref '${inFlight.ref}') is already running on this hub. Nothing was changed.",
                note: "Do not re-run the deploy. Watch hub_get_info.lastSelfDeploy for a record whose requestId matches the original acceptance response."
            ]
        }
        if (refusal == null) {
            _writeStateSetLocked("packageDeployInFlight", [
                requestId: requestId, ref: ref, startedAt: startedAt,
                phase: "queued", expiresAt: startedAt + _packageDeployRecoveryMs(),
                args: storedArgs
            ])
        }
    }
    if (refusal != null) return refusal
    try {
        runIn(1, "runPackageDeploy", [data: [requestId: requestId]])
    } catch (Exception scheduleErr) {
        synchronized (WRITE_RESERVATION_LOCK) {
            def current = _writeStateValueLocked("packageDeployInFlight")
            if (current instanceof Map && current.requestId?.toString() == requestId) {
                _writeStateSetLocked("packageDeployInFlight", null)
                try { atomicState.remove("packageDeployInFlight") } catch (Exception ignored) { }
            }
        }
        return [success: false, isError: true, status: "schedule_failed", ref: ref,
                error: "Package deploy could not be scheduled: ${scheduleErr.message}. Nothing was changed.",
                note: "The in-flight marker was released, so this call is safe to retry with the same ref. If it keeps failing, the hub's scheduler is refusing jobs -- check hub_get_logs, then deploy each app with hub_update_app instead."]
    }
    return [
        success: true,
        status: "in_progress",
        ref: ref,
        requestId: requestId,
        startedAt: startedAt,
        message: "Package deploy accepted and is running in the background.",
        note: "Do not submit it again. Read hub_get_info.lastSelfDeploy until its requestId matches this response; success/error then carries the final outcome."
    ]
}



def runPackageDeploy(Map job = [:]) {
    String requestId = job?.requestId?.toString()
    Map marker = null
    synchronized (WRITE_RESERVATION_LOCK) {
        def current = _writeStateValueLocked("packageDeployInFlight")
        if (current instanceof Map && current.requestId?.toString() == requestId
                && current.args instanceof Map && current.ref
                && !_writeExecutionLiveLocked(requestId)) {
            marker = [:] + (current as Map)
            marker.phase = "running"
            marker.expiresAt = now() + _packageDeployRecoveryMs()
            _writeStateSetLocked("packageDeployInFlight", marker)
            LIVE_WRITE_EXECUTIONS.add(requestId)
        }
    }
    if (marker == null) return
    def result = null
    try {
        Map workerContext = [requestId: requestId, packageRef: marker.ref.toString()]
        result = _updatePackageBody(marker.args as Map, marker.ref.toString(), false, workerContext)
        def last = atomicState.lastSelfDeploy
        if (!(last instanceof Map) || last.requestId?.toString() != requestId) {
            atomicState.lastSelfDeploy = [
                success: result?.success == true,
                error: result?.success == true ? null : (result?.error ?: result?.message ?: "Package deploy failed"),
                sourceMode: "package",
                ref: marker.ref,
                requestId: requestId,
                packageResult: result,
                at: now()
            ]
        }
    } catch (Exception e) {
        mcpLog("error", "developer-mode", "Background package deploy for ref ${marker.ref} failed: ${e.message}")



        def last = atomicState.lastSelfDeploy
        if (!(last instanceof Map) || last.requestId?.toString() != requestId) {
            atomicState.lastSelfDeploy = [success: false, error: e.message ?: e.toString(),
                                          sourceMode: "package", ref: marker.ref,
                                          requestId: requestId, at: now()]
        }
    } finally {
        synchronized (WRITE_RESERVATION_LOCK) {
            try {
                def current = _writeStateValueLocked("packageDeployInFlight")
                if (current instanceof Map && current.requestId?.toString() == requestId) {
                    _writeStateSetLocked("packageDeployInFlight", null)
                    atomicState.remove("packageDeployInFlight")
                }
            } catch (Exception ignored) {
            } finally {
                LIVE_WRITE_EXECUTIONS.remove(requestId)
            }
        }
    }
}


def _updatePackageBody(Map args, String ref, boolean dryRun, Map packageWorkerContext = null) {

    def base = (args?.baseUrl instanceof String && args.baseUrl.trim())
        ? args.baseUrl.trim().replaceAll('/+$', '')
        : getPackageSourceBase()


    def appUrl = "${base}/${ref}/hubitat-mcp-server.groovy".toString()



    def appSource
    try {
        appSource = _fetchSourceFromUrl(appUrl)
    } catch (Exception e) {
        return [
            success: false, aborted: true, abortReason: "app_source_fetch_failed", ref: ref, appUrl: appUrl,
            error: "Failed to fetch app source at ref '${ref}' (${appUrl}): ${e.message ?: e.toString()}. Nothing was changed."
        ]
    }
    def includeTokens = _parseIncludeDirectives(appSource)




    def manifestUrl = "${base}/${ref}/packageManifest.json".toString()
    def manifestText
    try {
        manifestText = _fetchSourceFromUrl(manifestUrl)
    } catch (Exception e) {
        return [
            success: false, aborted: true, abortReason: "manifest_fetch_failed", ref: ref, manifestUrl: manifestUrl,
            error: "Failed to fetch packageManifest.json at ref '${ref}' (${manifestUrl}): ${e.message ?: e.toString()}. Nothing was changed."
        ]
    }
    def manifest
    try {
        manifest = new groovy.json.JsonSlurper().parseText(manifestText)
    } catch (Exception e) {
        manifest = null
    }
    if (!(manifest instanceof Map)) {
        return [
            success: false, aborted: true, abortReason: "manifest_unparseable", ref: ref, manifestUrl: manifestUrl,
            error: "packageManifest.json at ref '${ref}' was not a JSON object. Nothing was changed."
        ]
    }











    def manifestBundles = (manifest.bundles instanceof List) ? manifest.bundles : []
    def plannedBundles = []
    for (b in manifestBundles) {
        def loc = (b?.location instanceof String) ? b.location.trim() : null
        def entry
        if (loc && loc.contains("/bundle-artifacts/")) {
            entry = [name: (b?.name ?: b?.id), url: loc, source: "manifest-current"]
        } else {
            def url = _reanchorToRef(loc, base, ref)
            if (!url) {
                return [
                    success: false, aborted: true, abortReason: "bundle_location_unusable", ref: ref,
                    error: "Bundle '${b?.name ?: b?.id ?: '?'}' in packageManifest.json has an unusable location '${b?.location}' (expected a scheme://host/owner/repo/ref/<path> raw URL or a bundle-artifacts URL). Nothing was changed."
                ]
            }
            entry = [name: (b?.name ?: b?.id), url: url, source: "committed-at-ref"]
        }
        def artifactUrl = _bundleArtifactUrlForRef(loc, base, ref)
        if (artifactUrl && _bundleArtifactExists(artifactUrl)) {
            entry.url = artifactUrl
            entry.source = "bundle-artifacts"
        }







        if (entry.source == "manifest-current" && ref != null && (ref.toString().trim() ==~ /(?i)^[0-9a-f]{7,40}$/)) {
            return [
                success: false, aborted: true, abortReason: "no_bundle_artifact_for_ref", ref: ref,
                bundle: (b?.name ?: b?.id), artifactUrlProbed: artifactUrl,
                error: "No per-ref bundle artifact exists for ref '${ref}' (probed ${artifactUrl ?: 'n/a'}); the manifest's bundle points at branches/main, so installing it would deliver MAIN's libraries, not this ref's. Pass the FULL 40-char commit SHA of a PUSHED commit (not an abbreviation), or push the branch so its bundle artifact is built. Nothing was changed."
            ]
        }
        plannedBundles << entry
    }




    if (!includeTokens.isEmpty() && plannedBundles.isEmpty()) {
        return [
            success: false, aborted: true, abortReason: "bundle_required_but_undeclared", ref: ref, includes: includeTokens,
            error: "App source #includes ${includeTokens.size()} library(ies) (${includeTokens.join(', ')}) but packageManifest.json at ref '${ref}' declares no bundle to deliver them. A bundle-less deploy would leave the #includes unresolved and the app would not compile. Nothing was changed."
        ]
    }





    def manifestApps = (manifest.apps instanceof List) ? manifest.apps : []
    def appTypes
    try {
        def typesText = hubInternalGet("/hub2/userAppTypes")
        appTypes = typesText ? new groovy.json.JsonSlurper().parseText(typesText) : null
    } catch (Exception e) {
        appTypes = null
    }
    if (!(appTypes instanceof List)) {
        return [
            success: false, aborted: true, abortReason: "app_class_unresolved", ref: ref,
            error: "Could not list Apps Code classes via /hub2/userAppTypes to resolve the manifest's apps. Nothing was changed; the app remains updatable via hub_update_app."
        ]
    }
    def plannedApps = []
    for (a in manifestApps) {
        def match = appTypes.find { it?.namespace == a?.namespace && it?.name == a?.name }
        def classId = match?.id?.toString()
        def url = _reanchorToRef(a?.location, base, ref)
        if (!classId || !url) {
            return [
                success: false, aborted: true, abortReason: "app_class_unresolved", ref: ref,
                error: "Could not resolve app '${a?.namespace}:${a?.name}' (class id: ${classId ?: 'unresolved'}, url: ${url ?: 'unusable location'}). Nothing was changed; the app remains updatable via hub_update_app."
            ]
        }
        plannedApps << [
            name: a?.name, namespace: a?.namespace, classId: classId, url: url,
            isSelf: (a?.namespace == "mcp" && a?.name == "MCP Rule Server")
        ]
    }

    def orderedApps = plannedApps.findAll { !it.isSelf } + plannedApps.findAll { it.isSelf }

    if (dryRun) {
        return [
            success: true, dryRun: true, ref: ref, appUrl: appUrl, includes: includeTokens,
            plannedBundles: plannedBundles, plannedApps: orderedApps,
            message: "Dry run: would install ${plannedBundles.size()} bundle(s) then deploy ${orderedApps.size()} app(s) (self app last) to ref ${ref}. No changes made."
        ]
    }









    def bundleResults = []
    for (b in plannedBundles) {
        def r
        try {
            r = toolInstallBundle([importUrl: b.url, confirm: true])
        } catch (Exception e) {
            mcpLog("warn", "developer-mode", "hub_update_package: bundle ${b.url} install threw: ${e.toString()}")
            return [
                success: false, aborted: true, abortReason: "bundle_install_threw", ref: ref, bundles: bundleResults,
                error: "Bundle ${b.name ?: b.url} failed to install: ${e.message ?: e.toString()}. Apps NOT touched -- they remain as-is and updatable via hub_update_app."
            ]
        }
        def ok = (r?.success == true)
        bundleResults << [name: b.name, url: b.url, source: b.source, success: ok, error: (ok ? null : (r?.error ?: r?.message))]
        if (!ok) {
            return [
                success: false, aborted: true, abortReason: "bundle_install_failed", ref: ref, bundles: bundleResults,
                error: "Bundle ${b.name ?: b.url} install reported failure: ${r?.error ?: r?.message ?: 'unknown'}. Apps NOT touched -- they remain as-is and updatable via hub_update_app."
            ]
        }
    }





    def appResults = []
    for (a in orderedApps) {
        def r
        try {
            def updateArgs = [appId: a.classId, importUrl: a.url, confirm: true]
            r = _toolUpdateAppCode(updateArgs, a.isSelf ? packageWorkerContext : null)
        } catch (Exception e) {
            if (a.isSelf) {



                appResults << [name: a.name, namespace: a.namespace, classId: a.classId, isSelf: true, success: false, error: (e.message ?: e.toString())]
                return [
                    success: false, partial: true, abortReason: "app_update_threw", ref: ref,
                    bundles: bundleResults, apps: appResults,
                    error: "Bundle(s) and other apps installed, but the self app update call did not return cleanly (likely the self-update recompile): ${e.message ?: e.toString()}. Verify with hub_get_source; re-run hub_update_app(importUrl) if needed."
                ]
            }
            mcpLog("warn", "developer-mode", "hub_update_package: app ${a.namespace}:${a.name} update threw: ${e.toString()}")
            return [
                success: false, aborted: true, abortReason: "app_update_threw", ref: ref,
                bundles: bundleResults, apps: appResults,
                error: "App ${a.namespace}:${a.name} update threw before the self app was touched: ${e.message ?: e.toString()}. The self (server) app was NOT touched -- it remains as-is and updatable via hub_update_app."
            ]
        }
        def ok = (r?.success == true)
        appResults << [name: a.name, namespace: a.namespace, classId: a.classId, isSelf: a.isSelf, success: ok, app: r]
        if (!ok) {
            if (a.isSelf) {



                mcpLog("warn", "developer-mode", "hub_update_package: ref=${ref} self app update reported failure")
                return [
                    success: false, partial: true, ref: ref, includes: includeTokens, bundles: bundleResults, apps: appResults, app: r,
                    message: "Bundle(s) + other apps installed; the self (server) app update reported failure -- see apps[].app.error. hub_update_app remains available to retry."
                ]
            }
            return [
                success: false, aborted: true, abortReason: "app_update_failed", ref: ref,
                bundles: bundleResults, apps: appResults,
                error: "App ${a.namespace}:${a.name} update reported failure: ${r?.error ?: r?.message ?: 'unknown'}. The self (server) app was NOT touched -- it remains as-is and updatable via hub_update_app."
            ]
        }
    }

    mcpLog("info", "developer-mode", "hub_update_package: ref=${ref} bundles=${bundleResults.size()} apps=${appResults.size()} repaired")
    def result = [
        success: true, ref: ref, includes: includeTokens, bundles: bundleResults, apps: appResults,
        message: "Package repaired to ref ${ref}: ${bundleResults.size()} bundle(s) + ${appResults.size()} app(s) deployed (self app last)."
    ]





    if (bundleResults.any { it.source == "manifest-current" }) {
        if (ref == "main") {
            result.bundleFreshnessWarning = "The per-ref artifact probe failed, so the bundle leg installed the manifest's branches/main zip directly -- for ref=main that is the correct, current bundle (the same bytes HPM users install). Noted only because the probe failing may indicate a transient raw.githubusercontent issue."
            mcpLog("warn", "developer-mode", "hub_update_package: ref=main artifact probe failed; installed the manifest's branches/main zip directly (correct bytes for main)")
        } else {
            result.bundleFreshnessWarning = "Ref '${ref}': no bundle-artifacts zip was found for this ref, so the bundle leg installed CURRENT MAIN's bundle (the manifest's branches/main zip). That is only correct if this ref's libraries match current main. If this ref changed library code, push it to this repo (publish-bundle-artifact stores a fresh zip per push, keyed by branch and full SHA) and re-run."
            mcpLog("warn", "developer-mode", "hub_update_package: non-main ref '${ref}' fell back to current main's bundle -- wrong if the ref changed library code")
        }
    } else if (bundleResults.any { it.source == "committed-at-ref" }) {
        result.bundleFreshnessWarning = "Ref '${ref}' (legacy manifest): no bundle-artifacts zip was found for this ref, so the bundle leg installed the zip COMMITTED at the ref. That is only stale if this ref CHANGED library code without rebuilding the zip."
        mcpLog("warn", "developer-mode", "hub_update_package: legacy ref '${ref}' fell back to the committed bundle zip -- stale if the ref changed library code")
    }
    return result
}

def _getAllToolDefinitions_partSelfAdmin() {
    return [
        [
            name: "hub_update_mcp_settings",
            description: "Update one or more of the MCP rule app's own settings (toggles, log levels, tuning, the device-access scope) in place — self-administer the app without the Hubitat UI. Gated on enableDeveloperMode + the Write master + confirm=true + a recent backup; every successful write is logged at WARN for audit.[[FLAT_TRIM]] Changing an enable* toggle or useGateways reshapes tools/list, and changing selectedDevices changes which devices are visible, so MCP clients may need to reconnect to refresh cached schemas / device visibility.[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    settings: [type: "object", description: "Map of setting key → new value (e.g. {\"mcpLogLevel\":\"warn\",\"enableCustomRuleEngine\":true}). Unlisted keys are rejected. bypassDeviceAllowlist (bool, default OFF): DANGEROUS escape hatch — when ON native device reads, writes, commands, inventory, health, dependents, swaps and replacements reach ANY hub device by id, IGNORING selectedDevices. Allowlisted keys: mcpLogLevel, debugLogging, maxCapturedStates, loopGuardMax, loopGuardWindowSec, enableRead, enableCustomRuleEngine, useGateways, enableMandatoryBPS, bypassDeviceAllowlist, maxConcurrentWrites, backupEveryRuleWrite, selectedDevices — any other key is rejected. mcpLogLevel: debug|info|warn|error. maxConcurrentWrites: integer 0-100 (default 2; 0 disables the server-side all-write concurrency cap). backupEveryRuleWrite (bool, default OFF): ON takes a fresh File Manager backup before every native-app edit instead of reusing a same-app baseline for one hour. bypassDeviceAllowlist is independent of Developer Mode; see hub_get_tool_guide(section='hub_admin_write_system'). selectedDevices = the device-access scope[[FLAT_TRIM]]: {mode:replace|add|remove, ids:[device id strings]}; a bare array is shorthand for a destructive replace[[/FLAT_TRIM]] — see hub_get_tool_guide(section='hub_admin_write_system') for per-mode semantics."],
                    confirm: [type: "boolean", description: "REQUIRED: must be true to confirm the operation"]
                ],
                required: ["settings", "confirm"]
            ]
        ],
        [
            name: "hub_update_package",
            description: """Developer Mode self-deploy: full HPM-repair of the MCP package at a git ref in one call -- OVERRIDES whatever is installed, anchored to packageManifest.json AT `ref` so an UNMERGED PR installs.[[FLAT_TRIM]] (Plain HPM Repair only reads the PUBLISHED manifest, so it can't reach an unmerged PR's artifacts.)[[/FLAT_TRIM]]

Gated on enableDeveloperMode[[FLAT_TRIM]] (the tool is hidden from tools/list when Developer Mode is off)[[/FLAT_TRIM]] + the Write master + confirm=true + a recent backup. Use dryRun=true to fetch + parse + plan with ZERO writes (no confirm/backup needed)[[FLAT_TRIM]] and see exactly which bundles and apps would deploy[[/FLAT_TRIM]].

A real deploy is accepted quickly with `status: "in_progress"`, then runs in Hubitat's background scheduler so neither the cloud relay nor the MCP client's request timeout has to stay open for the minutes-long repair. Do NOT submit it again: a concurrent second deploy is refused while one is in flight.[[FLAT_TRIM]] Poll hub_get_info.lastSelfDeploy until its `requestId` matches the acceptance response; that bound record's `success`/`error` fields carry the outcome. No client extension or custom token is required.[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    ref: [type: "string", description: "Branch, tag, or commit SHA to deploy (e.g. 'main' or a PR head SHA)."],
                    dryRun: [type: "boolean", description: "OPTIONAL. When true, report the deploy plan with NO writes (skips the confirm/backup gate). Default false."],
                    baseUrl: [type: "string", description: "OPTIONAL raw-source base override (no trailing slash); defaults to the canonical repo.[[FLAT_TRIM]] Per-call URLs are built as <baseUrl>/<ref>/<path>. Use for forks / CI branches on a different remote.[[/FLAT_TRIM]]"],
                    confirm: [type: "boolean", description: "REQUIRED for a real deploy (omit for dryRun). Must be true; confirms a recent backup exists and the user approved the self-deploy."]
                ],
                required: ["ref"]
            ]
        ],
    ]
}

def _idempotentWriteToolNames_partSelfAdmin() {


    return [



        "hub_update_mcp_settings",


        "hub_update_package"
    ]
}

def _openWorldToolNames_partSelfAdmin() {


    return [
        "hub_update_package"
    ]
}

def _developerModeOnlyToolNames_partSelfAdmin() {









    return [
        "hub_update_package"
    ]
}

def _toolDisplayMeta_partSelfAdmin() {


    return [

        hub_update_mcp_settings: [title: "Update MCP Settings", summary: "Update the MCP app's own settings + device-access scope (Developer Mode)."],
        hub_update_package: [title: "Deploy MCP Package", summary: "Full repair-install of the MCP package at a git ref (Developer Mode)."]
    ]
}
