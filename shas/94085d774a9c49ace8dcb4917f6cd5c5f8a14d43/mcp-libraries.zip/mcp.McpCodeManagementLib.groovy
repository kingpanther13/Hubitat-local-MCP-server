library(name: "McpCodeManagementLib", namespace: "mcp", author: "kingpanther13", description: "App/driver/library code management tool implementations (list/source/install/update/delete, app config + pages, device dependents) for the MCP Rule Server; #include'd by the main app. Gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")
// Developer comments are blanked in this hub copy so the hub's code pages stay fast -- Groovy discards them anyway. Below this line, a line number here is the repository file's plus one. Full source: https://github.com/kingpanther13/Hubitat-local-MCP-server/blob/main/libraries/mcp-code-management-lib.groovy

def toolListHubApps(args) {

    def cursor = args?.cursor
    def result = [:]
    try {
        def responseText = hubInternalGet("/hub2/userAppTypes")
        if (responseText) {
            try {
                def parsed = new groovy.json.JsonSlurper().parseText(responseText)
                result.apps = parsed
                result.count = parsed instanceof List ? parsed.size() : 0
                result.source = "hub_api"
            } catch (Exception parseErr) {



                result.apps = []
                result.rawResponse = responseText?.take(2000)
                result.source = "hub_api_raw"
                result.note = "Response was not JSON. This endpoint may return HTML on your firmware version."
            }
        } else {
            result.apps = []
            result.note = "Empty response from hub API"
        }
    } catch (Exception e) {
        mcpLog("warn", "hub-admin", "hub_list_apps API call failed: ${e.message}")

        def childApps = getChildApps()
        result.apps = childApps?.collect { ca ->
            [id: ca.id.toString(), name: ca.getSetting("ruleName") ?: ca.label ?: "Unknown", type: "MCP Rule"]
        } ?: []
        result.count = result.apps.size()
        result.source = "mcp_only"
        result.note = "Hub internal API unavailable (${e.message}). Showing only MCP Rule Server apps. This may require Hub Security credentials or a firmware update."
    }

    if (cursor != null && result.apps instanceof List) {
        def paged = _paginateList(result.apps, cursor, 50, "hub_list_apps")
        result.total = result.apps.size()
        result.apps = paged.page
        result.count = paged.page.size()
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }

    mcpLog("info", "hub-admin", "Listed hub apps (source: ${result.source})")
    return result
}

def toolListHubDrivers(args) {

    def cursor = args?.cursor
    def include = (args?.include ?: "user").toString().toLowerCase()
    def result = [:]
    if (include == "all") {





        try {
            def responseText = hubInternalGet("/device/drivers")
            def parsed = responseText ? new groovy.json.JsonSlurper().parseText(responseText) : null
            if (parsed?.drivers instanceof List) {
                def projected = []
                parsed.drivers.each { d ->
                    if (d?.type == "dep" || d?.category == "Hidden") return
                    def nm = d?.name?.toString() ?: ""
                    def bucket = (d?.type == "usr") ? "user" : (nm.startsWith("Virtual") ? "virtual" : "system")
                    projected << [id: d?.id?.toString(), name: nm, namespace: d?.namespace, bucket: bucket]
                }
                result.drivers = projected
                result.count = projected.size()
                result.source = "hub_api"
            } else {
                result.drivers = []
                result.count = 0
                result.rawResponse = responseText?.take(2000)
                result.source = "hub_api_raw"
                result.note = "Response was not the expected {drivers:[...]} shape; /device/drivers may differ on your firmware version."
            }
        } catch (Exception e) {
            mcpLog("warn", "hub-admin", "hub_list_drivers include=all API call failed: ${e.message}")
            result.drivers = []
            result.count = 0
            result.source = "unavailable"
            result.note = "Hub internal API unavailable (${e.message}). This may require Hub Security credentials or a firmware update."
        }
        result.include = "all"
    } else {
        try {
            def responseText = hubInternalGet("/hub2/userDeviceTypes")
            if (responseText) {
                try {
                    def parsed = new groovy.json.JsonSlurper().parseText(responseText)
                    result.drivers = parsed
                    result.count = parsed instanceof List ? parsed.size() : 0
                    result.source = "hub_api"
                } catch (Exception parseErr) {


                    result.drivers = []
                    result.rawResponse = responseText?.take(2000)
                    result.source = "hub_api_raw"
                    result.note = "Response was not JSON. This endpoint may return HTML on your firmware version."
                }
            } else {
                result.drivers = []
                result.note = "Empty response from hub API"
            }
        } catch (Exception e) {
            mcpLog("warn", "hub-admin", "hub_list_drivers API call failed: ${e.message}")
            result.drivers = []
            result.count = 0
            result.source = "unavailable"
            result.note = "Hub internal API unavailable (${e.message}). This may require Hub Security credentials or a firmware update."
        }
        result.include = "user"
    }

    if (cursor != null && result.drivers instanceof List) {
        def paged = _paginateList(result.drivers, cursor, 50, "hub_list_drivers")
        result.total = result.drivers.size()
        result.drivers = paged.page
        result.count = paged.page.size()
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }

    mcpLog("info", "hub-admin", "Listed hub drivers (source: ${result.source})")
    return result
}

def toolListLibraries(args) {

    def cursor = args?.cursor
    def result = [:]
    try {
        def responseText = hubInternalGet("/hub2/userLibraries")
        if (responseText) {
            try {
                def parsed = new groovy.json.JsonSlurper().parseText(responseText)
                if (parsed instanceof List) {


                    result.libraries = parsed.collect { lib ->
                        [id: lib.id?.toString(), name: lib.name, namespace: lib.namespace, version: lib.version]
                    }
                    result.count = result.libraries.size()
                    result.source = "hub_api"


                    def noId = result.libraries.count { it.id == null }
                    if (noId > 0) {
                        result.note = "${noId} librar${noId == 1 ? 'y' : 'ies'} returned by the hub had no id and cannot be read via hub_get_source (possible firmware shape change)."
                    }
                } else {
                    result.libraries = []
                    result.count = 0
                    result.rawResponse = responseText?.take(2000)
                    result.source = "hub_api_raw"
                    result.note = "Response was not a JSON array. This endpoint may return a different shape on your firmware version."
                }
            } catch (Exception parseErr) {
                result.libraries = []
                result.count = 0
                result.rawResponse = responseText?.take(2000)
                result.source = "hub_api_raw"
                result.note = "Response was not JSON. This endpoint may return HTML on your firmware version."
            }
        } else {
            result.libraries = []
            result.count = 0
            result.source = "unavailable"
            result.note = "Empty response from hub API"
        }
    } catch (Exception e) {
        mcpLog("warn", "hub-admin", "hub_list_libraries API call failed: ${e.message}")
        result.libraries = []
        result.count = 0
        result.source = "unavailable"
        result.note = "Hub internal API unavailable (${e.message}). This may require Hub Security credentials or a firmware update."
    }

    if (cursor != null && result.libraries instanceof List) {
        def paged = _paginateList(result.libraries, cursor, 50, "hub_list_libraries")
        result.total = result.libraries.size()
        result.libraries = paged.page
        result.count = paged.page.size()
        if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    }

    mcpLog("info", "hub-admin", "Listed hub libraries (source: ${result.source})")
    return result
}

def toolGetItemSource(String type, String idParam, args) {
    def itemId = args[idParam]
    if (!itemId) throw new IllegalArgumentException("${idParam} is required")

    def maxChunkSize = 64000
    def requestedOffset = args.offset ? args.offset as int : 0
    def requestedLength = args.length ? Math.min(args.length as int, maxChunkSize) : maxChunkSize

    def ajaxPath = (type == "app") ? "/app/ajax/code" : "/driver/ajax/code"

    try {
        def responseText = hubInternalGet(ajaxPath, [id: itemId])
        if (!responseText) return [success: false, error: "Empty response from hub"]

        def parsed = new groovy.json.JsonSlurper().parseText(responseText)
        if (parsed.status == "error") {
            return [success: false, error: parsed.errorMessage ?: "Failed to get ${type} source"]
        }

        def fullSource = parsed.source ?: ""
        def totalLength = fullSource.length()


        def savedToFile = null
        if (totalLength > maxChunkSize) {
            def sourceFileName = "mcp-source-${type}-${itemId}.groovy"
            try {
                uploadHubFile(sourceFileName, fullSource.getBytes("UTF-8"))
                savedToFile = sourceFileName
                mcpLog("info", "hub-admin", "Saved full ${type} ID ${itemId} source to File Manager: ${sourceFileName} (${totalLength} chars)")
            } catch (Exception saveErr) {
                mcpLog("warn", "hub-admin", "Could not save ${type} source to File Manager: ${saveErr.message}")
            }
        }


        def endIndex = Math.min(requestedOffset + requestedLength, totalLength)
        def chunk = (requestedOffset < totalLength) ? fullSource.substring(requestedOffset, endIndex) : ""
        def hasMore = endIndex < totalLength

        mcpLog("info", "hub-admin", "Retrieved ${type} ID ${itemId} source: ${totalLength} chars total, returning offset ${requestedOffset}..${endIndex}${hasMore ? ' (more available)' : ''}")

        def result = [
            success: true,
            (idParam): itemId,
            source: chunk,
            version: parsed.version,
            status: parsed.status,
            totalLength: totalLength,
            offset: requestedOffset,
            chunkLength: chunk.length(),
            hasMore: hasMore
        ]
        if (hasMore) {
            result.nextOffset = endIndex
            result.remainingChars = totalLength - endIndex
            result.hint = "Call again with offset: ${endIndex} to get the next chunk."
        }
        if (savedToFile) {
            result.sourceFile = savedToFile
            result.sourceFileHint = "Full source saved to File Manager. Use update_${type}_code with sourceFile: '${savedToFile}' to update without cloud size limits."
        }
        return result
    } catch (Exception e) {
        mcpLogError("hub-admin", "Failed to get ${type} source", e)
        return [success: false, error: "Failed to get ${type} source: ${e.message}"]
    }
}

private String stripAppConfigHtml(value) {
    if (value == null) return null
    def s = value.toString()





    if (s.contains("<")) {
        s = s.replaceAll(/<[^>]+>/, "").replaceAll(/[^{}]*\{[^{}]*[;:][^{}]*\}/, "")
    }



    if (s.contains("&")) {
        s = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", '"')
             .replace("&#39;", "'").replace("&apos;", "'").replace("&nbsp;", " ")
             .replace("&amp;", "&")
    }
    return s.trim()
}

private stripOptionsHtml(options) {
    if (options instanceof List) {
        def out = []
        for (entry in options) {
            if (entry instanceof Map) {
                def cleaned = [:]
                entry.each { k, v -> cleaned.put(k, (v instanceof String) ? stripAppConfigHtml(v) : v) }
                out << cleaned
            } else {
                out << entry
            }
        }
        return out
    }
    if (options instanceof Map) {
        def cleaned = [:]
        options.each { k, v -> cleaned.put(k, (v instanceof String) ? stripAppConfigHtml(v) : v) }
        return cleaned
    }
    return options
}

private List _extractEmbeddedActions(String html) {
    if (!html) return []
    def buttonNames = []
    def im = (html =~ /<input\s+type=['"]hidden['"]\s+name=['"]([^'"]+?)\.type['"]\s+value=['"]button['"][^>]*>/)
    while (im.find()) {
        buttonNames << im.group(1)
    }
    def divs = []
    def dm = (html =~ /(?s)<div([^>]*)class=['"]submitOnChange['"]([^>]*)>(.*?)<\/div>/)
    while (dm.find()) {
        def attrs = (dm.group(1) ?: "") + (dm.group(2) ?: "")
        def innerRaw = dm.group(3) ?: ""
        def title = null
        def state = null
        def tm = attrs =~ /title=['"]([^'"]+?)['"]/
        if (tm.find()) title = tm.group(1)
        def sm = attrs =~ /data-stateAttribute=['"]([^'"]+?)['"]/
        if (sm.find()) state = sm.group(1)
        def inner = innerRaw.replaceAll(/<[^>]+>/, "").replaceAll(/&nbsp;|&#65291|&#x[0-9a-fA-F]+;|&#\d+;/, "").trim()
        divs << [title: title, stateAttribute: state, description: inner ?: null]
    }
    if (!buttonNames || !divs) return []
    def actions = []
    int n = Math.min(buttonNames.size(), divs.size())
    for (int i = 0; i < n; i++) {
        def a = [name: buttonNames[i]]
        def d = divs[i]
        if (d.title) a.title = d.title
        if (d.stateAttribute) a.stateAttribute = d.stateAttribute
        if (d.description) a.description = d.description
        actions << a
    }
    return actions
}

def toolGetAppConfig(args) {

    if (args?.appId == null || args.appId.toString().trim() == "") {
        throw new IllegalArgumentException("appId is required")
    }
    def appIdStr = args.appId.toString().trim()
    if (!appIdStr.isInteger()) {
        throw new IllegalArgumentException("appId must be numeric: ${appIdStr}")
    }

    def pageName = args?.pageName?.toString()?.trim()
    if (pageName && !pageName.matches(/[A-Za-z0-9_]+/)) {
        throw new IllegalArgumentException("pageName must be alphanumeric/underscore only: ${pageName}")
    }

    boolean includeSettings = args?.includeSettings == true





    if (args?.summary == true) {
        def summaryPath = "/installedapp/json/${appIdStr}"
        mcpLog("info", "hub-admin", "hub_get_app_config appId=${appIdStr} summary mode")
        def summaryText
        try {
            summaryText = hubInternalGet(summaryPath, null, 30)
        } catch (Exception e) {




            def resp = null
            try { resp = e.response } catch (Exception ig) { resp = null }
            Integer st = null
            try { st = resp?.status as Integer } catch (Exception ig) { st = null }
            if (st == 404 || st == 410) {
                mcpLog("warn", "hub-admin", "hub_get_app_config app ${appIdStr} not found (HTTP ${st} from ${summaryPath})")
                return [success: false, error: "App ${appIdStr} not found (HTTP ${st} from ${summaryPath}). May be deleted, mid-delete, or a not-yet-committed install shell whose config page cannot render. Verify with hub_get_app_config(summary=true) or hub_list_apps.", appId: appIdStr as Integer, fingerprint: 'app not found (404)', status: st]
            }
            mcpLogError("hub-admin", "hub_get_app_config summary fetch failed", e)
            return [success: false, error: "Failed to fetch app summary [${e.class.simpleName}]: ${e.message}", appId: appIdStr as Integer]
        }
        if (!summaryText) {
            return [success: false, error: "Empty response from ${summaryPath}. App may not exist or hub internal API is unavailable.", appId: appIdStr as Integer]
        }
        def summaryParsed
        try {
            summaryParsed = new groovy.json.JsonSlurper().parseText(summaryText)
        } catch (Exception e) {
            mcpLogError("hub-admin", "hub_get_app_config summary JSON parse failed", e)
            return [success: false, error: "Failed to parse app summary JSON: ${e.message}. Hubitat firmware may have changed the endpoint contract.", appId: appIdStr as Integer]
        }
        if (!(summaryParsed instanceof Map)) {
            return [success: false, error: "Unexpected response shape: expected a JSON object. Firmware may have changed the endpoint contract.", appId: appIdStr as Integer, fingerprint: "top-level not a Map"]
        }
        def summaryResult = [:]
        summaryResult.putAll(summaryParsed)
        summaryResult.success = true
        summaryResult.endpoint = summaryPath
        return summaryResult
    }

    def path = "/installedapp/configure/json/${appIdStr}"
    if (pageName) path += "/${pageName}"

    mcpLog("info", "hub-admin", "hub_get_app_config appId=${appIdStr} page=${pageName ?: 'main'} includeSettings=${includeSettings}")

    def responseText
    try {
        responseText = hubInternalGet(path, null, 30)
    } catch (Exception e) {




        def resp = null
        try { resp = e.response } catch (Exception ig) { resp = null }
        Integer st = null
        try { st = resp?.status as Integer } catch (Exception ig) { st = null }
        if (st == 404 || st == 410) {
            mcpLog("warn", "hub-admin", "hub_get_app_config app ${appIdStr} not found (HTTP ${st} from ${path})")
            return [success: false, error: "App ${appIdStr} not found (HTTP ${st} from ${path}). May be deleted, mid-delete, or a not-yet-committed install shell whose config page cannot render. Verify with hub_get_app_config(summary=true) or hub_list_apps.", appId: appIdStr as Integer, fingerprint: 'app not found (404)', status: st]
        }
        mcpLogError("hub-admin", "hub_get_app_config fetch failed", e)
        return [success: false, error: "Failed to fetch app config [${e.class.simpleName}]: ${e.message}", appId: appIdStr as Integer]
    }

    if (!responseText) {
        return [success: false, error: "Empty response from ${path}. App may not exist or hub internal API is unavailable.", appId: appIdStr as Integer]
    }

    def parsed
    try {
        parsed = new groovy.json.JsonSlurper().parseText(responseText)
    } catch (Exception e) {
        mcpLogError("hub-admin", "hub_get_app_config JSON parse failed", e)
        return [success: false, error: "Failed to parse app config JSON: ${e.message}. Hubitat firmware may have changed the endpoint contract.", appId: appIdStr as Integer]
    }






    if (!(parsed instanceof Map)) {
        return [success: false, error: "Unexpected response shape: expected a JSON object. Firmware may have changed the endpoint contract.", appId: appIdStr as Integer, fingerprint: "top-level not a Map"]
    }
    if (!(parsed.app instanceof Map)) {
        return [success: false, error: "Unexpected response shape: missing 'app' object. Firmware may have changed the endpoint contract.", appId: appIdStr as Integer, fingerprint: "missing app"]
    }
    if (!(parsed.configPage instanceof Map)) {
        return [success: false, error: "Unexpected response shape: missing 'configPage' object. Firmware may have changed the endpoint contract.", appId: appIdStr as Integer, fingerprint: "missing configPage"]
    }
    if (!(parsed.configPage.sections instanceof List)) {
        return [success: false, error: "Unexpected response shape: configPage.sections is not a list. This page may be a dynamic redirect or action-only page (common in HPM multi-step flows). Try a different pageName -- call hub_list_app_pages for this app, or `hub_get_tool_guide(section='builtin_app_tools_apps')` for common multi-page app names.", appId: appIdStr as Integer, fingerprint: "sections not a list"]
    }




    def appTypeRaw = parsed.app.appType
    def appTypeSummary = null
    if (appTypeRaw instanceof Map) {
        appTypeSummary = [
            name: appTypeRaw.name,
            namespace: appTypeRaw.namespace,
            author: appTypeRaw.author,
            category: appTypeRaw.category,
            classLocation: appTypeRaw.classLocation,
            deprecated: appTypeRaw.deprecated == true,
            system: appTypeRaw.system == true,
            documentationLink: appTypeRaw.documentationLink
        ]
    }

    def appObj = [
        id: parsed.app.id,
        label: stripAppConfigHtml(parsed.app.trueLabel ?: parsed.app.label),
        name: parsed.app.name,
        appType: appTypeSummary,
        disabled: parsed.app.disabled == true,
        parentAppId: parsed.app.parentAppId,
        installed: parsed.app.installed == true
    ]







    def redactedPw = "***redacted (password)***"
    def passwordInputNames = [] as Set
    def sections = []
    for (s in parsed.configPage.sections) {
        if (!(s instanceof Map)) continue
        def section = [
            title: stripAppConfigHtml(s.title),
            inputs: []
        ]
        for (i in (s.input ?: [])) {
            if (!(i instanceof Map)) continue
            def input = [
                name: i.name,
                type: i.type,
                title: stripAppConfigHtml(i.title)
            ]
            if (i.multiple == true) input.multiple = true
            if (i.required == true) input.required = true
            def desc = stripAppConfigHtml(i.description)
            if (desc && desc != "Click to set") input.description = desc
            if (i.options) input.options = stripOptionsHtml(i.options)



















            if (i.defaultValue != null && (i.defaultValue != true || i.type == "bool")) input.value = i.defaultValue
            else if (i.value != null && (i.value != true || i.type == "bool")) input.value = i.value
            if (i.type == "password") {
                if (i.name) passwordInputNames << i.name.toString()
                if (input.containsKey("value")) input.value = redactedPw
            }
            section.inputs << input
        }














        def paragraphs = []
        def embeddedActions = []
        for (b in (s.body ?: [])) {
            if (!(b instanceof Map)) continue
            def rawHtml = (b.description ?: b.title)?.toString()
            def text = stripAppConfigHtml(rawHtml)
            if (text && text != "Click to set") paragraphs << text
            if (rawHtml) {
                def acts = _extractEmbeddedActions(rawHtml)
                if (acts) embeddedActions.addAll(acts)
            }
        }
        if (paragraphs) section.paragraphs = paragraphs
        if (embeddedActions) section.embeddedActions = embeddedActions
        sections << section
    }

    def children = []
    for (c in (parsed.childApps ?: [])) {
        if (!(c instanceof Map)) continue
        children << [id: c.id, label: stripAppConfigHtml(c.label ?: c.name), name: c.name]
    }

    def result = [
        success: true,
        app: appObj,
        page: [
            name: parsed.configPage.name,
            title: stripAppConfigHtml(parsed.configPage.title),
            install: parsed.configPage.install == true,
            refreshInterval: parsed.configPage.refreshInterval,
            sections: sections
        ],
        childApps: children,
        endpoint: path
    ]

    int settingsCount = (parsed.settings instanceof Map) ? parsed.settings.size() : 0
    result.settingsKeyCount = settingsCount
    if (includeSettings) {
        def rawSettings = (parsed.settings instanceof Map) ? parsed.settings : [:]
        result.settings = passwordInputNames ? rawSettings.collectEntries { k, v ->
            [(k): (passwordInputNames.contains(k?.toString()) ? redactedPw : v)]
        } : rawSettings
        if (rawSettings) {
            result.settingsRedactionNote = "Password-type values are redacted using this page's inputs. For a multi-page app, password values defined on OTHER pages are not detectable from this fetch and may appear here unredacted -- redaction is page-scoped (see hub_list_app_pages)."
        }
    } else if (settingsCount > 0) {
        result.settingsNote = "Raw settings omitted -- pass includeSettings=true to include. Large apps (Room Lighting, RM 5.1) may have 500-1000 keys with app-specific encoding (e.g. \"dm~<deviceId>~<scene>\" for Room Lighting dim presets) that is non-trivial to decode without app-specific knowledge."
    }

    return result
}

def toolListAppPages(args) {

    if (args?.appId == null || args.appId.toString().trim() == "") {
        throw new IllegalArgumentException("appId is required")
    }
    def appIdStr = args.appId.toString().trim()
    if (!appIdStr.isInteger()) {
        throw new IllegalArgumentException("appId must be numeric: ${appIdStr}")
    }

    mcpLog("info", "hub-admin", "hub_list_app_pages appId=${appIdStr}")

    def path = "/installedapp/configure/json/${appIdStr}"
    def responseText
    try {
        responseText = hubInternalGet(path, null, 30)
    } catch (Exception e) {




        def resp = null
        try { resp = e.response } catch (Exception ig) { resp = null }
        Integer st = null
        try { st = resp?.status as Integer } catch (Exception ig) { st = null }
        if (st == 404 || st == 410) {
            mcpLog("warn", "hub-admin", "hub_list_app_pages app ${appIdStr} not found (HTTP ${st} from ${path})")
            return [success: false, error: "App ${appIdStr} not found (HTTP ${st} from ${path}). May be deleted, mid-delete, or a not-yet-committed install shell whose config page cannot render. Verify with hub_get_app_config(summary=true) or hub_list_apps.", appId: appIdStr as Integer, fingerprint: 'app not found (404)', status: st]
        }
        mcpLogError("hub-admin", "hub_list_app_pages fetch failed", e)
        return [success: false, error: "Failed to fetch app config [${e.class.simpleName}]: ${e.message}", appId: appIdStr as Integer]
    }

    if (!responseText) {
        return [success: false, error: "Empty response from ${path}. App may not exist or hub internal API is unavailable.", appId: appIdStr as Integer]
    }

    def parsed
    try {
        parsed = new groovy.json.JsonSlurper().parseText(responseText)
    } catch (Exception e) {
        mcpLogError("hub-admin", "hub_list_app_pages JSON parse failed", e)
        return [success: false, error: "Failed to parse app config JSON: ${e.message}. Hubitat firmware may have changed the endpoint contract.", appId: appIdStr as Integer]
    }

    if (!(parsed instanceof Map)) {
        return [success: false, error: "Unexpected response shape: expected a JSON object. Firmware may have changed the endpoint contract.", appId: appIdStr as Integer, fingerprint: "top-level not a Map"]
    }
    if (!(parsed.app instanceof Map)) {
        return [success: false, error: "Unexpected response shape: missing 'app' object. Firmware may have changed the endpoint contract.", appId: appIdStr as Integer, fingerprint: "missing app"]
    }
    if (!(parsed.configPage instanceof Map)) {
        return [success: false, error: "Unexpected response shape: missing 'configPage' object. Firmware may have changed the endpoint contract.", appId: appIdStr as Integer, fingerprint: "missing configPage"]
    }

    def appTypeRaw = parsed.app.appType
    def appTypeName = (appTypeRaw instanceof Map) ? (appTypeRaw.name ?: "") : ""
    def appLabel = stripAppConfigHtml(parsed.app.trueLabel ?: parsed.app.label) ?: ""


    def primaryPageName = parsed.configPage.name ?: "mainPage"
    def primaryPageTitle = stripAppConfigHtml(parsed.configPage.title)
    def primaryPage = [name: primaryPageName, title: primaryPageTitle, role: "primary"]

    def appObj = [
        id: parsed.app.id,
        label: appLabel,
        name: parsed.app.name,
        appTypeName: appTypeName
    ]


    def appTypeNameLower = appTypeName.toLowerCase()
    def pages
    def note = null

    if (appTypeNameLower.contains("hubitat package manager")) {
        pages = [
            [name: "prefOptions",    title: "Main Menu",                role: "navigation"],
            [name: "prefPkgUninstall", title: "Uninstall / Full Package List", role: "full_package_list"],
            [name: "prefPkgModify",  title: "Modify Package (optional-components subset)", role: "modifiable_subset"],
            [name: "prefPkgInstall", title: "Install New Package",       role: "install_flow"],
            [name: "prefPkgMatchUp", title: "Match Up Packages",         role: "matching_flow"]
        ]
    } else if (appTypeNameLower.contains("rule-5") || appTypeNameLower.contains("rule machine")) {
        pages = [
            [name: "mainPage", title: appLabel ?: "Rule Settings", role: "primary"]
        ]
        note = "Rule Machine rules are single-page. No sub-pages available."
    } else if (appTypeNameLower.contains("room lights") || appTypeNameLower.contains("room lighting")) {
        pages = [
            [name: "mainPage", title: appLabel ?: "Room Lighting Settings", role: "primary"]
        ]
        note = "Room Lighting instances use a single mainPage. No named sub-pages."
    } else if (appTypeNameLower.contains("mode manager")) {
        pages = [
            [name: "mainPage", title: "Manage Setting of Modes", role: "primary"]
        ]
        note = "Mode Manager uses a single mainPage. No named sub-pages."
    } else {
        pages = [primaryPage]
        note = "App-type-specific page directory not curated; only primary page known. For multi-page apps, consult the app's Groovy source or the Web UI navigation for sub-page names."
    }

    return [
        success: true,
        app: appObj,
        primaryPage: primaryPage,
        pages: pages,
        note: note
    ]
}




def toolGetSource(args) {
    def type = args.type
    if (!(type in ["app", "driver", "library"])) {
        throw new IllegalArgumentException("type is required and must be one of: app, driver, library")
    }
    def id = (args.id != null) ? args.id : (type == "app" ? args.appId : (type == "driver" ? args.driverId : args.libraryId))
    if (type == "library") {
        return toolGetLibrarySource(args + [libraryId: id])
    }
    def idParam = (type == "app") ? "appId" : "driverId"
    return toolGetItemSource(type, idParam, args + [(idParam): id])
}

private Map _createUserAppInstance(Integer codeAppId) {
    def result
    try {
        result = hubInternalGetRaw("/installedapp/create/${codeAppId}")
    } catch (Exception e) {
        mcpLog("error", "hub-admin", "_createUserAppInstance(${codeAppId}): ${e.toString()}")
        return [
            success: false,
            error: "User app instantiation failed: ${e.toString()}",
            codeAppId: codeAppId
        ]
    }
    if (result?.status != 302 || !result.location) {
        def status = result?.status
        def hint
        switch (status) {
            case 401:
            case 403:
                hint = "Hub Security authentication failed (status ${status}). Verify MCP credentials and Hub Security state."
                break
            case 404:
                hint = "codeAppId ${codeAppId} does not exist in Apps Code."
                break
            case 500:
                hint = "Hub returned a server error (status 500). Code ${codeAppId} may be in a compile-error state -- inspect via hub_get_source(type='app')."
                break
            case 200:
                hint = "Hub returned the configure page without redirect (status 200). codeAppId ${codeAppId} may be a driver/library, or an already-instantiated app."
                break
            default:
                hint = "Hub returned unexpected status ${status}. The codeAppId may not exist or may not be a user app."
        }
        mcpLog("warn", "hub-admin", "_createUserAppInstance(${codeAppId}): non-302 (status=${status})")
        return [
            success: false,
            error: hint,
            codeAppId: codeAppId,
            status: status,
            hubResponse: result?.data?.toString()?.take(500)
        ]
    }
    def m = (result.location =~ /\/installedapp\/configure\/(\d+)(?:\/([^\/?#]+))?/)
    if (!m) {
        mcpLog("warn", "hub-admin", "_createUserAppInstance(${codeAppId}): could not parse instance id from Location ${result.location}")
        return [
            success: false,
            error: "Could not parse new instance id from Location header: ${result.location}",
            codeAppId: codeAppId
        ]
    }
    def newId = m[0][1] as Integer
    def firstPage = m[0][2]
    mcpLog("info", "hub-admin", "_createUserAppInstance: created shell instance ${newId} from codeAppId ${codeAppId} (page=${firstPage ?: 'default'}); committing install")



    def commit
    try {
        commit = _commitUserAppInstall(newId, firstPage)
    } catch (Exception ce) {
        mcpLog("warn", "hub-admin", "_createUserAppInstance: install-commit for instance ${newId} threw: ${ce.toString()}")
        return [
            success: false,
            error: "Instance ${newId} was created from codeAppId ${codeAppId} but the install-commit (Done) failed: ${ce.toString()}. The instance is an uninstalled shell -- delete it via hub_delete_native_app(appId:${newId}, confirm:true) and retry.",
            codeAppId: codeAppId,
            instanceAppId: newId,
            committed: false
        ]
    }
    if (!commit?.success) {
        return [
            success: false,
            error: "Instance ${newId} was created but the install did not commit: ${commit?.error}. It is an uninstalled shell -- delete via hub_delete_native_app(appId:${newId}, confirm:true) and retry.",
            codeAppId: codeAppId,
            instanceAppId: newId,
            committed: false
        ]
    }
    mcpLog("info", "hub-admin", "_createUserAppInstance: committed install of instance ${newId} (scheduledJobs=${commit.scheduledJobCount}, subscriptions=${commit.eventSubscriptionCount}, installedConfirmed=${commit.installedConfirmed})")
    def out = [
        success: true,
        message: "User app instance created and install committed (Done submitted; installed()/initialize() fired). scheduledJobCount/eventSubscriptionCount reflect what initialize() registered.",
        codeAppId: codeAppId,
        instanceAppId: newId,
        committed: true,
        installedConfirmed: (commit.installedConfirmed == true),
        scheduledJobCount: commit.scheduledJobCount,
        eventSubscriptionCount: commit.eventSubscriptionCount,
        mode: "installAsUserApp"
    ]
    if (commit.note) out.note = commit.note
    return out
}












private Map _submitAppDoneForm(Integer instanceId, String pageName, boolean requireLiveSettings = false) {
    def cfg = _rmFetchConfigJson(instanceId, pageName)
    def page = pageName ?: (cfg?.configPage?.name?.toString()) ?: "mainPage"
    def schema = _rmCollectInputSchema(cfg?.configPage)








    def pageValues = [:]
    for (s in (cfg?.configPage?.sections ?: [])) {
        for (i in (s?.input ?: [])) {
            if (i instanceof Map && i.name) {
                def nm = i.name.toString()
                if (i.value != null) pageValues.put(nm, i.value)
                else if (i.defaultValue != null) pageValues.put(nm, i.defaultValue)
            }
        }
    }
    def liveSettings = [:]
    boolean liveSettingsUnavailable = false
    try {
        liveSettings = _rmLiveSettingsFromStatus(_rmFetchStatusJson(instanceId)) ?: [:]
    } catch (Exception statusErr) {

        liveSettingsUnavailable = true
        mcpLog("error", "hub-admin", "_submitAppDoneForm: statusJson read for ${instanceId} failed (${statusErr.message}) -- the Done body cannot be built from live settings, so a DEVICE input would be re-submitted empty and CLEARED")
    }
    if (requireLiveSettings && liveSettingsUnavailable) {


        return [status: null, page: page, submitted: false, liveSettingsUnavailable: true, shapeRejections: 0]
    }
    def cfgSettings = (cfg?.settings instanceof Map) ? cfg.settings : [:]
    def settingsMap = [:]
    int shapeRejections = 0
    schema.each { name, meta ->









        def chosen = null
        for (candidate in [liveSettings.get(name), cfgSettings.get(name)]) {
            if (candidate == null) continue
            if (candidate instanceof CharSequence && candidate.toString().isEmpty()) continue
            if (!_isSimpleSettingValue(candidate)) {



                shapeRejections++
                mcpLog("error", "hub-admin", "_submitAppDoneForm: setting '${name}' on app ${instanceId} has an unencodable shape (${_settingShapeName(candidate)}); the Done body falls back to the page default for it, which may OVERWRITE the configured value")
                continue
            }
            chosen = candidate
            break
        }
        if (chosen != null) {
            settingsMap.put(name, chosen)
        } else {
            settingsMap.put(name, pageValues.containsKey(name) ? pageValues.get(name) : "")
        }
    }
    def body = _rmBuildSettingsBody(instanceId, settingsMap, schema)
    body.formAction = "update"
    body.currentPage = page
    body._action_update = "Done"
    body.pageBreadcrumbs = "[]"

    schema.each { name, meta ->
        def t = meta?.type?.toString()
        if (meta?.multiple != true) {
            body["${name}.multiple".toString()] = "false"
        }
        if (t == "bool") {
            body["checkbox[${name}]".toString()] = "on"
        } else if (t == "time") {
            body["hours[${name}]".toString()] = ""
            body["minutes[${name}]".toString()] = ""
            body["amPm[${name}]".toString()] = "AM"
        }
    }
    if (cfg?.app?.version != null) body.version = cfg.app.version.toString()





    body.appTypeId = ""
    body.appTypeName = ""
    body._cancellable = "false"

    def resp = hubInternalPostForm("/installedapp/update/json", body)
    return [status: resp?.status, page: page, submitted: true,
            liveSettingsUnavailable: liveSettingsUnavailable, shapeRejections: shapeRejections]
}







boolean _isSimpleSettingValue(v) {
    if (v instanceof Map) return false
    if (v instanceof List) {
        return v.every { it == null || it instanceof CharSequence || it instanceof Number || it instanceof Boolean }
    }
    return (v instanceof CharSequence || v instanceof Number || v instanceof Boolean)
}



def _settingShapeName(v) {
    if (v == null) return "null"
    if (v instanceof Map) return "Map"
    if (v instanceof List) return "List(with a non-scalar element)"
    return "non-scalar"
}

private Map _commitUserAppInstall(Integer instanceId, String pageName) {



    def submit = _submitAppDoneForm(instanceId, pageName, false)
    def st = submit.status
    def page = submit.page
    if (st != null && st >= 400) {
        return [
            success: false,
            error: "Done POST to /installedapp/update/json returned status ${st}",
            scheduledJobCount: 0,
            eventSubscriptionCount: 0
        ]
    }



    def installedConfirmed = null   // null = read failed -> committed-but-unconfirmed
    try {
        def postCfg = _rmFetchConfigJson(instanceId, page)
        installedConfirmed = (postCfg?.app?.installed == true)
    } catch (Exception ce) {
        mcpLog("warn", "hub-admin", "_commitUserAppInstall: post-commit installed-confirmation read for ${instanceId} failed (${ce.message}) -- reporting committed but unconfirmed")
    }
    if (installedConfirmed == false) {
        return [
            success: false,
            error: "Done POST returned ${st} but the instance still reads app.installed=false -- the commit did not take (inert shell). Delete via hub_delete_native_app(appId:${instanceId}, confirm:true) and retry.",
            scheduledJobCount: 0,
            eventSubscriptionCount: 0
        ]
    }

    def post = null
    try { post = _rmFetchStatusJson(instanceId) } catch (Exception se) {
        mcpLog("debug", "hub-admin", "_commitUserAppInstall: post-commit statusJson read for ${instanceId} failed (${se.message}) -- reporting zero counts")
    }
    def schedCount = (post?.scheduledJobs instanceof List) ? post.scheduledJobs.size() : 0
    def subCount = (post?.eventSubscriptions instanceof List) ? post.eventSubscriptions.size() : 0
    def out = [success: true, scheduledJobCount: schedCount, eventSubscriptionCount: subCount,
               installedConfirmed: (installedConfirmed == true)]


    def notes = []
    if (installedConfirmed == null) {
        notes << "app.installed could not be independently confirmed (the config read failed); scheduledJobCount/eventSubscriptionCount are the lifecycle evidence."
    }
    if (post == null) {
        notes << "The post-commit statusJson read failed, so scheduledJobCount/eventSubscriptionCount are reported as 0 rather than measured -- they are not evidence that initialize() registered nothing."
    }
    if (submit?.liveSettingsUnavailable) {
        notes << "The instance's live settings could not be read before the Done submit, so the form carried this page's defaults. Harmless on a fresh install (there was nothing configured yet), but re-check the instance if it was pre-seeded."
    }
    if (submit?.shapeRejections) {
        notes << "${submit.shapeRejections} setting(s) had a shape that cannot be form-encoded and fell back to the page default; see the hub log for their names."
    }
    if (notes) out.note = notes.join(" ")
    return out
}

def toolInstallApp(args) {
    if (args.installs != null) {
        throw new IllegalArgumentException("Bulk mode ('installs' array) is not supported for hub_create_app. Apps do not cluster the way drivers do; install each app individually.")
    }
    requireDestructiveConfirm(args.confirm)





    if (args.codeAppId != null) {
        if (args.source || args.sourceFile || args.importUrl) {
            throw new IllegalArgumentException(
                "codeAppId is mutually exclusive with source/sourceFile/importUrl. " +
                "Use two calls: (1) hub_create_app(source|sourceFile|importUrl, confirm:true) " +
                "to install the code, then " +
                "(2) hub_create_app(codeAppId:<codeAppId>, confirm:true) " +
                "to create the running instance."
            )
        }
        def codeAppId
        try { codeAppId = args.codeAppId as Integer }
        catch (Exception e) {
            throw new IllegalArgumentException("codeAppId must be a positive integer (got '${args.codeAppId}')")
        }


        if (codeAppId == null || codeAppId < 1) {
            throw new IllegalArgumentException("codeAppId must be a positive integer (got '${args.codeAppId}')")
        }
        return _createUserAppInstance(codeAppId)
    }

    return toolInstallItemSingle("app", args)
}

def toolInstallDriver(args) {
    return toolInstallItem("driver", args)
}

private Map toolInstallItem(String type, args) {
    requireDestructiveConfirm(args.confirm)

    def idField = (type == "app") ? "appId" : "driverId"


    if (args.installs != null) {
        if (args.source != null || args.sourceFile != null || args.importUrl != null) {
            throw new IllegalArgumentException("Cannot supply both 'installs' (bulk mode) and single-item fields (source/sourceFile/importUrl). Use one mode or the other.")
        }
        if (!(args.installs instanceof List)) {
            throw new IllegalArgumentException("'installs' must be an array of objects, each with 'source', 'sourceFile', or 'importUrl'.")
        }
        if (args.installs.isEmpty()) {
            throw new IllegalArgumentException("'installs' array must not be empty.")
        }


        def itemResults = []
        def allSucceeded = true
        for (int idx = 0; idx < args.installs.size(); idx++) {

            if (type == "driver" && idx > 0 && _resumableBudgetExceeded(null)) {
                return [success: allSucceeded, status: "in_progress", installs: itemResults,
                        installsRemaining: args.installs.subList(idx, args.installs.size()),
                        lastBackup: formatTimestamp(state.lastBackupTimestamp),
                        resume: [note: "Completed driver installs are retained. Continue with only installsRemaining; do not repeat completed installs."]]
            }
            def item = args.installs[idx]
            if (!(item instanceof Map) || (item.source == null && item.sourceFile == null && item.importUrl == null)) {
                itemResults << [(idField): null, success: false, error: "Each installs entry must have a 'source', 'sourceFile', or 'importUrl' field."]
                allSucceeded = false
                continue
            }
            try {
                def singleArgs = [confirm: args.confirm]
                if (item.sourceFile != null) singleArgs.sourceFile = item.sourceFile
                if (item.source != null) singleArgs.source = item.source
                if (item.importUrl != null) singleArgs.importUrl = item.importUrl
                def r = toolInstallItemSingle(type, singleArgs)
                def entry = [(idField): r.get(idField), success: r.success == true]
                if (r.success) {
                    if (r.sourceMode) entry.sourceMode = r.sourceMode
                    if (r.sourceLength != null) entry.sourceLength = r.sourceLength
                    if (r.verified != null) entry.verified = r.verified
                    if (r.verifyError) entry.verifyError = r.verifyError
                } else {
                    entry.error = r.error ?: "Install failed"
                    if (r.note) entry.note = r.note
                    if (r.lastBackup) entry.lastBackup = r.lastBackup
                    allSucceeded = false
                }
                itemResults << entry
            } catch (Exception e) {
                mcpLogError("hub-admin", "Bulk install_${type} item ${idx} threw", e)
                itemResults << [(idField): null, success: false, error: e.message ?: e.toString(), errorClass: e.class.simpleName]
                allSucceeded = false
            }
        }

        def successCount = itemResults.count { it.success == true }
        mcpLog("info", "hub-admin", "Bulk install_${type}: ${successCount}/${itemResults.size()} succeeded")
        return [
            success: allSucceeded,
            message: allSucceeded ? "All ${itemResults.size()} ${type}(s) installed successfully." : "${successCount} of ${itemResults.size()} ${type}(s) installed successfully.",
            installs: itemResults,
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
    }


    return toolInstallItemSingle(type, args)
}


private Map toolInstallItemSingle(String type, args) {
    def idField = (type == "app") ? "appId" : "driverId"



    def sourceCode = null
    def sourceMode = null
    def modesSet = [args.sourceFile, args.source, args.importUrl].count { it }
    if (modesSet > 1) {
        throw new IllegalArgumentException("Provide exactly one of 'source' (inline), 'sourceFile' (File Manager filename), or 'importUrl' (URL the hub will fetch).")
    }
    if (args.sourceFile) {
        sourceMode = "sourceFile"
        mcpLog("info", "hub-admin", "Reading ${type} source from File Manager: ${args.sourceFile}")
        def bytes = downloadHubFile(args.sourceFile)
        if (bytes == null) throw new IllegalArgumentException("Source file '${args.sourceFile}' not found in File Manager")
        sourceCode = new String(bytes, "UTF-8")
        mcpLog("info", "hub-admin", "Read ${sourceCode.length()} chars from ${args.sourceFile}")
    } else if (args.importUrl) {
        sourceMode = "importUrl"
        mcpLog("info", "hub-admin", "Reading ${type} source from importUrl: ${args.importUrl}")
        sourceCode = _fetchSourceFromUrl(args.importUrl)
        mcpLog("info", "hub-admin", "Read ${sourceCode.length()} chars from importUrl")
    } else if (args.source) {
        sourceMode = "source"
        sourceCode = args.source
    } else {
        throw new IllegalArgumentException("One of 'source' (inline Groovy code), 'sourceFile' (File Manager filename), or 'importUrl' (URL the hub will fetch) is required")
    }

    def savePath = (type == "app") ? "/app/saveOrUpdateJson" : "/driver/saveOrUpdateJson"
    def ajaxPath = (type == "app") ? "/app/ajax/code" : "/driver/ajax/code"

    mcpLog("info", "hub-admin", "Installing new ${type} (mode: ${sourceMode}, sourceLength: ${sourceCode.length()})...")
    try {




        def saveBody = groovy.json.JsonOutput.toJson([id: null, source: sourceCode, version: 1])
        def parsed = hubInternalPostJson(savePath, saveBody)

        if (parsed == null || parsed.success != true) {
            def hubMsg = (parsed instanceof Map) ? (parsed.message ?: parsed.errorMessage) : null
            mcpLog("warn", "hub-admin", "${type.capitalize()} create rejected: ${hubMsg ?: 'no/unparseable response'}")
            return [
                success: false,
                error: "${type.capitalize()} installation failed: ${hubMsg ?: 'the hub rejected the source or returned no parseable response'}",
                (idField): null,
                note: "The hub validates the source on create. Fix the reported issue -- e.g. a Groovy compile error, or a required definition() field such as a non-empty iconUrl/iconX2Url (enforced on create) -- and retry.",
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
        }

        def newItemId = parsed.id?.toString()
        if (!newItemId) {
            mcpLog("warn", "hub-admin", "${type.capitalize()} create returned success but no id: ${parsed}")
            return [
                success: false,
                error: "${type.capitalize()} install reported success but returned no item id.",
                (idField): null,
                note: "Unexpected /app/saveOrUpdateJson response shape. Check Hubitat > Apps Code (or Drivers Code).",
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
        }


        def verifyText = null
        def verifyError = null
        def verified = null

        try {
            verifyText = hubInternalGet(ajaxPath, [id: newItemId])
        } catch (Exception verifyErr) {
            verifyError = verifyErr.message ?: verifyErr.toString()
            mcpLog("warn", "hub-admin", "${type.capitalize()} post-install verification fetch failed for ID ${newItemId}: ${verifyError}")
        }

        def bodyPresent = verifyText instanceof String && !verifyText.trim().isEmpty()

        if (verifyError == null && bodyPresent) {
            try {
                verified = new groovy.json.JsonSlurper().parseText(verifyText)
            } catch (Exception parseErr) {
                mcpLog("warn", "hub-admin", "${type.capitalize()} ID ${newItemId}: verify body unparseable: ${parseErr.message}")
                return [
                    success: false,
                    error: "${type.capitalize()} install unverified: hub returned unparseable verify body for ID ${newItemId}",
                    (idField): newItemId,
                    note: "Hub created an item slot but the verify response was not valid JSON (possibly an HTML error/login page). Use get_${type}_source with ID ${newItemId} to confirm whether the item persisted. Do NOT retry the install without checking first -- a duplicate item with a different ID may result.",
                    lastBackup: formatTimestamp(state.lastBackupTimestamp)
                ]
            }

            if (verified.status == "error" || !verified.source) {
                def errMsg = verified.errorMessage ?: "item in error state after install"
                mcpLog("warn", "hub-admin", "${type.capitalize()} ID ${newItemId} installed but failed verification: ${errMsg}")
                return [
                    success: false,
                    error: "${type.capitalize()} installation failed: ${errMsg}",
                    (idField): newItemId,
                    note: "The hub created an item slot (ID: ${newItemId}) but reported an error. Check the Groovy source for compilation issues. You can view the error via hub_get_source(type='app'|'driver') with this ID.",
                    lastBackup: formatTimestamp(state.lastBackupTimestamp)
                ]
            }
        }

        if (verifyError == null && !bodyPresent) {
            mcpLog("warn", "hub-admin", "${type.capitalize()} ID ${newItemId}: verify endpoint returned empty body -- cannot confirm install")
            return [
                success: false,
                error: "${type.capitalize()} install unverified: hub returned empty verify body for ID ${newItemId}",
                (idField): newItemId,
                note: "Hub created an item slot but the verify fetch returned no content. Use get_${type}_source with ID ${newItemId} to confirm whether the item persisted. Do NOT retry the install without checking first -- a duplicate item with a different ID may result.",
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
        }

        mcpLog("info", "hub-admin", "${type.capitalize()} installed (ID: ${newItemId}, mode: ${sourceMode}, verified: ${verifyError == null})")
        def installResult = [
            success: true,
            message: "${type.capitalize()} installed successfully",
            (idField): newItemId,
            sourceMode: sourceMode,
            sourceLength: sourceCode.length(),
            verified: (verifyError == null),
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
        if (verifyError != null) installResult.verifyError = "${verifyError} -- use get_${type}_source with ID ${newItemId} to confirm."
        if (sourceMode == "sourceFile") installResult.note = "Source was read from File Manager file '${args.sourceFile}'."
        if (sourceMode == "importUrl") installResult.note = "Source was fetched from importUrl '${args.importUrl}' (hub-side fetch, no agent transcript)."
        return installResult
    } catch (Exception e) {
        mcpLogError("hub-admin", "${type.capitalize()} installation failed", e)
        return [
            success: false,
            error: "${type.capitalize()} installation failed: ${e.message}",
            note: "Check that the Groovy source code is valid and doesn't have syntax errors."
        ]
    }
}

def toolUpdateItemCode(String type, String idParam, args) {
    requireDestructiveConfirm(args.confirm)
    return toolUpdateItemCodeInner(type, idParam, args)
}



private Map toolUpdateItemCodeInner(String type, String idParam, args, Map packageWorkerContext = null) {
    def itemId = args[idParam]
    if (!itemId) throw new IllegalArgumentException("${idParam} is required")





    def modesSet = [args.resave, args.sourceFile, args.source, args.importUrl].count { it }
    if (modesSet == 0) {
        throw new IllegalArgumentException("One of 'source', 'sourceFile', 'importUrl', or 'resave' is required")
    }
    if (modesSet > 1) {
        throw new IllegalArgumentException("Provide exactly one of 'source', 'sourceFile', 'importUrl', or 'resave'")
    }



    if (args.containsKey('expectedVersion') && args.expectedVersion == null) {
        throw new IllegalArgumentException("expectedVersion was supplied as null. Omit the field entirely to skip the optimistic-lock check, or pass an integer.")
    }



    def itemIdInt
    try {
        itemIdInt = itemId as Integer
    } catch (NumberFormatException | ClassCastException idErr) {
        throw new IllegalArgumentException("${idParam} must be an integer ${type} code id (got '${itemId}')")
    }




    if (type == "app") {
        def selfAppId = app?.id?.toString()
        if (selfAppId == null) {
            mcpLog("error", "hub-admin", "hub_update_app: self-update guard cannot verify -- app context unavailable (app=${app}); refusing appId=${itemId} to fail closed")
            throw new IllegalArgumentException("hub_update_app cannot verify the self-update guard: app context is unavailable (app=${app}). Refusing to proceed to avoid a silent self-update brick. Retry the call; this is typically a transient lifecycle window.")
        }
        if (itemId.toString() == selfAppId) {
            if (!settings.enableDeveloperMode) {
                mcpLog("warn", "hub-admin", "hub_update_app: self-update of MCP server app (id=${itemId}) BLOCKED -- Developer Mode is off")
                throw new IllegalArgumentException("hub_update_app refuses to overwrite the MCP server's own app source (appId=${itemId}) while Developer Mode is off. A bad self-update can brick the MCP loop -- enable 'Developer Mode Tools' in the MCP Rule Server app settings to permit self-updates.")
            }
            mcpLog("warn", "hub-admin", "hub_update_app: self-update of MCP server app (id=${itemId}) ALLOWED -- Developer Mode is on")
        }
    }

    def ajaxPath = (type == "app") ? "/app/ajax/code" : "/driver/ajax/code"
    def savePath = (type == "app") ? "/app/saveOrUpdateJson" : "/driver/saveOrUpdateJson"


    def sourceCode = null
    def sourceMode = null
    def freshVersion = null  // Track version from fresh fetch (not from backup cache)

    if (args.resave) {

        sourceMode = "resave"
        mcpLog("info", "hub-admin", "Resave mode: fetching current ${type} ID ${itemId} source locally")
        def responseText = hubInternalGet(ajaxPath, [id: itemId])
        if (!responseText) throw new IllegalArgumentException("Could not fetch current source for ${type} ID ${itemId}")
        def parsed = new groovy.json.JsonSlurper().parseText(responseText)
        if (parsed.status == "error" || !parsed.source) {
            throw new IllegalArgumentException("Cannot read ${type} ID ${itemId}: ${parsed.errorMessage ?: 'no source returned'}")
        }
        sourceCode = parsed.source
        freshVersion = parsed.version  // Capture fresh version for optimistic locking
    } else if (args.sourceFile) {

        sourceMode = "sourceFile"
        mcpLog("info", "hub-admin", "Reading ${type} source from File Manager: ${args.sourceFile}")
        def bytes = downloadHubFile(args.sourceFile)
        if (bytes == null) throw new IllegalArgumentException("Source file '${args.sourceFile}' not found in File Manager")
        sourceCode = new String(bytes, "UTF-8")
        mcpLog("info", "hub-admin", "Read ${sourceCode.length()} chars from ${args.sourceFile}")
    } else if (args.importUrl) {
        sourceMode = "importUrl"
        mcpLog("info", "hub-admin", "Reading ${type} source from importUrl: ${args.importUrl}")
        sourceCode = _fetchSourceFromUrl(args.importUrl)
        mcpLog("info", "hub-admin", "Read ${sourceCode.length()} chars from importUrl")
    } else {

        sourceMode = "source"
        sourceCode = args.source
    }




    def itemBackup = backupItemSource(type, itemId.toString())



    def currentVersion = freshVersion
    if (currentVersion == null) {
        try {
            def versionResponse = hubInternalGet(ajaxPath, [id: itemId])
            if (versionResponse) {
                def versionParsed = new groovy.json.JsonSlurper().parseText(versionResponse)
                currentVersion = versionParsed.version
            }
        } catch (Exception vErr) {
            mcpLog("warn", "hub-admin", "Could not fetch fresh version for ${type} ID ${itemId}, falling back to backup version: ${vErr.message}")
        }

        if (currentVersion == null) currentVersion = itemBackup.version
    }

    if (currentVersion == null) {
        throw new IllegalArgumentException("Could not determine current version for ${type} ID ${itemId}. The ${type} may not exist.")
    }


    if (args.containsKey('expectedVersion')) {
        def expectedVersionInt
        try {
            expectedVersionInt = args.expectedVersion as Integer
        } catch (NumberFormatException | ClassCastException coerceErr) {



            throw new IllegalArgumentException("expectedVersion must be an integer (got '${args.expectedVersion}'): ${coerceErr.message}")
        }
        def currentVersionInt
        try {
            currentVersionInt = currentVersion as Integer
        } catch (NumberFormatException | ClassCastException currErr) {
            mcpLog("error", "hub-admin", "Hub returned non-integer version for ${type} ${itemId}: ${currentVersion}; aborting optimistic-lock evaluation to avoid an unguarded write")
            throw new IllegalArgumentException("Cannot evaluate expectedVersion: hub returned a non-integer current version (${currentVersion}). Update aborted to avoid an unguarded write.")
        }
        if (expectedVersionInt != currentVersionInt) {
            mcpLog("warn", "hub-admin", "${type} update ID ${itemId} aborted: expectedVersion=${expectedVersionInt} but currentVersion=${currentVersionInt} (concurrent edit detected)")
            return [
                success: false,
                error: "Optimistic-lock conflict: expected ${type} version ${expectedVersionInt} but hub has ${currentVersionInt}. Re-read the source and retry with the new expectedVersion.",
                (idParam): itemId,
                expectedVersion: expectedVersionInt,
                currentVersion: currentVersionInt,
                conflict: true,
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
        }
    }











    boolean isSelfUpdate = false
    if (type == "app") {
        def selfInstanceId = app?.id?.toString()
        if (selfInstanceId != null && itemId?.toString() == selfInstanceId) {
            isSelfUpdate = true
        } else {
            def selfClassId = _resolveSelfAppClassId()
            if (selfClassId != null && itemId?.toString() == selfClassId.toString()) isSelfUpdate = true
            else if (selfClassId == null && sourceCode.length() > 500000) {



                mcpLog("warn", "hub-admin", "hub_update_app: large app-source update to id ${itemId} but the self app-class lookup returned null -- if this IS the MCP server, #237 self-deploy error capture is disabled for this deploy.")
            }
        }
    }
    mcpLog("info", "hub-admin", "Updating ${type} ID: ${itemId} (version: ${currentVersion}, mode: ${sourceMode}, sourceLength: ${sourceCode.length()})")
    try {




        def parsed = hubInternalPostJson(savePath, groovy.json.JsonOutput.toJson([
            id: itemIdInt,
            source: sourceCode,
            version: currentVersion
        ]))

        def success = false
        def errorMsg = null

        if (parsed instanceof Map) {
            success = parsed.success == true
            if (success && parsed.id != null && parsed.id.toString() != itemIdInt.toString()) {


                success = false
                errorMsg = "Hub reported success but saved to ${type} id ${parsed.id} instead of the targeted id ${itemIdInt} -- a duplicate code entry may have been created. Check Apps Code / Drivers Code before retrying."
            } else if (!success) {
                errorMsg = parsed.message ?: parsed.errorMessage ?: "hub response lacked success=true: ${parsed.toString().take(200)}"
            }
        } else if (parsed == null) {




            success = isSelfUpdate
            if (!success) errorMsg = "Empty response from ${savePath} -- the update may or may not have applied. Re-read the ${type} source to verify before retrying."
        } else {
            errorMsg = "Unexpected response shape from ${savePath}: ${parsed.toString().take(200)}"
        }



        if (isSelfUpdate) {
            try {
                def stash = [
                    success: success,
                    error: success ? null : (errorMsg ?: "Update failed -- the hub returned an error"),
                    sourceMode: sourceMode,
                    importUrl: (args.importUrl ?: null),
                    sourceLength: sourceCode.length(),
                    at: now()
                ]
                def packageCorrelation = _validatedPackageWorkerContext(packageWorkerContext)
                if (packageCorrelation != null) {
                    stash.requestId = packageCorrelation.requestId
                    stash.packageRef = packageCorrelation.packageRef
                }


                if (success && parsed == null) stash.assumed = true
                atomicState.lastSelfDeploy = stash
            } catch (Exception stashErr) {


                mcpLog("error", "hub-admin", "lastSelfDeploy stash write failed -- self-deploy outcome record lost: ${stashErr}")
            }
        }

        if (success) {
            mcpLog("info", "hub-admin", "${type} ID ${itemId} updated successfully (mode: ${sourceMode})")
            def successResult = [
                success: true,
                message: "${type.capitalize()} code updated successfully",
                (idParam): itemId,
                previousVersion: currentVersion,
                sourceMode: sourceMode,
                sourceLength: sourceCode.length(),
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
            if (sourceMode == "resave") successResult.note = "Source was fetched and re-saved entirely on-hub — no cloud round-trip."
            if (sourceMode == "sourceFile") successResult.note = "Source was read from File Manager file '${args.sourceFile}' — no cloud size limits."
            if (sourceMode == "importUrl") successResult.note = "Source was fetched from importUrl '${args.importUrl}' (hub-side fetch, no agent transcript)."






            if (type == "app" && args.containsKey('triggerUpdated') && args.triggerUpdated != null) {
                def triggerId = null
                try { triggerId = args.triggerUpdated as Integer }
                catch (Exception coerceErr) {
                    successResult.triggerUpdated = args.triggerUpdated
                    successResult.updatedFired = false
                    successResult.repairHints = ["triggerUpdated must be a positive integer (instance appId); got '${args.triggerUpdated}'. The code save succeeded; lifecycle was NOT refreshed."]
                    return successResult
                }
                if (triggerId == null || triggerId < 1) {
                    successResult.triggerUpdated = args.triggerUpdated
                    successResult.updatedFired = false
                    successResult.repairHints = ["triggerUpdated must be a positive integer (instance appId). The code save succeeded; lifecycle was NOT refreshed."]
                    return successResult
                }
                successResult.triggerUpdated = triggerId
                try {








                    def submit = _submitAppDoneForm(triggerId, null, true)
                    if (submit?.liveSettingsUnavailable) {
                        throw new IllegalStateException("the instance's live settings (statusJson) could not be read, so the Done was NOT submitted -- submitting it would have re-sent this page's defaults and cleared the instance's configured settings, device selections included")
                    }
                    def submitStatus = submit?.status
                    if (submitStatus != null && submitStatus >= 400) {
                        throw new RuntimeException("Done POST to /installedapp/update/json returned status ${submitStatus}")
                    }
                    successResult.updatedFired = true
                    if (submit?.shapeRejections) {



                        successResult.repairHints = ((successResult.repairHints ?: []) + [
                            "${submit.shapeRejections} setting(s) on instance ${triggerId} could not be form-encoded and were re-submitted as this page's defaults, which may have overwritten their configured values -- see the hub log for the setting names, then re-check them via hub_get_app_config(appId:${triggerId}, includeSettings:true)."
                        ])
                    }
                    mcpLog("info", "hub-admin", "triggerUpdated: fired updated() on instance ${triggerId} via /installedapp/update/json after app code save")
                } catch (Exception updErr) {






                    successResult.updatedFired = false
                    successResult.partial = true
                    successResult.repairHints = ["triggerUpdated requested but the Done submit to /installedapp/update/json for instance ${triggerId} failed: ${updErr.toString()}. The new code is deployed (success:true) but subscriptions/schedules may not have refreshed -- open the app in the hub UI and click Done, or toggle it off/on."]
                    mcpLog("warn", "hub-admin", "triggerUpdated failed on instance ${triggerId}: ${updErr.toString()}")
                }
            }

            return successResult
        } else {
            return [
                success: false,
                error: errorMsg ?: "Update failed - the hub returned an error",
                (idParam): itemId,
                note: "Check the Groovy source code for syntax errors or compilation issues.",
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
        }
    } catch (Exception e) {
        mcpLogError("hub-admin", "${type} update failed", e)
        if (isSelfUpdate) {
            try {
                def stash = [
                    success: false,
                    error: "${type.capitalize()} update failed: ${e.message}",
                    sourceMode: sourceMode,
                    importUrl: (args.importUrl ?: null),
                    sourceLength: (sourceCode != null ? sourceCode.length() : 0),
                    at: now()
                ]
                def packageCorrelation = _validatedPackageWorkerContext(packageWorkerContext)
                if (packageCorrelation != null) {
                    stash.requestId = packageCorrelation.requestId
                    stash.packageRef = packageCorrelation.packageRef
                }
                atomicState.lastSelfDeploy = stash
            } catch (Exception stashErr) {
                mcpLog("error", "hub-admin", "lastSelfDeploy stash write failed -- self-deploy outcome record lost: ${stashErr}")
            }
        }
        return [
            success: false,
            error: "${type.capitalize()} update failed: ${e.message}",
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
    }
}




private Map _validatedPackageWorkerContext(packageWorkerContext) {
    if (!(packageWorkerContext instanceof Map) || packageWorkerContext.requestId == null ||
            packageWorkerContext.packageRef == null) return null
    synchronized (WRITE_RESERVATION_LOCK) {
        def marker = _writeStateValueLocked("packageDeployInFlight")
        if (marker instanceof Map && marker.requestId != null && marker.ref != null &&
                marker.requestId.toString() == packageWorkerContext.requestId.toString() &&
                marker.ref.toString() == packageWorkerContext.packageRef.toString()) {
            return [requestId: marker.requestId.toString(), packageRef: marker.ref.toString()]
        }
    }
    return null
}

def toolUpdateAppCode(args) {
    return _toolUpdateAppCode(args, null)
}



def _toolUpdateAppCode(args, Map packageWorkerContext) {
    if (args.updates != null) {
        throw new IllegalArgumentException("Bulk mode ('updates' array) is not supported for hub_update_app. Apps do not cluster the way drivers do; update each app individually.")
    }
    if (args.oauth == null) {
        requireDestructiveConfirm(args.confirm)
        return toolUpdateItemCodeInner("app", "appId", args, packageWorkerContext)
    }




    requireDestructiveConfirm(args.confirm)
    if (!args.appId) throw new IllegalArgumentException("appId is required")

    def hasSourceMode = [args.resave, args.sourceFile, args.source, args.importUrl].count { it } > 0
    def result
    if (hasSourceMode) {
        result = toolUpdateItemCodeInner("app", "appId", args, packageWorkerContext)   // gate already fired above
        if (result?.success != true) return result               // source update failed -- leave OAuth untouched
    } else {
        result = [success: true, appId: args.appId.toString(), message: "OAuth settings updated (no source change)."]
    }

    def oauthRes = _updateAppOAuth(args.appId, args.oauth)
    result.oauth = oauthRes
    if (oauthRes.success != true) {
        result.success = false
        if (hasSourceMode) result.partial = true   // source saved, OAuth leg failed
    }
    return result
}







private Map _updateAppOAuth(appId, oauth) {
    if (!(oauth instanceof Map)) {
        throw new IllegalArgumentException("oauth must be an object, e.g. {enabled: true} (optionally client_id, client_secret, refresh_secret).")
    }





    boolean isSelf = false
    def selfInstanceId = app?.id?.toString()
    if (selfInstanceId != null && appId?.toString() == selfInstanceId) {
        isSelf = true
    } else {
        def selfClassId = _resolveSelfAppClassId()
        if (selfClassId != null && appId?.toString() == selfClassId.toString()) isSelf = true
    }
    if (isSelf && !settings.enableDeveloperMode) {
        mcpLog("warn", "hub-admin", "hub_update_app: OAuth change to the MCP server's own app (id=${appId}) BLOCKED -- Developer Mode is off")
        throw new IllegalArgumentException("hub_update_app refuses to change the MCP server's own OAuth (appId=${appId}) while Developer Mode is off -- its client id/secret back the live /mcp access token and changing them would break this connection. Enable Developer Mode to override.")
    }

    boolean enabled = (oauth.enabled != null) ? (oauth.enabled == true) : true
    boolean refreshSecret = (oauth.refresh_secret == true)
    String clientId = (oauth.client_id != null) ? oauth.client_id.toString() : null
    String clientSecret = (oauth.client_secret != null) ? oauth.client_secret.toString() : null
    if (clientId == null || clientSecret == null) {
        def cur = _readAppOAuthCreds(appId)
        if (cur == null) {


            return [success: false, error: "Could not read the app's current OAuth credentials to preserve them.",
                    note: "Refusing to submit empty credentials (would clobber an already-enabled app's live creds). Pass client_id + client_secret explicitly, or retry."]
        }
        if (clientId == null) clientId = cur.clientId?.toString() ?: ""
        if (clientSecret == null) clientSecret = cur.clientSecret?.toString() ?: ""
    }

    try {




        def respText = hubInternalGet("/app/updateOAuth", [
            id: appId.toString(),
            oauthEnabled: enabled,
            clientId: clientId,
            clientSecret: clientSecret,
            refreshSecret: refreshSecret
        ], 30)




        def parsed = null
        boolean unparseable = false
        if (respText) {
            try { parsed = new groovy.json.JsonSlurper().parseText(respText) }
            catch (Exception parseErr) { unparseable = true }
        }
        if (parsed instanceof Map) {
            if (parsed.success == true) {
                return [success: true, enabled: enabled,
                        clientId: parsed.clientId ?: (clientId ?: null),
                        clientSecret: parsed.clientSecret ?: (clientSecret ?: null)]
            }

            if (parsed.error || parsed.message) {
                return [success: false, error: (parsed.error ?: parsed.message)?.toString(), response: respText?.take(300),
                        note: "The app's source must declare OAuth (an oauth block + mappings) before it can be enabled."]
            }
        }
        if (unparseable) {
            return [success: false, error: "/app/updateOAuth returned a non-JSON body", response: respText?.take(300),
                    note: "That is not a hub OAuth answer -- an HTML body here is typically the Hub Security login page, so check the MCP app's Hub Security credentials (and that the hub is not mid-reboot). This says nothing about whether the app's source declares OAuth."]
        }
        if (!respText) {
            return [success: false, error: "/app/updateOAuth returned an empty body",
                    note: "The request reached the hub but produced no answer -- retry; if it persists, check Hub Security credentials."]
        }
        return [success: false, error: "/app/updateOAuth did not report success", response: respText?.take(300),
                note: "The app's source must declare OAuth (an oauth block + mappings) before it can be enabled."]
    } catch (Exception e) {
        mcpLogError("hub-admin", "OAuth update failed", e)
        return [success: false, error: "OAuth update failed: ${e.message}", note: "Check the app id and Hub Security credentials."]
    }
}







private _readAppOAuthCreds(appId) {
    try {
        def txt = hubInternalGet("/app/list/single/data/${java.net.URLEncoder.encode(appId.toString(), 'UTF-8')}", null, 30)
        def d = txt ? new groovy.json.JsonSlurper().parseText(txt) : null
        def o = (d instanceof List && d) ? d[0] : (d instanceof Map ? d : null)
        if (!(o instanceof Map)) return null   // unreadable / unrecognized shape -- NOT "no creds"
        return [clientId: o.oauthClientId, clientSecret: o.oauthClientSecret]
    } catch (Exception e) {
        mcpLogError("hub-admin", "Could not read current OAuth creds for app ${appId}", e)
        return null
    }
}

def toolUpdateDriverCode(args) {
    requireDestructiveConfirm(args.confirm)


    if (args.updates != null) {
        if (args.driverId != null || args.source != null || args.sourceFile != null || args.importUrl != null || args.resave != null || args.expectedVersion != null) {
            throw new IllegalArgumentException("Cannot supply both 'updates' (bulk mode) and single-driver fields (driverId/source/sourceFile/importUrl/resave/expectedVersion). Use one mode or the other -- expectedVersion belongs on each entry inside updates[] for bulk.")
        }
        if (!(args.updates instanceof List)) {
            throw new IllegalArgumentException("'updates' must be an array of objects, each with 'driverId' and 'sourceFile' (or 'source', 'importUrl', or 'resave').")
        }
        if (args.updates.isEmpty()) {
            throw new IllegalArgumentException("'updates' array must not be empty.")
        }


        def itemResults = []
        def allSucceeded = true
        for (int idx = 0; idx < args.updates.size(); idx++) {

            if (idx > 0 && _resumableBudgetExceeded(null)) {
                return [success: allSucceeded, status: "in_progress", updates: itemResults,
                        updatesRemaining: args.updates.subList(idx, args.updates.size()),
                        lastBackup: formatTimestamp(state.lastBackupTimestamp),
                        resume: [note: "Completed driver updates are retained. Continue with only updatesRemaining, preserving their order and expectedVersion values."]]
            }
            def item = args.updates[idx]
            if (!(item instanceof Map) || !item.driverId) {
                itemResults << [driverId: item?.driverId?.toString() ?: "item[${idx}]", success: false, error: "Each updates entry must have a 'driverId' field."]
                allSucceeded = false
                continue
            }
            try {
                def singleArgs = [driverId: item.driverId]
                if (item.sourceFile != null) singleArgs.sourceFile = item.sourceFile
                if (item.source != null) singleArgs.source = item.source
                if (item.importUrl != null) singleArgs.importUrl = item.importUrl
                if (item.resave != null) singleArgs.resave = item.resave


                if (item.containsKey('expectedVersion')) singleArgs.expectedVersion = item.expectedVersion
                def r = toolUpdateItemCodeInner("driver", "driverId", singleArgs)
                def entry = [driverId: item.driverId.toString(), success: r.success == true]
                if (r.success) {
                    entry.sourceMode = r.sourceMode
                    entry.sourceLength = r.sourceLength
                } else {
                    entry.error = r.error ?: "Update failed"
                    if (r.note) entry.note = r.note
                    if (r.lastBackup) entry.lastBackup = r.lastBackup
                    if (r.conflict) {
                        entry.conflict = true
                        entry.expectedVersion = r.expectedVersion
                        entry.currentVersion = r.currentVersion
                    }
                    allSucceeded = false
                }
                itemResults << entry
            } catch (Exception e) {
                mcpLogError("hub-admin", "Bulk hub_update_driver item ${idx} (driverId ${item.driverId}) threw", e)
                itemResults << [driverId: item.driverId.toString(), success: false, error: e.message ?: e.toString(), errorClass: e.class.simpleName]
                allSucceeded = false
            }
        }

        def successCount = itemResults.count { it.success == true }
        mcpLog("info", "hub-admin", "Bulk hub_update_driver: ${successCount}/${itemResults.size()} succeeded")
        return [
            success: allSucceeded,
            message: allSucceeded ? "All ${itemResults.size()} driver(s) updated successfully." : "${successCount} of ${itemResults.size()} driver(s) updated successfully.",
            updates: itemResults,
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
    }


    return toolUpdateItemCodeInner("driver", "driverId", args)
}




def toolDeleteItem(args) {
    def type = args.type
    if (!(type in ["app", "driver", "library"])) {
        throw new IllegalArgumentException("type is required and must be one of: app, driver, library")
    }
    def id = (args.item_id != null) ? args.item_id : (type == "app" ? args.appId : (type == "driver" ? args.driverId : args.libraryId))
    if (type == "library") {
        return toolDeleteLibrary(args + [libraryId: id])
    }
    def idParam = (type == "app") ? "appId" : "driverId"
    def deletePath = (type == "app") ? "/app/edit/deleteJsonSafe/" : "/driver/editor/deleteJson/"
    return _deleteItemViaEndpoint(type, idParam, deletePath, args + [(idParam): id])
}

private Map _deleteItemViaEndpoint(String type, String idParam, String deletePath, args) {
    requireDestructiveConfirm(args.confirm)
    def itemId = args[idParam]
    if (!itemId) throw new IllegalArgumentException("${idParam} is required")

    def backupSucceeded = true
    try {
        backupItemSource(type, itemId.toString())
    } catch (Exception backupErr) {
        backupSucceeded = false
        mcpLog("warn", "hub-admin", "Pre-delete backup failed for ${type} ${itemId}: ${backupErr.message} -- proceeding with delete")
    }

    mcpLog("warn", "hub-admin", "Deleting ${type} ID: ${itemId}")
    try {
        def responseText = hubInternalGet("${deletePath}${itemId}")
        mcpLog("debug", "hub-admin", "Delete ${type} ${itemId} response: ${responseText?.take(200)}")
        def success = false
        if (responseText) {
            try {
                def parsed = new groovy.json.JsonSlurper().parseText(responseText)
                success = parsed.status?.toString() == "true"
            } catch (Exception parseErr) {
                success = !responseText.toLowerCase().contains("error")
            }
        }

        if (success) {
            mcpLog("info", "hub-admin", "${type.capitalize()} ID ${itemId} deleted successfully")

            def backupEntry = (_itemBackupManifest())?.get("${type}_${itemId}".toString())
            def installTool = (type == "app") ? "hub_create_app" : "hub_create_driver"
            def result = [
                success: true,
                message: backupSucceeded ? "${type.capitalize()} deleted successfully. Source code backed up to File Manager." : "${type.capitalize()} deleted successfully. WARNING: Pre-delete backup failed -- source code may not be recoverable.",
                (idParam): itemId,
                lastBackup: formatTimestamp(state.lastBackupTimestamp),
                backupFile: backupEntry?.fileName,
                restoreHint: backupEntry ? "To restore: use '${installTool}' with the backup source, or download ${backupEntry.fileName} from Hubitat > Settings > File Manager and re-install manually." : null
            ]
            if (!backupSucceeded) result.backupWarning = "Pre-delete backup could not be created. The source code may be permanently lost."
            return result
        } else {
            return [
                success: false,
                error: "Delete may have failed - check the Hubitat web UI to verify",
                (idParam): itemId,
                response: responseText?.take(500)
            ]
        }
    } catch (Exception e) {
        mcpLogError("hub-admin", "${type.capitalize()} deletion failed", e)
        return [success: false, error: "${type.capitalize()} deletion failed: ${e.message}"]
    }
}

private Map backupLibrarySource(String libraryId) {
    return _withBackupLock("backup library ${libraryId}") { _backupLibrarySourceLocked(libraryId) }
}

private Map _backupLibrarySourceLocked(String libraryId) {
    def manifest = _itemBackupManifest()
    String key = "library_${libraryId}"
    def existing = _reusableItemBackup(manifest, key, "Library")
    if (existing != null) return existing

    def responseText = hubInternalGet("/library/list/single/data/${libraryId}")
    if (!responseText) {
        throw new IllegalArgumentException("Cannot back up library ID ${libraryId}: empty response from hub")
    }

    def parsed
    try {
        parsed = new groovy.json.JsonSlurper().parseText(responseText)
    } catch (Exception parseEx) {
        throw new IllegalArgumentException("Cannot back up library ID ${libraryId}: failed to parse hub response: ${parseEx.message}")
    }

    if (!(parsed instanceof List) || parsed.isEmpty()) {
        throw new IllegalArgumentException("Cannot back up library ID ${libraryId}: library not found")
    }

    def libData = parsed[0]
    def backupSource = libData.source ?: ""
    def fileName = _itemBackupFileName("mcp-backup-library-${libraryId}.groovy")
    try {
        uploadHubFile(fileName, backupSource.getBytes("UTF-8"))
    } catch (Exception e) {
        mcpLogError("hub-admin", "Failed to save library backup file '${fileName}'", e)
        throw new IllegalArgumentException("Cannot back up library ID ${libraryId}: file upload failed -- ${e.message}")
    }

    def entry = [
        type: "library",
        id: libraryId.toString(),
        fileName: fileName,
        version: libData.version,
        timestamp: now(),
        sourceLength: backupSource.length()
    ]
    _publishUploadedItemBackup(key, entry)
    mcpLog("info", "hub-admin", "Backed up library ID ${libraryId} source to File Manager: ${fileName} (version ${libData.version}, ${backupSource.length()} chars)")
    return entry
}

def toolGetLibrarySource(args) {
    def libraryId = args.libraryId
    if (!libraryId) throw new IllegalArgumentException("libraryId is required")
    if (!libraryId.toString().isInteger() || libraryId.toString().toInteger() <= 0) throw new IllegalArgumentException("libraryId must be a positive integer (got: '${libraryId}')")

    def maxChunkSize = 64000
    def requestedOffset = args.offset ? args.offset as int : 0
    def requestedLength = args.length ? Math.min(args.length as int, maxChunkSize) : maxChunkSize

    try {
        def responseText = hubInternalGet("/library/list/single/data/${libraryId}")
        if (!responseText) return [success: false, error: "Empty response from hub for library ${libraryId}"]

        def parsed
        try {
            parsed = new groovy.json.JsonSlurper().parseText(responseText)
        } catch (Exception parseErr) {
            return [success: false, error: "Failed to parse library response: ${parseErr.message}"]
        }

        if (!(parsed instanceof List) || parsed.isEmpty()) {
            return [success: false, error: "Library ${libraryId} not found"]
        }

        def libraryData = parsed[0]
        def fullSource = libraryData?.source ?: ""
        def totalLength = fullSource.length()


        def savedToFile = null
        def savedToFileError = null
        if (totalLength > maxChunkSize) {
            def sourceFileName = "mcp-source-library-${libraryId}.groovy"
            try {
                uploadHubFile(sourceFileName, fullSource.getBytes("UTF-8"))
                savedToFile = sourceFileName
                mcpLog("info", "hub-admin", "Saved full library ID ${libraryId} source to File Manager: ${sourceFileName} (${totalLength} chars)")
            } catch (Exception saveErr) {
                savedToFileError = saveErr.message ?: saveErr.toString()
                mcpLog("warn", "hub-admin", "Could not save library source to File Manager: ${savedToFileError}")
            }
        }


        def endIndex = Math.min(requestedOffset + requestedLength, totalLength)
        def chunk = (requestedOffset < totalLength) ? fullSource.substring(requestedOffset, endIndex) : ""
        def hasMore = endIndex < totalLength

        mcpLog("info", "hub-admin", "Retrieved library ID ${libraryId} source: ${totalLength} chars total, returning offset ${requestedOffset}..${endIndex}${hasMore ? ' (more available)' : ''}")

        def result = [
            success: true,
            libraryId: libraryId,
            source: chunk,
            version: libraryData?.version,
            name: libraryData?.name,
            namespace: libraryData?.namespace,
            totalLength: totalLength,
            offset: requestedOffset,
            chunkLength: chunk.length(),
            hasMore: hasMore
        ]
        if (hasMore) {
            result.nextOffset = endIndex
            result.remainingChars = totalLength - endIndex
            result.hint = "Call again with offset: ${endIndex} to get the next chunk."
        }
        if (savedToFile) {
            result.sourceFile = savedToFile
            result.sourceFileHint = "Full source saved to File Manager. Use hub_update_library with sourceFile: '${savedToFile}' to update without cloud size limits."
        }
        if (savedToFileError) {
            result.sourceFileError = "Failed to auto-save full source to File Manager: ${savedToFileError}. Use chunked reads (offset/length) to retrieve the full source."
        }
        return result
    } catch (Exception e) {
        mcpLogError("hub-admin", "Failed to get library source", e)
        return [success: false, error: "Failed to get library source: ${e.message}"]
    }
}

def toolInstallLibrary(args) {
    requireDestructiveConfirm(args.confirm)


    def sourceCode = null
    def sourceMode = null
    def modesSet = [args.sourceFile, args.source, args.importUrl].count { it }
    if (modesSet > 1) {
        throw new IllegalArgumentException("Provide exactly one of 'source', 'sourceFile', or 'importUrl'")
    }
    if (args.sourceFile) {
        sourceMode = "sourceFile"
        mcpLog("info", "hub-admin", "Reading library source from File Manager: ${args.sourceFile}")
        def bytes = downloadHubFile(args.sourceFile)
        if (bytes == null) throw new IllegalArgumentException("Source file '${args.sourceFile}' not found in File Manager")
        sourceCode = new String(bytes, "UTF-8")
        mcpLog("info", "hub-admin", "Read ${sourceCode.length()} chars from ${args.sourceFile}")
    } else if (args.importUrl) {
        sourceMode = "importUrl"
        mcpLog("info", "hub-admin", "Reading library source from importUrl: ${args.importUrl}")
        sourceCode = _fetchSourceFromUrl(args.importUrl)
        mcpLog("info", "hub-admin", "Read ${sourceCode.length()} chars from importUrl")
    } else if (args.source) {
        sourceMode = "source"
        sourceCode = args.source
    } else {
        throw new IllegalArgumentException("One of 'source', 'sourceFile', or 'importUrl' is required")
    }

    mcpLog("info", "hub-admin", "Installing new library (mode: ${sourceMode}, sourceLength: ${sourceCode.length()})")
    try {
        def body = groovy.json.JsonOutput.toJson([id: null, source: sourceCode, version: null])
        def result = hubInternalPostJson("/library/saveOrUpdateJson", body)

        def newLibraryId = result?.id?.toString()
        def newVersion = result?.version

        if (result?.success == false) {
            def msg = result?.message ?: "Hub returned failure"
            mcpLog("warn", "hub-admin", "Library install failed: ${msg}")
            return [
                success: false,
                error: "Library installation failed: ${msg}",
                note: "Check that the Groovy source includes a valid library() definition block and has no syntax errors.",
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
        }





        if (result == null || !newLibraryId) {
            def detail = result == null ? "empty/null response" : "response missing id field"
            mcpLog("warn", "hub-admin", "Library install: hub returned ${detail} -- cannot confirm install")
            return [
                success: false,
                error: "Library install unverified: hub returned ${detail}",
                note: "Check Hubitat web UI (FOR DEVELOPERS > Libraries code) to confirm whether the library was actually persisted. Do NOT retry without checking first -- a duplicate library may result.",
                lastBackup: formatTimestamp(state.lastBackupTimestamp)
            ]
        }

        mcpLog("info", "hub-admin", "Library installed successfully (ID: ${newLibraryId}, version: ${newVersion})")






        def verifyText = null
        def verifyError = null
        try {
            verifyText = hubInternalGet("/hub2/userLibraries")
        } catch (Exception verifyErr) {
            verifyError = verifyErr.message ?: verifyErr.toString()
            mcpLog("warn", "hub-admin", "Library post-install verification fetch failed for ID ${newLibraryId}: ${verifyError}")
        }

        if (verifyError == null) {
            if (!verifyText) {
                mcpLog("warn", "hub-admin", "Library ID ${newLibraryId}: verify endpoint returned empty body -- cannot confirm install")
                return [
                    success: false,
                    error: "Library install unverified: hub returned empty verify body for ID ${newLibraryId}",
                    libraryId: newLibraryId,
                    note: "Hub created a library slot but the verify fetch returned no content. Use hub_get_source(type='library', id=${newLibraryId}) to confirm whether the library persisted. Do NOT retry without checking first -- a duplicate library at a new ID may result.",
                    lastBackup: formatTimestamp(state.lastBackupTimestamp)
                ]
            }
            def libraries
            try {
                libraries = new groovy.json.JsonSlurper().parseText(verifyText)
            } catch (Exception parseErr) {
                mcpLog("warn", "hub-admin", "Library ID ${newLibraryId}: verify body unparseable: ${parseErr.message}")
                return [
                    success: false,
                    error: "Library install unverified: hub returned unparseable verify body for ID ${newLibraryId}",
                    libraryId: newLibraryId,
                    note: "Hub created a library slot but the verify response was not valid JSON. Use hub_get_source(type='library', id=${newLibraryId}) to confirm whether the library persisted. Do NOT retry without checking first -- a duplicate library at a new ID may result.",
                    lastBackup: formatTimestamp(state.lastBackupTimestamp)
                ]
            }
            def found = (libraries instanceof List) && libraries.any { it.id?.toString() == newLibraryId }
            if (!found) {
                mcpLog("warn", "hub-admin", "Library ID ${newLibraryId} not found in post-install library list")
                return [
                    success: false,
                    error: "Library install unverified: ID ${newLibraryId} not found in post-install library list",
                    libraryId: newLibraryId,
                    note: "Hub created a library slot but the verify list did not include it. Use hub_get_source(type='library', id=${newLibraryId}) to confirm. Do NOT retry without checking first -- a duplicate library at a new ID may result.",
                    lastBackup: formatTimestamp(state.lastBackupTimestamp)
                ]
            }
        }

        mcpLog("info", "hub-admin", "Library installed (ID: ${newLibraryId}, mode: ${sourceMode}, verified: ${verifyError == null})")
        def installResult = [
            success: true,
            message: "Library installed successfully",
            libraryId: newLibraryId,
            version: newVersion,
            sourceMode: sourceMode,
            sourceLength: sourceCode.length(),
            verified: (verifyError == null),
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
        if (verifyError != null) installResult.verifyError = "${verifyError} -- use hub_get_source(type='library', id=${newLibraryId}) to confirm."
        return installResult
    } catch (Exception e) {
        mcpLogError("hub-admin", "Library installation failed", e)
        return [
            success: false,
            error: "Library installation failed: ${e.message}",
            note: "Check that the Groovy source includes a valid library() definition block and has no syntax errors."
        ]
    }
}

def toolUpdateLibraryCode(args) {
    requireDestructiveConfirm(args.confirm)
    def libraryId = args.libraryId
    if (!libraryId) throw new IllegalArgumentException("libraryId is required")
    if (!libraryId.toString().isInteger() || libraryId.toString().toInteger() <= 0) throw new IllegalArgumentException("libraryId must be a positive integer (got: '${libraryId}')")




    def sourceCode = null
    def sourceMode = null
    def freshVersion = null
    def modesSet = [args.resave, args.sourceFile, args.source, args.importUrl].count { it }
    if (modesSet > 1) {
        throw new IllegalArgumentException("Provide exactly one of 'source', 'sourceFile', 'importUrl', or 'resave'")
    }

    if (args.resave) {
        sourceMode = "resave"
        mcpLog("info", "hub-admin", "Resave mode: fetching current library ID ${libraryId} source locally")
        def responseText = hubInternalGet("/library/list/single/data/${libraryId}")
        if (!responseText) throw new IllegalArgumentException("Could not fetch current source for library ID ${libraryId}")
        def parsed
        try {
            parsed = new groovy.json.JsonSlurper().parseText(responseText)
        } catch (Exception parseEx) {
            throw new IllegalArgumentException("Could not parse library source response for ID ${libraryId}: ${parseEx.message}")
        }
        if (!(parsed instanceof List) || parsed.isEmpty()) {
            throw new IllegalArgumentException("Library ID ${libraryId} not found")
        }
        def lib = parsed[0]
        sourceCode = lib.source
        freshVersion = lib.version
        if (!sourceCode) throw new IllegalArgumentException("Library ID ${libraryId} has no source to resave")
    } else if (args.sourceFile) {
        sourceMode = "sourceFile"
        mcpLog("info", "hub-admin", "Reading library source from File Manager: ${args.sourceFile}")
        def bytes = downloadHubFile(args.sourceFile)
        if (bytes == null) throw new IllegalArgumentException("Source file '${args.sourceFile}' not found in File Manager")
        sourceCode = new String(bytes, "UTF-8")
        mcpLog("info", "hub-admin", "Read ${sourceCode.length()} chars from ${args.sourceFile}")
    } else if (args.importUrl) {
        sourceMode = "importUrl"
        mcpLog("info", "hub-admin", "Reading library source from importUrl: ${args.importUrl}")
        sourceCode = _fetchSourceFromUrl(args.importUrl)
        mcpLog("info", "hub-admin", "Read ${sourceCode.length()} chars from importUrl")
    } else if (args.source) {
        sourceMode = "source"
        sourceCode = args.source
    } else {
        throw new IllegalArgumentException("One of 'source', 'sourceFile', 'importUrl', or 'resave' is required")
    }





    def backupFileName = null
    def existingEntry = null
    def backupEntry = null


    _withBackupLock("update library ${libraryId}") {
        existingEntry = _reusableItemBackup(_itemBackupManifest(), "library_${libraryId}".toString(), "Library")
        if (existingEntry != null) {
            backupFileName = existingEntry.fileName
        } else {



            backupEntry = backupLibrarySource(libraryId.toString())
            backupFileName = backupEntry.fileName
        }
    }
    def skipBackup = backupEntry == null

    def versionFetchError = null
    if (skipBackup) {


        if (freshVersion == null) {
            try {
                def versionText = hubInternalGet("/library/list/single/data/${libraryId}")
                if (versionText) {
                    def versionParsed = new groovy.json.JsonSlurper().parseText(versionText)
                    if (versionParsed instanceof List && !versionParsed.isEmpty()) {
                        freshVersion = versionParsed[0]?.version
                    }
                }
            } catch (Exception vErr) {
                versionFetchError = vErr.message ?: vErr.toString()
                mcpLog("warn", "hub-admin", "Could not fetch fresh version for library ID ${libraryId}, falling back to backup version: ${versionFetchError}")
            }

            if (freshVersion == null) freshVersion = existingEntry.version
        }
    } else if (freshVersion == null) {
        freshVersion = backupEntry.version
    }

    if (freshVersion == null) {



        throw new IllegalArgumentException("Could not determine current version for library ID ${libraryId} -- version fetch failed (${versionFetchError ?: 'unknown'}) and cached backup has no version. Check that the library exists.")
    }
    def currentVersion = freshVersion

    mcpLog("info", "hub-admin", "Updating library ID: ${libraryId} (version: ${currentVersion}, mode: ${sourceMode}, sourceLength: ${sourceCode.length()})")
    try {
        def body = groovy.json.JsonOutput.toJson([id: libraryId as Integer, source: sourceCode, version: currentVersion as Integer])
        def result = hubInternalPostJson("/library/saveOrUpdateJson", body)

        if (result?.success == false) {
            def msg = result?.message ?: "Hub returned failure"
            mcpLog("warn", "hub-admin", "Library update failed: ${msg}")
            return [
                success: false,
                error: "Library update failed: ${msg}",
                libraryId: libraryId,
                note: "Check the Groovy source code for syntax errors or compilation issues."
            ]
        }

        mcpLog("info", "hub-admin", "Library ID ${libraryId} updated successfully (mode: ${sourceMode})")
        def successResult = [
            success: true,
            message: "Library code updated successfully",
            libraryId: libraryId,
            previousVersion: currentVersion,
            newVersion: result?.version,
            sourceMode: sourceMode,
            sourceLength: sourceCode.length(),
            lastBackup: formatTimestamp(state.lastBackupTimestamp)
        ]
        if (sourceMode == "resave") successResult.note = "Source was fetched and re-saved entirely on-hub -- no cloud round-trip."
        if (sourceMode == "sourceFile") successResult.note = "Source was read from File Manager file '${args.sourceFile}' -- no cloud size limits."
        return successResult
    } catch (Exception e) {
        mcpLogError("hub-admin", "Library update failed", e)
        return [success: false, error: "Library update failed: ${e.message}"]
    }
}

def toolDeleteLibrary(args) {
    requireDestructiveConfirm(args.confirm)
    def libraryId = args.libraryId
    if (!libraryId) throw new IllegalArgumentException("libraryId is required")
    if (!libraryId.toString().isInteger() || libraryId.toString().toInteger() <= 0) throw new IllegalArgumentException("libraryId must be a positive integer (got: '${libraryId}')")


    def backupSucceeded = false
    def backupFileName = null
    try {
        def backupEntry = backupLibrarySource(libraryId.toString())
        backupFileName = backupEntry.fileName
        backupSucceeded = true
    } catch (Exception backupErr) {
        mcpLog("warn", "hub-admin", "Pre-delete backup failed for library ${libraryId}: ${backupErr.message} -- proceeding with delete")
    }

    mcpLog("warn", "hub-admin", "Deleting library ID: ${libraryId}")
    try {
        def responseText = hubInternalGet("/library/edit/deleteJson/${libraryId}")
        mcpLog("debug", "hub-admin", "Delete library ${libraryId} response: ${responseText?.take(200)}")





        def success = false
        if (responseText) {
            try {
                def parsed = new groovy.json.JsonSlurper().parseText(responseText)

                if (parsed?.success == true) {
                    success = true
                } else {
                    def hubMsg = parsed?.message ?: parsed?.error ?: "Hub returned success=false"
                    mcpLog("warn", "hub-admin", "Delete library ${libraryId}: hub indicated failure: ${hubMsg}")
                    return [
                        success: false,
                        error: hubMsg,
                        libraryId: libraryId,
                        note: "Hub rejected the delete request. If the library is in use, remove all #include references from apps and drivers before deleting."
                    ]
                }
            } catch (Exception parseErr) {
                mcpLog("warn", "hub-admin", "Delete library ${libraryId}: response not parseable as JSON -- treating as failure. Response: ${responseText?.take(200)}")
                return [
                    success: false,
                    error: "Delete response was not valid JSON -- cannot confirm deletion. Response: ${responseText?.take(200)}",
                    libraryId: libraryId,
                    note: "Check Hubitat web UI (FOR DEVELOPERS > Libraries code) to verify whether the library was deleted."
                ]
            }
        }

        if (success) {
            mcpLog("info", "hub-admin", "Library ID ${libraryId} deleted successfully")
            def backupEntry = (_itemBackupManifest())?.get("library_${libraryId}".toString())
            def result = [
                success: true,
                message: backupSucceeded ? "Library deleted successfully. Source code backed up to File Manager." : "Library deleted successfully. WARNING: Pre-delete backup failed -- source code may not be recoverable.",
                libraryId: libraryId,
                lastBackup: formatTimestamp(state.lastBackupTimestamp),
                backupFile: backupEntry?.fileName ?: backupFileName,
                restoreHint: backupEntry ? "To restore: use 'hub_create_library' with the backup source, or download ${backupEntry.fileName} from Hubitat > Settings > File Manager and re-install manually." : null
            ]
            if (!backupSucceeded) result.backupWarning = "Pre-delete backup could not be created. The source code may be permanently lost."
            return result
        } else {
            return [
                success: false,
                error: "Delete may have failed - check the Hubitat web UI (FOR DEVELOPERS > Libraries code) to verify",
                libraryId: libraryId,
                response: responseText?.take(500)
            ]
        }
    } catch (Exception e) {
        mcpLogError("hub-admin", "Library deletion failed", e)
        return [success: false, error: "Library deletion failed: ${e.message}"]
    }
}

def toolListInstalledApps(args) {
    def filter = args?.filter ?: "all"
    def includeHidden = args?.includeHidden == true
    def cursor = args?.cursor

    def validFilters = ["all", "builtin", "user", "disabled", "parents", "children"]
    if (!validFilters.contains(filter)) {
        throw new IllegalArgumentException("Invalid filter '${filter}'. Must be one of: ${validFilters.join(', ')}")
    }

    try {

        Map pendingBefore = null
        try { pendingBefore = _rmPendingPredClearSnapshot() }
        catch (Exception snapshotError) { mcpLog("warn", "rm-native", "Recovery-record snapshot unavailable; skipping reconciliation for this listing: ${snapshotError.message}") }
        def responseText = hubInternalGet("/hub2/appsList")
        if (!responseText) {
            return [success: false, error: "Empty response from /hub2/appsList", note: "Hub internal API may be transiently unavailable."]
        }
        def parsed
        try {
            parsed = new groovy.json.JsonSlurper().parseText(responseText)
        } catch (Exception parseErr) {
            return [success: false, error: "Failed to parse /hub2/appsList response: ${parseErr.message}", note: "Hubitat firmware may have changed the endpoint format."]
        }
        try { _rmReconcilePredClearPending(parsed, pendingBefore) }
        catch (Exception reconcileError) { mcpLog("error", "rm-native", "Could not reconcile deleted-app recovery records during hub_list_apps; records are unchanged: ${reconcileError.message}") }
        def apps = parsed?.apps ?: []







        def flat = []
        def recurse
        recurse = { Map node, parentId ->
            def d = node?.data ?: [:]
            def isHidden = d.hidden == true
            def included = includeHidden || !isHidden
            if (included) {
                flat << [
                    id: d.id,


                    name: stripAppConfigHtml(d.name),
                    type: d.type,
                    disabled: d.disabled == true,
                    user: d.user == true,
                    hidden: isHidden,
                    parentId: parentId,
                    hasChildren: (node?.children?.size() ?: 0) > 0,
                    childCount: node?.children?.size() ?: 0
                ]
            }
            def childParentId = included ? d.id : parentId
            node?.children?.each { c -> recurse(c, childParentId) }
        }
        apps.each { a -> recurse(a, null) }

        def filtered = flat.findAll { entry ->
            switch (filter) {
                case "all": return true
                case "builtin": return !entry.user
                case "user": return entry.user
                case "disabled": return entry.disabled
                case "parents": return entry.hasChildren
                case "children": return entry.parentId != null
                default:



                    throw new IllegalStateException("filter branch missing for '${filter}' -- validFilters and switch have drifted")
            }
        }

        def paged = _paginateList(filtered, cursor, 50, "hub_list_apps")
        def result = [
            apps: paged.page,
            count: paged.page.size(),
            filter: filter,
            totalOnHub: flat.size()
        ]
        if (cursor != null) {
            result.total = filtered.size()
            if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
        }
        return result
    } catch (IllegalArgumentException e) {
        throw e  // let cursor / arg-validation surface as a validation result; don't reframe as transport failure
    } catch (IllegalStateException e) {



        mcpLogError("installed-apps", "hub_list_apps internal invariant violated", e)
        throw e
    } catch (Exception e) {





        mcpLogError("installed-apps", "hub_list_apps failed", e)
        return [success: false, error: "Failed to list installed apps: ${e.message}", note: "Hub transport error or unexpected /hub2/appsList response shape -- retry; if persistent, inspect the raw response for firmware-side drift."]
    }
}

def toolGetDeviceInUseBy(args) {
    if (!args?.deviceId) throw new IllegalArgumentException("deviceId is required")
    def deviceId = args.deviceId.toString().trim()
    boolean listed = _requireDeviceToolAccess(deviceId)

    try {
        def responseText = hubInternalGet("/device/fullJson/${deviceId}")
        if (!responseText) {
            return [success: false, error: "Empty response from /device/fullJson/${deviceId}", note: "Device ID may not exist."]
        }
        def parsed
        try {
            parsed = new groovy.json.JsonSlurper().parseText(responseText)
        } catch (Exception parseErr) {
            return [success: false, error: "Failed to parse device JSON: ${parseErr.message}", note: "Device ID '${deviceId}' may not exist, or firmware changed the endpoint format."]
        }



        if (!(parsed instanceof Map) || (!listed &&
            (!(parsed.device instanceof Map) || parsed.device.id?.toString() != deviceId))) {
            return [success: false, deviceId: deviceId,
                    error: "Device metadata could not be verified for ${deviceId}.",
                    note: "Verify the device exists in the native Devices page and retry."]
        }






        if (parsed?.appsUsing != null && !(parsed.appsUsing instanceof List)) {
            String shape = (parsed.appsUsing instanceof Map) ? "Map" :
                           (parsed.appsUsing instanceof String) ? "String" :
                           (parsed.appsUsing instanceof Number) ? "Number" : "non-list"
            mcpLog("warn", "installed-apps", "hub_list_device_dependents: appsUsing is ${shape} not List for device ${deviceId} -- treating as empty")
            return [success: false, deviceId: deviceId, error: "Firmware returned unexpected appsUsing shape: ${shape}", note: "Hub firmware may have changed the /device/fullJson endpoint contract."]
        }
        def appsUsing = parsed?.appsUsing ?: []
        def count
        try {
            count = (parsed?.appsUsingCount != null) ? (parsed.appsUsingCount as Integer) : appsUsing.size()
        } catch (NumberFormatException ne) {



            mcpLog("warn", "installed-apps", "hub_list_device_dependents: non-numeric appsUsingCount '${parsed?.appsUsingCount}' for device ${deviceId}; using appsUsing.size()=${appsUsing.size()}")
            count = appsUsing.size()
        }

        def appsUsingList = appsUsing.collect { a ->
            [
                id: a?.id,
                name: a?.name,         // app type name (e.g. "Room Lights", "Rule-5.1")
                label: a?.label,       // user-visible label, may include HTML decoration
                trueLabel: a?.trueLabel,  // label stripped of HTML (null if same as label)
                disabled: a?.disabled == true
            ]
        }
        def cursor = args?.cursor
        def paged = _paginateList(appsUsingList, cursor, 100, "hub_list_device_dependents")
        def result = [
            deviceId: deviceId,



            deviceName: parsed?.extraBreadcrumb ?: parsed?.name ?: parsed?.label,
            appsUsing: paged.page,
            count: count,
            parentApp: parsed?.parentApp
        ]



        if (count != appsUsingList.size()) {
            result.countMismatch = "appsUsingCount=${count} but appsUsing array carries ${appsUsingList.size()} entries -- firmware may be truncating"
        }
        if (cursor != null) {
            result.total = appsUsingList.size()
            if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
        }
        return result
    } catch (Exception e) {
        mcpLogError("installed-apps", "hub_list_device_dependents failed for device ${deviceId}", e)
        return [success: false, error: "Failed: ${e.message}", note: "Verify the device ID is valid and the Read master is enabled."]
    }
}

def _getAllToolDefinitions_partCodeManagement() {
    return [


        [
            name: "hub_list_apps",
            description: """List apps on the hub — running instances or installed app code/types (see scope). Per-app event history: hub_list_device_events with appId. Requires the Read master.""",
            inputSchema: [
                type: "object",
                properties: [
                    scope: [type: "string", enum: ["instances", "types"], description: "What to list. 'instances' (default) = running app instances with parent/child tree; 'types' = installed app code library / available app types.", default: "instances"],
                    filter: [type: "string", enum: ["all", "builtin", "user", "disabled", "parents", "children"], description: "scope='instances' only: category filter."],
                    includeHidden: [type: "boolean", description: "scope='instances' only: include hidden apps (typically Hubitat internal). Default: false", default: false],
                    cursor: [type: "string", description: "Opt-in pagination cursor. Omit for unbounded (subject to 120KB guard); pass \"\" for the first page, iterate nextCursor (page size 50)."]
                ]
            ]
        ],
        [
            name: "hub_list_drivers",
            description: "List device driver types on the hub. Requires Read master.",
            inputSchema: [
                type: "object",
                properties: [
                    include: [type: "string", enum: ["user", "all"], description: "Scope: 'user' (default) = user-installed drivers only; 'all' = full catalog (system + virtual + user)."],
                    cursor: [type: "string", description: "Opt-in pagination cursor. Omit for unbounded; pass \"\" for the first page, iterate nextCursor (page size 50)."]
                ]
            ]
        ],
        [
            name: "hub_list_libraries",
            description: "List all Groovy libraries installed on the hub (id, name, namespace, version). Use this to discover a library's id, then read its source with hub_get_source(type='library', id=N); the source is omitted here to keep the list lean. Requires Read master.",
            inputSchema: [
                type: "object",
                properties: [
                    cursor: [type: "string", description: "Opt-in pagination cursor. Omit for unbounded; pass \"\" for the first page, iterate nextCursor (page size 50)."]
                ]
            ]
        ],

        [
            name: "hub_get_source",
            description: "Get the Groovy source of an installed app, driver, or library. Supports chunked reading (offset/length); large sources are auto-saved to the File Manager for use with the matching update tool's sourceFile mode. Requires Read master.",
            inputSchema: [
                type: "object",
                properties: [
                    type: [type: "string", enum: ["app", "driver", "library"], description: "What kind of code to read."],
                    id: [type: "string", description: "App/driver/library ID (positive integer), from hub_list_apps / hub_list_drivers / hub_list_libraries respectively (library id is also in a hub_create_library response or the Hubitat Libraries code page)."],
                    offset: [type: "integer", description: "Char offset to start reading from. Default: 0"],
                    length: [type: "integer", description: "Max characters to return in this chunk. Default/max: 64000"]
                ],
                required: ["type", "id"]
            ]
        ],

        [
            name: "hub_create_app",
            description: """⚠️ Install new app. Show code to user and get confirmation first.

Supply the code via exactly one of source / sourceFile / importUrl (mutually exclusive; see each param).

[[FLAT_TRIM]]
After the code installs, create a running instance with a SECOND call: hub_create_app(codeAppId: <newAppId>, confirm: true).
[[/FLAT_TRIM]]

Verifies the install compiled -- returns success=false with the error if it didn't. Requires Write master + confirm + backup <24h. Returns the new app ID.
[[FLAT_TRIM]]
A transport drop can lose the response while the hub still commits this write; verify current hub state before retrying. See hub_get_tool_guide(section='slow_ops').
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    source: [type: "string", description: "Inline Groovy source (stubs only)."],
                    sourceFile: [type: "string", description: "File Manager filename (write it first via hub_write_file), e.g. my-app.groovy."],
                    importUrl: [type: "string", description: "URL the hub fetches directly (http/https)."],
                    codeAppId: [type: "integer", description: "Second-step mode: instantiate already-installed code (codeAppId from a prior call) and commit the install; not combinable with source/sourceFile/importUrl."],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms backup was created and user approved."],
                ],
                required: ["confirm"]
            ]
        ],
        [
            name: "hub_create_driver",
            description: """⚠️ Install new driver. Show code to user and get confirmation first.

Supply the code via exactly one of source / sourceFile / importUrl (mutually exclusive; see each param). For >1 driver use BULK mode (the installs param).

Verifies the install compiled: returns success=false with the error if the hub accepted the request but the driver failed to compile. Requires Write master + confirm + backup <24h. Returns new driver ID(s).
[[FLAT_TRIM]]
MCP 2026-07-28 clients automatically continue this slow write and can replay its retained terminal response. Older clients can still lose the response on a transport drop; verify current hub state before retrying. See hub_get_tool_guide(section='slow_ops').
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    source: [type: "string", description: "Inline Groovy source (stubs only)."],
                    sourceFile: [type: "string", description: "File Manager filename (write it first via hub_write_file), e.g. my-code.groovy."],
                    importUrl: [type: "string", description: "URL the hub fetches directly (http/https)."],
                    installs: [
                        type: "array",
                        description: "Bulk mode: one round-trip for many drivers. Each entry {source|sourceFile|importUrl}; cannot mix with single-driver fields; continue-on-error.",
                        items: [
                            type: "object",
                            properties: [
                                sourceFile: [type: "string", description: "File Manager filename (preferred)."],
                                source: [type: "string", description: "Inline source (stubs only)."],
                                importUrl: [type: "string", description: "URL the hub fetches directly."]
                            ]
                        ]
                    ],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms backup was created and user approved."],
                ],
                required: ["confirm"]
            ]
        ],
        [
            name: "hub_update_app",
            description: """⚠️ CRITICAL: Modify existing app code. Read current source first, explain changes, get confirmation.

Supply the new code via exactly one of source / sourceFile / importUrl, or resave to recompile in place (see each param). Optionally enable OAuth via the oauth param (apps only), alone or alongside a source change.

Auto-backs up before modifying. Requires Write master + confirm + backup <24h.[[FLAT_TRIM]]

Self-update guard: refuses to overwrite the MCP server's own app source or OAuth unless Developer Mode is on.[[/FLAT_TRIM]]
[[FLAT_TRIM]]
A transport drop can lose the response while the hub still commits this write; verify current hub state before retrying. See hub_get_tool_guide(section='slow_ops').
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    appId: [type: "string", description: "The app ID (Apps Code id) to update"],
                    source: [type: "string", description: "Inline Groovy source (stubs only)."],
                    sourceFile: [type: "string", description: "File Manager filename (write it first via hub_write_file), e.g. my-code.groovy."],
                    importUrl: [type: "string", description: "URL the hub fetches directly (http/https)."],
                    resave: [type: "boolean", description: "Re-save the current source without changes; runs entirely on-hub."],
                    expectedVersion: [type: "integer", description: "OPTIONAL optimistic-lock guard; aborts with conflict:true on mismatch.[[FLAT_TRIM]] Stringified integers coerced; explicit null rejected.[[/FLAT_TRIM]]"],
                    triggerUpdated: [type: "integer", description: "OPTIONAL: running instance appId to fire updated() on after the code save, so its subscriptions/schedules/atomicState re-initialize against the new code. Mechanically this submits the app's mainPage 'Done' form, which RE-SENDS EVERY input on that page -- the tool rebuilds them from the instance's live settings so nothing is blanked, and REFUSES to submit (updatedFired:false, partial:true) if it cannot read them, rather than risk clearing device selections. On failure the code save still stands: success stays true with partial:true, updatedFired:false and repairHints. Omit it to match what the hub's own editor Save does (no lifecycle call)."],
                    oauth: [type: "object", description: "OPTIONAL: enable/configure OAuth on this app (apps only); e.g. {enabled:true}. Full shape: hub_get_tool_guide(section='hub_admin_write_code')."],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms backup was created and user approved."],
                ],
                required: ["appId", "confirm"]
            ]
        ],
        [
            name: "hub_update_driver",
            description: """⚠️ CRITICAL: Modify existing driver code. Read current source first, explain changes, get confirmation.

Supply the new code via exactly one of source / sourceFile / importUrl, or resave to recompile in place (see each param). For >1 driver use BULK mode (the updates param).

Auto-backs up before modifying. Requires Write master + confirm + backup <24h.
[[FLAT_TRIM]]
MCP 2026-07-28 clients automatically continue this slow write and can replay its retained terminal response. Older clients can still lose the response on a transport drop; verify current hub state before retrying. See hub_get_tool_guide(section='slow_ops').
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    driverId: [type: "string", description: "The driver ID to update (single-driver mode). Omit when using 'updates' array."],
                    source: [type: "string", description: "Inline Groovy source (stubs only)."],
                    sourceFile: [type: "string", description: "File Manager filename (write it first via hub_write_file), e.g. my-code.groovy."],
                    importUrl: [type: "string", description: "URL the hub fetches directly (http/https)."],
                    resave: [type: "boolean", description: "Re-save the current source without changes. Runs entirely on-hub."],
                    expectedVersion: [type: "integer", description: "Optional optimistic-lock guard; aborts with conflict:true on mismatch.[[FLAT_TRIM]] In bulk mode, put it inside each updates[] entry.[[/FLAT_TRIM]]"],
                    updates: [
                        type: "array",
                        description: "Bulk mode: one round-trip for many drivers. Each entry {driverId, sourceFile|source|importUrl|resave, optional expectedVersion}; cannot mix with single-driver fields; continue-on-error.",
                        items: [
                            type: "object",
                            properties: [
                                driverId: [type: "string", description: "The driver ID to update"],
                                sourceFile: [type: "string", description: "File Manager filename (preferred)."],
                                source: [type: "string", description: "Inline source (stubs only)."],
                                importUrl: [type: "string", description: "URL the hub fetches directly."],
                                resave: [type: "boolean", description: "Re-save without changes."],
                                expectedVersion: [type: "integer", description: "OPTIONAL optimistic-lock guard for this item only."]
                            ],
                            required: ["driverId"]
                        ]
                    ],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms backup was created and user approved."],
                ],
                required: ["confirm"]
            ]
        ],
        [
            name: "hub_delete_item",
            description: """⚠️ DESTRUCTIVE: Permanently delete an app, driver, or library. Auto-backs up the source before deletion.

[[FLAT_TRIM]]
Pre-flight by type: apps -- remove app instances via the Hubitat UI first; drivers -- switch any devices to a different driver first; libraries -- ensure no apps/drivers still #include it (else compile errors).
[[/FLAT_TRIM]]

Tell the user the item name/ID, warn it's permanent, get confirmation. Requires Write master + confirm + backup <24h.
[[FLAT_TRIM]]
For type=driver, MCP 2026-07-28 clients automatically continue this slow write and can replay its retained terminal response. Other item types and older clients can still lose the response on a transport drop; verify current hub state before retrying. See hub_get_tool_guide(section='slow_ops').
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    type: [type: "string", enum: ["app", "driver", "library"], description: "What to delete."],
                    item_id: [type: "string", description: "The app/driver/library ID to delete."],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms backup was created and user approved."]
                ],
                required: ["type", "item_id", "confirm"]
            ]
        ],

        [
            name: "hub_create_library",
            description: """⚠️ Install new Groovy library code. Libraries are #include'd by drivers/apps. Show code to user and get confirmation first.

Provide exactly one of source / sourceFile / importUrl (see each param).

Source must include a library() block with name/namespace/author/description (all required). The hub does NOT compile-check libraries at install -- syntax errors surface only when an app/driver #includes it. Requires Write master + confirm + backup <24h. Returns new libraryId.
[[FLAT_TRIM]]
A transport drop can lose the response while the hub still commits this write; verify current hub state before retrying. See hub_get_tool_guide(section='slow_ops').
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    source: [type: "string", description: "Inline source (stubs only)."],
                    sourceFile: [type: "string", description: "File Manager filename (write it first via hub_write_file), e.g. my-code.groovy."],
                    importUrl: [type: "string", description: "URL the hub fetches directly (http/https)."],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms backup was created and user approved."],
                ],
                required: ["confirm"]
            ]
        ],
        [
            name: "hub_update_library",
            description: """⚠️ CRITICAL: Modify existing library code. Read current source first, explain changes, get confirmation.

Supply the new code via exactly one of source / sourceFile / importUrl, or resave to recompile in place (see each param). Not compile-checked at save (see hub_create_library).

Auto-backs up before modifying. Requires Write master + confirm + backup <24h.
[[FLAT_TRIM]]
A transport drop can lose the response while the hub still commits this write; verify current hub state before retrying. See hub_get_tool_guide(section='slow_ops').
[[/FLAT_TRIM]]
""",
            inputSchema: [
                type: "object",
                properties: [
                    libraryId: [type: "string", description: "The library ID to update"],
                    source: [type: "string", description: "Inline source (stubs only)."],
                    sourceFile: [type: "string", description: "File Manager filename (write it first via hub_write_file), e.g. my-code.groovy."],
                    importUrl: [type: "string", description: "URL the hub fetches directly (http/https)."],
                    resave: [type: "boolean", description: "Re-save the current source without changes. Runs entirely on-hub."],
                    confirm: [type: "boolean", description: "REQUIRED: Must be true. Confirms backup was created and user approved."],
                ],
                required: ["libraryId", "confirm"]
            ]
        ],

        [
            name: "hub_get_app_config",
            description: """Read an installed app's configuration — the structured data the Hubitat Web UI shows on an app's settings page. Works for any legacy SmartApp (Rule Machine rules, Room Lighting, Basic Rules, HPM, Mode Manager, etc.). Read-only.

Returns the app's identity plus its current config page (sections, inputs, current values) and `embeddedActions` — clickable RM wizard buttons hub_set_rule can drive. Multi-page apps (e.g. RM 5.1): pass pageName; call hub_list_app_pages to discover sub-page names.

Get appId from hub_list_apps (scope='instances') or hub_list_rules.[[FLAT_TRIM]] For RM rules use hub_list_rules, NOT hub_get_custom_rule (which only handles MCP-native rules).[[/FLAT_TRIM]] Requires Read master.""",
            inputSchema: [
                type: "object",
                properties: [
                    appId: [type: "string", description: "Installed-app ID (decimal). From hub_list_apps (scope='instances'), hub_list_rules, or the numeric id in the Hubitat UI URL (/installedapp/configure/<id>)."],
                    pageName: [type: "string", description: "Optional sub-page name for multi-page apps; main page when omitted. Call hub_list_app_pages to discover available names."],
                    includeSettings: [type: "boolean", description: "Include the raw app-internal settings key-value map (default false). Set true only for power-user inspection.", default: false],
                    summary: [type: "boolean", description: "Fast identity-only read: returns the thin app record (id, name, type, disabled, user), no config page; pageName/includeSettings ignored.", default: false]
                ],
                required: ["appId"]
            ]
        ],

        [
            name: "hub_list_app_pages",
            description: """List page names for a multi-page installed app: the live-introspected primary page plus a curated directory of sub-pages for well-known app types (HPM, Rule Machine, Room Lighting, Mode Manager).[[FLAT_TRIM]] Unknown app types return the primary page only, with a note to consult the app's source or Web UI for other page names.[[/FLAT_TRIM]]

Use before hub_get_app_config on multi-page apps to avoid guessing page names. Requires Read master.""",
            inputSchema: [
                type: "object",
                properties: [
                    appId: [type: "string", description: "Installed-app ID (decimal). From hub_list_apps (scope='instances'), hub_list_rules, or the Hubitat UI URL (/installedapp/configure/<id>)."]
                ],
                required: ["appId"]
            ]
        ],

        [
            name: "hub_list_device_dependents",
            description: """List all apps that reference a specific device[[FLAT_TRIM]] (Room Lighting instances, Rule Machine rules, Groups and Scenes, Mode Manager, dashboards, Maker API, Echo Skill, etc.)[[/FLAT_TRIM]] — critical before device cleanup, troubleshooting, or reassignment. Requires the Read master.""",
            inputSchema: [
                type: "object",
                properties: [
                    deviceId: [type: "string", description: "Device ID from hub_list_devices"],
                    cursor: [type: "string", description: "Opt-in pagination cursor for the appsUsing list. Omit for unbounded; pass \"\" for the first page, iterate nextCursor (page size 100)."]
                ],
                required: ["deviceId"]
            ]
        ],
    ]
}

def _readOnlyToolNames_partCodeManagement() {



    return [

        "hub_list_apps", "hub_list_drivers", "hub_list_libraries", "hub_get_source",

        "hub_list_device_dependents", "hub_get_app_config", "hub_list_app_pages"
    ]
}

def _idempotentWriteToolNames_partCodeManagement() {


    return [

        "hub_update_app", "hub_update_driver", "hub_update_library", "hub_delete_item"
    ]
}

def _openWorldToolNames_partCodeManagement() {


    return [
        "hub_create_app", "hub_create_driver", "hub_create_library", "hub_update_app", "hub_update_driver", "hub_update_library"
    ]
}

def _toolDisplayMeta_partCodeManagement() {


    return [

        hub_list_apps: [title: "List Apps", summary: "List installed app types or enumerate app instances."],
        hub_list_drivers: [title: "List Drivers", summary: "List all installed drivers."],
        hub_list_libraries: [title: "List Libraries", summary: "List installed Groovy libraries."],
        hub_get_source: [title: "Get Source Code", summary: "Read Groovy source for an app, driver, or library."],
        hub_create_app: [title: "Install App", summary: "Install a new app from source, a File Manager file, or a URL, or instantiate installed app code."],
        hub_create_driver: [title: "Install Driver", summary: "Install one or more drivers from source, File Manager files, or a URL."],
        hub_update_app: [title: "Update App Code", summary: "Modify an existing app's source code, or enable/configure its OAuth (client id/secret)."],
        hub_update_driver: [title: "Update Driver Code", summary: "Modify an existing driver's source code."],
        hub_create_library: [title: "Install Library", summary: "Install a new Groovy library."],
        hub_update_library: [title: "Update Library Code", summary: "Modify an existing library's source code."],
        hub_delete_item: [title: "Delete Code Item", summary: "Permanently delete an app, driver, or library (auto-backs up first)."],
        hub_list_device_dependents: [title: "List Device Dependents", summary: "Find all apps that reference a device."],
        hub_get_app_config: [title: "Get App Configuration", summary: "Read an installed app's configuration page."],
        hub_list_app_pages: [title: "List App Pages", summary: "List known page names for a multi-page app."]
    ]
}
