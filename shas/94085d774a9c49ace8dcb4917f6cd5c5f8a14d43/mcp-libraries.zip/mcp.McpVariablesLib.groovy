library(name: "McpVariablesLib", namespace: "mcp", author: "kingpanther13", description: "Hub variable + connector tool implementations (list/get/set/create/delete variables, connectors, change history) plus the variable event-subscription handlers for the MCP Rule Server; #include'd by the main app. Gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")
// Developer comments are blanked in this hub copy so the hub's code pages stay fast -- Groovy discards them anyway. Below this line, a line number here is the repository file's plus one. Full source: https://github.com/kingpanther13/Hubitat-local-MCP-server/blob/main/libraries/mcp-variables-lib.groovy

private void _refreshHubVarInUseRegistrations() {
    Set<String> currentVars = [] as Set
    Set<String> hubVarNames
    try {
        hubVarNames = (getAllGlobalVars()?.keySet() ?: []) as Set<String>
    } catch (Exception e) {



        mcpLog("error", "hub-vars",
            "_refreshHubVarInUseRegistrations: getAllGlobalVars failed (${e.class.simpleName}: ${e.message}) -- " +
            "in-use safety registrations are STALE. hub_delete_variable's hub-side warning may not fire until " +
            "this transient failure resolves and updated() re-runs the refresh.")
        return
    }
    if (!hubVarNames) {

        def previous = (atomicState.inUseHubVars ?: []) as List<String>
        previous.each { name ->
            try { removeInUseGlobalVar(name) } catch (Exception e) { /* idempotent */ }
        }
        atomicState.inUseHubVars = []
        return
    }
    try {
        getChildApps()?.each { child ->
            def ruleData = null
            try { ruleData = child.getRuleData() } catch (Exception e) { /* not an MCP rule child */ }
            if (ruleData) {
                def serialized = groovy.json.JsonOutput.toJson(ruleData)
                hubVarNames.each { varName ->




                    def needle = "\"${varName}\""
                    if (serialized?.contains(needle)) {
                        currentVars << varName
                    }
                }
            }
        }
    } catch (Exception e) {
        logDebug("_refreshHubVarInUseRegistrations: getChildApps() scan failed: ${e.class.simpleName}: ${e.message}")
        return
    }

    def previous = ((atomicState.inUseHubVars ?: []) as List<String>) as Set<String>
    def toAdd = currentVars - previous
    def toRemove = previous - currentVars

    toAdd.each { name ->



        try { addInUseGlobalVar(name) }
        catch (Exception e) { mcpLogError("hub-vars", "addInUseGlobalVar('${name}') failed -- in-use safety warning will not surface for this var", e) }
    }
    toRemove.each { name ->
        try { removeInUseGlobalVar(name) }
        catch (Exception e) { mcpLogError("hub-vars", "removeInUseGlobalVar('${name}') failed -- stale in-use registration will linger", e) }
    }

    atomicState.inUseHubVars = (currentVars as List).sort()
    if (toAdd || toRemove) {
        mcpLog("info", "hub-vars", "in-use registrations refreshed: added=${toAdd.sort()}, removed=${toRemove.sort()}, total=${currentVars.size()}")
    }
}

private void _subscribeToAllHubVariables() {
    def vars
    try { vars = getAllGlobalVars() }
    catch (Exception e) {
        logDebug("_subscribeToAllHubVariables: getAllGlobalVars threw ${e.class.simpleName}: ${e.message}")
        return
    }
    if (location == null) return  // unit-test environment safety
    vars?.keySet()?.each { varName ->
        try {
            subscribe(location, "variable:${varName}", "handleHubVariableEvent")
        } catch (Throwable e) {







            mcpLog("error", "hub-vars", "subscribe to variable:${varName} failed: ${e.message} -- hub_list_variable_changes will not capture changes for this var")
        }
    }
}

def renameVariable(String oldName, String newName) {
    mcpLog("info", "hub-vars", "renameVariable callback: '${oldName}' -> '${newName}'")
    def history = atomicState.variableHistory ?: []
    def rewrote = false
    history = history.collect { entry ->
        if (entry?.name == oldName) {
            rewrote = true


            return entry + [name: newName]
        }
        return entry
    }
    if (rewrote) atomicState.variableHistory = history







    if (location != null) {
        try { subscribe(location, "variable:${newName}", "handleHubVariableEvent") }
        catch (Throwable e) {
            mcpLog("error", "hub-vars", "post-rename subscribe to variable:${newName} failed: ${e.message} -- history capture for renamed var will lag until next initialize()")
        }
    }
}

def handleHubVariableEvent(evt) {
    if (evt == null) return
    def varName = evt.name?.toString()
    if (varName?.startsWith("variable:")) {
        varName = varName.substring("variable:".length())
    }
    if (!varName) return

    def entry = [
        name: varName,
        value: evt.value,
        timestamp: now(),
        descriptionText: evt.descriptionText?.toString()
    ]




    def history = atomicState.variableHistory ?: []
    history << entry



    def cap = 200
    if (history.size() > cap) {
        history = history[(history.size() - cap)..-1]
    }
    atomicState.variableHistory = history
}

def toolGetVariableHistory(args) {
    def history = atomicState.variableHistory ?: []
    def filtered = history
    if (args?.name) {
        def n = args.name.toString()
        filtered = filtered.findAll { it?.name == n }
    }
    if (args?.sinceMs != null) {
        def since = args.sinceMs as Long
        filtered = filtered.findAll { (it?.timestamp ?: 0L) >= since }
    }
    def limit = (args?.limit != null) ? (args.limit as Integer) : 50
    if (limit < 1) limit = 1

    def recent = filtered.reverse().take(limit)
    return [
        entries: recent,
        total: recent.size(),
        bufferSize: history.size(),
        bufferCap: 200
    ]
}

def toolListVariables(args = null) {





    def hubVariables = []
    String hubVarsError = null
    try {
        def allVars = getAllGlobalVars()
        if (allVars) {
            hubVariables = allVars.collect { name, var ->
                [
                    name: name,
                    value: var?.value,
                    type: var?.type,
                    deviceId: var?.deviceId,
                    attribute: var?.attribute,
                    source: "hub"
                ]
            }
        }
    } catch (Exception e) {


        hubVarsError = e.message ?: e.toString()
        mcpLog("warn", "hub-vars", "hub_list_variables: getAllGlobalVars() failed: ${hubVarsError} -- returning empty hubVariables", null, [details: [error: hubVarsError]])
    }

    def ruleVariables = state.ruleVariables?.collect { name, value ->
        [name: name, value: value, source: "rule_engine"]
    } ?: []

    def cursor = args?.cursor
    def paged = _paginateList(hubVariables, cursor, 100, "hub_list_variables")




    def result = [
        hubVariables: paged.page,
        ruleVariables: ruleVariables,
        totalHubVariables: hubVariables.size(),
        totalRuleVariables: ruleVariables.size(),
        total: hubVariables.size() + ruleVariables.size()
    ]
    if (hubVarsError) result.hubVariablesError = hubVarsError
    if (cursor != null && paged.nextCursor != null) result.nextCursor = paged.nextCursor
    return result
}

def toolGetVariable(name) {
    try {
        def hubVar = getGlobalVar(name)
        if (hubVar != null) {
            return [
                name: name,
                value: hubVar.value,
                type: hubVar.type,
                deviceId: hubVar.deviceId,
                attribute: hubVar.attribute,
                source: "hub"
            ]
        }
    } catch (Exception e) {
        logDebug("Hub variable '${name}' lookup threw ${e.class.simpleName}: ${e.message}")
    }

    def ruleVar = state.ruleVariables?.get(name)
    if (ruleVar != null) {
        return [name: name, value: ruleVar, source: "rule_engine"]
    }

    throw new IllegalArgumentException("Variable not found: ${name}")
}





private List getHubVarForbiddenChars() {
    return ["'", '"', '\\', '~', '[', ':', ']', '<', '>']
}









private String getAsyncCommitMarker() {
    return " [asyncCommitLikely]"
}

private List getHubVarTypes() {
    return ["Number", "Decimal", "String", "Boolean", "DateTime"]
}

private void _validateHubVarName(String name) {
    if (!name?.trim()) {
        throw new IllegalArgumentException("Variable name is required")
    }
    def bad = getHubVarForbiddenChars().findAll { c -> name.contains(c) }
    if (bad) {
        throw new IllegalArgumentException(
            "Variable name '${name}' contains forbidden character(s): ${bad.join(' ')}. " +
            "Hubitat rejects: ' \" \\ ~ [ : ] < >")
    }
}

private String _validateHubVarType(String type) {
    def types = getHubVarTypes()
    def match = types.find { it.equalsIgnoreCase(type) }
    if (!match) {
        throw new IllegalArgumentException(
            "Variable type '${type}' is invalid. Must be one of: ${types.join(', ')}")
    }
    return match  // canonical casing
}







def _primeHubVarsWizard(Integer appId, String context) {
    try {
        hubInternalGet("/installedapp/configure/json/${appId}")
        hubInternalGet("/installedapp/statusJson/${appId}")
    } catch (Exception e) {
        logDebug("${context}: _primeHubVarsWizard for ${appId} threw ${e.class.simpleName}: ${e.message}")
    }
}





def _findHubVariablesAppId() {

    def cached = atomicState.hubVarsAppId
    if (cached != null) {
        try { return cached.toString().toInteger() } catch (NumberFormatException e) {
            mcpLog("warn", "hub-vars", "Invalid cached hubVarsAppId '${cached}' -- rediscovering")
            atomicState.remove("hubVarsAppId")
        }
    }





    def directId = _resolveDirectAppId("hubVariables")
    if (directId != null) {
        atomicState.hubVarsAppId = directId
        mcpLog("info", "hub-vars", "Discovered Hub Variables app id: ${directId} (via /installedapp/direct/hubVariables)")
        return directId
    }


    try {
        def responseText = hubInternalGet("/hub2/appsList")
        if (responseText) {
            def parsed = new groovy.json.JsonSlurper().parseText(responseText)
            def found = null
            def recurse
            recurse = { node ->
                def d = node?.data
                if (found == null && d?.type == "Hub Variables" && d?.id != null) {
                    found = d
                }
                node?.children?.each { c -> recurse(c) }
            }
            (parsed?.apps ?: []).each { a -> recurse(a) }
            if (found?.id != null) {
                def id = found.id.toString().toInteger()






                def verified = true
                try {
                    def cfgText = hubInternalGet("/installedapp/configure/json/${id}")
                    if (cfgText) {
                        def cfg = new groovy.json.JsonSlurper().parseText(cfgText)
                        if (cfg?.app?.appType?.name != "Hub Variables") verified = false
                    }
                } catch (Exception e) {
                    logDebug("_findHubVariablesAppId: verify fetch for ${id} threw ${e.class.simpleName}: ${e.message}")
                }
                if (verified) {
                    atomicState.hubVarsAppId = id
                    mcpLog("info", "hub-vars", "Discovered Hub Variables app id: ${id} (via /hub2/appsList)")
                    return id
                }
                mcpLog("warn", "hub-vars", "appsList candidate ${id} failed configure/json verification -- not caching")
            }
        }
    } catch (Exception e) {
        logDebug("_findHubVariablesAppId: /hub2/appsList walk threw ${e.class.simpleName}: ${e.message}")
    }

    throw new IllegalStateException(
        "Hub Variables system app not found via the /installedapp/direct/hubVariables redirect chain " +
        "OR the /hub2/appsList walk. This should not happen on a normally-functioning hub -- the app " +
        "is system-installed. Check that Hub Variables is enabled (Settings > Hub Variables).")
}

def toolCreateVariable(args) {
    requireDestructiveConfirm(args.confirm)






    if (args.variables != null) {
        if (args.name != null || args.type != null || args.value != null) {
            throw new IllegalArgumentException(
                "Provide EITHER the single name/type/value form OR the bulk variables array -- not both.")
        }
        return _createVariablesBulk(args.variables)
    }

    def name = args.name?.toString()?.trim()
    _validateHubVarName(name)
    def type = _validateHubVarType(args.type?.toString())
    def value = args.value
    _validateInitialValue(name, type, value)



    try {
        def existing = getGlobalVar(name)
        if (existing != null) {
            throw new IllegalArgumentException(
                "Hub variable '${name}' already exists (type=${existing.type}, value=${existing.value}). " +
                "Use hub_set_variable to change the value, or pick a different name.")
        }
    } catch (IllegalArgumentException reraise) { throw reraise }
    catch (Exception e) {
        logDebug("hub_create_variable: getGlobalVar('${name}') threw ${e.class.simpleName}: ${e.message}")
    }

    def appId = _findHubVariablesAppId()
    return _createOneVariable(appId, name, type, value)
}





private Map _createVariablesBulk(variables) {
    if (!(variables instanceof List) || variables.isEmpty()) {
        throw new IllegalArgumentException("variables must be a non-empty array of {name, type, value} objects.")
    }

    def appId = _findHubVariablesAppId()
    def results = []
    int createdCount = 0
    int failedCount = 0

    variables.eachWithIndex { item, idx ->


        def itemName = (item instanceof Map) ? item.name?.toString()?.trim() : null
        try {
            if (!(item instanceof Map)) {
                throw new IllegalArgumentException("variables[${idx}] must be an object with name, type, and value.")
            }
            _validateHubVarName(itemName)
            def itemType = _validateHubVarType(item.type?.toString())
            _validateInitialValue(itemName, itemType, item.value)


            def existing = null
            try { existing = getGlobalVar(itemName) } catch (Exception e) {
                logDebug("hub_create_variable bulk: getGlobalVar('${itemName}') threw ${e.class.simpleName}: ${e.message}")
            }
            if (existing != null) {
                throw new IllegalArgumentException(
                    "Hub variable '${itemName}' already exists (type=${existing.type}). Use hub_set_variable to change the value, or pick a different name.")
            }

            def created = _createOneVariable(appId, itemName, itemType, item.value)
            results << [name: itemName, success: true, type: created.type, value: created.value]
            createdCount++
        } catch (Exception e) {



            def rawName = (item instanceof Map) ? item.name : null
            results << [name: (itemName ?: rawName ?: "variables[${idx}]"), success: false, error: e.message ?: e.toString()]
            failedCount++
        }
    }

    return [
        success: failedCount == 0,
        results: results,
        createdCount: createdCount,
        failedCount: failedCount
    ]
}





private void _validateInitialValue(String name, String type, value) {
    if (value == null) {
        throw new IllegalArgumentException("Initial value is required")
    }
    if (type == "String" && !value.toString().trim()) {
        throw new IllegalArgumentException(
            "String variable '${name}' requires a non-empty initial value. " +
            "Hubitat reports success for an empty String value but the variable never persists; supply any non-empty initial value.")
    }
}







private Map _createOneVariable(Integer appId, String name, String type, value) {
    def applied = []
    def skipped = []

    _primeHubVarsWizard(appId, "hub_create_variable pre-moreVar")
    _rmClickAppButton(appId, "moreVar", "moreVar", "hubVar")
    _rmWriteSettingOnPage(appId, "hubVar", "hbVar",   name, applied, "text", skipped)
    _rmWriteSettingOnPage(appId, "hubVar", "varType", type, applied, "enum", skipped)
    if (type == "DateTime") {



        def dateStr, timeStr
        if (value instanceof Map) {
            dateStr = value.date?.toString()
            timeStr = value.time?.toString()
        } else {
            def s = value.toString().trim()
            def parts = s.contains("T") ? s.split("T", 2) : (s.contains(" ") ? s.split(" ", 2) : [s, null])
            dateStr = parts[0]
            timeStr = parts.size() > 1 ? parts[1]?.take(5) : null  // "HH:mm" only
        }
        if (!dateStr || !timeStr) {
            throw new IllegalArgumentException(
                "DateTime variable '${name}' requires both date and time. " +
                "Pass an ISO string like '2026-05-06T12:00:00' or a {date,time} map. Got: ${value}")
        }
        _rmWriteSettingOnPage(appId, "hubVar", "varDate", dateStr, applied, "date", skipped)
        _rmWriteSettingOnPage(appId, "hubVar", "varTime", timeStr, applied, "time", skipped)



        _primeHubVarsWizard(appId, "hub_create_variable DateTime pre-Done")
        _rmClickAppButton(appId, "dateTimeDone", null, "hubVar")
    } else {
        _rmWriteSettingOnPage(appId, "hubVar", "varValue", value, applied, "textarea", skipped)
    }




    def created = null
    for (int attempt = 0; attempt < 8; attempt++) {
        try { created = getGlobalVar(name) } catch (Exception e) {
            logDebug("hub_create_variable: post-write getGlobalVar('${name}') threw ${e.class.simpleName}: ${e.message}")
        }
        if (created != null) break



        if (attempt < 7) {
            try { pauseExecution(300) } catch (Exception e) { logDebug("pauseExecution interrupted: ${e.class.simpleName}: ${e.message}") }
        }
    }
    if (created == null) {
        throw new IllegalStateException(
            "hub_create_variable: wizard completed but '${name}' is not visible via getGlobalVar. " +
            "Settings applied: ${applied.join(', ')}. Skipped: ${skipped}")
    }







    if (location != null) {
        try { subscribe(location, "variable:${name}", "handleHubVariableEvent") }
        catch (Throwable e) {
            mcpLog("error", "hub-vars", "post-create subscribe to variable:${name} failed: ${e.message} -- hub_list_variable_changes won't capture this var's changes until next initialize()")
        }
    }

    mcpLog("info", "hub-vars", "Created hub variable '${name}' type=${type} value=${value}")
    return [
        success: true,
        name: name,
        type: type,
        value: created.value,
        source: "hub",
        message: "Variable '${name}' (${type}) created with initial value ${created.value}."
    ]
}

def toolCreateConnector(args) {
    requireDestructiveConfirm(args.confirm)
    def name = args.name?.toString()?.trim()
    if (!name) throw new IllegalArgumentException("Variable name is required")
    def requestedType = args.connectorType?.toString()?.trim()

    def existing
    try { existing = getGlobalVar(name) }
    catch (Exception e) { existing = null }
    if (existing == null) {
        throw new IllegalArgumentException("Hub variable '${name}' does not exist. Create it first with hub_create_variable.")
    }
    if (existing.deviceId != null) {
        return [
            success: true,
            name: name,
            deviceId: existing.deviceId,
            attribute: existing.attribute,
            alreadyExists: true,
            message: "Connector for '${name}' already exists (deviceId=${existing.deviceId})."
        ]
    }

    def appId = _findHubVariablesAppId()
    _primeHubVarsWizard(appId, "hub_create_connector pre-click")
    _rmClickAppButton(appId, name, "createCon", "hubVar")







    def chosenType = requestedType?.trim() ?: "Variable"
    def applied = []
    def skipped = []
    _primeHubVarsWizard(appId, "hub_create_connector pre-capab")
    _rmWriteSettingOnPage(appId, "hubVar", "capab", chosenType, applied, "enum", skipped)

    def after
    for (int v = 0; v < 8; v++) {
        try { after = getGlobalVar(name) } catch (Exception e) { after = null }
        if (after?.deviceId != null) break

        if (v < 7) {
            try { pauseExecution(300) } catch (Exception e) { logDebug("pauseExecution interrupted: ${e.class.simpleName}: ${e.message}") }
        }
    }
    if (after?.deviceId == null) {
        throw new IllegalStateException(
            "hub_create_connector: wizard completed but '${name}' still has no deviceId. " +
            "Tried capab='${chosenType}' (only relevant for Number/Decimal). The connector did not bake.")
    }

    mcpLog("info", "hub-vars", "Created connector for '${name}' (deviceId=${after.deviceId}, attribute=${after.attribute}, capab=${chosenType})")
    return [
        success: true,
        name: name,
        deviceId: after.deviceId,
        attribute: after.attribute,
        connectorType: chosenType,
        message: "Connector created for '${name}' (deviceId=${after.deviceId})."
    ]
}

def toolRemoveConnector(args) {
    requireDestructiveConfirm(args?.confirm as Boolean)
    def name = args?.name?.toString()?.trim()
    if (!name) throw new IllegalArgumentException("Variable name is required")

    def existing
    try { existing = getGlobalVar(name) }
    catch (Exception e) { existing = null }
    if (existing == null) {
        throw new IllegalArgumentException("Hub variable '${name}' does not exist.")
    }
    if (existing.deviceId == null) {
        return [
            success: true,
            name: name,
            alreadyRemoved: true,
            message: "Variable '${name}' has no connector to remove."
        ]
    }

    def deviceId = existing.deviceId







    def res = toolDeleteDevice([deviceId: deviceId.toString(), confirm: true])
    if (res?.success != true) {
        throw new IllegalStateException(
            "hub_delete_connector: toolDeleteDevice failed for deviceId=${deviceId}: ${res?.error ?: 'unknown error'}")
    }




    def after = null
    for (int v = 0; v < 8; v++) {
        try { after = getGlobalVar(name) } catch (Exception e) { after = null }
        if (after?.deviceId == null) break

        if (v < 7) {
            try { pauseExecution(300) } catch (Exception e) { logDebug("pauseExecution interrupted: ${e.class.simpleName}: ${e.message}") }
        }
    }
    if (after?.deviceId != null) {
        throw new IllegalStateException(
            "hub_delete_connector: device ${deviceId} delete returned success but variable '${name}' still has deviceId=${after.deviceId}")
    }

    mcpLog("info", "hub-vars", "Removed connector for '${name}' (deviceId=${deviceId})")
    return [
        success: true,
        name: name,
        deviceId: deviceId,
        deviceDeleted: true,
        message: "Connector for '${name}' (deviceId=${deviceId}) removed. Variable itself is unchanged.",
        note: "A java.lang.StackOverflowError from Hubitat's built-in 'Variable Connectors' driver (childRemoved) may appear in the hub log during this removal. It is a known Hubitat platform bug -- the same crash occurs via the UI's Remove Device button -- and is harmless: the connector is removed regardless."
    ]
}

def toolSetVariable(name, value) {





    try {
        if (setGlobalVar(name, value)) {
            return [success: true, name: name, value: value, source: "hub"]
        }
    } catch (Exception e) {
        logDebug("setGlobalVar('${name}') threw ${e.class.simpleName}: ${e.message}")
    }
    if (!state.ruleVariables) state.ruleVariables = [:]
    state.ruleVariables.put(name, value)
    return [success: true, name: name, value: value, source: "rule_engine"]
}

def toolDeleteHubVariable(args) {
    requireDestructiveConfirm(args?.confirm as Boolean)
    def varName = args?.name?.toString()?.trim()
    if (!varName) throw new IllegalArgumentException("name is required")
    def force = args?.force == true





    def hubVar = null
    try { hubVar = getGlobalVar(varName) }
    catch (Exception e) {
        logDebug("hub_delete_variable: getGlobalVar('${varName}') threw ${e.class.simpleName}: ${e.message}")
    }
    def isHubVar = (hubVar != null)
    def isRuleVar = state.ruleVariables?.containsKey(varName) ?: false

    if (!isHubVar && !isRuleVar) {
        throw new IllegalArgumentException(
            "Variable '${varName}' not found in either the hub-variables namespace or the rule_engine namespace.")
    }






    def consumers = []
    try {


        def needles = ["\"${varName}\"".toString(), "%${varName}%".toString()]
        getChildApps()?.each { child ->
            def ruleData = null
            try { ruleData = child.getRuleData() } catch (Exception e) { /* not an MCP rule child */ }
            if (ruleData) {
                def serialized = groovy.json.JsonOutput.toJson(ruleData)
                if (needles.any { serialized?.contains(it) }) {
                    consumers << [id: child.id, label: child.label]
                }
            }
        }
    } catch (Exception e) {



        logDebug("hub_delete_variable: getChildApps() scan failed: ${e.class.simpleName}: ${e.message}")
    }


    def hubVarsAppId = null
    Boolean platformInUse = null
    if (isHubVar) {
        try {
            hubVarsAppId = _findHubVariablesAppId()
            platformInUse = _hubVarPlatformInUse(hubVarsAppId, varName)
        } catch (Exception e) {
            logDebug("hub_delete_variable: platform in-use check failed: ${e.class.simpleName}: ${e.message}")
        }
        if (platformInUse != false && !force) {
            throw new IllegalArgumentException(platformInUse ?
                "Hub Variable '${varName}' is registered as in use by at least one app (Settings > Hub Variables shows it in orange; click its name to see which). Deleting it breaks those apps, which is why the hub's own delete prompt warns. Update or remove the consuming apps first, or pass force=true to delete anyway." :
                "Could not read the hub's in-use registry for Hub Variable '${varName}', so whether an app uses it is unknown. Check Settings > Hub Variables (an in-use variable is shown in orange), then retry, or pass force=true to delete anyway.")
        }
    }
    if (consumers && !force) {
        def consumerCount = consumers.size()
        def consumerWord = consumerCount == 1 ? "rule" : "rules"
        throw new IllegalArgumentException(
            "Variable '${varName}' is referenced by ${consumerCount} ${consumerWord}: " +
            "${consumers.collect { "${it.label} (id=${it.id})" }.join(', ')}. " +
            "Deleting will silently break ${consumerCount == 1 ? 'that rule' : 'those rules'} (null lookups, false conditions, " +
            "literal %${varName}% in substitutions). Pass force=true to proceed anyway, " +
            "or update/remove the consuming ${consumerWord} first."
        )
    }

    if (isHubVar) {





        def previousValue = hubVar.value
        def previousType  = hubVar.type
        def hadConnector  = hubVar.deviceId != null
        def appId = hubVarsAppId ?: _findHubVariablesAppId()





        def stillThere = null
        for (int attempt = 0; attempt < 2; attempt++) {
            _primeHubVarsWizard(appId, "hub_delete_variable pre-click attempt-${attempt + 1}")
            _rmClickAppButton(appId, varName, "deleteGV", "hubVar")
            _rmClickAppButton(appId, "delConfirm", null, "hubVar")

            for (int v = 0; v < 8; v++) {
                try { stillThere = getGlobalVar(varName) } catch (Exception e) { stillThere = null }
                if (stillThere == null) break

                if (v < 7) {
                    try { pauseExecution(300) } catch (Exception e) { logDebug("pauseExecution interrupted: ${e.class.simpleName}: ${e.message}") }
                }
            }
            if (stillThere == null) break
        }
        if (stillThere != null) {
            throw new IllegalStateException(
                "hub_delete_variable: wizard completed but '${varName}' still exists in getGlobalVar after 2 click-sequence attempts.")
        }

        def prevStr = previousValue?.toString()
        def auditValue = prevStr == null ? "null" : (prevStr.length() > 80 ? "${prevStr.take(80)} [truncated, original length: ${prevStr.length()}]" : prevStr)
        def connectorNote = hadConnector ? " (connector deviceId=${hubVar.deviceId} also deleted)" : ""
        def consumerNote = ""
        if (consumers) {
            def cc = consumers.size()
            consumerNote = " (forced; ${cc} ${cc == 1 ? 'rule' : 'rules'} now broken: ${consumers.collect { "id=${it.id}" }.join(', ')})"
        }
        def registryNote = (platformInUse != false) ? " (forced; hub in-use registry: ${platformInUse == null ? 'unreadable' : 'true'})" : ""
        mcpLog("warn", "developer-mode", "hub_delete_variable: removed hub var '${varName}' (type=${previousType}, previous value: ${auditValue})${connectorNote}${registryNote}${consumerNote}")
        return [
            success: true,
            name: varName,
            deleted: true,
            source: "hub",
            type: previousType,
            previousValue: previousValue,
            connectorDeleted: hadConnector,
            brokenConsumers: consumers ?: null,
            platformInUse: platformInUse,
            coverageNote: _hubVarDeleteCoverageNote()
        ]
    }



    def previousValue = state.ruleVariables.get(varName)
    def updated = state.ruleVariables.findAll { k, v -> k != varName }
    state.ruleVariables = updated

    def prevStr = previousValue?.toString()
    def auditValue = prevStr == null ? "null" : (prevStr.length() > 80 ? "${prevStr.take(80)} [truncated, original length: ${prevStr.length()}]" : prevStr)
    def consumerNote = ""
    if (consumers) {
        def cc = consumers.size()
        consumerNote = " (forced; ${cc} ${cc == 1 ? 'rule' : 'rules'} now broken: ${consumers.collect { "id=${it.id}" }.join(', ')})"
    }
    mcpLog("warn", "developer-mode", "hub_delete_variable: removed '${varName}' (previous value: ${auditValue})${consumerNote}")
    return [success: true, name: varName, deleted: true, source: "rule_engine", previousValue: previousValue, brokenConsumers: consumers ?: null]
}




Boolean _hubVarPlatformInUse(Integer hubVarsAppId, String varName) {
    if (hubVarsAppId == null || !varName) return null
    def text
    try { text = hubInternalGet("/installedapp/configure/json/${hubVarsAppId}")?.toString() }
    catch (Exception e) { return null }
    if (!text) return null
    def escaped = varName.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&#39;").replace('"', "&quot;")
    def forms = [varName, escaped].unique()
    if (forms.any { text.contains("Show In Use Apps for ${it}'".toString()) }) return true
    if (forms.any { text.contains("<td>${it}</td>".toString()) }) return false
    return null
}

String _hubVarDeleteCoverageNote() {
    return "Checked the hub's in-use registry and this server's own rules. Apps that do not register Hub Variable use with the hub, such as webCoRE pistons, are not covered."
}

def _getAllToolDefinitions_partVariables() {
    return [
        [
            name: "hub_list_variables",
            description: "List all hub variables (every type, including ones without connectors) and rule-engine variables.",
            inputSchema: [
                type: "object",
                properties: [
                    cursor: [type: "string", description: "Opt-in pagination cursor for the hubVariables list. Omit for unbounded; pass \"\" for the first page, iterate nextCursor (page size 100)."]
                ]
            ]
        ],
        [
            name: "hub_get_variable",
            description: "Get one variable's current value by name.[[FLAT_TRIM]] Searches the hub-variable namespace first, then falls back to rule-engine variables.[[/FLAT_TRIM]] Use hub_list_variables to enumerate.",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Exact variable name to look up, e.g. \"vacationMode\". Case-sensitive."]
                ],
                required: ["name"]
            ]
        ],
        [
            name: "hub_set_variable",
            description: "Set an existing variable's value. For hub variables, value type must match the variable's declared type.[[FLAT_TRIM]] Creating new hub variables requires hub_create_variable — Hubitat does not allow setGlobalVar to create.[[/FLAT_TRIM]] Falls back to the rule_engine namespace when no hub variable matches.",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Variable name"],
                    value: [type: "string", description: "Variable value (string, number, or boolean as string)"]
                ],
                required: ["name", "value"]
            ]
        ],
        [
            name: "hub_create_variable",
            description: "Create a new hub variable[[FLAT_TRIM]] (global variable visible to apps and Rule Machine)[[/FLAT_TRIM]], one at a time or several in one call. Single form: name + type + value.",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "New variable name, e.g. \"vacationMode\". Omit when using variables."],
                    type: [type: "string", enum: ["Number", "Decimal", "String", "Boolean", "DateTime"], description: "Variable type. Omit when using variables."],
                    value: [description: "Initial value, must match the type; for DateTime e.g. 2026-02-04T14:00. Omit when using variables."],
                    variables: [type: "array", description: "Bulk form: several variables in one call.", items: [
                        type: "object",
                        properties: [
                            name: [type: "string", description: "New variable name"],
                            type: [type: "string", enum: ["Number", "Decimal", "String", "Boolean", "DateTime"], description: "Variable type"],
                            value: [description: "Initial value, must match the type"]
                        ],
                        required: ["name", "type", "value"]
                    ]],
                    confirm: [type: "boolean", description: "REQUIRED: must be true to perform the creation"]
                ],
                required: ["confirm"]
            ]
        ],
        [
            name: "hub_delete_variable",
            description: "Permanently delete a variable (DESTRUCTIVE — no undo). Auto-detects whether the target is a hub variable (also deletes its connector device when one exists) or a rule_engine variable. Gated on the Write master + confirm=true + a recent backup.[[FLAT_TRIM]]\n\n**Reference safety:** for a hub variable the tool first reads the hub's own in-use registry (what Settings > Hub Variables shows in orange, covering Rule Machine and other registering apps) and refuses when it is in use or when the registry cannot be read. It also scans this server's child rules for the name, quoted or as a %name% substitution. Apps that never register use, such as webCoRE pistons, are not covered (see `coverageNote`). To proceed anyway, pass `force=true` after acknowledging the breakage; `brokenConsumers` then lists the affected child rules.\n\nThe consumer scan makes this call slow; if the transport drops, verify whether the variable still exists before retrying.[[/FLAT_TRIM]]",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Variable name to delete"],
                    confirm: [type: "boolean", description: "REQUIRED: must be true to confirm the deletion"],
                    force: [type: "boolean", description: "OPTIONAL: must be true to proceed when the hub reports the variable in use, the in-use registry cannot be read, or a child rule references it. Without force, the tool refuses and says why."],
                ],
                required: ["name", "confirm"]
            ]
        ],
        [
            name: "hub_create_connector",
            description: "Create a virtual-device connector for an existing hub variable so apps that only consume devices can read/write it. No-op if a connector already exists.",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Existing hub-variable name"],
                    connectorType: [type: "string", description: "Optional connector type for Number/Decimal vars (e.g. 'Dimmer', 'Variable').[[FLAT_TRIM]] Other options: 'Volume', 'ColorTemp', 'Humidity', 'Illuminance'.[[/FLAT_TRIM]] Defaults to 'Variable'. Ignored for vars that don't show a chooser."],
                    confirm: [type: "boolean", description: "REQUIRED: must be true"]
                ],
                required: ["name", "confirm"]
            ]
        ],
        [
            name: "hub_delete_connector",
            description: "Delete the connector device backing a hub variable. DESTRUCTIVE and not undoable — the connector device is removed, but the hub variable itself and its value are unchanged. confirm=true required. No-op if the variable has no connector.",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Hub-variable name whose connector device to remove, e.g. \"vacationMode\""],
                    confirm: [type: "boolean", description: "REQUIRED: must be true to perform the deletion"]
                ],
                required: ["name", "confirm"]
            ]
        ],
        [
            name: "hub_list_variable_changes",
            description: "List recent hub-variable change events captured by the MCP app's location-event subscription, most-recent first.[[FLAT_TRIM]] Use this to audit or debug what changed a variable and when, without polling hub_get_variable.[[/FLAT_TRIM]] The buffer holds at most the 200 most recent changes (oldest dropped) and survives app and hub restarts, but it is not a complete history — an empty or partial result does NOT mean the variable never changed.[[FLAT_TRIM]] For the hub's separately retained location-event history call hub_list_device_events with no deviceId (location-event mode).[[/FLAT_TRIM]] Filter by variable name and/or timestamp.",
            inputSchema: [
                type: "object",
                properties: [
                    name: [type: "string", description: "Optional: filter to changes for this variable name only, e.g. \"vacationMode\". Omit to include all variables."],
                    sinceMs: [type: "integer", description: "Optional: only return changes whose timestamp >= this epoch-millis value, e.g. 1717459200000"],
                    limit: [type: "integer", description: "Optional: max entries to return (default 50)"]
                ]
            ]
        ],
    ]
}

def _readOnlyToolNames_partVariables() {



    return [

        "hub_list_variables", "hub_get_variable", "hub_list_variable_changes"
    ]
}

def _idempotentWriteToolNames_partVariables() {


    return [

        "hub_set_variable", "hub_delete_variable", "hub_create_connector", "hub_delete_connector"
    ]
}

def _toolDisplayMeta_partVariables() {


    return [

        hub_list_variables: [title: "List Variables", summary: "List all hub and rule-engine variables."],
        hub_get_variable: [title: "Get Variable", summary: "Get a variable's value and metadata."],
        hub_set_variable: [title: "Set Variable", summary: "Set an existing variable's value."],
        hub_create_variable: [title: "Create Variable", summary: "Create a new hub variable."],
        hub_delete_variable: [title: "Delete Variable", summary: "Permanently delete a hub variable and any connector it has."],
        hub_create_connector: [title: "Create Variable Connector", summary: "Create a virtual-device connector for a hub variable."],
        hub_delete_connector: [title: "Delete Variable Connector", summary: "Remove a hub variable's connector device."],
        hub_list_variable_changes: [title: "List Variable Changes", summary: "Recent hub-variable changes from the retained 200-entry history."]
    ]
}
