library(name: "McpDiscoveryLib", namespace: "mcp", author: "kingpanther13", description: "Tool discovery implementations (hub_search_tools BM25 search + the hub_get_tool_guide dispatcher) for the MCP Rule Server; #include'd by the main app. Gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")
// Developer comments are blanked in this hub copy so the hub's code pages stay fast -- Groovy discards them anyway. Below this line, a line number here is the repository file's plus one. Full source: https://github.com/kingpanther13/Hubitat-local-MCP-server/blob/main/libraries/mcp-discovery-lib.groovy

def toolSearchTools(args) {
    def query = args.query
    if (!query?.trim()) return [error: "query is required"]
    _cleanupRetiredToolState()
    def maxResults = args.maxResults != null ? Math.max(0, args.maxResults as Integer) : 5














    def allDefs = null
    String corpusFp = TOOL_SEARCH_CORPUS_FP
    if (corpusFp == null) {
        allDefs = getAllToolDefinitions()
        corpusFp = toolSearchCorpusFingerprint(allDefs)
        TOOL_SEARCH_CORPUS_FP = corpusFp
    }
    def corpus = null
    def docTokensAll = null
    synchronized (TOOL_SEARCH_INDEX) {
        if (TOOL_SEARCH_INDEX.fingerprint != corpusFp || !(TOOL_SEARCH_INDEX.corpus instanceof List) ||
                !(TOOL_SEARCH_INDEX.tokens instanceof List) || TOOL_SEARCH_INDEX.tokens.size() != TOOL_SEARCH_INDEX.corpus.size()) {
            def built = buildToolSearchCorpus(allDefs)


            def tokens = built.collect { bm25Tokenize(_bm25DocText(it)) }
            TOOL_SEARCH_INDEX.clear()
            TOOL_SEARCH_INDEX.putAll([fingerprint: corpusFp, corpus: built, tokens: tokens])
        }
        corpus = TOOL_SEARCH_INDEX.corpus
        docTokensAll = TOOL_SEARCH_INDEX.tokens
    }







    def searchHideByName = getHiddenToolNames()





    def visibleCorpus = []
    def docTokens = []
    corpus.eachWithIndex { entry, i ->
        if (searchHideByName.contains(entry.name)) return
        visibleCorpus << entry
        docTokens << docTokensAll[i]
    }


    def queryTokens = bm25Tokenize(query)

    if (!queryTokens) return [results: [], message: "No searchable terms in query"]


    def scores = bm25Score(docTokens, queryTokens)


    def ranked = []
    scores.eachWithIndex { score, idx ->
        if (score > 0) ranked << [index: idx, score: score]
    }
    ranked.sort { -it.score }




    def seenSearchNames = [] as Set
    ranked = ranked.findAll { r ->
        def nm = visibleCorpus[r.index].name
        if (seenSearchNames.contains(nm)) return false
        seenSearchNames << nm
        return true
    }
    if (ranked.size() > maxResults) ranked = ranked.take(maxResults)

    def gatewayConfig = getGatewayConfig()
    def displayMeta = getToolDisplayMeta()
    def results = ranked.collect { r ->
        def tool = visibleCorpus[r.index]
        def entry = [
            tool: _externalToolName(tool.name as String),
            description: tool.description,
            relevance: Math.round(r.score * 100) / 100.0
        ]



        if (tool.title) entry.title = tool.title
        if (tool.gateway) {

            def config = gatewayConfig.get(tool.gateway)
            def intro = _visibleGatewayIntro(tool.gateway, gatewayConfig, searchHideByName, displayMeta)
            entry.description = "${config.summaries.get(tool.name) ?: ''} [${intro}]".toString()
            entry.gateway = _externalToolName(tool.gateway as String)
            entry.callAs = "Call via ${_externalToolName(tool.gateway as String)}(tool=\"${_externalToolName(tool.name as String)}\", args={...})"
        } else {
            entry.callAs = "Call directly: ${_externalToolName(tool.name as String)}({...})"
        }
        return entry
    }

    return [
        query: query,
        resultsCount: results.size(),




        totalToolsSearched: visibleCorpus*.name.toSet().size(),
        results: results
    ]
}



















def toolSearchCorpusFingerprint(List defs = null) {
    long h = 17L
    def displayMeta = getToolDisplayMeta()
    applyDescriptionTransform(defs ?: getAllToolDefinitions(), false).each { toolDef ->
        h = _fpField(h, toolDef.name as String)
        h = _fpField(h, displayMeta[toolDef.name]?.title)
        h = _fpField(h, toolDef.description)
        h = _fpField(h, toolDef.inputSchema?.properties?.keySet()?.join(','))
    }
    getGatewayConfig().each { gwName, config ->
        h = _fpField(h, gwName as String)
        h = _fpField(h, config.description)
        config.tools.each { toolName ->
            h = _fpField(h, toolName as String)
            h = _fpField(h, config.summaries?."${toolName}")
            h = _fpField(h, config.searchHints?."${toolName}")
        }
    }



    h = _fpField(h, bm25Tokenize(_bm25DocText(
        [name: 'hub_x-1', title: 'A_b', description: 'cd', params: 'ef', hints: 'gh',
         gateway: 'ij'])).join(','))
    return Long.toString(h)
}




private String _bm25DocText(entry) {
    return "${entry.name} ${entry.title ?: ''} ${entry.description} ${entry.params ?: ''} ${entry.hints ?: ''}"
}




private long _fpField(long h, value) {
    String s = (value == null) ? "" : value.toString()





    h = h * 31L + s.length()
    return h * 31L + s.hashCode()
}


private buildToolSearchCorpus(List defs = null) {
    def gatewayConfig = getGatewayConfig()
    def proxiedNames = gatewayConfig.values().collectMany { it.tools } as Set



    def allDefs = applyDescriptionTransform(defs ?: getAllToolDefinitions(), false)
    def allDefsMap = allDefs.collectEntries { [(it.name): it] }




    def displayMeta = getToolDisplayMeta()

    def corpus = []


    allDefs.each { toolDef ->
        if (!proxiedNames.contains(toolDef.name)) {
            def params = toolDef.inputSchema?.properties?.keySet()?.join(" ") ?: ""
            corpus << [name: toolDef.name, title: displayMeta[toolDef.name]?.title, description: toolDef.description?.replaceAll(/\n+/, ' ')?.trim(), params: params, gateway: null]
        }
    }


    gatewayConfig.each { gwName, config ->
        config.tools.each { toolName ->
            def summary = config.summaries[toolName] ?: ""
            def hints = config.searchHints?."${toolName}" ?: ""
            def fullDef = allDefsMap[toolName]
            def params = fullDef?.inputSchema?.properties?.keySet()?.join(" ") ?: ""
            corpus << [name: toolName, title: displayMeta[toolName]?.title, description: "${summary} [${config.description}]", params: params, hints: hints, gateway: gwName]
        }
    }

    return corpus
}


private bm25Tokenize(String text) {
    if (!text) return []
    return text.toLowerCase().split(/[^a-z0-9]+/).findAll { it.length() > 1 }
}


private String _bm25Key(String token) {


    return "t_${token}".toString()
}

private bm25Score(List<List<String>> docTokens, List<String> queryTokens) {
    def k1 = 1.5
    def b = 0.75
    def n = docTokens.size()

    if (n == 0) return []


    def docLengths = docTokens.collect { it.size() }
    def avgDl = docLengths.sum() / (double) n
    if (avgDl == 0) return new double[n] as List



    def df = [:]
    docTokens.each { tokens ->
        tokens.toSet().each { token ->
            def k = _bm25Key(token)
            df.put(k, (df.get(k) ?: 0) + 1)
        }
    }


    def scores = new double[n]
    docTokens.eachWithIndex { tokens, docIdx ->

        def tf = [:]
        tokens.each { t -> def k = _bm25Key(t); tf.put(k, (tf.get(k) ?: 0) + 1) }

        def dl = docLengths[docIdx]
        double score = 0.0

        queryTokens.each { rawQt ->
            def qt = _bm25Key(rawQt)
            def termFreq = tf.get(qt) ?: 0
            if (termFreq > 0) {
                def docFreq = df.get(qt) ?: 0
                def idf = Math.log((n - docFreq + 0.5) / (docFreq + 0.5) + 1.0)
                def num = termFreq * (k1 + 1)
                def den = termFreq + k1 * (1 - b + b * dl / avgDl)
                score += idf * num / den
            }
        }

        scores[docIdx] = score
    }

    return scores as List
}

def toolGetToolGuide(section, cursor = null) {
    def sections = getToolGuideSections()
    def subSections = getToolGuideSubSections()

    if (section) {
        def key = section.toLowerCase().replaceAll(/[^a-z_]/, "_")
        if (sections.containsKey(key)) {
            def result = [success: true, section: key]


            if (subSections.containsKey(key)) result.subSections = subSections[key].keySet().toList()
            return _withGuidePage(result, sections[key], cursor)
        }
        def sub = guideSubSectionLookup(key)
        if (sub) {




            def result = [
                success: true,
                section: key,
                parentSection: sub.parent,
                subSections: subSections[sub.parent].keySet().toList(),
                note: "Part of the '${sub.parent}' section. A sibling sub-key may hold what you need; hub_get_tool_guide(section='${sub.parent}') returns all of it.".toString()
            ]
            return _withGuidePage(result, sub.content, cursor)
        }
        return [
            success: false,
            error: "Unknown section: ${section}",
            availableSections: sections.keySet().toList(),
            availableSubSections: subSections.collectEntries { k, v -> [(k): v.keySet().toList()] }
        ]
    }




    def fullGuide = sections.collect { k, v -> v }.join("\n\n---\n\n")
    def result = [
        success: true,
        section: "full",
        availableSections: sections.keySet().toList(),
        availableSubSections: subSections.collectEntries { k, v -> [(k): v.keySet().toList()] }
    ]
    return _withGuidePage(result, fullGuide, cursor)
}




private Map _withGuidePage(Map result, content, cursor) {
    def paged = paginateGuideContent(content, cursor)
    result.content = paged.content
    if (paged.nextCursor != null || paged.offset > 0) {
        result.offset = paged.offset
        result.totalChars = paged.totalChars
    }



    if (paged.nextCursor != null) result.nextCursor = paged.nextCursor
    return result
}

def _getAllToolDefinitions_partDiscovery() {
    return [

        [
            name: "hub_get_tool_guide",
            description: "Get the deep-reference guide for an MCP tool topic[[FLAT_TRIM]] (exhaustive capability tables, wire formats, worked examples)[[/FLAT_TRIM]] when a tool's own description and parameter descriptions are not enough. Supplement only - reach for it just for the named sections. A `<parent>_<part>` key (e.g. set_rule_reference_conditions) returns just that part of its parent section; the bare parent key returns all of it.[[FLAT_TRIM]] A parent's response lists its own sub-keys.[[/FLAT_TRIM]] Prefer a section to minimize tokens: omitting it returns the section + sub-section key list plus the first page of the whole guide, paging onward via nextCursor -- that first page is the largest response this tool produces, so on a timeout retry a specific section instead.",
            inputSchema: [
                type: "object",
                properties: [
                    section: [type: "string", description: "One section key from the enum. Omit to get the key list plus the first page of the full guide.", enum: ["device_authorization", "best_practice_reference", "hub_admin_write", "hub_admin_write_overview", "hub_admin_write_destructive", "hub_admin_write_radios", "hub_admin_write_devices", "hub_admin_write_code", "hub_admin_write_system", "virtual_devices", "update_device", "rules", "backup", "file_manager", "performance", "performance_overview", "performance_devices", "performance_diagnostics", "builtin_app_tools", "builtin_app_tools_overview", "builtin_app_tools_apps", "builtin_app_tools_rules", "builtin_app_tools_crud", "set_rule_reference", "set_rule_reference_overview", "set_rule_reference_triggers", "set_rule_reference_actions", "set_rule_reference_conditions", "set_rule_reference_walkstep", "set_rule_reference_responses", "set_rule_reference_guards", "set_rule_create_reference", "visual_rule_reference", "variables", "dashboards", "bundles", "rooms", "slow_ops"]],
                    cursor: [type: "string", description: "Continue a paged payload: pass the prior call's nextCursor. Omit otherwise -- a cursor is rejected on a payload that fit one response, and only the no-section full-guide call exceeds one."]
                ]
            ]
        ],

        [
            name: "hub_search_tools",
            description: "Search all MCP tools by natural language query (BM25 ranking). Searches tool names, friendly titles, descriptions, and parameter names. Returns matching tools with their gateway location so you know how to call them. Use when unsure which gateway contains the tool you need.",
            inputSchema: [
                type: "object",
                properties: [
                    query: [type: "string", description: "Natural language search query (e.g. 'zigbee radio', 'delete app', 'memory leak', 'room management')"],
                    maxResults: [type: "integer", description: "Max results to return. Default: 5.", default: 5]
                ],
                required: ["query"]
            ]
        ],
    ]
}

def _readOnlyToolNames_partDiscovery() {



    return [

        "hub_get_tool_guide", "hub_search_tools"
    ]
}

def _toolDisplayMeta_partDiscovery() {


    return [

        hub_get_tool_guide: [title: "Get Tool Guide", summary: "Deep-reference guide for MCP tool topics beyond the tool descriptions."],
        hub_search_tools: [title: "Search Tools", summary: "Search all MCP tools by natural-language query."]
    ]
}
