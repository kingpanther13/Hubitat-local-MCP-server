library(name: "McpAppClonerLib", namespace: "mcp", author: "kingpanther13", description: "Native-app cloner tool implementations (hub_clone_native_app/hub_export_native_app/hub_import_native_app) plus the backup-restore primitive built on them for the MCP Rule Server; #include'd by the main app. Gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")
// Developer comments are blanked in this hub copy so the hub's code pages stay fast -- Groovy discards them anyway. Below this line, a line number here is the repository file's plus one. Full source: https://github.com/kingpanther13/Hubitat-local-MCP-server/blob/main/libraries/mcp-app-cloner-lib.groovy

private Map _appClonerInit(Integer sourceAppId) {
    def resp
    try {
        resp = hubInternalGetRaw("/installedapp/sysAppApi/appCloner/app/${sourceAppId}")
    } catch (Exception e) {
        throw new IllegalStateException("appCloner entry failed for source ${sourceAppId}: ${e.message}. The source app may not exist or appCloner may be unavailable.")
    }
    def loc = resp?.location
    if (!loc) {
        throw new IllegalStateException("appCloner entry returned no Location header for source ${sourceAppId} (status=${resp?.status})")
    }

    def m = (loc =~ /\/(?:apps\/api|installedapp\/configure)\/(\d+)/)
    Integer clonerId = m.find() ? (m[0][1] as Integer) : null
    if (clonerId == null) {
        throw new IllegalStateException("Unexpected appCloner Location: ${loc}")
    }




    String hubIp = null
    try { hubIp = location?.hub?.localIP?.toString() } catch (Exception ignored) { /* fall through */ }
    if (!hubIp) hubIp = "127.0.0.1"
    String sourceContextUrl = loc.startsWith("http") ? loc : "http://${hubIp}${loc}"
    String configUrl = "http://${hubIp}/installedapp/configure/${clonerId}/main".toString()








    def relPath = loc.replaceFirst(/^https?:\/\/[^\/]+/, '')
    def parts = relPath.split(/\?/, 2)
    def justPath = parts[0]
    def query = [:]
    if (parts.length > 1) {
        parts[1].split('&').each { kv ->
            def eq = kv.indexOf('=')
            if (eq > 0) query[kv.substring(0, eq)] = kv.substring(eq + 1)
        }
    }
    try {
        hubInternalGet(justPath, query)
    } catch (Exception followErr) {



        throw new IllegalStateException("appCloner source-context render failed for source ${sourceAppId} (cloner ${clonerId}): ${followErr.message}. Without this step the cloner state machine never seeds state.cloneSource and subsequent clicks silently produce no rule.")
    }
    pauseExecution(1000)




    try {
        hubInternalGet("/installedapp/configure/json/${clonerId}/main", [:])
    } catch (Exception primeErr) {
        throw new IllegalStateException("appCloner configPage prime failed for cloner ${clonerId}: ${primeErr.message}. Without this step settings[ruleUpload] writes are silently dropped on the import path.")
    }
    return [clonerAppId: clonerId, referrer: sourceContextUrl, configUrl: configUrl]
}

private Map _appClonerSubmitForm(Integer clonerAppId, String currentPage, String formState, String referrer, String configUrl, Map extras = null) {








    def pageBreadcrumbs = currentPage == "main" ? "[]" : '["main"]'
    def body = [
        formAction: "update",
        id: clonerAppId.toString(),
        version: "1",
        appTypeId: "",
        appTypeName: "",
        currentPage: currentPage,
        pageBreadcrumbs: pageBreadcrumbs,





        referrer: referrer ?: "",
        url: configUrl ?: "",
        _cancellable: "false"
    ]
    switch (formState) {
        case "source":
            body["exportRuleButton.type"] = "button"
            body["exportRuleButton.multiple"] = "false"
            body["settings[exportRuleButton]"] = ""
            body["ruleUpload.type"] = "file-text"
            body["ruleUpload.multiple"] = "false"
            body["settings[ruleUpload]"] = ""
            body["cloneRuleButton.type"] = "button"
            body["cloneRuleButton.multiple"] = "false"
            body["settings[cloneRuleButton]"] = ""
            break
        case "confirmation":
            body["cancelUpload.type"] = "button"
            body["cancelUpload.multiple"] = "false"
            body["settings[cancelUpload]"] = ""
            break
        case "importRule":

            break
        default:
            break
    }
    if (extras) body.putAll(extras)




    StringBuilder sb = new StringBuilder()
    boolean first = true
    body.each { k, v ->
        if (!first) sb.append('&')
        first = false
        sb.append(URLEncoder.encode(k.toString(), "UTF-8"))
        sb.append('=')
        sb.append(v == null ? "" : URLEncoder.encode(v.toString(), "UTF-8"))
    }
    def resp = hubInternalPostFormRaw("/installedapp/update/json", sb.toString())
    if (resp == null) {



        throw new IllegalStateException("appCloner POST /installedapp/update/json returned no response (cloner ${clonerAppId}, currentPage=${currentPage}, formState=${formState}). Network call failed before delivering a status.")
    }
    return resp
}

private Integer _appClonerFindActionHrefIdx(Integer clonerAppId, String pageName, String targetActionName) {








    def pn = pageName ?: "main"
    String body = null
    try {
        def resp = hubInternalGet("/installedapp/configure/json/${clonerAppId}/${pn}", [:])
        body = (resp instanceof Map) ? (resp.data?.toString()) : (resp?.toString())
    } catch (Exception e) {
        mcpLog("warn", "rm-native", "appCloner: fetch state for href discovery failed: ${e.message}")
        return null
    }
    if (!body) return null
    def m = (body =~ /_action_href_name\|${java.util.regex.Pattern.quote(targetActionName)}\|(\d+)/)
    return m.find() ? (m[0][1] as Integer) : null
}

private void _appClonerCommitImportRule(Integer clonerAppId, Integer sourceAppId, String newName, String referrer, String configUrl) {








    Integer hrefIdx = null
    for (int attempt = 0; attempt < 4 && hrefIdx == null; attempt++) {
        if (attempt > 0) pauseExecution(500)
        hrefIdx = _appClonerFindActionHrefIdx(clonerAppId, "main", "importRule")
    }
    if (hrefIdx == null) {
        throw new IllegalStateException("appCloner importRule action_href not found on cloner ${clonerAppId} main page after 4 polls (~2s). The cloner did not transition to the expected confirmation/restore-or-import state — clicking importNow now would silently no-op.")
    }
    _appClonerSubmitForm(clonerAppId, "main", "confirmation", referrer, configUrl, [
        ("_action_href_name|importRule|${hrefIdx}".toString()): "",
        ("params_for_action_href_name|importRule|${hrefIdx}".toString()): ""
    ])
    pauseExecution(500)



    def newNameField = "settings[newName${sourceAppId}]".toString()
    def newNameTypeKey = "newName${sourceAppId}.type".toString()
    def newNameMultKey = "newName${sourceAppId}.multiple".toString()
    if (newName) {
        _appClonerSubmitForm(clonerAppId, "importRule", "importRule", referrer, configUrl, [
            (newNameField): newName,
            (newNameTypeKey): "text",
            (newNameMultKey): "false"
        ])
    }




    def btnBody = [
        id: clonerAppId.toString(),
        name: "importNow",
        ("settings[importNow]".toString()): "clicked",
        ("importNow.type".toString()): "button"
    ]
    def finalExtras = [
        (newNameField): (newName ?: ""),
        (newNameTypeKey): "text",
        (newNameMultKey): "false",
        ("importNow.type".toString()): "button",
        ("importNow.multiple".toString()): "false",
        ("settings[importNow]".toString()): ""
    ]
    for (int attempt = 0; attempt < 2; attempt++) {
        def resp = hubInternalPostForm("/installedapp/btn", btnBody)
        if (resp?.status != null && resp.status >= 400) {
            throw new IllegalStateException("appCloner importNow click failed: status=${resp.status}")
        }
        pauseExecution(500)



        _appClonerSubmitForm(clonerAppId, "importRule", "importRule", referrer, configUrl, finalExtras)
        pauseExecution(500)
    }
}

private Map _appClonerSnapshotChildren(Integer parentAppId) {


    try {
        def cfg = _rmFetchConfigJson(parentAppId)
        if (!(cfg.childApps instanceof List)) {
            throw new IllegalStateException("missing childApps list")
        }
        return [ids: cfg.childApps.collect { it?.id?.toString() }.findAll { it }]
    } catch (Exception e) {
        return [success: false, isError: true,
                error: "Cannot read the child-app snapshot for parent ${parentAppId}: ${e.message}".toString(),
                note: "Nothing was created. Restore access to the parent app and retry the clone/import."]
    }
}

private Integer _appClonerDiscoverNewChild(Integer parentAppId, Set<String> preCloneIds, String sourceLabel, String hint) {
    if (parentAppId == null) return null
    def afterCfg
    try {
        afterCfg = _rmFetchConfigJson(parentAppId)
    } catch (Exception e) {
        mcpLog("warn", "rm-native", "appCloner: parent ${parentAppId} fetch after commit failed: ${e.message}")
        return null
    }
    def afterIds = ((afterCfg?.childApps ?: []) as List).collect { it?.id?.toString() }.findAll { it }
    def added = afterIds.findAll { !preCloneIds.contains(it) }
    if (added.isEmpty()) return null
    if (added.size() == 1) return added[0] as Integer


    def candidates = (afterCfg.childApps as List).findAll { added.contains(it?.id?.toString()) }
    def hintMatches = hint ? candidates.findAll { (it.label?.toString() ?: "") == hint } : []
    if (hintMatches.size() == 1) return hintMatches[0].id as Integer
    mcpLog("warn", "rm-native", "appCloner: ambiguous new children ${added} for '${hint ?: sourceLabel}'; no app selected")
    return null
}

private boolean _appClonerCleanup(Integer clonerAppId) {
    if (clonerAppId == null) return false
    try {
        _rmForceDeleteApp(clonerAppId)
        mcpLog("debug", "rm-native", "appCloner: cleaned up temporary cloner ${clonerAppId}")
        return true
    } catch (Exception e) {
        mcpLog("warn", "rm-native", "appCloner: cleanup of temporary cloner ${clonerAppId} failed: ${e.message} -- a hidden 'Export/Import/Clone' app may remain; delete via hub_delete_native_app(appId=${clonerAppId}, force=true)")
        return false
    }
}

private void _appClonerClickClone(Integer clonerAppId, String referrer, String configUrl) {

    def btnBody = [
        id: clonerAppId.toString(),
        name: "cloneRuleButton",
        ("settings[cloneRuleButton]".toString()): "clicked",
        ("cloneRuleButton.type".toString()): "button"
    ]
    for (int attempt = 0; attempt < 2; attempt++) {
        hubInternalPostForm("/installedapp/btn", btnBody)
        pauseExecution(500)
        _appClonerSubmitForm(clonerAppId, "main", "source", referrer, configUrl, null)
        pauseExecution(500)
    }
}

def toolCloneNativeApp(args) {
    requireDestructiveConfirm(args?.confirm as Boolean)
    def _srcRaw = (args?.sourceAppId != null) ? args.sourceAppId : args?.appId
    if (_srcRaw == null) throw new IllegalArgumentException("sourceAppId (or appId) is required")
    def sourceAppId = normalizeRuleId(_srcRaw)
    def newName = args?.newName?.toString()?.trim()

    def sourceCfg
    try {
        sourceCfg = _rmFetchConfigJson(sourceAppId)
    } catch (Exception sourceErr) {
        mcpLog("warn", "rm-native", "hub_clone_native_app: source ${sourceAppId} config fetch failed: ${sourceErr.message}")
        sourceCfg = null
    }
    if (!sourceCfg?.app) {
        throw new IllegalArgumentException("Source app ${sourceAppId} not found or unreadable")
    }
    def sourceLabel = sourceCfg.app.label?.toString()
    Integer parentAppId = null
    try {
        parentAppId = (sourceCfg.app.parentAppId != null) ? (sourceCfg.app.parentAppId.toString() as Integer) : null
    } catch (NumberFormatException ignored) {
        mcpLog("warn", "rm-native", "hub_clone_native_app: source ${sourceAppId} parentAppId not numeric: ${sourceCfg.app.parentAppId}")
    }

    if (parentAppId == null) {
        throw new IllegalArgumentException("Source app ${sourceAppId} has no numeric parentAppId. MCP cannot safely discover its clone; pass a child of the target parent app.")
    }
    Map snapshot = _appClonerSnapshotChildren(parentAppId)
    if (snapshot.isError == true) return snapshot
    def preIds = snapshot.ids as Set

    def initRes = _appClonerInit(sourceAppId)
    Integer clonerAppId = initRes.clonerAppId
    String referrer = initRes.referrer
    String configUrl = initRes.configUrl

    try {
        _appClonerClickClone(clonerAppId, referrer, configUrl)


        _appClonerCommitImportRule(clonerAppId, sourceAppId, newName, referrer, configUrl)

        Integer newAppId = _appClonerDiscoverNewChild(parentAppId, preIds, sourceLabel, newName)

        String note = newAppId
            ? "Cloned source ${sourceAppId} -> new app ${newAppId}${newName ? " (renamed to '${newName}')" : ""}. Use hub_set_native_app (or hub_set_rule for RM rules) to further customize."
            : "Clone fired but no new child appeared under parent ${parentAppId}. Re-check via hub_list_apps (scope='instances') shortly."
        def result = [
            success: newAppId != null,
            sourceAppId: sourceAppId,
            clonerAppId: clonerAppId,
            newAppId: newAppId,
            note: note
        ]
        if (newAppId == null) {




            result.isError = true
            result.error = note
        }
        if (args?.stageDisabled == true && newAppId != null) {
            _appClonerApplyStageDisabled(result, newAppId, args?.__reqT0 as Long)
        } else if (args?.stageDisabled == true) {


            _appClonerStagingDiscoveryMiss(result, "clone")
        }
        return result
    } finally {



        _appClonerCleanup(clonerAppId)
    }
}

def toolExportNativeApp(args) {
    def _srcRaw = (args?.sourceAppId != null) ? args.sourceAppId : args?.appId
    if (_srcRaw == null) throw new IllegalArgumentException("sourceAppId (or appId) is required")
    def sourceAppId = normalizeRuleId(_srcRaw)
    def saveAs = args?.saveAs?.toString()?.trim()

    def sourceCfg
    try {
        sourceCfg = _rmFetchConfigJson(sourceAppId)
    } catch (Exception sourceErr) {
        mcpLog("warn", "rm-native", "hub_export_native_app: source ${sourceAppId} config fetch failed: ${sourceErr.message}")
        sourceCfg = null
    }
    if (!sourceCfg?.app) {
        throw new IllegalArgumentException("Source app ${sourceAppId} not found or unreadable")
    }
    def sourceLabel = sourceCfg.app.label?.toString() ?: "app-${sourceAppId}"

    def initRes = _appClonerInit(sourceAppId)
    Integer clonerAppId = initRes.clonerAppId
    String referrer = initRes.referrer
    String configUrl = initRes.configUrl

    try {









        def btnBody = [
            id: clonerAppId.toString(),
            name: "exportRuleButton",
            ("settings[exportRuleButton]".toString()): "clicked",
            ("exportRuleButton.type".toString()): "button"
        ]
        hubInternalPostForm("/installedapp/btn", btnBody)
        pauseExecution(500)
        def refreshResp = _appClonerSubmitForm(clonerAppId, "main", "source", referrer, configUrl, null)
        String jsonContent = _appClonerExtractJsonFromResponse(refreshResp?.data)
        if (!jsonContent) {



            def reason
            if (refreshResp?.data == null) {
                reason = "the cloner response body was empty/unreadable (status ${refreshResp?.status})"
            } else {





                reason = "no JSON content could be extracted (looked for configPage.sections[].input[].filecontent). " +
                    "Known cause: if the source rule has a Required Expression, appCloner export currently fails for it -- " +
                    "delete the Required Expression in the Rule Machine UI, export, then re-add it (no MCP tool removes a " +
                    "Required Expression: replaceRequiredExpression only swaps one for another); or edit the rule in place " +
                    "via hub_set_rule instead of export/import. " +
                    "If the rule has NO Required Expression, the cloner wire format may have changed"
            }
            throw new IllegalStateException("appCloner export fired but ${reason} for cloner ${clonerAppId}")
        }

        def result = [
            success: true,
            sourceAppId: sourceAppId,
            sourceLabel: sourceLabel,
            clonerAppId: clonerAppId,
            contentLength: jsonContent.length(),
            jsonContent: jsonContent,
            note: "Exported source ${sourceAppId} via appCloner. Pass jsonContent to hub_import_native_app to re-create the rule."
        ]
        if (saveAs) {
            try {
                uploadHubFile(saveAs, jsonContent.getBytes("UTF-8"))
                result.savedAs = saveAs
                String hubIp = null
                try { hubIp = location?.hub?.localIP?.toString() } catch (Exception ignored) { /* fall through */ }
                if (hubIp) {
                    result.savedUrl = "http://${hubIp}/local/${saveAs}"
                } else {


                    mcpLog("warn", "rm-native", "hub_export_native_app: location.hub.localIP unavailable; savedUrl omitted from result")
                }
            } catch (Exception fileErr) {
                result.saveError = fileErr.message
                mcpLog("warn", "rm-native", "hub_export_native_app: saveAs '${saveAs}' upload failed: ${fileErr.message}")
            }
        }
        return result
    } finally {


        _appClonerCleanup(clonerAppId)
    }
}

private String _appClonerExtractJsonFromResponse(String responseBody) {
    if (!responseBody || !(responseBody instanceof String)) return null
    def parsed
    try { parsed = new groovy.json.JsonSlurper().parseText(responseBody) }
    catch (Exception e) {
        mcpLog("debug", "rm-native", "appCloner: response JSON parse failed: ${e.message}")
        return null
    }
    def sections = (parsed instanceof Map) ? parsed?.configPage?.sections : null
    if (!(sections instanceof List)) return null
    for (section in sections) {


        for (key in ["input", "inputs", "body"]) {
            def items = section?."${key}"
            if (!(items instanceof List)) continue
            for (item in items) {
                def fc = (item instanceof Map) ? item.filecontent : null
                if (fc instanceof String && fc.contains("appReplacements") && fc.startsWith("{")) {








                    return fc.replace('\\\\"', '\\"')
                }
            }
        }
    }
    return null
}

def toolImportNativeApp(args) {
    requireDestructiveConfirm(args?.confirm as Boolean)
    if (args?.parentHintAppId == null) {
        throw new IllegalArgumentException("parentHintAppId is required (any existing rule's id under the target parent — used to seed the cloner)")
    }
    def parentHintAppId = normalizeRuleId(args.parentHintAppId)
    def newName = args?.newName?.toString()?.trim()

    String jsonContent = args?.jsonContent?.toString()
    if (!jsonContent && args?.fromFile) {
        try {
            def bytes = downloadHubFile(args.fromFile.toString())
            jsonContent = new String(bytes, "UTF-8")
        } catch (Exception e) {
            throw new IllegalArgumentException("Cannot read fromFile '${args.fromFile}': ${e.message}")
        }
    }
    if (!jsonContent) {
        throw new IllegalArgumentException("jsonContent or fromFile is required")
    }



    def parsed
    try { parsed = new groovy.json.JsonSlurper().parseText(jsonContent) }
    catch (Exception e) { throw new IllegalArgumentException("jsonContent is not valid JSON: ${e.message}") }
    def appReplacements = (parsed instanceof Map) ? parsed.appReplacements : null
    if (!(appReplacements instanceof Map) || appReplacements.isEmpty()) {
        throw new IllegalArgumentException("jsonContent does not contain an appReplacements map — not an appCloner export")
    }
    Integer originalSourceId = null
    try {
        originalSourceId = ((appReplacements.keySet() as List)[0]).toString() as Integer
    } catch (Exception e) {
        throw new IllegalArgumentException("Could not extract original source id from appReplacements: ${e.message}")
    }
    def originalLabel = appReplacements.get(originalSourceId.toString())?.appLabel?.toString()


    def parentHintCfg
    try {
        parentHintCfg = _rmFetchConfigJson(parentHintAppId)
    } catch (Exception hintErr) {
        mcpLog("warn", "rm-native", "hub_import_native_app: parentHintAppId ${parentHintAppId} fetch failed: ${hintErr.message}")
        parentHintCfg = null
    }
    if (!parentHintCfg?.app) {
        throw new IllegalArgumentException("parentHintAppId ${parentHintAppId} not found or unreadable")
    }
    Integer parentAppId = null
    try {
        parentAppId = (parentHintCfg.app.parentAppId != null) ? (parentHintCfg.app.parentAppId.toString() as Integer) : null
    } catch (NumberFormatException nfe) {
        mcpLog("warn", "rm-native", "hub_import_native_app: parentHintAppId ${parentHintAppId} parentAppId not numeric: ${parentHintCfg.app.parentAppId}; new-child discovery will be skipped")
    }
    if (parentAppId == null) {


        throw new IllegalArgumentException("parentHintAppId ${parentHintAppId} has no numeric parentAppId — pass a hint that's a child of the target parent app (e.g. an existing RM rule for an RM import).")
    }
    Map snapshot = _appClonerSnapshotChildren(parentAppId)
    if (snapshot.isError == true) return snapshot
    def preIds = snapshot.ids as Set

    def initRes = _appClonerInit(parentHintAppId)
    Integer clonerAppId = initRes.clonerAppId
    try {






        String referrer = initRes.configUrl
        String configUrl = initRes.configUrl






        _appClonerSubmitForm(clonerAppId, "main", "source", referrer, configUrl, [
            ("settings[ruleUpload]".toString()): jsonContent
        ])


        pauseExecution(2000)


        _appClonerCommitImportRule(clonerAppId, originalSourceId, newName, referrer, configUrl)

        Integer newAppId = _appClonerDiscoverNewChild(parentAppId, preIds, originalLabel, newName)

        String note = newAppId
            ? "Imported '${originalLabel ?: 'app'}' as new app ${newAppId}${newName ? " (renamed to '${newName}')" : ""}. Use hub_set_native_app (or hub_set_rule for RM rules) to further customize."
            : "Import fired but no new child appeared under parent ${parentAppId}. Re-check via hub_list_apps (scope='instances') shortly."
        def result = [
            success: newAppId != null,
            clonerAppId: clonerAppId,
            newAppId: newAppId,
            originalSourceId: originalSourceId,
            originalLabel: originalLabel,
            contentLength: jsonContent.length(),
            note: note
        ]
        if (newAppId == null) {


            result.isError = true
            result.error = note
        }
        if (args?.stageDisabled == true && newAppId != null) {
            _appClonerApplyStageDisabled(result, newAppId, args?.__reqT0 as Long)
        } else if (args?.stageDisabled == true) {
            _appClonerStagingDiscoveryMiss(result, "import")
        }
        return result
    } finally {



        _appClonerCleanup(clonerAppId)
    }
}

private Map _appClonerStagePlan(Integer newAppId) {




    List failures = []
    List targets = []




    try {
        def responseText = hubInternalGet("/hub2/appsList")
        def parsed = new groovy.json.JsonSlurper().parseText(responseText)
        Map root = null
        def findNode
        findNode = { List nodes ->
            for (def n : (nodes ?: [])) {
                if (n?.data?.id?.toString() == newAppId.toString()) { root = n; return }
                findNode(n?.children as List)
                if (root != null) return
            }
        }
        findNode(parsed?.apps as List)
        if (root == null) throw new IllegalStateException("app ${newAppId} not present in /hub2/appsList")
        Set visited = [] as Set
        def collect
        collect = { Map node ->
            def nid = node?.data?.id?.toString()
            if (!nid?.isInteger() || visited.contains(nid)) return
            visited << nid
            targets << nid.toInteger()
            (node?.children as List ?: []).each { c -> if (c instanceof Map) collect(c) }
        }
        collect(root)
    } catch (Exception treeErr) {

        mcpLog("warn", "rm-native", "stageDisabled: /hub2/appsList enumeration failed (${treeErr.message}) -- falling back to per-node configure/json BFS")
        targets = []
        Set visited = [] as Set
        List queue = [newAppId]
        while (queue) {
            Integer tid = queue.remove(0)
            if (visited.contains(tid)) continue
            visited << tid
            targets << tid
            try {
                def cfg = _rmFetchConfigJson(tid)
                ((cfg?.childApps ?: []) as List).each { c ->
                    def cid = c?.id?.toString()
                    if (cid?.isInteger()) queue << cid.toInteger()
                }
            } catch (Exception childErr) {
                failures << [appId: tid, kind: "childEnumeration", error: "child enumeration failed for app ${tid}: ${childErr.message} -- its DESCENDANTS (if any) were not discovered and were NOT disabled; app ${tid} itself is still attempted below"]
            }
        }
    }
    return [targets: targets.unique(), failures: failures]
}

private Map _appClonerDisableTargets(List targets, Long reqT0, List staged, List failures) {


    List stageRemaining = []
    for (int i = 0; i < targets.size(); i++) {
        if (i > 0 && _timeBudgetExceeded(reqT0)) {
            stageRemaining = targets.subList(i, targets.size()).collect { it }
            break
        }
        def tid = targets[i]
        def dres
        try { dres = toolSetAppDisabled([appId: tid, disabled: true]) }
        catch (Exception dErr) { dres = [success: false, error: dErr.message ?: dErr.toString()] }
        if (dres?.success == true) staged << tid
        else failures << [appId: tid, kind: "disable", error: dres?.error ?: "disable read-back mismatch"]
    }
    return [staged: staged.unique(), failures: failures, remaining: stageRemaining]
}

private void _appClonerFinishStaging(Map result, Integer newAppId, Map outcome) {


    List staged = outcome.staged
    List failures = outcome.failures
    List stageRemaining = outcome.remaining
    result.stagedDisabled = staged
    if (failures || stageRemaining) {
        if (failures) result.stageFailures = failures
        if (stageRemaining) result.stageRemaining = stageRemaining
        result.partial = true
        result.success = false
        result.isError = true
        def newAppItselfFailed = failures.any { it.kind == "disable" && it.appId == newAppId }
        def remainderText = stageRemaining ? "Response budget ran out before ${stageRemaining.size()} app(s) were disabled (${stageRemaining.join(', ')}). " : ""
        result.error = "stageDisabled did NOT fully land: ${failures.size()} failure(s)${stageRemaining ? " + ${stageRemaining.size()} not yet attempted" : ""} -- see stageFailures/stageRemaining. ${newAppItselfFailed ? "The NEW APP ITSELF (${newAppId}) is still ENABLED and live. " : ""}${remainderText}The clone/import DID commit (newAppId=${newAppId}) -- do NOT re-issue this call (that would create a duplicate app); disable the listed apps via hub_set_app_disabled(appId=<id>, disabled=true) instead."
        result.note = "${result.note} STAGING ${stageRemaining ? 'INCOMPLETE' : 'FAILED'} -- see error/stageFailures."
    } else {
        result.note = "${result.note} Staged inactive: ${staged.size()} app(s) disabled (the new app${staged.size() > 1 ? ' + descendants' : ''}); re-enable with hub_set_app_disabled(disabled=false)."
    }
}

private void _appClonerApplyStageDisabled(Map result, Integer newAppId, Long reqT0 = null) {
    Map plan = _appClonerStagePlan(newAppId)
    Map outcome = _appClonerDisableTargets(plan.targets as List, reqT0, [], plan.failures as List)
    _appClonerFinishStaging(result, newAppId, outcome)
}

private void _appClonerStagingDiscoveryMiss(Map result, String operationLabel) {
    result.stagedDisabled = []
    result.success = false
    result.isError = true
    result.error = "${result.error ?: ''} stageDisabled was requested but could NOT run: no newAppId was discovered. If the ${operationLabel} did land, it is ENABLED and live -- find it via hub_list_apps (scope='instances') and disable it with hub_set_app_disabled. Do NOT re-issue creation: it may already have committed.".toString().trim()
}

private Map _appClonerCappedStaging(Map cp) {


    Map result = (cp.baseResult instanceof Map) ? ([:] + cp.baseResult) : [:]
    _appClonerFinishStaging(result, cp.newAppId as Integer, [
        staged: (cp.stagedDisabled ?: []) as List,
        failures: (cp.stageFailures ?: []) as List,
        remaining: (cp.stageTargets ?: []) as List
    ])
    return result
}

private Map _rmReadBackupSnapshot(Map entry) {
    def fileName = entry.fileName
    def jsonBytes
    try {
        jsonBytes = downloadHubFile(fileName)
    } catch (Exception e) {
        throw new IllegalArgumentException("Cannot read RM backup file '${fileName}': ${e.message}")
    }
    def snapshot
    try {
        snapshot = new groovy.json.JsonSlurper().parseText(new String(jsonBytes, "UTF-8"))
    } catch (Exception e) {
        throw new IllegalArgumentException("Cannot parse RM backup file '${fileName}': ${e.message}")
    }
    if (snapshot?.schemaVersion != 1) {
        throw new IllegalArgumentException("Unsupported RM backup schemaVersion: ${snapshot?.schemaVersion} (expected 1)")
    }

    return snapshot as Map
}

private Map _rmRestoreFromBackup(Map entry, Map preparedSnapshot = null) {
    def fileName = entry.fileName
    Map snapshot = preparedSnapshot != null ? preparedSnapshot : _rmReadBackupSnapshot(entry)
    def savedId = snapshot.ruleId as Integer
    def savedSettings = (snapshot?.configJson?.settings ?: [:]) as Map
    def savedLabel = snapshot?.appLabel





    def savedAppType = snapshot?.appType ?: "rule_machine"
    if (savedAppType == "visual_rule") {




        return _vrbRestoreFromSnapshot(snapshot, fileName?.toString())
    }

    def exists = true
    try {
        _rmFetchConfigJson(savedId)
    } catch (Exception e) {
        def liveApps = _collectLiveApps()
        if (liveApps == null || liveApps.containsKey(savedId)) {
            String detail = liveApps == null ? "the app inventory could not confirm its absence" : "it is still present in the app inventory"
            mcpLog("warn", "rm-native", "Restore target ${savedId} could not be inspected (${e.message}); ${detail}")
            return [success: false, type: "rm-rule", ruleId: savedId, originalRuleId: savedId,
                    error: "Cannot restore rule ${savedId}: its configuration could not be read and ${detail}.",
                    note: "No replacement was created and no settings were changed. Inspect hub_list_apps and hub_get_app_config(appId=${savedId}), then retry when the rule is readable or its deletion is confirmed."]
        }
        exists = false
    }
    def reg = _appTypeRegistry()[savedAppType]
    if (!reg) {
        throw new IllegalArgumentException("Backup references unknown appType '${savedAppType}'. Supported: ${_appTypeRegistry().keySet().join(', ')}")
    }

    def ruleId
    if (exists) {
        ruleId = savedId


        _rmRejectDisabledAppEdit(ruleId, "restore")
    } else {
        def parentId = _discoverParentAppId(savedAppType)
        ruleId = _rmCreateChildApp(parentId, reg.namespace, reg.appName)
        try {
            def firstPage = _rmFetchConfigJson(ruleId)
            def firstSchema = _rmCollectInputSchema(firstPage?.configPage)
            def seedBody = _rmBuildSettingsBody(ruleId, [origLabel: savedLabel ?: "restored-app-${savedId}"], firstSchema)
            hubInternalPostForm("/installedapp/update/json", seedBody)
            _rmClickAppButton(ruleId, "updateRule")
        } catch (Exception e) {
            try { _rmForceDeleteApp(ruleId) } catch (Exception ce) {
                mcpLog("warn", "rm-native", "_rmRestoreFromBackup: orphan cleanup of newly-created app ${ruleId} failed after recreate error (${ce.message}) -- app may be left in an empty-label state; clean up manually via hub_delete_native_app(appId=${ruleId})")
            }
            throw new IllegalArgumentException("Restore failed during app recreate (appType=${savedAppType}): ${e.message}")
        }
    }










    def savedSchema = _rmCollectInputSchema(snapshot?.configJson?.configPage) ?: [:]
    snapshot?.statusJson?.appSettings?.each { s ->
        def n = s?.name?.toString()
        if (n && !savedSchema.containsKey(n)) {
            savedSchema.put(n, [
                name: n,
                type: s?.type?.toString(),
                multiple: s?.multiple == true
            ])
        }
    }









    def replaySettings = savedSettings.findAll { k, v -> savedSchema.get(k.toString())?.type != "button" }
    def skippedButtons = (savedSettings.keySet() - replaySettings.keySet()).collect { it.toString() }.sort()







    def liveDeviceIds = [:]
    snapshot?.statusJson?.appSettings?.each { st ->
        def n = st?.name?.toString()
        if (n && st?.deviceIdsForDeviceList instanceof List && st.deviceIdsForDeviceList) liveDeviceIds.put(n, st.deviceIdsForDeviceList)
    }
    def skippedMaps = []
    replaySettings = replaySettings.collectEntries { k, v ->
        String key = k.toString()
        boolean isPicker = savedSchema.get(key)?.type?.toString()?.startsWith("capability.") == true
        if (!isPicker) {


            if (v instanceof Map) { skippedMaps << key; return [:] }
            return [(key): v]
        }
        def ids = liveDeviceIds.containsKey(key) ? liveDeviceIds.get(key) : ((v instanceof Map) ? v.keySet().toList() : v)
        return [(key): (ids instanceof List ? ids.collect { it?.toString() } : ids)]
    }
    String step = "settings replay"
    try {
        _rmUpdateAppSettings(ruleId, replaySettings, savedSchema)
        step = "the final updateRule click"
        _rmClickAppButton(ruleId, "updateRule")
    } catch (Exception e) {
        mcpLog("error", "rm-native", "restore of rule ${ruleId} from ${fileName} failed during ${step}: ${e.message}")
        return [
            success: false,
            type: "rm-rule",
            ruleId: ruleId,
            originalRuleId: savedId,
            failedStep: step,
            error: "Restore applied partially; failed during ${step}: ${e.message}",
            note: (step == "settings replay"
                ? "Rule ${ruleId} exists but may have incomplete settings. Inspect with hub_get_app_config(appId=${ruleId}) and compare against hub_get_backup(backupKey) before retrying."
                : "The settings were replayed but the rule's updateRule did not fire, so its subscriptions may still reflect the pre-restore state. Open the rule and click Update Rule, or call hub_set_rule(appId=${ruleId}, button='updateRule').")
        ]
    }




    def out = [
        success: true,
        type: "rm-rule",
        ruleId: ruleId,
        originalRuleId: savedId,
        recreated: !exists,
        backupFile: fileName,
        settingsApplied: replaySettings.keySet().toList(),
        settingsSkipped: skippedButtons.collect { key -> [key: key, reason: "button input excluded from replay"] }
            + skippedMaps.collect { key -> [key: key, reason: "map value without a device-picker schema; not replayable through the settings endpoint"] },
        note: exists ? "Settings restored in place." : "Rule was deleted; recreated with new id ${ruleId} and replayed settings."
    ]
    if (skippedMaps) {
        out.partial = true
        out.note = "${out.note} ${skippedMaps.size()} saved setting(s) could NOT be replayed (see settingsSkipped): ${skippedMaps.join(', ')}. Inspect with hub_get_app_config(appId=${ruleId}) and set them by hand if the rule needs them.".toString()
    }
    return out
}

def _getAllToolDefinitions_partAppCloner() {
    return [
        [
            name: "hub_clone_native_app",
            description: """Clone any classic native automation app (RM rule, Room Lighting, Button Controller, Basic Rule, Notifier, etc.) using Hubitat's first-party appCloner, then surgically edit fields via hub_set_rule (RM rules) or hub_set_native_app (other classic apps).[[FLAT_TRIM]] A lower-overhead alternative to rebuilding via the wizard: clone an existing rule that has the shape you want. Preserves the full rule shape (conditions, expressions, IF/THEN/ELSE structure). The clone completes in tens of seconds for typical rules.[[/FLAT_TRIM]] Returns newAppId on success. Requires the Write master + confirm=true (+ a recent backup).""",
            inputSchema: [
                type: "object",
                properties: [
                    sourceAppId: [type: "integer", description: "Installed-app ID of the rule/app to clone. (alias: appId) Either sourceAppId or appId is required."],
                    appId: [type: "integer", description: "Alias for sourceAppId."],
                    newName: [type: "string", description: "Label for the new cloned app.[[FLAT_TRIM]] If omitted, the cloner default ('<source-label> clone') is kept.[[/FLAT_TRIM]]"],
                    stageDisabled: [type: "boolean", description: "true = disable the new app AND every DESCENDANT under it right after the clone. Staged-migration safety: a clone of an ACTIVE rule lands ACTIVE, and a cloned Button Controller's child Button Rules react to live button events. Re-enable via hub_set_app_disabled(disabled=false)."],
                    confirm: [type: "boolean", description: "Must be true."]
                ],



                required: ["confirm"]
            ]
        ],
        [
            name: "hub_export_native_app",
            description: """Export any classic native automation app to its canonical JSON shape via Hubitat's first-party appCloner — a self-contained document that round-trips cleanly through hub_import_native_app.[[FLAT_TRIM]] The exported JSON is the same format Hubitat's UI 'Export' button produces. Use for: (1) backup before risky edits, (2) edit-as-text workflows that materialize the rule, mutate the JSON, and re-import as a new rule, (3) hub-to-hub transfer.[[/FLAT_TRIM]] Pass saveAs to also write the JSON to the hub's File Manager[[FLAT_TRIM]] (e.g. for HPM-style distribution)[[/FLAT_TRIM]]. Requires the Write master (no confirm/backup required).[[FLAT_TRIM]] Export instantiates a cloner app and persists, so it counts as a write.[[/FLAT_TRIM]]""",
            inputSchema: [
                type: "object",
                properties: [
                    sourceAppId: [type: "integer", description: "Installed-app ID of the rule/app to export. (alias: appId)"],
                    appId: [type: "integer", description: "Alias for sourceAppId."],
                    saveAs: [type: "string", description: "Optional File Manager filename (.json or .txt). When provided, the export is also written to /local/<saveAs>."],
                ]
            ]
        ],
        [
            name: "hub_import_native_app",
            description: """Create a new rule/app from a previously-exported JSON via Hubitat's first-party appCloner.[[FLAT_TRIM]] Pair with hub_export_native_app for round-trip edits or backup/restore workflows.[[/FLAT_TRIM]] Pass jsonContent (the exported JSON string) OR fromFile (a File Manager filename written by hub_export_native_app). Pass parentHintAppId — any existing rule id under the target parent the imported rule should land under[[FLAT_TRIM]] (e.g. another RM rule for an RM import); the cloner needs it to seed itself[[/FLAT_TRIM]]. Requires the Write master + confirm=true (+ a recent backup).""",
            inputSchema: [
                type: "object",
                properties: [
                    jsonContent: [type: "string", description: "The exported JSON content. Either jsonContent or fromFile is required."],
                    fromFile: [type: "string", description: "File Manager filename to read the JSON from."],
                    parentHintAppId: [type: "integer", description: "Any existing rule's id under the target parent app.[[FLAT_TRIM]] Used purely to seed the cloner instance — has no semantic effect on the imported rule beyond placing it under the same parent.[[/FLAT_TRIM]]"],
                    newName: [type: "string", description: "Label for the imported app.[[FLAT_TRIM]] If omitted, the cloner default ('<original-label> import') is kept.[[/FLAT_TRIM]]"],
                    stageDisabled: [type: "boolean", description: "true = disable the new app AND every DESCENDANT under it right after the import (staged-migration safety: an import lands ACTIVE). Re-enable via hub_set_app_disabled(disabled=false)."],
                    confirm: [type: "boolean", description: "Must be true."]
                ],








                required: ["parentHintAppId", "confirm"]
            ]
        ],
    ]
}

def _idempotentWriteToolNames_partAppCloner() {


    return [

        "hub_export_native_app"
    ]
}

def _toolDisplayMeta_partAppCloner() {


    return [
        hub_clone_native_app: [title: "Clone Native App", summary: "Clone an existing classic app."],
        hub_export_native_app: [title: "Export Native App", summary: "Export a classic app to JSON, optionally saving it to the File Manager."],
        hub_import_native_app: [title: "Import Native App", summary: "Import previously exported app JSON as a new instance."]
    ]
}

private Map _mrtrCloneNativeAppSlice(Map rec, Map outerArgs) {
    Map args = _mrtrLeafArguments(rec.outerTool?.toString(), rec.leafTool?.toString(), outerArgs) as Map



    Map cp = (rec.checkpoint instanceof Map) ? _mrtrCopyMap(rec.checkpoint as Map) : null
    if (cp == null) {
        requireDestructiveConfirm(args?.confirm as Boolean)
        def rawSource = (args?.sourceAppId != null) ? args.sourceAppId : args?.appId
        if (rawSource == null) throw new IllegalArgumentException("sourceAppId (or appId) is required")
        Integer sourceAppId = normalizeRuleId(rawSource)
        String newName = args?.newName?.toString()?.trim()
        def sourceCfg
        try { sourceCfg = _rmFetchConfigJson(sourceAppId) }
        catch (Exception sourceErr) {
            mcpLog("warn", "rm-native", "hub_clone_native_app: source ${sourceAppId} config fetch failed: ${sourceErr.message}")
            sourceCfg = null
        }
        if (!sourceCfg?.app) throw new IllegalArgumentException("Source app ${sourceAppId} not found or unreadable")
        String sourceLabel = sourceCfg.app.label?.toString()
        Integer parentAppId = null
        try {
            parentAppId = sourceCfg.app.parentAppId != null ? sourceCfg.app.parentAppId.toString() as Integer : null
        } catch (NumberFormatException ignored) {
            mcpLog("warn", "rm-native", "hub_clone_native_app: source ${sourceAppId} parentAppId not numeric: ${sourceCfg.app.parentAppId}")
        }
        if (parentAppId == null) {
            throw new IllegalArgumentException("Source app ${sourceAppId} has no numeric parentAppId. MCP cannot safely discover its clone; pass a child of the target parent app.")
        }
        Map snapshot = _appClonerSnapshotChildren(parentAppId)
        if (snapshot.isError == true) return snapshot
        def preIds = snapshot.ids
        def initRes = _appClonerInit(sourceAppId)
        cp = [phase: "clone_clicks", clonerAppId: initRes.clonerAppId,
              referrer: initRes.referrer, configUrl: initRes.configUrl,
              sourceAppId: sourceAppId, sourceLabel: sourceLabel,
              parentAppId: parentAppId, preIds: preIds, newName: newName,
              stageDisabled: args?.stageDisabled == true]
        return _mrtrControl("clone_native_app", cp)
    }

    Integer clonerAppId = cp.clonerAppId as Integer
    try {
        if (cp.phase == "clone_clicks") {
            _appClonerClickClone(clonerAppId, cp.referrer?.toString(), cp.configUrl?.toString())
            cp.phase = "clone_commit"
            return _mrtrControl("clone_native_app", cp)
        }
        if (cp.phase == "clone_commit") {
            _appClonerCommitImportRule(clonerAppId, cp.sourceAppId as Integer,
                cp.newName?.toString(), cp.referrer?.toString(), cp.configUrl?.toString())
            Integer newAppId = _appClonerDiscoverNewChild(cp.parentAppId as Integer,
                (cp.preIds ?: []) as Set, cp.sourceLabel?.toString(), cp.newName?.toString())
            String note = newAppId
                ? "Cloned source ${cp.sourceAppId} -> new app ${newAppId}${cp.newName ? " (renamed to '${cp.newName}')" : ""}. Use hub_set_native_app (or hub_set_rule for RM rules) to further customize."
                : "Clone fired but no new child appeared under parent ${cp.parentAppId}. Re-check via hub_list_apps (scope='instances') shortly."
            def baseResult = [success: newAppId != null, sourceAppId: cp.sourceAppId,
                              clonerAppId: clonerAppId, newAppId: newAppId, note: note]
            if (newAppId == null) {
                baseResult.isError = true
                baseResult.error = note
                if (cp.stageDisabled == true) _appClonerStagingDiscoveryMiss(baseResult, "clone")
                _appClonerCleanup(clonerAppId)
                return baseResult
            }
            if (cp.stageDisabled != true) {
                _appClonerCleanup(clonerAppId)
                return baseResult
            }
            def stagePlan = _appClonerStagePlan(newAppId)
            cp.phase = "stage_disable"
            cp.newAppId = newAppId
            cp.stageTargets = stagePlan.targets
            cp.stageFailures = stagePlan.failures
            cp.stagedDisabled = []
            cp.baseResult = baseResult
            return _mrtrControl("clone_native_app", cp)
        }
        if (cp.phase == "stage_disable") return _mrtrAppClonerStageSlice(cp, "clone")
        throw new IllegalStateException("Unknown clone continuation phase '${cp.phase}'")
    } catch (Exception e) {
        try { _appClonerCleanup(clonerAppId) } catch (Exception ignored) { }
        throw e
    }
}

private Map _mrtrImportNativeAppSlice(Map rec, Map outerArgs) {
    Map args = _mrtrLeafArguments(rec.outerTool?.toString(), rec.leafTool?.toString(), outerArgs) as Map



    Map cp = (rec.checkpoint instanceof Map) ? _mrtrCopyMap(rec.checkpoint as Map) : null
    if (cp == null) {
        requireDestructiveConfirm(args?.confirm as Boolean)
        if (args?.parentHintAppId == null) {
            throw new IllegalArgumentException("parentHintAppId is required (any existing rule's id under the target parent — used to seed the cloner)")
        }
        Integer parentHintAppId = normalizeRuleId(args.parentHintAppId)
        String newName = args?.newName?.toString()?.trim()
        String jsonContent = args?.jsonContent?.toString()
        if (!jsonContent && args?.fromFile) {
            try { jsonContent = new String(downloadHubFile(args.fromFile.toString()), "UTF-8") }
            catch (Exception e) { throw new IllegalArgumentException("Cannot read fromFile '${args.fromFile}': ${e.message}") }
        }
        if (!jsonContent) throw new IllegalArgumentException("jsonContent or fromFile is required")
        def parsed
        try { parsed = new groovy.json.JsonSlurper().parseText(jsonContent) }
        catch (Exception e) { throw new IllegalArgumentException("jsonContent is not valid JSON: ${e.message}") }
        def replacements = (parsed instanceof Map) ? parsed.appReplacements : null
        if (!(replacements instanceof Map) || replacements.isEmpty()) {
            throw new IllegalArgumentException("jsonContent does not contain an appReplacements map — not an appCloner export")
        }
        Integer originalSourceId
        try { originalSourceId = ((replacements.keySet() as List)[0]).toString() as Integer }
        catch (Exception e) { throw new IllegalArgumentException("Could not extract original source id from appReplacements: ${e.message}") }
        String originalLabel = replacements.get(originalSourceId.toString())?.appLabel?.toString()
        def hintCfg
        try { hintCfg = _rmFetchConfigJson(parentHintAppId) }
        catch (Exception hintErr) {
            mcpLog("warn", "rm-native", "hub_import_native_app: parentHintAppId ${parentHintAppId} config fetch failed: ${hintErr.message}")
            hintCfg = null
        }
        if (!hintCfg?.app) throw new IllegalArgumentException("parentHintAppId ${parentHintAppId} not found or unreadable")
        Integer parentAppId = null
        try { parentAppId = hintCfg.app.parentAppId?.toString() as Integer }
        catch (NumberFormatException ignored) {
            mcpLog("warn", "rm-native", "hub_import_native_app: parentHintAppId ${parentHintAppId} parentAppId not numeric: ${hintCfg.app.parentAppId}")
        }
        if (parentAppId == null) {
            throw new IllegalArgumentException("parentHintAppId ${parentHintAppId} has no numeric parentAppId — pass a child of the target parent app")
        }
        Map snapshot = _appClonerSnapshotChildren(parentAppId)
        if (snapshot.isError == true) return snapshot
        def preIds = snapshot.ids
        def initRes = _appClonerInit(parentHintAppId)
        Integer clonerAppId = initRes.clonerAppId as Integer
        try {
            String configUrl = initRes.configUrl?.toString()
            _appClonerSubmitForm(clonerAppId, "main", "source", configUrl, configUrl,
                [("settings[ruleUpload]".toString()): jsonContent])
            pauseExecution(2000)
            cp = [phase: "import_commit", clonerAppId: clonerAppId,
                  referrer: configUrl, configUrl: configUrl,
                  parentAppId: parentAppId, preIds: preIds,
                  originalSourceId: originalSourceId, originalLabel: originalLabel,
                  contentLength: jsonContent.length(), newName: newName,
                  stageDisabled: args?.stageDisabled == true]
            return _mrtrControl("import_native_app", cp)
        } catch (Exception e) {
            try { _appClonerCleanup(clonerAppId) } catch (Exception ignored) { }
            throw e
        }
    }

    Integer clonerAppId = cp.clonerAppId as Integer
    try {
        if (cp.phase == "import_commit") {
            _appClonerCommitImportRule(clonerAppId, cp.originalSourceId as Integer,
                cp.newName?.toString(), cp.referrer?.toString(), cp.configUrl?.toString())
            Integer newAppId = _appClonerDiscoverNewChild(cp.parentAppId as Integer,
                (cp.preIds ?: []) as Set, cp.originalLabel?.toString(), cp.newName?.toString())
            String note = newAppId
                ? "Imported '${cp.originalLabel ?: 'app'}' as new app ${newAppId}${cp.newName ? " (renamed to '${cp.newName}')" : ""}. Use hub_set_native_app (or hub_set_rule for RM rules) to further customize."
                : "Import fired but no new child appeared under parent ${cp.parentAppId}. Re-check via hub_list_apps (scope='instances') shortly."
            def baseResult = [success: newAppId != null, clonerAppId: clonerAppId,
                              newAppId: newAppId, originalSourceId: cp.originalSourceId,
                              originalLabel: cp.originalLabel, contentLength: cp.contentLength,
                              note: note]
            if (newAppId == null) {
                baseResult.isError = true
                baseResult.error = note
                if (cp.stageDisabled == true) _appClonerStagingDiscoveryMiss(baseResult, "import")
                _appClonerCleanup(clonerAppId)
                return baseResult
            }
            if (cp.stageDisabled != true) {
                _appClonerCleanup(clonerAppId)
                return baseResult
            }
            def stagePlan = _appClonerStagePlan(newAppId)
            cp.phase = "stage_disable"
            cp.newAppId = newAppId
            cp.stageTargets = stagePlan.targets
            cp.stageFailures = stagePlan.failures
            cp.stagedDisabled = []
            cp.baseResult = baseResult
            return _mrtrControl("import_native_app", cp)
        }
        if (cp.phase == "stage_disable") return _mrtrAppClonerStageSlice(cp, "import")
        throw new IllegalStateException("Unknown import continuation phase '${cp.phase}'")
    } catch (Exception e) {
        try { _appClonerCleanup(clonerAppId) } catch (Exception ignored) { }
        throw e
    }
}

private Map _mrtrAppClonerStageSlice(Map cp, String operationLabel) {
    List targets = (cp.stageTargets instanceof List) ? cp.stageTargets as List : []
    List staged = (cp.stagedDisabled instanceof List) ? cp.stagedDisabled as List : []
    List failures = (cp.stageFailures instanceof List) ? cp.stageFailures as List : []
    Map outcome = _appClonerDisableTargets(targets, now(), staged, failures)
    List remaining = outcome.remaining
    if (remaining) {
        cp.stageTargets = remaining
        cp.stagedDisabled = staged
        cp.stageFailures = failures
        return _mrtrControl("${operationLabel}_native_app".toString(), cp)
    }
    def result = (cp.baseResult instanceof Map) ? ([:] + cp.baseResult) : [:]
    _appClonerFinishStaging(result, cp.newAppId as Integer, outcome)
    _appClonerCleanup(cp.clonerAppId as Integer)
    return result
}
