library(name: "McpDashboardsLib", namespace: "mcp", author: "kingpanther13", description: "Easy Dashboard CRUD tool implementations for the MCP Rule Server (hub_list_dashboards/hub_get_dashboard/hub_create_dashboard/hub_update_dashboard/hub_delete_dashboard/hub_clone_dashboard) -- issue #259 item #9. Easy Dashboards are classic child apps of the Easy Dashboard Parent, driven by GET /dashboard/* endpoints. #include'd by the main app; gateway entries and dispatch cases stay in the app; tool definitions, implementations, domain helpers, and per-tool metadata live here.")

// TEMP bisect (issue #259): this library is stripped to a smoke test. The six tool impls are
// one-line stubs and the defs/schemas are minimal, so we can learn whether a MINIMAL dashboards
// library binds at runtime on the hub at all (the full lib's methods fail to link with
// MissingMethodException while every other library binds). The real impl + schemas + domain
// helpers are preserved in git history (41beaa2); restore them once the binding cause is found.

def toolListDashboards(args = null) { return [success: true, stub: "dashboards-smoke-test"] }

def toolGetDashboard(args) { return [success: true, stub: "dashboards-smoke-test"] }

def toolCreateDashboard(args) { return [success: true, stub: "dashboards-smoke-test"] }

def toolUpdateDashboard(args) { return [success: true, stub: "dashboards-smoke-test"] }

def toolDeleteDashboard(args) {
    requireDestructiveConfirm(args?.confirm)
    return [success: true, stub: "dashboards-smoke-test"]
}

def toolCloneDashboard(args) { return [success: true, stub: "dashboards-smoke-test"] }

// Tool DEFINITIONS (minimized for the bisect): keep the SAME 6 tool names so the gateway config
// and the executeTool dispatch cases in the main app still match; each def is a one-line
// description plus an empty inputSchema. Concatenated into getAllToolDefinitions() in the app.
def _getAllToolDefinitions_partDashboards() {
    def emptySchema = [type: "object", properties: [:]]
    // Minimal but non-empty outputSchema -- the catalog-wide convention guard
    // (McpToolAnnotationsSpec "every leaf tool ... declares a well-formed outputSchema")
    // requires every def to carry an object outputSchema with >=1 property.
    def stubOutput = [type: "object", properties: [success: [type: "boolean", description: "Smoke-test stub result"]]]
    return [
        [
            name: "hub_list_dashboards",
            description: "List the hub's Easy Dashboards (smoke-test stub).",
            inputSchema: emptySchema,
            outputSchema: stubOutput
        ],
        [
            name: "hub_get_dashboard",
            description: "Get one Easy Dashboard by id (smoke-test stub).",
            inputSchema: emptySchema,
            outputSchema: stubOutput
        ],
        [
            name: "hub_create_dashboard",
            description: "Create an Easy Dashboard (smoke-test stub).",
            inputSchema: emptySchema,
            outputSchema: stubOutput
        ],
        [
            name: "hub_update_dashboard",
            description: "Update an Easy Dashboard (smoke-test stub).",
            inputSchema: emptySchema,
            outputSchema: stubOutput
        ],
        [
            name: "hub_delete_dashboard",
            description: "Delete an Easy Dashboard (smoke-test stub).",
            inputSchema: emptySchema,
            outputSchema: stubOutput
        ],
        [
            name: "hub_clone_dashboard",
            description: "Clone an Easy Dashboard (smoke-test stub).",
            inputSchema: emptySchema,
            outputSchema: stubOutput
        ]
    ]
}

def _readOnlyToolNames_partDashboards() {
    return [
        "hub_list_dashboards", "hub_get_dashboard"
    ]
}

def _idempotentWriteToolNames_partDashboards() {
    return [
        "hub_update_dashboard", "hub_delete_dashboard"
    ]
}

def _toolDisplayMeta_partDashboards() {
    return [
        hub_list_dashboards: [title: "List Dashboards", summary: "List Easy Dashboards with ids, names, and tile/theme config."],
        hub_get_dashboard: [title: "Get Dashboard", summary: "Get one Easy Dashboard's full config by id (list-then-filter)."],
        hub_create_dashboard: [title: "Create Dashboard", summary: "Create a new Easy Dashboard from devices and tile options."],
        hub_update_dashboard: [title: "Update Dashboard", summary: "Replace an Easy Dashboard's config wholesale (pass the full config)."],
        hub_delete_dashboard: [title: "Delete Dashboard", summary: "Permanently delete an Easy Dashboard by id."],
        hub_clone_dashboard: [title: "Clone Dashboard", summary: "Clone an existing Easy Dashboard into a new one."]
    ]
}
